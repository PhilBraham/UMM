# UMM Python — Handover Document
## April 2026 — Session 7

This document summarises everything needed to continue development in a new conversation.
Pass it verbatim to the next Claude session along with the project zip.

---

## Project overview

**UMM (Universal Message Manager)** — typed publish/subscribe middleware. Messages carry TLV-encoded data. The router dispatches based on mtype, subtype, and optional content-match criteria. Agents attach to the router, register subscriptions, and receive matching messages.

**Key concepts:**
- `mtype` — message type (domain). Negative mtypes are infrastructure channels. System mtypes 1–11. Application mtypes 100+
- `subtype` — command/event within the domain. Subtypes 1–99 reserved (1–3 system-wide standard). Application subtypes start at 100
- `TLV` — type(4) + match(4) + meta(4) + length(4) + value. Can nest
- `match` — in subscriptions: operator index (EQ=0, NE=1, GT=2, LT=3, GE=4, LE=5, CONTAINS=6, WILDCARD=7, SOUNDSLIKE=8, WITHIN=11, WITHIN_3D=12, BBOX=13). In published messages: free sub-qualifier, passed through by router
- `meta` — semantic qualifier for the base type (0=absent, always matches). Type-scoped: `meta=1` on Float=temperature, on Char=filename. See `umm/core/meta.py`
- `MatchOp` — comparison operators used in the match field of subscription TLVs
- `agent_mtype` — primary mtype an agent handles; declared in ATTACH, appears in discovery

**Project location:** `UMMProject/` (all paths relative to this)

---

## Current state — end of Session 7

The sorting machine demo runs end-to-end. The GUI console has Send, Timer, Agents, Capability, Types, and Debug tabs. All agents support GetCapability (subtype 1), GetVersion (subtype 2), SetDebug (subtype 3).

**To run:**
```bash
python3 umm_ctl.py start              # router, timer, typedir, gui, watchdog, string-match, coord-match
python3 umm_ctl.py start parser --flags   # parser in foreground with flag display
open http://localhost:8765            # GUI console
```

All modules must be run with `python3 -m` from the project root:
```bash
python3 -m umm.modules.parser --port 5100
python3 -m umm.modules.parser --interactive
```

---

## Session 7 changes

### 1. CONFIRM_APP — agent.py
- `send_confirmed()` now accepts `on_app_ack` callback; sets `MsgFlag.CONFIRM_APP`
- New `send_app_confirm(original_msg)` method — receiving agents call this to trigger the sender's `on_app_ack`

### 2. GUI polish — gui.html
- `_agentMap` (mtype→name) populated from agents list; debug log shows `AgentName(mtype)` instead of raw mtype
- Agents tab: inline `debug on/off` toggle per agent row
- Subscribe tab: quick-subscribe buttons for ch2 Confirm, ch3 Debug, ch4 Meta channels

### 3. External match plugin system — router.py, agent.py, umm/plugins/
**Plugin base** (`umm/plugins/_base.py`): `MatchPluginBase` — all connection, retry, JSON protocol, sub_add/sub_remove, match_req/match_resp, and positional AND-logic. Subclasses implement only `_decode_sub` and `_eval`.

**String plugin** (`umm/plugins/string_match.py`): handles Char (8) and FName (14). Operators: `=`, `!=`, `CI=`, `CI!=`, `*=`/`~=`, `*!=`, `contains`, `soundslike` (mwords 0–8).

**CoOrd plugin** (`umm/plugins/coord_match.py`): handles CoOrd (13). Operators: `=` (0), `!=` (1), `within` 2D circle (11), `within3d` sphere (12), `bbox` 2D bounding box (13). Subscription value encodes the geometry parameters as packed doubles.

**Router changes**: `CLookup.find_candidates_split()` separates sync vs plugin-pending entries. `_PendingPluginReq` stores inflight async match requests. Plugin server on port+1. `_svc_match_query` handles dry-run match queries. Plugin fallback: if plugin not connected, `registry.match()` used.

**MatchOp**: added `WITHIN_3D=12`, `BBOX=13`.

**ResequenceMixin** (`umm/mixins.py`): optional per-subscription reordering buffer for agents that need delivery order guarantees when plugins are involved. Enable with `agent.enable_resequencing(window=0.1)`.

### 4. MATCH_QUERY service — (1, 22) / (1, 23)
Send `(1, 22)` with `TLV_MSG(mtype(4) subtype(4) <payload>)` to ask which subscriptions would match. Router responds with `(1, 23)` Char(json) containing attach_id, reg_id, agent_name, agent_mtype per match. Plugin-pending subscriptions trigger a second response. Agent API: `agent.query_matches(mtype, subtype, tlvs, callback)`.

### 5. LIST_TYPES service — (1, 112) / (1, 113)
Send `(1, 112)` to get all registered TLV types. Response is `(1, 113)` Char(json) with type_id, name, base_type, description, unit, and match_ops (mword + symbol) for each type. GUI has a Types tab with "List types" button showing all 16 types.

### 6. Operational fixes
- `UMMAgent.run()` restored (was accidentally removed; `arun()` kept for async use)
- `umm_ctl.py`: config/pid/log paths now resolve relative to the script itself, not CWD; stale `logs/current` pointer validated against configured log_dir before reuse
- Parser: default port changed `5000→5100`; mtype=1 system messages suppressed in main log unless `--show-control` (prevents capability query flood on startup)
- Parser: `--flags` option shows non-zero message flags as `flags[RTR,RCV,APP]`
- Debug log dedup: `_seenMsgs` in GUI prevents same physical message appearing twice when it matches multiple subscriptions

### 7. UMMSubType additions
```
22   MATCH_QUERY          C→R  dry-run match — returns who would receive this
23   MATCH_RESULT         R→C  Char(json) list of matching subscriptions
112  LIST_TYPES           C→R  request all registered TLV types
113  LIST_TYPES_RESPONSE  R→C  Char(json) type list with match operators
```

---

## Architecture — external match plugins

See DESIGN_NOTES.md §11 for the full protocol. Key points:

**Plugin port**: router listens on agent_port+1 (default 5101). Run with `--plugin-port N` to override, `--plugin-port -1` to disable.

**Protocol** (newline-delimited JSON):
- Plugin→Router on connect: `{"msg":"register","type_ids":[8,14],"name":"StringMatch"}`
- Router→Plugin on sub: `{"msg":"sub_add","reg_id":7,"sub_tlvs":"<hex>"}`
- Router→Plugin on unsub: `{"msg":"sub_remove","reg_ids":[7,12]}`
- Router→Plugin on match: `{"msg":"match_req","req_id":42,"msg_tlvs":"<hex>","reg_ids":[7]}`
- Plugin→Router response: `{"msg":"match_resp","req_id":42,"results":[[7,true]]}`

**Writing a new plugin**: subclass `MatchPluginBase`, set `HANDLED_TYPE_IDS` and `NAME`, implement `_decode_sub(type_id, mword, value)→criteria` and `_eval(msg_value, mword, criteria)→bool`. See DESIGN_NOTES.md §11 "Writing a match plugin".

---

## Next — router bridge

`umm/modules/bridge.py` has a working skeleton (~400 lines). Current state:

**What works:**
- `RouterLink` class: connects to remote router, registers subscriptions, forwards messages to local router
- `BridgeModule`: connects two `RouterLink`s (A→B and B→A for symmetric mode)
- Static subscriptions (configured at startup) forwarded in both directions
- Dynamic subscriptions: clients send `(11, 101)` Bridge Subscribe request; bridge registers on remote and forwards
- `run()` connects both sides, registers control handlers, starts B in background thread

**What's missing / needs work:**
- **Origin stamping**: forwarded messages currently lose their original `origin` — the forwarded message looks like it came from the bridge agent, not the original sender. The `origin` field should be preserved or wrapped so the receiving side knows the true source
- **Loop prevention**: a message bridged A→B should not be bridged back B→A. Need a bridge-origin flag or mtype exclusion list
- **Reconnect handling**: `RouterLink` sets `reconnect=True` on the remote agent but doesn't re-register subscriptions after a reconnect
- **Heartbeat**: `ST_BRIDGE_HEARTBEAT=105` is defined but not implemented
- **Status response**: `_on_status_a` handler is a stub
- **umm.conf entry**: bridge is not in the default stack (correct — it needs explicit config with remote host/port)
- **CLI**: `_main()` exists with `--router-a`/`--router-b` args but needs `--static-sub` support for configuring forwarded mtypes from the command line

**Design decision needed**: the current model requires clients to explicitly request bridge subscriptions via `(11, 101)`. An alternative is *transparent bridging* where the bridge monitors all subscriptions on both routers and automatically forwards anything that has subscribers on the other side. Which model is intended?

---

## Quick reference — UMM system subtypes (mtype=1)

| Subtype | Name | Direction | Notes |
|---------|------|-----------|-------|
| 1 | Attach | C→R | |
| 2 | AttachConfirm | R→C | |
| 3 | Detach | C→R | |
| 4 | Register | C→R | |
| 5 | Unregister | C→R | |
| 7 | AgentAttached | R→* | lifecycle |
| 8 | AgentDetached | R→* | lifecycle |
| 10 | CapabilityQuery | C→* | |
| 11 | CapabilityResponse | *→C | |
| 20 | StatusRequest | C→R | |
| 21 | StatusResponse | R→C | |
| 22 | MatchQuery | C→R | dry-run match |
| 23 | MatchResult | R→C | |
| 110 | ListAgents | C→R | |
| 111 | ListAgentsResponse | R→C | |
| 112 | ListTypes | C→R | |
| 113 | ListTypesResponse | R→C | |

## Quick reference — negative mtype channels

| mtype | Name | Subtype | Purpose |
|-------|------|---------|---------|
| -1 | Confirm | 1 | Error response |
| -1 | Confirm | 2–4 | Router/receiver/app acks |
| -2 | Debug | 1 | Agent debug output |
| -3 | Meta | 1 | Capability response |
| -3 | Meta | 2 | Version response |

## Quick reference — system mtypes

| mtype | Service | Key subtypes |
|-------|---------|-------------|
| 1 | UMM system | see table above |
| 2 | Timer | 101 Request, 102 Cancel, 103 Confirmed, 104 Error |
| 5 | FSM | 101–104 state control |
| 10 | TypeDir | 101–110 |
| 11 | Bridge | 101 Subscribe, 102 Unsubscribe, 103 Status, 104 StatusReply, 105 Heartbeat |

## Quick reference — TLV types

| ID | Name | Notes |
|----|------|-------|
| 1 | Raw | raw bytes |
| 2 | Int | signed 32-bit NBO |
| 3 | UInt | unsigned 32-bit NBO |
| 4 | Short | signed 16-bit NBO |
| 5 | UShort | unsigned 16-bit NBO |
| 6 | Float | IEEE-754 64-bit NBO |
| 7 | Bool | 1 byte |
| 8 | Char | UTF-8 string, null-terminated — **string plugin** |
| 10 | MDNum | metadata (field-ID based match) |
| 11 | Msg | nested message/subscription |
| 12 | AttId | attach ID (router+id) |
| 13 | CoOrd | 2D/3D coordinate — **coord plugin** |
| 14 | FName | filename string — **string plugin** |
| 15 | LogId | login credentials |
| 16 | MsgRef | message reference (router+attach+msg_id) |

## Quick reference — sorting demo mtypes

| mtype | Agent | Key subtypes |
|-------|-------|-------------|
| 1001 | Control | 101 Start, 102 EStop, 103 Restart, 104 BinCleared, 199 OperatorMessage |
| 1002 | Conveyor | 101 CmdC1, 102 CmdC2, 103-108 State/Pulse/Stall |
| 1003 | Photocell | 101-107 Detected, 111-112 Cleared |
| 1004 | Barcode | 101 Request, 102 Success, 103 Failed |
| 1005 | Diverter | 101 Route, 102 Activated |
| 1006 | Bin | 101 Full, 102 Cleared, 103 Level |
| 1050 | ConveyorTimer | timer instance |
| 1051 | BarcodeTimer | timer instance |

---

## Key file paths

```
umm/router.py                     message router (asyncio TCP)
umm/agent.py                      UMMAgent — synchronous client API
umm/mixins.py                     DebugMixin, VersionMixin, ResequenceMixin
umm/capability.py                 CapabilityMixin, STANDARD_RESERVED_SUBTYPES
umm/names.py                      mtype/subtype name registry
umm/core/messages.py              MType, UMMSubType, MsgFlag, MatchOp etc.
umm/core/tlv.py                   TLV wire format encode/decode
umm/core/registry.py              type registry + match dispatch
umm/types/_base.py                BaseUMMType, MatchOp enum
umm/types/builtin.py              Int, Char, Bool, UTime, CoOrd, MsgRef etc.
umm/plugins/_base.py              MatchPluginBase — base class for all plugins
umm/plugins/string_match.py       Char/FName string matching plugin
umm/plugins/coord_match.py        CoOrd spatial matching plugin
umm/modules/timer.py              Timer service
umm/modules/fsm.py                Multi-dimensional FSM engine
umm/modules/typedir.py            Type directory service
umm/modules/watchdog.py           Agent liveness monitor
umm/modules/parser.py             Bus monitor / traffic display
umm/modules/bridge.py             Inter-router bridge (skeleton — next task)
umm_gui/server.py                 WebSocket bridge to GUI
umm_gui/gui.html                  General console (Send/Timer/Agents/Cap/Types/Debug tabs)
umm_gui/conveyor.html             Sorting machine visualisation
umm_gui/feed_browser.html         Live RSS/Atom feed browser (http://localhost:8766/feed)
examples/sorting/sorting_demo.py  All sorting agents
examples/sorting/sorting.fsm      FSM state machine config
examples/sorting/capabilities.py  Sorting mtype/subtype constants
umm_ctl.py                        Service manager (start/stop/status/logs)
umm.conf                          Service configuration (port 5100)
DESIGN_NOTES.md                   Architecture decisions and full protocol spec
```

---

*Handover written April 2026.*
*Session 5: router version migration; parser auto-discovery; GUI Debug tab; watchdog config; CONFIRM_RTR/RCV.*
*Session 6: CONFIRM_APP; plugin system (string_match, coord_match, PluginBase); ResequenceMixin; MATCH_QUERY (1,22/23); LIST_TYPES (1,112/113); GUI Types tab; debug log dedup; --flags parser option.*
*Session 7: UMMAgent.run() restored; umm_ctl.py path fixes; parser port default 5100; parser mtype=1 flood fix; CoOrd plugin with WITHIN_3D and BBOX; MatchOp additions; handover updated.*
*Authors: Phil Braham (design), Claude Sonnet 4.6 (implementation).*

---

## Sessions 8 & 9 changes

### Session 8 — error handling, env var, shutdown, supervisor design

**`umm/core/messages.py`**
- `ReservedSubType.SHUTDOWN = 4` — graceful shutdown, standard across all agents
- `ReservedSubType` range comment updated: 1–4 standard, 5–20 reserved, 21–99 domain
- `MType.SUPERVISOR = 12` — reserved
- `MType.HEARTBEAT = -4` — supervisor liveness ping/pong (later migrated to channel 4)
- `HeartbeatSubType`: `PING = 1`, `PONG = 2`

**`umm/mixins.py`**
- `ShutdownMixin` — `register_shutdown_handler(agent, mtype)`; `_on_shutdown_request()` override for cleanup
- `HeartbeatMixin` — `register_heartbeat_handler(agent, mtype)`; responds to pings transparently

**`umm/capability.py`** — Shutdown added to `STANDARD_RESERVED_SUBTYPES`

**`umm/agent.py`**
- `UMMConnectionError` — clear error on connection refused / timeout / OS error
- Task exception handler suppresses asyncio noise for `UMMConnectionError`

**`umm_ctl.py`**
- `UMM_ROUTER=host:port` env var overrides `umm.conf` (router host/port)
- `UMM_ROUTER_ID=site.node` env var overrides `umm.conf` (router ID)
- `cfg.router_id` added; passed as `--id` to router on startup
- `Config` class gains `router_id: str = '1.1'`

**`umm/router.py`**
- `--id` now accepts `site.node` format (e.g. `1.3`), encoded as `(site<<16)|node`
- Reads `UMM_ROUTER` and `UMM_ROUTER_ID` env vars when started standalone
- Default port changed `5000→5100` in CLI

**`umm.conf`** — `router_id = 1.1` added to `[settings]`

**`umm/__init__.py`** — public exports added: `UMMAgent`, `UMMConnectionError`, all mixins, `CapabilityMixin`

**All modules** (timer, fsm, typedir, watchdog) — `ShutdownMixin` added to base classes and `register_shutdown_handler()` called in `run()`

### Session 9 — supervisor, initiator, start script, RouterId type

**New files:**
- `umm/modules/supervisor.py` — Supervisor agent (mtype=12). Reads `supervisor.conf`, starts/monitors/restarts agents. Flags: `C` (critical, permanent attach), `E` (essential, restart on detach), `H <secs>` (heartbeat). Exponential backoff restart (2s→60s cap, give up after 5). Publishes AgentStarted/Stopped/Failed. Accepts StartAgent/StopAgent/RestartAgent messages.
- `umm/modules/initiator.py` — Startup script player. Reads `init.conf` (Wait/Message directives). `--dry-run` flag. Connects as transient agent, sends messages, exits.
- `umm_start.py` — Canonical startup script. Reads `umm.conf` + env vars, starts router then supervisor, waits for router to be ready, monitors. Ctrl-C stops cleanly.
- `supervisor.conf` — Sample supervisor config (standard stack pre-filled)
- `init.conf` — Sample initiator script

**`umm/core/tlv.py`** — `TLV_ROUTERLINK=17` renamed `TLV_ROUTER_ID=17`

**`umm/types/builtin.py`** — `RouterIdType` added (type_id=17, `site.node` text format, 4-byte wire format, `make_tlv(site,node)`, `wildcard_tlv()` for `0.0`). Added to `BUILTIN_TYPES` — auto-registers everywhere including GUI Types tab.

**`umm_names.conf`** — `-4 Heartbeat`, `-4 1 Ping`, `-4 2 Pong`, Supervisor section (mtype 12)

**`umm_gui/gui.html`** — `−4 Heartbeat` quick-subscribe button; `MN` table gains `[-4]:'Heartbeat'` and `[12]:'Supervisor'`; inline names map updated

---

## How to start the system (Session 9+)

```bash
# Canonical — reads umm.conf + env vars, starts router then supervisor
python3 umm_start.py

# With environment overrides
UMM_ROUTER=localhost:5100 UMM_ROUTER_ID=1.3 python3 umm_start.py

# Legacy — still works, starts full stack via umm.conf
python3 umm_ctl.py start

# Manual — router only, then supervisor
python3 -m umm.router --port 5100 --id 1.1 --name router-1.1
python3 -m umm.modules.supervisor --router localhost --port 5100 --config supervisor.conf

# Initiator standalone (dry-run)
python3 -m umm.modules.initiator --config init.conf --dry-run
```

---

## Next — channel field in message header (DO THIS BEFORE BRIDGE)

**Design agreed in Session 9:**

Add a `channel` byte to the `UMMMsg` fixed header, expanding it from 52 to 56 bytes:

```
VersionId   4   (unchanged)
AttachId    8   (unchanged)
Origin      8   (unchanged)
UTime      12   (unchanged)
Flags       4   (unchanged)
RegId       4   (unchanged)
MsgId       4   (unchanged)
Mtype       4   (unchanged)
SubType     4   (unchanged)
Channel     1   ← NEW: 0–255, default 0
Reserved    3   ← NEW: must be zero on send, ignored on receive (future expansion)
─────────── ─
Total      56
```

**Reserved channels:**

| Channel | Purpose |
|---------|---------|
| 0 | Application bus — all current traffic |
| 1 | Confirm |
| 2 | Debug |
| 3 | Meta (capability, version) |
| 4 | Heartbeat |
| 5 | Supervisor control |
| 6 | Bridge protocol |
| 7–10 | Reserved for future system use |
| 11–255 | User-defined |

**Migration of negative mtypes:**
- `-1 Confirm`, `-2 Debug`, `-3 Meta`, `-4 Heartbeat` → replaced by channel field (CONFIRM=2, DEBUG=3, META=4, HEARTBEAT=5)
- Negative `MType` enum values become aliases during transition, then removed
- `MType.HEARTBEAT = -4` etc. will be replaced by channel-based routing

**Router changes:**
- Filter by channel before mtype/subtype matching
- Registration table keyed by `(channel, mtype, subtype, match_tlvs)`
- Infrastructure messages (lifecycle, confirms) stamped with correct channel

**Agent/mixin changes:**
- `register()` gains `channel=0` parameter (default keeps all existing code unchanged)
- `HeartbeatMixin` moves to channel 4 transparently — application never sees it
- `DebugMixin` moves to channel 2
- `ShutdownMixin` stays on channel 0 (application-visible)

**Bridge (after channel change):**
- Bridge protocol traffic on channel 7
- `RouterId` TLV (type 17, `site.node`) in channel-0 subscriptions signals "I want remote traffic"
- Router sees `RouterId` TLV → forwards subscription to bridge
- Bridge requests matching messages from remote router
- Loop detection via A-table/B-table (router IDs seen on each side); `attach_id.router` in header is the source of truth
- No path vector on wire — loop detection is entirely in the bridge

**Files to change for channel:**
- `umm/core/messages.py` — header layout, `UMMMsg` dataclass, `encode()`/`decode()`, `FIXED_HEADER_SIZE = 56`
- `umm/agent.py` — `register()` signature, `_async_send()`, `_read_one()`
- `umm/router.py` — registration table, dispatch loop, all internal message construction
- `umm/modules/*.py` — any that construct messages directly
- `umm_gui/server.py` + `gui.html` — channel display, channel filter in subscribe tab
- `DESIGN_NOTES.md` — update wire format section

---

## Updated quick reference — channels (replaces negative mtype table)

| Channel | mtype | Subtype | Purpose |
|---------|-------|---------|---------|
| 1 | 1 | 1 | Error response |
| 1 | 1 | 2–4 | Router/receiver/app confirms |
| 2 | 1 | 1 | Agent debug output |
| 3 | 1 | 1 | Capability response |
| 3 | 1 | 2 | Version response |
| 4 | 1 | 1 | Heartbeat ping |
| 4 | 1 | 2 | Heartbeat pong |

## Updated quick reference — TLV types

| ID | Name | Notes |
|----|------|-------|
| 1 | Raw | raw bytes |
| 2 | Int | signed 32-bit NBO |
| 3 | UInt | unsigned 32-bit NBO |
| 4 | Short | signed 16-bit NBO |
| 5 | UShort | unsigned 16-bit NBO |
| 6 | Float | IEEE-754 32-bit NBO |
| 7 | Bool | 1 byte |
| 8 | Char | UTF-8 string, null-terminated — **string plugin** |
| 10 | MDNum | metadata (field-ID based match) |
| 11 | Msg | nested message/subscription |
| 12 | AttId | attach ID (router+id) |
| 13 | CoOrd | 2D/3D coordinate — **coord plugin** |
| 14 | FName | filename string — **string plugin** |
| 15 | LogId | login credentials |
| 16 | MsgRef | message reference (router+attach+msg_id) |
| 17 | RouterId | inter-router addressing: site.node (2+2 bytes) — `(0,0)` = any router |

## Updated key file paths

```
umm/modules/supervisor.py         Supervisor agent (mtype=12)
umm/modules/initiator.py          Startup message script player
umm/modules/feed.py               RSS/Atom feed agent (mtype=14) — sources via AddFeed messages
umm/modules/bridge.py             Inter-router bridge (skeleton — redesign needed)
umm_start.py                      Canonical startup script (router + supervisor)
supervisor.conf                   Supervisor agent configuration
init.conf                         Initiator startup script
umm_ctl.py                        Legacy service manager (still works)
umm.conf                          Legacy service configuration
```

---

*Sessions 8 & 9: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

---

## Session 9 — additional fixes (post-handover)

### Bugs fixed

**`umm/modules/supervisor.py`**
- `Path` import added
- `cwd` set to `supervisor.conf` directory when launching processes — fixes relative paths like `umm_gui/server.py` failing when supervisor is started from a different directory
- Agent stdout/stderr now logged to `logs/<agent-name>.log` instead of DEVNULL — silent crashes are now visible
- `{router}` and `{port}` placeholders substituted in commands at launch time, using the host/port the supervisor connected to
- `CAPABILITY = SUPERVISOR_CAPABILITY` added as class attribute; import updated

**`umm/capability.py`**
- `SUPERVISOR_CAPABILITY` added with full subtype spec
- `BRIDGE_CAPABILITY` preserved (was accidentally removed then restored)
- Both registered in `BUILTIN_CAPABILITIES`

**`umm/router.py`**
- Startup log now shows router ID as `1.1` instead of raw integer `65537`

**`umm_start.py`**
- 0.3s pause before TCP probe to reduce log confusion

**`supervisor.conf`**
- All hardcoded `localhost:5100` replaced with `{router}` and `{port}` placeholders
- These are substituted at launch by the supervisor using its own connection details
- Adding a new agent: just use `{router}` and `{port}` — they always match `UMM_ROUTER`

**`umm_gui/gui.html`**
- `min="0"` removed from mtype/subtype input fields — **this was the subscribe bug** (prevented entering negative values)
- Negative mtype quick-subscribe buttons (`-1 Confirm`, `-2 Debug`, `-3 Meta`, `-4 Heartbeat`) removed — replaced by channel buttons (ch2 Confirm, ch3 Debug, ch4 Meta, ch5 Heartbeat)
- `12 Supervisor` quick-subscribe button added — subscribes to AgentStarted/Stopped/Failed in one click
- `SUP_ST` table and `snName()` function added — supervisor subtypes now show names in log
- `RouterId` (type 17) added to TYPES array with `site.node` input hint
- Shutdown button added to each agent row in Agents tab
- `shutdownAgent()` function added

### Verified working
- `python3 umm_start.py` starts router + supervisor
- Supervisor reads `supervisor.conf`, launches timer, typedir, GUI server, string-match, coord-match
- All agents connect to correct port from `UMM_ROUTER` env var
- GUI loads at `http://localhost:8766`, connects via WebSocket
- Subscribe, send, agents tab, capability tab all working

---

## Session 10 — channel field in message header (COMPLETE)

The channel field has been fully implemented, tested, and debugged across all files.

### Core changes

**`umm/core/messages.py`**
- `FIXED_HEADER_SIZE` updated 52 → 56
- New `Channel` enum: ALL=0, APP=1, CONFIRM=2, DEBUG=3, META=4, HEARTBEAT=5, SUPERVISOR=6, BRIDGE=7
- `UMMMsg` gains `channel: int = 0` field; `encode()`/`decode()`/`make_msg()`/`__repr__` all updated

**`umm/agent.py`**
- `send()`, `asend()`, `register()`, `aregister()`, `_async_send()`, `_async_register()`, `_make_msg()` all gain `channel=0`
- UMMReg payload: `mtype(4) + subtype(4) + channel(1) + reserved(3) + match_TLVs`
- Infrastructure sends use correct channels (CONFIRM, META etc.)

**`umm/router.py`**
- `CLookup` three-level table: `[channel][mtype][subtype]`
- **channel=0 in a subscription is a wildcard** — matches all channels (consistent with mtype=0/subtype=0)
- `_svc_register` parses channel from UMMReg payload
- All infrastructure messages stamped with correct channel
- Router appears in LIST_AGENTS as synthetic entry (attach_id=0, mtype=1)
- Router handles `SetDebug` and publishes on `channel=DEBUG` — same as all agents
- Router capability response on `channel=META`; includes standard reserved subtypes

**`umm/mixins.py`**
- `DebugMixin`: publishes on `channel=DEBUG` with `mtype=UMM`
- `VersionMixin`: responds on `channel=META` with `mtype=UMM`
- `HeartbeatMixin`: ping/pong on `channel=HEARTBEAT` with `mtype=UMM`

**`umm/capability.py`**
- All query handlers (`on_query_targeted`, `on_query_broadcast`, `on_reserved_get_capability`) respond on `channel=META`
- `STANDARD_RESERVED_SUBTYPES` notes updated for channel-based routing

**`umm/modules/supervisor.py`** — heartbeat uses `channel=HEARTBEAT`

**`umm/modules/parser.py`**
- `--channel N` flag (repeatable) subscribes on specific channels
- Channel=0 default is a wildcard — sees everything on all channels
- Capability auto-discovery subscription uses `channel=META`
- Startup banner shows channel filter

**`umm/core/messages.py`** — `MType.GUI = 13` added

**`umm_gui/server.py`**
- `format_msg` includes `channel` field
- `subscribe_debug` uses `channel=DEBUG`
- `register` action accepts `channel`
- GUI agent declares `agent_mtype=MType.GUI` (13) so it appears in agents list
- GUI registers capability on connect via `register_capability_handler`
- `get_capability` subscribes on `channel=META`
- HTTP server uses `SO_REUSEADDR` + port-kill on startup (fixes repeated restart crashes)

**`umm_gui/gui.html`**
- Subscribe tab: `channel` input + quick-subscribe channel buttons (ch2 Confirm, ch3 Debug, ch4 Meta, ch5 Heartbeat)
- Log rows: channel badge for non-zero channels
- Detail panel: channel field
- `handleDebugMessage`: checks `data.channel === 2`
- Agents tab: router shown with debug button, no shutdown button; all agents show debug

**`umm_names.conf`** — `13 GUI` added

### Key design decision

**channel=0 in a subscription = wildcard across all channels.** This means:
- Existing code that doesn't pass `channel` continues to work unchanged
- The parser's `(0,0)` subscription sees all traffic including META, DEBUG etc.
- Channel-specific subscriptions use `channel=1`, `channel=2` etc.

### Next — bridge

Channel 6 (BRIDGE) is reserved. Bridge implementation can now proceed.

*Session 10: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 10 (continued) — bug fixes and polish

These fixes were made during testing of the session 10 channel field implementation.

### Bugs fixed

**`umm/capability.py`**
- `register_capability_handler` added as a standalone module-level function (was only an instance method on `CapabilityMixin`) so non-mixin agents (e.g. GUI server) can register capability without subclassing
- All capability query handlers (`on_query_targeted`, `on_query_broadcast`, `on_reserved_get_capability`) now respond on `channel=META` — previously only the reserved subtype handler did
- `STANDARD_RESERVED_SUBTYPES` notes updated to reference channels instead of negative mtypes

**`umm/router.py`**
- Router capability response stamped with `channel=META` (was channel 0 — server subscription never matched)
- Router added as synthetic `attach_id=0` entry in `LIST_AGENTS_RESPONSE`
- Router handles `SetDebug` (`mtype=UMM, subtype=3`) and publishes debug events on `channel=DEBUG`
- `channel=0` in a subscription is a wildcard matching all channels (critical fix — parser's `(0,0)` wildcard now sees META, DEBUG etc.)
- Standard reserved subtypes (GetCapability, GetVersion, SetDebug) added to router's capability descriptor

**`umm/mixins.py`** — `VersionMixin` response subtype fixed to `MetaSubType.VERSION` (was subtype=1)

**`umm/modules/parser.py`**
- `--channel N` flag added (repeatable); channel=0 default = all channels
- Capability auto-discovery subscription uses `channel=META`
- Startup banner shows channel filter

**`umm_gui/server.py`**
- GUI server now declares `agent_mtype=MType.GUI` (13) — appears correctly in agents list
- GUI server registers capability via `register_capability_handler` on connect
- `make_capability()` call uses `what=` not `name=` (correct parameter name)
- HTTP server uses `SO_REUSEADDR` + `lsof`-based port kill on startup (fixes repeated restart crashes)
- `get_capability` response subscription uses `channel=META`
- `list_agents_response` raw JSON logged at INFO for debugging

**`umm_gui/gui.html`**
- Channel quick-subscribe buttons fixed (`sch` input updated, not `sm`)
- Router row in agents tab: debug button shown, shutdown button hidden
- `soundslike` added to Char operator dropdown
- `OPM` operator-to-mword map fixed: `*=`→7 (was 4), `before`→9, `after`→10; `soundslike`→8 added, `CI!=`→3 added
- `CI!=` added to Char ops list

**`umm/core/messages.py`** — `MType.GUI = 13` added

**`umm_names.conf`** — `13 GUI` added

**`umm/plugins/string_match.py`**
- `_soundslike` replaced with proper Soundex algorithm (Russell & Odell, 1918)
- Pure Python, no imports — "Supervisors" now matches "Supervisor" (plurals/suffixes handled correctly)

### umm_ctl.py changes

- `umm.conf` port corrected to 5300 (was 5100)
- `supervisor` added as a core agent in `umm.conf` (after router) — `python3 umm_ctl.py start` now starts everything
- Timer/typedir/gui/plugins removed from `umm.conf` core (supervisor manages those via `supervisor.conf` — no double-starting)
- `killall` command added — kills all UMM-related Python processes by pattern regardless of PID files
- `cleanstart` command added — kills stale processes then starts fresh
- `build_command` resolves `--config` path for supervisor relative to project directory

### Usage going forward

```bash
# Start everything (replaces umm_start.py)
python3 umm_ctl.py start

# Kill stale processes and restart clean
python3 umm_ctl.py cleanstart

# Kill everything
python3 umm_ctl.py killall

# Status / logs / stop as before
python3 umm_ctl.py status
python3 umm_ctl.py logs
python3 umm_ctl.py stop
```

`umm_start.py` still works as before if preferred.

### Next — bridge

Channel 6 (BRIDGE) is reserved. Bridge implementation can now proceed.

*Session 10 continued: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 10 (continued further) — channel message display fixes

### Bugs fixed

**`umm/router.py`**
- `_process_umm` now gates on `msg.channel == 0` before processing router control subtypes. Messages on channel>0 bypass all control handling and go straight to `_process_msg`. This fixes the critical collision where `ReservedSubType.GET_VERSION=2` and `MetaSubType.VERSION=2` are the same integer — the router was intercepting version *responses* as version *requests*.

**`umm/names.py`**
- `full_name()` gains `channel` parameter with channel-specific subtype name tables. Subtype=2 on channel=3 now returns `VersionResponse` instead of `AttachConfirm`.

**`umm/modules/parser.py`**
- `_on_msg` filter fixed: only suppresses `mtype=UMM, channel=0, subtype 1-9` (router control). Infrastructure channel messages (channel>0) always shown.
- Control tracking subscription uses `channel=0` explicitly — doesn't intercept META/DEBUG responses.
- Channel-aware type label: `Meta/UMM,VersionResponse` format.
- `ch=N` shown automatically when `--channel` specified or `--show-channel` flag set.
- `--show-channel` CLI flag added.
- UMMReg parse reads 12-byte format (with channel byte).
- `subs`/`who` commands show channel per subscription.

**`umm_gui/server.py`**
- `_subtype_name()` gains `channel` parameter with same channel-specific tables — fixes `AttachConfirm` label for version responses.
- `format_msg` passes `msg.channel` to `_subtype_name`.
- `DebugMixin`, `VersionMixin`, `ShutdownMixin` registered for GUI server — SetDebug, GetVersion, Shutdown all work on mtype=13.
- No-cache HTTP headers prevent browser caching stale GUI code.
- All diagnostic logging removed.

**`umm_gui/gui.html`**
- `appendLog` showCtrl filter: only suppresses `mtype=1, channel=0, subtype 1-9`. Infrastructure channel messages (channel>0) always displayed.
- `snName()` gains `channel` parameter with channel-specific subtype tables.
- `typeLabel` uses `Meta/UMM(1),VersionResponse` format for channel>0 messages.
- Channel filter input (`ch`) added to log filter bar — treats 0 as no-filter.
- `applyFilter` treats 0 in any field as no-filter (was filtering *to* mtype=0).
- Dedup key includes `ts_ms` and `channel` to prevent false dedup across reconnects.
- `quickSubChannel` fixed to use `mtype:0` wildcard (was `mtype:1`).
- `renderSubs` shows channel badge separately from desc.
- Log entry spacing: spaces between spans for readability.

### Key insight
The channel field on mtype=UMM creates subtype number collisions with the UMM control subtype table. Any code that formats or filters mtype=UMM messages must check `channel` first — channel>0 means an infrastructure response, not a router control message. This applies in: the router (`_process_umm`), the name registry (`full_name`), the server (`_subtype_name`), the parser (`_on_msg` filter), and the GUI (`appendLog` showCtrl filter, `snName`).

### Key insight
The channel field on mtype=UMM creates subtype number collisions with the UMM control subtype table. Any code that formats or filters mtype=UMM messages must check `channel` first — channel>0 means an infrastructure response, not a router control message. This applies in: the router (`_process_umm`), the name registry (`full_name`), the server (`_subtype_name`), the parser (`_on_msg` filter), and the GUI (`appendLog` showCtrl filter, `snName`).

### Next — bridge
Channel 6 (BRIDGE) is reserved. Session 11.

*Session 10 (continued further): Phil Braham (design/testing), Claude Sonnet 4.6 (implementation). April 2026.*

---

## Session 11 — bridge implementation

### GUI fix

**`umm_gui/gui.html`**
- Log row spacing: removed dead `chBadge` variable (was always `''`); added explicit space before `<span class="lr">#reg_id</span>`.
- Root cause noted: the type label column is not fixed-width so longer labels (e.g. `Meta/UMM(1),VersionResponse`) push the badge right. Layout fix deferred.

### Double-registration discovery

While testing, sending a registration from the GUI produced two `(UMM, Register)` entries on the parser. Root cause not yet confirmed — likely the GUI or WebSocket layer sending the request twice. To investigate next session.

### Bridge — `umm/modules/bridge.py` (complete rewrite)

**Key insight:** The router already dispatches `(UMM, REGISTER)` and `(UMM, UNREGISTER)` through the normal pub/sub system (visible on the parser with `--show-control`). The bridge just subscribes to those events like any other agent. **No router changes required.**

The earlier approach (special `_notify_bridge_sub_add` router methods, `_find_bridge_attach`, `mtype=` parameter on `_make_router_msg`) was reverted entirely. Router is unchanged from Session 10.

**Design:**

`RouterSide` — one UMMAgent attached to one router:
- On connect, registers `(UMM, REGISTER)` and `(UMM, UNREGISTER)` subscriptions
- `_on_register`: parses the UMMReg payload, calls `strip_router_id_tlv` — if a RouterId TLV is found, calls `on_sub_add` callback (BridgeModule wires these together)
- `_on_unregister`: calls `on_sub_rem` callback
- `mirror_sub(local_reg_id, ...)` — registers the stripped subscription on this router; tracks remote_reg_id
- `unmirror_sub(local_reg_id)` — unregisters the mirrored sub
- `forward(msg)` — sends msg onto this router
- Loop detection: `record_router` / `has_router` / `expire_routers` (LOOP_TTL=60s)

`BridgeModule` — owns two `RouterSide`s:
- `_sub_add_from_a`: mirrors onto B; callback forwards B→A with loop check
- `_sub_add_from_b`: mirrors onto A; callback forwards A→B with loop check
- Expiry thread publishes `(11, RouterGone)` as IDs age out

**`strip_router_id_tlv(match_bytes)`** — standalone helper:
- Scans match_bytes for `TLV_ROUTER_ID` (type 17)
- Returns `(site, node), stripped_bytes` or `None, original_bytes`
- `(0, 0)` is a valid wildcard — matches messages from any remote router

**`parse_register_msg(msg)`** — extracts `(reg_id, mtype, subtype, channel, match_bytes)` from a `(UMM, REGISTER)` message.

**Lifecycle events published on `mtype=11`:**
- `(11, 106) RouterSeen` — `Int(site) Int(node) Char("A"|"B")` — new router observed
- `(11, 107) RouterGone` — `Int(site) Int(node)` — router timed out

**Running:**
```bash
python3 -m umm.modules.bridge --router-a localhost:5300 --router-b 192.168.1.2:5300
python3 -m umm.modules.bridge --debug
```

**Subscribing to remote messages:**
```python
from umm.types.builtin import RouterIdType

agent.register(
    mtype      = 100,
    subtype    = 1,
    callback   = on_msg,
    match_tlvs = [RouterIdType.make_tlv(1, 3)],  # site=1, node=3
    # RouterIdType.make_tlv(0, 0) = wildcard — any remote router
)
```

### Not yet done / next session
- End-to-end test: two router instances, one bridge, publisher on A, subscriber on B
- Investigate double-registration from GUI
- Bridge capability descriptor (GetCapability for mtype=11)
- Heartbeat (ST_HEARTBEAT=105) — defined, not implemented

*Session 11: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 11 (continued) — router unregister-on-detach

### Problem
When a non-permanent agent detaches, the router silently removes its subscriptions internally (`_lookup.remove_all_for`, `reg_list.clear`) without publishing `(UMM, UNREGISTER)` messages. Any bus observer tracking subscriptions (e.g. the bridge) would never learn the subscriptions were gone.

### Fix — `umm/router.py` `_handle_disconnect`

For non-permanent agents, before clearing subscriptions, the router now synthesises a `(UMM, UNREGISTER)` message for each reg_id and dispatches it through `_process_msg`. This means any agent subscribed to `(UMM, UNREGISTER)` sees exactly the same events whether the agent unregistered cleanly or simply dropped the connection.

Permanent (critical) agents are unchanged — their subscriptions are retained on disconnect and no Unregister messages are sent.

### Consequence for bridge
The bridge requires no special attach/detach handling. When an agent with bridged subscriptions detaches, the router's synthesised Unregister messages flow through normally and `RouterSide._on_unregister` cleans up the mirrored subs on the far router.

*Session 11 continued: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 11 (continued) — bridge standard subtypes

**`umm/modules/bridge.py`**

`BridgeModule` now subclasses `CapabilityMixin`, `DebugMixin`, `VersionMixin`, `ShutdownMixin`. After connecting both sides, `run()` registers all four handlers on **both** agents:

```python
for agent in (self._side_a._agent, self._side_b._agent):
    self.register_capability_handler(agent)
    self.register_version_handler(agent, MType.BRIDGE)
    self.register_debug_handler(agent, MType.BRIDGE, debug=self._debug_startup)
    self.register_shutdown_handler(agent, MType.BRIDGE)
```

`BRIDGE_CAPABILITY` descriptor added (subtypes 103 Status, 104 StatusReply, 106 RouterSeen, 107 RouterGone).

`--debug` CLI flag now also enables debug output at startup (passed through to `register_debug_handler`).

*Session 11 continued: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 11 (continued) — bridge mtype-per-side and startup config

### Bridge changes — `umm/modules/bridge.py`

**Separate mtype per side:**
- `RouterSide` takes a `mtype` parameter; its agent attaches with that mtype
- `BridgeModule` takes `mtype_a` (default `MType.BRIDGE=11`) and `mtype_b` (required, no default — raises `ValueError` if zero)
- Lifecycle events (`RouterSeen`, `RouterGone`) are sent on `mtype_a`
- Status dict now includes `mtype_a` and `mtype_b`

**Shutdown on A only:**
- `register_shutdown_handler` is called only for `_side_a`; Router B cannot shut down the bridge

**CLI:**
- `--router-b` is now required (no default)
- `--mtype-b` is required
- `--mtype-a` is optional (default 11)
- `--name` added for process name

**Usage:**
```bash
python3 -m umm.modules.bridge \
    --router-a localhost:5300 \
    --router-b 192.168.1.2:5300 \
    --mtype-b 11 \
    --debug
```

### Startup config

**`umm.conf`:**
- `[settings]` gains two commented-out keys: `router_b` and `port_b`
- New `[agent.bridge]` section in group `bridge` (not started by default):
  ```ini
  [agent.bridge]
  module  = umm.modules.bridge
  group   = bridge
  after   = manual
  options = --mtype-b 11
  ```
- Start with: `python3 umm_ctl.py start bridge`

**`umm_ctl.py`:**
- `Config` gains `router_b: str` and `port_b: int` fields, parsed from `[settings]`
- `build_command` handles `umm.modules.bridge` specially: constructs `--router-a {router}:{port} --router-b {router_b}:{port_b}` and then appends `options` (which carries `--mtype-b N` and any other flags)
- Raises `RuntimeError` at start time if bridge is started without `router_b` set

*Session 11 continued: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 11 (continued) — UMM_BRIDGE_<NAME> environment variables

### Design

Each bridge agent in `umm.conf` can be configured via an environment variable named `UMM_BRIDGE_<NAME>` where `<NAME>` is the agent name suffix uppercased with hyphens replaced by underscores.

Example: `[agent.bridge-link-to-store]` → `UMM_BRIDGE_LINK_TO_STORE`

**Format** (key=value, comma-separated):
```
export UMM_BRIDGE_LINK_TO_STORE=router_b=192.168.1.2:5300,mtype_b=11
export UMM_BRIDGE_PLANT_B=router_b=10.0.0.1:5300,mtype_a=15,mtype_b=11
```
Keys: `router_b=host:port` (required), `mtype_b=N` (required), `mtype_a=N` (optional, defaults to 11).

**Priority** (highest wins):
1. `--router-b`, `--mtype-a`, `--mtype-b` in agent `options` (config file)
2. `UMM_BRIDGE_<NAME>` environment variable
3. `router_b` / `port_b` in `[settings]`

### Changes

**`umm_ctl.py`:**
- `AgentDef` gains `bridge_env: dict` field (populated from env var at parse time)
- `_parse_bridge_env(key, value)` — standalone helper; validates and parses the env var string; warns and returns `None` on malformed input
- `parse_config` scans `os.environ` for `UMM_BRIDGE_*` after building agents; attaches parsed dict to matching agent's `bridge_env`; warns if no matching agent found
- `build_command` for bridge: layers settings → env → options; extracts `--router-b`, `--mtype-a`, `--mtype-b` from `options` as explicit overrides; remaining options passed through unchanged

**`umm.conf`:**
- Bridge section renamed from `[agent.bridge]` to `[agent.bridge-link-to-store]` as a named example
- Comments document env var format and priority

*Session 11 continued: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 11 (continued) — status/show improvements and --config

### `--config` flag
Already existed. Takes a path to a `.conf` file; bare filenames resolve relative to the script directory. Use separate config files for separate router instances on the same machine (different `port`, `gui_port`, `router_id`, `log_dir` in each).

### `cmd_status` improvements
- Header now shows: `Router: host:port  GUI: port  ID: router_id`
- Running bridges listed under header: name, remote address, running/stopped

### `cmd_show` improvements  
- Shows router ID alongside address
- New `── Bridges ──` section: for each `[agent.bridge-*]`, shows effective router_b address, mtype_a, mtype_b, and whether the matching `UMM_BRIDGE_<NAME>` env var is set

### Help text updated
Documents `--config`, bridge start commands, and second-router usage.

*Session 11 continued: Phil Braham (design), Claude Sonnet 4.6 (implementation). April 2026.*

## Session 12 — Bridge heartbeat, LIST_SUBS, JSON type, channel reply convention

### Changes made this session

**Bridge heartbeat (`umm/modules/bridge.py`):**
- `BridgeHeartbeat` rewritten to on-quiet logic — normally silent, only sends a ping after `quiet_threshold` seconds (default 10s) of no B-side traffic. Any incoming B-side message resets the timer via `note_activity()`. Constant ping traffic eliminated.
- `_forward_b_to_a` calls `note_activity()` so normal message flow keeps the probe silent.
- `HeartbeatMixin` added to `BridgeModule` base classes; `register_heartbeat_handler` called on B-side agent in `_register_side_handlers` so the bridge responds to pings from external monitors.
- `on_reconnect` callback added to `UMMAgent` (`umm/agent.py`) — fires after `_attempt_reconnect` succeeds, after all subscriptions are re-registered. `RouterSide` passes `_on_side_b_connect` as `on_reconnect` so it fires on every B-side reconnect, not just the initial connect.

**LIST_SUBS router service (`umm/router.py`, `umm/core/messages.py`):**
- New subtypes `LIST_SUBS = 114` (C→R) and `LIST_SUBS_RESPONSE = 115` (R→C).
- Router responds with JSON containing all current subscriptions including `match_hex` (raw match TLV bytes as hex) so consumers can reconstruct subscriptions verbatim.
- Bridge uses this on B-side connect/reconnect (`_replay_subs_from_a`) to mirror any RouterId-bearing subscriptions that were registered while the bridge was down.

**JSON TLV type (`umm/core/tlv.py`, `umm/types/builtin.py`):**
- `TLV_JSON = 18` — wire-identical to Char (null-terminated UTF-8) but distinct type_id.
- `JsonType` registered in `BUILTIN_TYPES`, inherits all string match operators from `StringType`.
- JSON matching handled synchronously by the router's built-in registry — NOT sent to the string plugin. String plugin remains unchanged (handles Char=8 and FName=14 only).
- `LIST_SUBS_RESPONSE` uses `TLV_JSON` for its payload. All other existing `TLV_STRING` uses left as-is for later retrofit.
- GUI `TYPES` array updated with JSON entry; `umm_names.conf` updated with ListTypes/ListSubs subtypes.

### To-do: application channel reply convention

**Design decision — deferred implementation.**

Channels 1–9 reserved for system use (APP=1, CONFIRM=2, DEBUG=3, META=4, HEARTBEAT=5, SUPERVISOR=6, BRIDGE=7). Channels 10+ available for application use (128–255 by convention for simulation).

**Proposed convention:** when an agent receives a request on a user-defined channel (>= 10), any response that would normally go on channel 1 (APP) is sent on the request channel instead. Responses on system channels (1–9) are unchanged.

**Implementation point:** `UMMAgent` — a single place so all agents get the behaviour automatically. The agent framework captures `msg.channel` when dispatching a callback and makes it available as a `reply_channel` for the handler to use on the response send call.

**Use case:** simulation/demo separation. Simulation messages (e.g. belt movement in the sorting demo) sent on channel 150. In a live demo, subscribe to channel 0 only — simulation traffic invisible. In a test/debug session, subscribe to channel 150 to see simulator activity. No code changes needed in agents; they just pass `reply_channel` through.

**Key property:** zero overhead — channel is already a field in every message; the only addition is a single integer comparison per response.

*Session 12: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 13 — sim_channel, reply_channel

### Design note — channel as pure transport

The channel field is a plain integer in the wire format. The framework imposes no semantic restrictions on which values agents use. Named constants (`Channel.SIM`, `Channel.HEARTBEAT` etc.) are documentation and convention, not enforcement. An agent that wants to send on channel 4 for its own purposes is free to do so. The system stays at the transport layer; policy lives in the application.

The earlier suggestion of checking `channel >= 101` before enabling reply-channel passthrough was rejected for this reason — and because system agents may legitimately want to send on infrastructure channels (e.g. a watchdog that publishes its own heartbeats).

### Changes made

**`umm/agent.py`**
- `sim_channel: int = 0` constructor parameter. When non-zero, `send()` and `asend()` use it as the default channel for all outgoing messages from this agent. Pass `channel=0` explicitly to force the app bus regardless.
- `reply_channel` property — returns the channel of the message currently being dispatched to a callback (zero outside a callback). Callbacks read this to echo the incoming channel on any responses.
- `_dispatch_application()` sets/restores `self._current_channel` around each callback invocation.
- `send()` and `asend()` default `channel` changed to sentinel `-1`; if `-1`, resolves to `self.sim_channel`.

**`umm/core/messages.py`**
- `Channel.SIM = 128` added with convention comment: 128–255 = simulation/test scaffolding.
- Module docstring channel table updated.

**`examples/sorting/capabilities.py`**
- `SIM_CHANNEL = 128` constant added.
- Module docstring updated with full explanation of the channel separation pattern.

**`examples/sorting/sorting_demo.py`**
- `ConveyorSim.__init__` accepts `sim_channel=SIM_CHANNEL`.
- `ConveyorSim._send()` accepts `channel=0` param, threads through to `_async_send`.
- Timer requests and cancels → `channel=self._sim_channel`.
- Timer confirmation and internal tick subscriptions → `channel=self._sim_channel`.
- `_publish_pulse` stays on channel 0 — belt encoder pulses are real-world events.

**`umm_gui/gui.html`**
- `ch128 Sim` quick-subscribe button added.
- `128:'Sim'` added to all three CH_NAME/CH_NAMES tables and the channel input tooltip.

**`DESIGN_NOTES.md`** — channel table updated with 128–255 sim convention row.

### How simulation channel separation works

On a real machine: belt motor state changes, photocell events, barcode results, diverter activations all travel on channel 0. The simulation adds belt encoder pulse timers to drive the GUI animation. Those timer requests, tick confirmations, and internal tick messages are simulation scaffolding — they wouldn't exist on a real machine.

With `SIM_CHANNEL=128`, a channel-0 subscriber sees exactly what a real machine would produce. A channel-128 subscriber sees the simulation machinery. The parser and GUI can subscribe to either or both:

```bash
# Real-machine view — no simulation noise
python3 -m umm.modules.parser --channel 0

# Simulation-only view
python3 -m umm.modules.parser --channel 128

# Everything
python3 -m umm.modules.parser          # channel=0 wildcard = all channels
```

### reply_channel usage pattern

```python
def _on_request(self, msg):
    # Echo the response back on whatever channel the request arrived on.
    # If the caller is on ch128 (sim), the response stays on ch128.
    # If the caller is on ch1 (app bus), the response goes to ch1.
    result_tlvs = [...]
    self._agent.send(MT_MYAGENT, ST_RESPONSE, result_tlvs,
                     channel=self._agent.reply_channel)
```

### Next

- GUI: belt movement animation for conveyor demo (second belt, position tracking)
- Sort out the demo startup — `sorting_demo.py` is launched manually; note it should NOT be in `supervisor.conf` or `umm_start.py`

*Session 13: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 14 — Multi-parcel demo, L-shaped GUI, FSM redesign

### Overview

This session completed a major overhaul of the parcel sorting demo: the FSM was redesigned for multi-parcel operation, the conveyor GUI was rebuilt with an L-shaped layout and mechanical pushers, and a significant number of framework bugs introduced in session 13 were identified and fixed.

---

### Framework bugs fixed

#### 1. Register messages on non-zero channels bypassed by router

**File:** `umm/router.py` — `_dispatch()` method

**Bug:** When a Register message arrived with `channel > 0` in the header (introduced in session 13 when channel was moved from payload to header), the router's dispatch logic bypassed the control path and treated it as a regular publish. The subscription was never stored.

**Fix:** `REGISTER`, `UNREGISTER`, `ATTACH`, and `DETACH` subtypes are always routed to the control path regardless of the header channel value.

```python
_ALWAYS_CONTROL = {
    int(UMMSubType.ATTACH), int(UMMSubType.DETACH),
    int(UMMSubType.REGISTER), int(UMMSubType.UNREGISTER),
}
if msg.channel != 0 and st not in _ALWAYS_CONTROL:
    await self._process_msg(msg, from_attach)
    return
```

**Impact:** Any subscription on a non-zero channel (ch2 Confirm, ch3 Debug, ch4 META, ch128 Sim) was silently lost. This broke capability queries, debug subscriptions, and the sim-channel timer tick subscriptions.

#### 2. Capability response race condition in GUI server

**File:** `umm_gui/server.py`

**Bug:** The GUI registered a per-query subscription for capability responses, then sent the query. The router processed the query faster than the subscription was stored, so the response arrived before the subscription was active.

**Fix:** Replaced per-query subscribe/unsubscribe with a permanent `(UMM, CapabilityResponse, ch3)` subscription registered at startup. Responses are correlated by `MsgRef` (which echoes the query's `msg_id`) via `self._cap_pending` dict. Race-free by design.

#### 3. GUI ST subtype constants wrong

**File:** `umm_gui/conveyor.html`

**Bug:** `CTRL_START:1` instead of `101`, `PC_C1:1` instead of `101`, etc. — all subtypes were using 1-based values from an older numbering scheme. The FSM subscribed to `1001,101` but the GUI was sending `1001,1`.

**Fix:** All ST constants corrected to match `capabilities.py` (101+ range).

#### 4. TLV_BOOL wrong type ID in GUI

**File:** `umm_gui/conveyor.html`

**Bug:** `getBool()` checked for `type_id === 3` but `TLV_BOOL = 7`. Belt state changes from ConveyorSim use type 7. Result: `c1` and `c2` were always `false`, chevrons never animated.

**Fix:** `getBool()` now checks for `type_id === 7 || type_id === 3`.

#### 5. Capability response sent on wrong channel

**File:** `umm/capability.py`

**Bug:** The legacy broadcast response path called `agent._async_send(...)` without `channel=int(Channel.META)`. With the session 13 `sim_channel` sentinel change, this defaulted to ch0 instead of ch4. GUI subscribed on ch4 so never received it.

**Fix:** Explicit `channel=int(Channel.META)` added to the legacy path.

#### 6. Multiple arm fires per parcel (cascade loop)

**Files:** `examples/sorting/sorting.fsm`, `examples/sorting/sorting_demo.py`

**Bug:** FSM handled both `BC_SUCCESS` (→ DiverterCmd) and `PC_BIN*_DETECTED` (→ DiverterCmd). DiverterSim responded to DiverterCmd by firing the arm and then publishing the bin-entry PC. FSM received the bin-entry PC and fired DiverterCmd again. Infinite loop.

**Fix:** Removed all `PC_BIN*_DETECTED` → DiverterCmd transitions from the FSM. FSM routes only on barcode scan results. Bin-entry PCs go to BinMonitor only.

#### 7. JavaScript ReferenceError — c1Active used before definition

**File:** `umm_gui/conveyor.html`

**Bug:** `const frontC1 = c1Active.length > 0 ? ...` appeared before `const c1Active = ...`. JS `const` does not hoist — ReferenceError silently killed `drawParcels()` every frame. Nothing rendered.

**Fix:** Moved `c1Active` definition to top of `drawParcels()`.

#### 8. Stray array elements — JS syntax error

**File:** `umm_gui/conveyor.html`

**Bug:** A partial str_replace left three orphaned lines after the closing `];` of the `armY` array, causing a syntax error. Belts did not appear at all.

**Fix:** Removed stray lines. Now running `node` syntax check before packaging.

---

### FSM redesign — `examples/sorting/sorting.fsm`

The old FSM was a single-parcel sequential state machine with a `Sequence` dimension that tracked one parcel through the pipeline. Replaced with a multi-parcel event-driven design.

**Dimensions:**
- Sequence: `Idle` | `Running`
- Safety: `Running` | `EStopped` | `RestartPending` | `BinStopped`
- Bins: `BinsOK` | `BinFull`

**Key design decisions:**
- FSM stays `(SAME, SAME, SAME)` for all normal running events — multiple parcels in flight simultaneously
- C1 stops when parcel reaches scanner (`PC_C2_DETECTED`), restarts when scan completes
- `DiverterCmd` fires once per parcel from scan result only — NOT from bin photocells
- EStop forces sequence to `Idle` — operator must press Start after clearing all parcels
- BinFull preserves sequence state (`SAME`) — parcels stay on belt, belts restart automatically when bin cleared
- Belt stalls treated as EStop

**Important:** Bin-entry photocells (`PC_BIN1-REJ`, 1003,103-107) are intentionally NOT handled by the FSM. DiverterSim publishes them after diverting; BinMonitor uses them for counting. If the FSM handled them it would cause a DiverterCmd cascade loop.

---

### Conveyor GUI redesign — `umm_gui/conveyor.html`

Complete rewrite. Old single-belt design replaced with L-shaped layout.

**Layout:**
- C1 (feed belt): horizontal, top of canvas, entry at left, scanner PC near right end
- Corner: bezier curve transfer from C1 end to C2 top
- C2 (delivery belt): vertical strip on right side of canvas, parcels travel downward
- Bins panel: left side, one card per bin with fill bar, LED indicator, Empty button
- Bin capacity control: sets when BinMonitor triggers BinFull
- Log panel: right side

**Parcel lifecycle in GUI:**
1. `PC_C1` → spawn parcel at `xEnt`, `stage='c1'`
2. Pulse-driven movement along C1 (using `c1Pulse - entryC1`)
3. Parcel reaches `xScan` → fire `PC_C2`, `stage='corner'`
4. 550ms bezier corner animation → `stage='scanner'`
5. `BC_SUCCESS`/`BC_FAIL` → set `destBin`, `stage='c2'`
6. Pulse-driven movement down C2 (using `c2Pulse - entryC2`)
7. `Diverter,Activated` → `stage='dropping'`, arm fires, parcel slides left into chute
8. Fade out over 400ms → `done=true`, removed from array

**Queue blocking:**
- C1: parcels sorted ascending by `entryC1` (lowest = frontmost). Each parcel capped at `aheadX - 26px`. Only frontmost parcel can enter scanner — others wait if scanner occupied.
- C2: same pattern, sorted by `entryC2`.
- Minimum add spacing: `MIN_PARCEL_GAP = 18` pulses enforced in `addParcel()`.

**T-shaped pushers:**
- Rod extends horizontally from right C2 wall (pivot at `c2X2`)
- Push face: vertical bar at rod tip, ±16px, wide enough to cover parcel
- Three phases: extend (160ms) → hold (260ms) → retract (520ms)
- Triggered by `Diverter,Activated` message

**Bin indicators:**
- Fill bar: green → amber → red as percentage fills
- LED: green (ok) / red blinking (full)
- Card border pulses red when full
- Bin counts driven by BinMonitor agent (`Bin,BinLevel`, `Bin,BinFull`, `Bin,BinCleared`)
- GUI does NOT send `Bin,BinFull` — that is entirely the BinMonitor agent's responsibility

**Controls:**
- START: fires EStop/Restart/AllClear/Start sequence, clears parcels
- E-STOP: immediate stop
- RESTART: appears after EStop
- CLEAR PARCELS: appears after EStop, clears the GUI parcel array without sending any messages
- + PARCEL: disabled until system running, enforces minimum spacing

---

### Known issues / next work

**Parcel/arm timing:** In a real system the diverter arm fires when the parcel reaches the bin position photocell. DiverterSim approximates this with a 0.2s delay after the divert command. The GUI defers the drop animation until `_c2Y >= armY[destBin]` so it is visually correct, but the timing relationship between the physical arm fire and the parcel position is not precisely simulated.

**Race conditions and the epoch pattern:** Messaging systems are inherently
subject to race conditions where a cancel or stop message arrives after a new
request has already been sent. The current workaround (cancel by `TLV_MSGREF`
correlation ID in addition to assigned ref) tightens the window but does not
eliminate it.

The proper solution is an **epoch/generation pattern**: the sender increments
a local counter on each new session and the receiver silently discards messages
whose epoch does not match the current one. Old operations become harmless
rather than needing explicit cancellation.

The proposed UMM implementation is a new `TLV_EPOCH` type. An agent includes
`TLV_EPOCH(N)` in its registration; the router copies it into the payload of
every message delivered to that registration. The receiving agent checks the
epoch on arrival and discards stale deliveries without any application-level
bookkeeping. This requires:
- A new TLV type `TLV_EPOCH = 20` in `core/tlv.py`
- An optional `epoch` field on `Registration` / `RegEntry`
- Router delivery prepends `TLV_EPOCH` when `reg.epoch` is set
- A helper in `agent.py` to check epoch on delivery

Note: the epoch is a property of the *registration* not the request, so the
router does not need any concept of request/response pairing — it simply copies
a tag from the registration into the delivery. This fits naturally with UMM's
subscription model.

**Infeed belt:** C1 starts at 18% of canvas width; the left 18% shows a dashed `INFEED →` placeholder. A future session should add a C0 infeed belt that stops/starts to gap parcels onto C1.

**Second belt start condition:** C2 should run whenever C1 is running OR when it has a parcel on it. Currently C2 is started/stopped together with C1 by the FSM. If a parcel is on C2 when C1 stops (scan hold), C2 continues running — this is correct because the FSM only stops C1, not C2, on `PC_C2_DETECTED`.

**Parser default channel:** Parser defaults to `channel=0` wildcard which sees everything including ch128 sim traffic. A future improvement would be a `--exclude-channel` flag or a display filter so operators can see a clean app-bus view without subscribing on a specific channel.

---

### How to start the demo

```bash
# 1. Start core services (router, supervisor, GUI server)
python3 umm_start.py

# 2. Start the sorting demo agents (separate terminal)
python3 -m examples.sorting.sorting_demo --router localhost --port 5300 --name SortingAgents

# 3. Start the FSM (separate terminal)  
python3 -m umm.modules.fsm --router localhost --port 5300 --name SortingFSM \
  --config examples/sorting/sorting.fsm

# 4. Open the conveyor GUI
# Navigate to http://localhost:8765/conveyor.html
# Click CONN, then START
```

Note: `sorting_demo.py` and the FSM are NOT in `supervisor.conf` — they are started manually for the demo.

---

*Session 15: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 17 — Bug fixes, DEFAULT_PORT, MWORD_IGNORE_MATCH, timer fixes, GUI fixes

### Context
This session worked from an older stable zip (pre-session-16) because session 16's changes introduced regressions. The session-16 handover was provided as reference for what had been done and what remained to do.

---

### 1. Two known bugs fixed on the older codebase

**Parser default port (`umm/modules/parser.py`)**
`UMMParser.__init__` had `port: int = 5000` while the argparse CLI default was already 5100. Fixed to `5100`. See item 2 below for the full consolidation.

**Registration isolation — GUI vs conveyor browser (`umm_gui/server.py`)**
`self._regs` was a flat dict shared across all WebSocket clients. Cancelling a registration in the GUI browser called `self._agent.unregister(reg_id)` unconditionally, which also cancelled the conveyor browser's subscriptions when they shared reg_ids.

**Fix:** Added `self._ws_regs: Dict[int, Set[int]]` — maps `id(ws)` → set of reg_ids owned by that client.
- `handle_ws`: initialises an empty set per client on connect; on disconnect, auto-unregisters and removes all reg_ids owned by that client (handles tab close/refresh cleanly).
- `register` action: records ownership in `_ws_regs`. Changed from `broadcast()` to `ws.send()` — other browsers don't need to know about this client's new subscription.
- `unregister` action: checks ownership before unregistering; returns error if reg_id doesn't belong to the requesting client.
- `subscribe_debug` action: same ownership tracking; `broadcast()` replaced with `ws.send()`.
- `connect` / `disconnect` actions: clear `_ws_regs` sets (agent reset invalidates all reg_ids).
- Initial status message now sends only the registrations belonging to the connecting client.

---

### 2. DEFAULT_PORT constant (`umm/core/messages.py`)

Added `DEFAULT_PORT = 5100` with a comment pointing to `umm.conf` and `UMM_ROUTER` as the real sources of truth. All modules updated to import and use this constant instead of bare literals:

| File | Change |
|------|--------|
| `umm/core/messages.py` | Added `DEFAULT_PORT = 5100` |
| `umm/agent.py` | `UMMAgent.__init__` default + docstring |
| `umm/router.py` | `UMMRouter.__init__` default, argparse, docstring |
| `umm/modules/parser.py` | `UMMParser.__init__` default, argparse |
| `umm/modules/timer.py` | `TimerModule.__init__` default, argparse |
| `umm/modules/supervisor.py` | `SupervisorModule.__init__` default, argparse + help text |
| `umm_gui/server.py` | argparse default |

`umm_ctl.py` was left alone — it always passes `--port str(cfg.port)` explicitly to every process it starts and doesn't import from the UMM stack.

**Note:** `umm.conf` currently has `port = 5300`. The `Config` dataclass fallback in `umm_ctl.py` is `5100` (used only when no `umm.conf` is found). These may want aligning in a future session.

---

### 3. MWORD_IGNORE_MATCH (`umm/core/tlv.py`, `umm/core/registry.py`, `umm/types/_base.py`, `umm/router.py`, `umm/__init__.py`, `umm/modules/parser.py`)

Implements the spec from the session-16 handover (§ "M-word clarification and IGNORE_MATCH specification").

**Constant:** `MWORD_IGNORE_MATCH = 0xFFFFFFFF` in `umm/core/tlv.py`.

**Semantics:** A subscription TLV with `mword == MWORD_IGNORE_MATCH` skips that positional slot — always passes, regardless of the message TLV's type or value. Zero-length value. The router does **not** search the message for a matching type; positional matching is strict.

**Files changed:**

- `umm/core/tlv.py` — constant defined.
- `umm/core/registry.py` — `registry.match()` checks `MWORD_IGNORE_MATCH` before the type-id equality check, so it bypasses both type and value checks.
- `umm/types/_base.py` — `BaseUMMType.match()` handles IGNORE_MATCH (defence in depth for type handlers that override `match()`). Added `BaseUMMType.make_ignore_tlv(type_id=0)` factory. Added `MWORD_IGNORE_MATCH_SYMBOL = "ignore"` for display.
- `umm/router.py` — both `_matches()` and `find_candidates_split()` now `continue` on IGNORE_MATCH before the `i >= len(msg_tlvs)` guard, so trailing IGNORE_MATCH TLVs also pass on short messages.
- `umm/__init__.py` — `MWORD_IGNORE_MATCH` exported at package level.
- `umm/modules/parser.py` — displays `[ignore]` instead of `[m=4294967295]`.

**Usage:**
```python
from umm import MWORD_IGNORE_MATCH
from umm.types._base import BaseUMMType, MatchOp

# Subscribe to temperature > 30 at position 1, ignoring city name at position 0
agent.register(
    mtype=100, subtype=5,
    callback=on_hot_city,
    match_tlvs=[
        BaseUMMType.make_ignore_tlv(),                       # pos 0 — skip city
        temp_type.make_subscription_tlv(30.0, MatchOp.GT),  # pos 1 — temp > 30
    ]
)
```

---

### 4. Timer request TLV_MSG header fix (`umm_gui/server.py`)

The GUI was packing the `TLV_MSG` inner header as 8 bytes (`!ii` — mtype + subtype only). The timer unpacks it as 12 bytes (`!iiHH` — mtype + subtype + channel + flags) and rejected anything shorter with "Timer request has no message".

**Fix:** `inner_reg = struct.pack('!iiHH', target_mtype, target_subtype, msg_channel, msg_flags) + tlvs_enc`

`msg_channel` defaults to 1, `msg_flags` to 0. Both can be overridden by passing `target_channel` / `target_flags` in the timer command JSON.

---

### 5. Timer cancel sent on wrong subtype (`umm/modules/timer.py`)

A successful cancellation was calling `self._send_error()` (subtype 104, ST_ERROR). It should send on subtype 103 (ST_CONFIRMED).

**Fix:** Added `_send_confirmed_msg(message, msg=None)` helper — parallel to `_send_error()` but sends on ST_CONFIRMED (103). `_on_cancel()` now uses `_send_confirmed_msg` for success and keeps `_send_error` for "not found". Both now explicitly send on `channel=2` (Confirm channel), matching the existing new-timer confirmation. This also means `_send_error` now includes MsgRef correlation on the cancel-not-found path.

---

### 6. GUI timer and registration fixes (`umm_gui/gui.html`)

**Channel 0 bug:** `parseInt('0')||1` was converting channel 0 (all channels) to 1 in the register button handler. Fixed: `chRaw===''?1:parseInt(chRaw)`.

**Auto-subscribe on timer send:** Clicking "Send timer request" now checks whether the GUI is already subscribed to `Timer(mtype),103` or a wildcard. If not, it auto-registers for ST_TIMER_CONFIRMED (103) and ST_TIMER_ERROR (104) on **channel=2** (Confirm), so the cancel box and active-timers list populate automatically.

**Channel=2 for timer subscriptions:** Timer confirmations and errors are all sent on channel=2 (Confirm channel). The auto-subscriptions were previously using channel=1, so they missed all timer responses. Fixed to channel=2.

**Cancel label:** "reg_id (from Confirmed message)" renamed to "ref (from Confirmed message)" — the field is the timer ref, not a registration id.

---

### Next priorities

1. **Manual §5 — System Components** (router, timer, FSM, supervisor, GUI, parser, bridge): use Claude Opus 4.6 for this work — better for long-form structured technical prose.
2. **Manual §6 — Building an Application** (sorting demo worked example).
3. **C0 infeed belt** — dashed placeholder exists in `conveyor.html`; add a belt that gaps parcels onto C1.
4. **Race condition handling** — idempotent command guard + msg_id correlation in `ConveyorSim`. `TLV_EPOCH` remains a valid future improvement. Deliberately deferred until the demo has settled.
5. **`umm.conf` port alignment** — currently says `port = 5300`; `DEFAULT_PORT` is 5100. Decide on one canonical port and update both.

*Session 17: Phil Braham (design), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 18 — Subtype renumbering, TRUSTED flag, SystemShutdown, send tool refactor

### 1. UMMSubType renumbering (`umm/core/messages.py`)

The subtype namespace is now split into three clean zones:

| Range | Zone | Purpose |
|-------|------|---------|
| 1–50 | Router wire protocol | Attach, Register, Detach, lifecycle events |
| 51–99 | Router query services | Capability, Version, Status, MatchQuery, SystemShutdown |
| 100+ | System messages | SysError, SysInfo, SysWarn, SysDenied, agent directory, type registry |

**Old → new subtype numbers:**

| Name | Old | New |
|------|-----|-----|
| CAPABILITY_QUERY | 10 | 51 |
| CAPABILITY_RESPONSE | 11 | 52 |
| VERSION_REQUEST | 12 | 53 |
| VERSION_RESPONSE | 13 | 54 |
| STATUS_REQUEST | 20 | 55 |
| STATUS_RESPONSE | 21 | 56 |
| MATCH_QUERY | 22 | 57 |
| MATCH_RESULT | 23 | 58 |
| SYSTEM_SHUTDOWN | new | 59 |
| SYS_DENIED | new | 103 |

All references updated in: `umm/router.py`, `umm/capability.py`, `umm/modules/parser.py`, `umm_gui/gui.html`, `umm_names.conf`.

---

### 2. AttachFlag.TRUSTED (`umm/core/messages.py`)

Added `TRUSTED = 0x00008` to `AttachFlag`. Stored automatically in `AttachInfo.attach_flags` at attach time. Foundation for privileged operations — currently gates `SYSTEM_SHUTDOWN`. Future privileged operations (force-detach, runtime config changes, etc.) should check `_is_trusted()`.

---

### 3. SYSTEM_SHUTDOWN (subtype 59) and SYS_DENIED (103) (`umm/router.py`)

New router handler `_svc_system_shutdown`:

- Only trusted agents (`AttachFlag.TRUSTED`) may send it.
- Non-trusted agents receive `SYS_DENIED (103)` with message "System shutdown refused: not a trusted agent".
- Payload: `Int(delay_seconds) [Char(reason)]` — delay 0 = immediate.
- Sequence: validate trust → broadcast `SYSTEM_SHUTDOWN` to all subscribers (passthrough) → wait delay → send `SHUTDOWN (6)` to every attached agent → 1s grace → `loop.stop()`.

New helpers in router: `_is_trusted(attach_id)`, `_send_denied(to_attach, message)`.

**GUI** — Capability tab now has a System Shutdown section: delay (seconds) input, optional message input, red "System shutdown" button with confirmation dialog.

**Server** — new `system_shutdown` WebSocket action in `server.py`.

---

### 4. Version query fix (`umm/core/messages.py`, `umm/router.py`, `umm_gui/server.py`, `umm_gui/gui.html`)

`ReservedSubType.GET_VERSION = 2` could not be reused for the router because `UMMSubType.ATTACH_CONFIRM = 2` is already occupied and the supervisor subscribes to it on channel 5 (Heartbeat). Attempting to query version with subtype 2 routed to the supervisor instead of the router.

Fixed by using the new dedicated `VERSION_REQUEST = 53` / `VERSION_RESPONSE = 54` subtypes. The router still handles the legacy `UMMSubType.VERSION = -1` for backward compatibility.

GUI Capability tab now has two buttons: "Query capability" and "Query version", both using the mtype input.

---

### 5. Router capability descriptor duplicate fix (`umm/router.py`)

The router's capability descriptor was appending standard agent subtypes (GetCapability=1, GetVersion=2, SetDebug=3) after its own protocol subtypes (Attach=1, AttachConfirm=2, Detach=3), causing duplicates with conflicting names. Removed the appended entries.

---

### 6. Parser interactive mode removed; send tool enhanced (`umm/modules/parser.py`, `umm/tools/send.py`)

**Parser:** `--interactive` flag removed from CLI. `run_interactive()` function kept but deprecated — it now just prints a redirect notice and runs the parser normally. The query thread (subs/who/agents commands) still works as before.

**Send tool (`umm/tools/send.py`):**
- Port default changed from 5000 → `DEFAULT_PORT` (5100).
- Added `--trusted` flag — attaches with `AttachFlag.TRUSTED`, required to send privileged commands.
- Added `--shutdown` / `--delay` CLI shortcuts for system shutdown.
- Added `shutdown [delay] [message]` command to interactive REPL.
- Timer inner header fixed from 8-byte `!ii` to 12-byte `!iiHH` (mtype+subtype+channel+flags) — matches the timer module's expectation.
- Updated module docstring with new examples.

**Usage examples:**
```bash
# Immediate system shutdown
python3 -m umm.tools.send --trusted --shutdown

# Shutdown in 30 seconds with message
python3 -m umm.tools.send --trusted --shutdown --delay 30 "Scheduled maintenance"

# Interactive session as trusted agent
python3 -m umm.tools.send --trusted --interactive
```

---

### Next priorities

1. **Manual §5 — System Components**: router, timer, FSM, supervisor, GUI, parser, bridge. Use Claude Opus 4.6.
2. **Manual §6 — Building an Application**: sorting demo worked example.
3. **C0 infeed belt** — placeholder in `conveyor.html`; belt to gap parcels onto C1.
4. **Race condition handling** — idempotent command guard + msg_id correlation in `ConveyorSim`. Deliberately deferred.
5. **`umm.conf` port alignment** — currently says `port = 5300`; `DEFAULT_PORT` is 5100.
6. **Trusted agent in `umm.conf`** — supervisor.conf or umm.conf could specify `trusted = true` for the supervisor and other core agents so they attach as trusted automatically without a code change.

*Session 18: Phil Braham (design), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 18 addendum — umm_ctl.py flag conflicts and `help` command

### Problem
`umm_ctl.py` used argparse's built-in `-h/--help`, which fired before the command was parsed. This meant:
- `umm_ctl.py start parser --help` showed umm_ctl's help, not the parser's.
- `--config`, `--debug`, `--version` all existed in agents and could conflict.
- No way to inspect an agent's own help without running it directly.

### Changes (`umm_ctl.py`)

**`--help` handling:** `add_help=False` added to the ArgumentParser so argparse doesn't intercept `-h/--help`. Instead `-h/--help` is registered manually as a boolean flag. If `--help` is given with no command, umm_ctl's own help is printed. If given after a command with an agent name, it shows that agent's help.

**`help` command added:** `umm_ctl.py help [agent]` is now a first-class command:
```
python3 umm_ctl.py help             # umm_ctl's own help
python3 umm_ctl.py help parser      # shows parser's --help output
python3 umm_ctl.py help supervisor  # shows supervisor's --help output
python3 umm_ctl.py help send        # shows send tool's --help output
```
`_cmd_agent_help()` added — looks up the agent's module from umm.conf, falls back to a hardcoded built-in module table for standard agents not necessarily in the config.

**`--` separator documented and tested:** `parse_known_args()` already handles `--` correctly — everything after it goes into `extra_args` and is passed verbatim to the agent. Documented prominently in help text:
```
python3 umm_ctl.py start parser -- --help
python3 umm_ctl.py start supervisor -- --config supervisor.conf
```

**Conflict table documented in help text:**
- `--config` — umm_ctl uses for its own config file; supervisor also has `--config` for supervisor.conf. Must be placed after the agent name, or use `-- --config`.
- `--debug` — umm_ctl passes through automatically; don't repeat after agent name.
- `--version` — use the `version` command for running agents; `help <agent>` to see the agent's own version flag.
- `--help` — use `help <agent>` command or `-- --help` separator.

**`extra_args` warning expanded** to also cover `cleanstart` (which also accepts extra_args).

*Session 18 addendum: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 18 addendum 2 — send tool started via umm_ctl

`umm.tools.send` should be started via `umm_ctl.py` like all other tools, not run directly. The infrastructure for this was already in place (`foreground = true`, `after = manual`).

### Changes (`umm.conf`)

Added `[agent.send-trusted]` alongside the existing `[agent.send]`:

```ini
[agent.send]
module     = umm.tools.send
group      = dev
after      = manual
name       = Send
foreground = true
options    = --interactive

[agent.send-trusted]
module     = umm.tools.send
group      = dev
after      = manual
name       = SendTrusted
foreground = true
options    = --interactive --trusted
```

**Usage:**
```
python3 umm_ctl.py start send                        # interactive REPL, normal agent
python3 umm_ctl.py start send-trusted                # interactive REPL, trusted agent
python3 umm_ctl.py start send -- --shutdown          # immediate shutdown (trusted needed)
python3 umm_ctl.py start send-trusted -- --shutdown --delay 30 "Maintenance"
python3 umm_ctl.py start send -- 100,1 Float 85.3   # single message then exit
```

`build_command` already passes `--router` and `--port` to `umm.tools.send` via the standard `else` branch (all modules not explicitly listed get `--router`/`--port`). No code changes were needed in `umm_ctl.py`.

*Session 18 addendum 2: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 19 — Bug fixes: subtype renumbering fallout, timer, permanent subscriptions, send tool

### Context
This session fixed a cascade of bugs introduced by the session 18 subtype renumbering (10→51, 11→52, etc.) and related issues with the send tool, GUI timer, and permanent subscription registration.

---

### 1. Timer send tool — wrong subtype and TLV type (`umm/tools/send.py`)

- `send_timer_request()` was sending on `subtype=1` (Attach) instead of `ST_REQUEST=101`. Fixed to import and use `ST_REQUEST` from `umm.modules.timer`.
- Timer cancel was sending on `subtype=2` (AttachConfirm) instead of `ST_CANCEL=102`. Fixed similarly.
- Count `-1` (send tool's internal "forever" convention) was sent directly; timer rejects count < 0. Fixed by converting `-1` → `0` before packing.
- Inner message was wrapped in `TLV_SUBSPEC` (type 12) instead of `TLV_MSG` (type 11). Timer scans for `TLV_MSG` only. Fixed.

---

### 2. GUI subtype name bleed (`umm_gui/gui.html`)

`snName()` was using the global `SN` (UMM system subtype) table as fallback for ALL mtypes. So `(mtype=2, subtype=51)` displayed as `Timer,GetCapability` instead of `Timer,51`. Fixed: `SN` is only applied when `mtype===1`. Added per-mtype tables:
- `TMR_ST` for timer subtypes (101 Request, 102 Cancel, 103 Confirmed, 104 Error, -101 Fired)
- Added missing entries 112–115 (ListTypes, ListTypesResponse, ListSubs, ListSubsResponse) to the SN map

---

### 3. Permanent capability subscription used hardcoded old subtype (`umm_gui/server.py`)

`_register_capability` registered the permanent capability response subscription with hardcoded `subtype=11` (old number). Should be `UMMSubType.CAPABILITY_RESPONSE=52`. This caused all capability, list agents, and list types queries to fail on second click. Fixed to use the symbolic constant.

---

### 4. Router dedup breaking repeated list queries (`umm_gui/server.py`)

`list_agents` and `list_types` used temporary per-click registrations. On second click the router's dedup check found an identical subscription and silently ignored the new reg_id. The callback was stored under a new reg_id the router didn't know about, so responses were never delivered.

Fixed by switching to **permanent subscriptions** for `LIST_AGENTS_RESPONSE` and `LIST_TYPES_RESPONSE` (same pattern as capability responses), with a pending slot (`self._list_agents_pending`, `self._list_types_pending`) that any button click can set and wait on. Handlers: `_on_list_agents_response`, `_on_list_types_response`.

---

### 5. Permanent subscriptions failing silently — wrong event loop (`umm_gui/server.py`)

**Root cause of all permanent subscription failures:** The `UMMAgent` runs its own `asyncio.new_event_loop()` in a background thread. All agent I/O (`_async_register`, `_async_send`, `_write`) must run on `self._agent._loop`. Calling `await self._agent._async_register()` from the server's event loop runs the coroutine on the wrong loop — the `StreamWriter` belongs to the agent's loop, so the TCP write silently never happens.

**Rule:** All agent I/O from the server must go through either:
1. `run_in_executor(None, lambda: self._agent.register/send/unregister(...))` — `agent.register()` internally uses `run_coroutine_threadsafe` onto the agent's loop.
2. `asyncio.run_coroutine_threadsafe(coro, self._agent._loop).result()` — schedules on the agent's loop and blocks.

**Fix:** `_register_permanent_subs()` now uses `run_coroutine_threadsafe(..., self._agent._loop)` inside an executor thread for each registration. `get_version` and `subscribe_debug` fixed similarly — they were using `await self._agent._async_register/unregister/send` directly from the server's loop.

`_register_capability` split into two:
- `_register_capability()` — runs in executor, does mixin registration only (mixins write to agent's internal tables without TCP I/O, so no loop issue).
- `_register_permanent_subs()` — async, called after connect from both startup and the `connect` action handler; schedules all custom permanent subscriptions on the agent's loop correctly.

---

### 6. Timer auto-subscriptions removed from button handler

The "Send timer request" button was registering for `Timer,Confirmed` and `Timer,Error` before each send. This caused the two registration confirm messages to appear before the timer request, and introduced ordering/race issues. These are now permanent subscriptions registered at connect time in `_register_permanent_subs()`.

---

### 7. GUI timer action handler rewritten (`umm_gui/server.py`)

The `timer` action handler was silently failing due to a combination of import scope issues and exception swallowing. Rewritten as a self-contained `_send_timer()` function run entirely inside `run_in_executor` — all imports (struct, TLV, TLVBuffer, decode_all) local to the function, no external dependencies. Subtype hardcoded as `101` directly inside the executor function for clarity. Any exception now propagates correctly through `run_in_executor` to the `handle_cmd` exception handler.

---

### 8. handle_cmd debug logging

Added `logger.info("handle_cmd: action=%s", action)` at the top of `handle_cmd` to make it easy to trace which actions are being received. Can be removed once things are stable.

---

### Key architecture rule (important for future development)

**The GUI server has two event loops:**
1. The server's asyncio loop — handles WebSocket connections, HTTP, and the `handle_cmd` dispatch.
2. The agent's asyncio loop (`self._agent._loop`) — handles TCP I/O to the UMM router.

These are completely separate. Any method that writes to or reads from the agent's TCP connection must run on the agent's loop, not the server's loop. Always use `run_in_executor` + `agent.register/send/unregister()` for agent I/O from the server's async context.

---

### Next priorities

1. **Manual §5 — System Components**: use Claude Opus 4.6.
2. **Manual §6 — Building an Application**.
3. **C0 infeed belt** — placeholder in `conveyor.html`.
4. **Race condition handling** — deliberately deferred.
5. **`umm.conf` port alignment** — currently 5300 in umm.conf, DEFAULT_PORT is 5100.
6. **Trusted agent in umm.conf** — supervisor should attach as trusted automatically.
7. **Remove handle_cmd debug logging** once timer and subscription issues are confirmed stable.

*Session 19: Phil Braham (design), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 20 — GUI server isolation and conveyor GUI bug fixes

### Context

Two bugs in `umm_gui/server.py` were identified and fixed. The root cause of both was the original shared `broadcast()` model and its assumptions about message delivery.

---

### 1. Interactive GUI jams conveyor GUI; stopping one stops the other (`umm_gui/server.py`)

**Root cause:** `GUIServer` had a single `on_umm_message` callback registered for all UMM subscriptions and a single `broadcast()` method that sent every received message to **all** connected WebSocket clients. Both `gui.html` and `conveyor.html` shared `_clients` and `_msg_count`.

**Two failure modes:**
- **Flooding:** When `gui.html` subscribed to everything, every UMM message triggered `on_umm_message` → `broadcast()` → `conveyor.html` received all of them too, saturating its WebSocket and throttling the animation loop.
- **Shutdown kills both:** When `gui.html` disconnected, `handle_ws` unregistered all its `_ws_regs` from the shared UMM agent, removing subscriptions that `conveyor.html` depended on.

**Fix:** Replaced the shared `on_umm_message` + `broadcast()` with per-client message delivery:

- `_make_message_callback(ws)` — creates a closure per WebSocket client. Each closure delivers only to its own `ws` and maintains a per-client message counter in `_ws_msg_count: Dict[int, int]`.
- `_send_to(ws, data)` — single-client targeted send, replaces `broadcast()` for message delivery.
- `broadcast_status(data)` — retained for genuine all-client notifications (connect/disconnect).
- `register` and `subscribe_debug` actions — use `self._make_message_callback(ws)` instead of `self.on_umm_message`.
- `clear_log` — resets only the requesting client's counter, sends `cleared` only to that client.
- `connect` / `disconnect` — use `broadcast_status`, reset all per-client counters.
- Removed the two timer permanent subs (`TIMER, ST_CONFIRMED/ERROR`) that used the shared `on_umm_message` — these were driving the broadcast to all clients. Timer responses now arrive naturally via each client's own subscription.

---

### 2. Conveyor GUI receives no messages — channel default wrong (`umm_gui/server.py`)

**Root cause:** Once per-client callbacks replaced broadcast, each client's subscriptions had to actually work. The `register` action defaulted `channel` to `1` when the client sent no channel field:

```python
channel = int(cmd.get("channel", 1))   # WRONG
```

`conveyor.html` sends `{action:'register', mtype:0, subtype:0, ...}` with no `channel` field. Under the original broadcast model this was irrelevant — the conveyor received messages because the server agent received them and broadcast to everyone. With per-client callbacks, the subscription's channel matters. Channel=1 meant the subscription was stored in `_table[1]`, which only matched messages explicitly sent on channel 1.

The interactive GUI always sends `channel:ch` explicitly (from the channel input field), so it was unaffected.

**Fix:** Changed the default to `0` (ALL channels wildcard):

```python
channel = int(cmd.get("channel", 0))   # 0 = ALL channels wildcard
```

Channel=0 in a subscription is stored in `_table[0]`, which the router checks for every message regardless of the message's channel. This means `conveyor.html`'s wildcard subscription `(mtype=0, subtype=0, channel=0)` now receives all messages on all channels — matching the original broadcast behaviour.

**Note:** `conveyor.html` itself was reverted to its original state (registration sent in `ws.onopen`, not in a `status` handler). The intermediate changes to `conveyor.html` were unnecessary and introduced a new failure mode; all the required changes were in `server.py` only.

---

### Key architecture note — dual event loops in GUI server

The GUI server has two separate asyncio event loops:

1. **Server loop** — handles WebSocket connections, HTTP, and `handle_cmd` dispatch.
2. **Agent loop** (`self._agent._loop`) — handles TCP I/O to the UMM router.

All agent I/O (register, unregister, send) from the server's async context must go through `run_in_executor(None, lambda: self._agent.register/send/unregister(...))`. The `agent.register()` method internally uses `run_coroutine_threadsafe` onto the agent's loop. Calling `await self._agent._async_register()` directly from the server loop silently fails because the `StreamWriter` belongs to the agent's loop, not the server's.

---

### Files changed this session

- `umm_gui/server.py` — per-client callbacks, channel=0 default, broadcast_status
- `umm_gui/conveyor.html` — reverted to original (no changes from baseline)

---

*Session 20: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*
---

## Session 21 — Database agent, supervisor lifecycle fixes, router queuing

### Context
This session added the database agent and fixed a series of bugs in the supervisor and router that prevented critical agents from being monitored, restarted, and queued correctly.

---

### 1. Database agent — `umm/modules/database.py` (new file)

Full implementation of a config-driven TLV→SQL bridge agent (mtype=8).

**Features:**
- SQLite / PostgreSQL / MySQL backends (backend-specific drivers, lazy import)
- `database.conf` config file maps `mtype+subtype` → table + column definitions
- Column selector syntax: `Int[N]` / `Float[N]` etc. selects TLV by mword (position)
- Auto-columns: `id` (PK), `received_at`, `origin_site`, `origin_node`, `msg_id`
- `--create-tables` flag creates tables from config then exits
- `--permanent` flag attaches with `PERM_KEEP_CONN` (injected automatically by supervisor for C agents)
- Standard mixins: `CapabilityMixin`, `VersionMixin`, `DebugMixin`, `ShutdownMixin`
- Publishes `RecordSaved (8,101)` / `RecordError (8,102)` on the bus per insert

**`database.conf`** — annotated config file at project root. Tables: `temperature_readings`, `parcel_records`, `parcel_scans`, `bin_events`, `process_events`.

**`supervisor.conf`** — database agent added with `C` flag (Critical).

**`umm.conf`** — `[agent.database-setup]` in `setup` group for one-time table creation:
```bash
python3 umm_ctl.py start database-setup   # creates tables then exits
```

**`examples/sorting/capabilities.py`** — added mword constants:
```python
MW_BC_SORT_CODE     = 0
MW_BC_BIN_NUMBER    = 1
MW_BC_TRACKING_NUM  = 2
```

---

### 2. Bugs fixed

#### send() inside callback = deadlock (`umm/modules/database.py`, `umm/modules/supervisor.py`)

**Root cause:** `agent.send()` submits a coroutine to the agent's asyncio event loop and blocks waiting for the result (`fut.result(timeout=5.0)`). Callbacks run *on* that same event loop thread. Calling `send()` from inside a callback deadlocks — the future can never complete because the loop is busy dispatching the callback. After 5 seconds, `TimeoutError` is raised.

This affected:
- Database agent's `RecordSaved`/`RecordError` notifications — caused a spurious "Insert failed" log line after every successful insert.
- Supervisor's `_on_status_request` handler — caused 5-second stalls every time the GUI polled for agent status.

**Fix pattern** (both files): use `loop.call_soon_threadsafe()` to schedule the send without blocking:
```python
loop = self._client._loop
if loop and loop.is_running():
    loop.call_soon_threadsafe(
        lambda: loop.create_task(
            self._client._async_send(mtype, subtype, tlvs, 0)
        )
    )
```

#### `sys.exit(0)` in ShutdownMixin traceback (`umm/mixins.py`)

**Root cause:** `ShutdownMixin._on_shutdown_request()` called `sys.exit(0)` from inside an asyncio callback. Python 3.12+ causes `SystemExit` to propagate through the event loop internals, producing a noisy traceback and a "coroutine was never awaited" warning.

**Fix:** Removed `sys.exit(0)`. The correct shutdown path is `agent.disconnect()` → `loop.stop()` → `_stop_event.set()` → `agent.run()` returns → process exits naturally.

#### AGENT_ATTACHED lifecycle never published (`umm/router.py`)

**Root cause:** `_publish_lifecycle(AGENT_ATTACHED, ...)` was never called anywhere in the router. The docstring mentioned it but no code path invoked it. Supervisor's `_on_agent_attached` was therefore dead code — it subscribed correctly but the message never arrived. All agents showed `mtype=0` in supervisor status because the mtype is only recorded when `_on_agent_attached` fires.

**Fix:** Added `await self._publish_lifecycle(UMMSubType.AGENT_ATTACHED, from_attach)` at the end of `_svc_attach`, after the confirm is sent.

#### AGENT_DETACHED not published on clean shutdown (`umm/router.py`)

**Root cause:** `_svc_detach` (called when an agent sends a proper `DETACH` message) set `EAS_DETACHED` and called `_handle_disconnect`. The `finally` block in `_handle_disconnect` skipped `_publish_lifecycle` because `EAS_DETACHED` was already set. Result: clean shutdowns were invisible to supervisor — `_on_agent_detached` never fired, no restart was scheduled.

**Fix:** Added `await self._publish_lifecycle(UMMSubType.AGENT_DETACHED, from_attach)` in `_svc_detach`, before `_handle_disconnect`.

#### Critical agents could give up restarting (`umm/modules/supervisor.py`)

**Root cause:** `_schedule_restart` set `given_up = True` after `max_restarts` attempts for all agents. A Critical (`C`) agent that had accumulated 5+ failures (during earlier debugging) would never restart again.

**Fix:** Critical agents never set `given_up`. When `restart_count` exceeds `max_restarts`, a warning is logged and the count is pinned at `max_restarts` (keeping delay capped at `RESTART_MAX_DELAY=60s`). Essential (`E`) agents retain the original give-up behaviour.

#### `--permanent` not injected into C agent launch commands

**Root cause:** The injection code was correct but the Mac was running an older `supervisor.py` that predated the injection logic. Confirmed by checking the supervisor log — command showed no `--permanent` flag. Once the current `supervisor.py` is deployed, injection works correctly (verified by running `parse_supervisor_conf` locally — database parsed as `CRITICAL`).

**Without `--permanent`:** the router treats the agent as a transient connection and discards messages while it is offline. The attach flag `PERM_KEEP_CONN` must be set at attach time for queuing to work.

---

### 3. Log verbosity reduction

- **`umm/modules/timer.py`**: `Timer N firing` log line demoted from INFO to DEBUG. At 120ms intervals with two belts, this was generating ~8 INFO lines per second.
- **`examples/sorting/sorting_demo.py`**: C1/C2 tick pulse counter log lines demoted from INFO to DEBUG.

---

### 4. Shutdown restart hint (design note for future implementation)

When supervisor sends `(mtype, 4)` to stop a C/E agent for an upgrade or reconfiguration, it currently restarts it anyway (by design — C agents should always be running). But for intentional permanent decommissioning this is wrong.

**Proposed:** Add an optional `Bool` TLV to the `(mtype, 4)` shutdown message payload. Absent or `true` = restart as normal. `false` = permanent stop, skip restart.

**Simpler alternative:** set a `no_restart` flag on the `ManagedAgent` struct before supervisor sends the shutdown — supervisor already knows when it is the initiator, so it can set the flag before sending `(mtype, 4)` and clear it in `_on_agent_detached` after consuming it.

---

### Key files changed this session

| File | Change |
|------|--------|
| `umm/modules/database.py` | New — full database agent |
| `database.conf` | New — annotated config |
| `umm/mixins.py` | Removed `sys.exit(0)` from ShutdownMixin |
| `umm/router.py` | AGENT_ATTACHED published; AGENT_DETACHED published on clean detach |
| `umm/modules/supervisor.py` | Status send deadlock fixed; C agents never give up; `--permanent` injection (was already there) |
| `umm/modules/timer.py` | Firing log demoted to DEBUG |
| `examples/sorting/sorting_demo.py` | Pulse tick log demoted to DEBUG; mword constants used in ST_BC_RECORD send |
| `examples/sorting/capabilities.py` | `MW_BC_SORT_CODE/BIN_NUMBER/TRACKING_NUM` constants added |
| `supervisor.conf` | Database agent added with C flag |
| `umm.conf` | `[agent.database-setup]` added in setup group |

---

### Quick reference — database agent mtypes

| mtype | subtype | Name | Direction | Notes |
|-------|---------|------|-----------|-------|
| 8 | 101 | RecordSaved | DB→* | Char(table) Int(mtype) Int(subtype) |
| 8 | 102 | RecordError | DB→* | Char(table) Char(error) |

---

### Architecture note — PERM_KEEP_CONN queuing

When an agent attaches with `AttachFlag.PERM_KEEP_CONN`, the router retains its subscriptions and queues any matching messages while it is offline. On reconnect, the agent re-registers its subscriptions and the router flushes the queue.

For this to work:
1. Supervisor must inject `--permanent` into C agent launch commands ✓
2. Agent's `_main()` must set `attach_flags = AttachFlag.PERM_KEEP_CONN` and `reconnect = True` ✓
3. Agent must implement `_on_reconnect` to re-register subscriptions ✓

The queuing is router-side and transparent — the agent just processes the burst of messages normally on reconnect.

---

*Session 21: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 22

### Summary

- Fixed PERM_KEEP_CONN re-attach: queued messages now delivered on reconnect
- Parser recording (`--record`) and send replay (`--replay`) implemented
- Parser send/replay functionality removed (moved to `umm.tools.send`)
- Database agent: `RecordSaved` notifications off by default; `--notify` flag and `SetNotify(103)` message added
- Channel numbering corrected in `DESIGN_NOTES.md` and `HANDOVER.md` (old scheme had APP=0; correct is ALL=0, APP=1 … BRIDGE=7)
- `umm.conf` `--interactive` removed from send agent options
- `send.py` dispatch reordered: `--file`/`--replay` take priority over `--interactive`

---

### 1. PERM_KEEP_CONN re-attach fix (`umm/router.py`)

Three bugs prevented queued messages from being delivered to reconnecting permanent agents.

#### Bug 1 — `_alloc_attach` always created a new slot

When a permanent agent reconnected, `_alloc_attach` gave it a brand new attach ID.
The old offline slot (with its queue and retained subscriptions) was never linked to
the new TCP connection, so the router had no way to match them.

**Fix:** Re-attach detection moved into `_svc_attach`. Once the ATTACH message is
decoded and the process name is known, `_svc_attach` scans `_attaches` for an
existing slot that is: permanent, `EAS_OFFLINE`, and has the same `process_name`.
If found, the new TCP writer is migrated onto the old slot and the temporary slot
from `_alloc_attach` is released (`EAS_UNUSED`).

#### Bug 2 — `EAS_REATTACH` was never set

`EAS_REATTACH` was defined (0x10) and checked in `_svc_register`, but never set
anywhere. As a result the queue-flush branch in `_svc_register` never fired.

**Fix:** `_svc_attach` sets `EAS_REATTACH` on the reinstated old slot when a
returning permanent agent is detected, and sends `AttachConfFlag.PERM_REATT`
instead of `PERM_NEW`.

#### Bug 3 — flush triggered on `LAST_REQUEST` which was never sent

`_flush_queue` was triggered by `LAST_REQUEST` flag in `_svc_register`. The agent
never sets this flag — `_async_register` always sends `flags=0`.

**Fix:** Queue is flushed immediately after `ATTACH_CONFIRM` is sent in `_svc_attach`,
on the `PERM_REATT` path only. This is the right place: the agent is ready to
receive and no registrations have arrived yet, so message ordering is correct.
`LAST_REQUEST` path in `_svc_register` retained as a safety net but no longer
relied upon.

#### Additional `_flush_queue` improvement

Mid-flush write failures now re-queue the undelivered tail (previously the remaining
messages were silently dropped). `EAS_REATTACH` is cleared alongside `EAS_OFFLINE`
once the flush completes.

#### Re-attach flow (after fix)

```
Agent reconnects → _alloc_attach (temp slot)
→ _svc_attach decodes process_name
  → finds old offline permanent slot with same name
  → migrates writer to old slot, releases temp slot
  → sets EAS_REATTACH, sends PERM_REATT confirm
  → calls _flush_queue → queued messages delivered
  → publishes AGENT_REATTACHED lifecycle event
Agent re-sends subscriptions → _svc_register skips (EAS_REATTACH set, subs retained)
EAS_REATTACH cleared by _flush_queue
```

---

### 2. Parser recording and send replay

#### Problem

The parser had `--replay` and an interactive send facility. These were
redundant with `umm.tools.send` and added maintenance burden to a monitor-only tool.

#### Solution

- `parser.py`: removed `--log`, `--replay`, `--replay-delay` CLI args and
  `MessageLog.replay()` method and `run_interactive()` function
- `parser.py`: added `--record FILE` — records all messages to a JSON-lines file
  alongside normal display output (display is unaffected)
- `send.py`: added `--replay FILE`, `--speed N`, `--timestamps {relative|original|now}`
- `agent.py`: `send()`, `_async_send()`, `_make_msg()` all gained optional `tm: UTime`
  parameter for injecting a specific timestamp (used by replay)

#### JSON recording format

One JSON object per line. First line is a metadata header:

```json
{"_umm_recording": true, "_version": 1, "_recorded": "2026-05-10T...Z"}
{"ts_secs": 1778366116, "ts_ms": 414, "channel": 1, "mtype": 1004, "subtype": 101, "flags": 0, "tlvs_hex": ""}
```

Timestamp fields come from the **message header** `UTime`, not wall clock, so
relative timing between messages is preserved exactly.

#### Replay timestamp modes

| Mode | Behaviour |
|------|-----------|
| `relative` (default) | Shifts all timestamps to start from now; preserves inter-message gaps |
| `original` | Sends exact recorded `UTime` values |
| `now` | Ignores recorded timestamps; agent stamps with current time |

#### Usage

```bash
# Record
python3 -m umm.modules.parser --record session.json

# Replay at real time
python3 -m umm.tools.send --replay session.json

# Replay at double speed with original timestamps
python3 -m umm.tools.send --replay session.json --speed 2.0 --timestamps original

# Via runumm
./runumm start send --replay session.json
```

#### `--interactive` removed from umm.conf send agent options

`umm.conf` had `options = --interactive` hardcoded for `[agent.send]`. When
`--replay` was added via `runumm`, both flags were on the command line and
`--interactive` won (checked first). Fixed two ways:
1. Removed `--interactive` from `umm.conf` — send already falls back to
   interactive mode when no other mode is given
2. Reordered dispatch in `send.py`: `--file` and `--replay` are checked before
   `--interactive` so explicit modes always win

---

### 3. Database agent — notification flag

#### Problem

The database agent published `RecordSaved(101)` to the bus after every successful
INSERT. This generated significant traffic (two messages per scan cycle) that was
only useful for debugging.

#### Solution

- `RecordSaved` notifications default **off**
- `RecordError(102)` always fires — silent failures are worse than noise
- `--notify` CLI flag enables notifications at startup
- `SetNotify(103)` message enables/disable at runtime without restart

#### SetNotify protocol

```
Send: (mtype=8, subtype=103)  Bool(1)   # enable
Send: (mtype=8, subtype=103)  Bool(0)   # disable
```

`Int` is also accepted as a convenience. No response is sent — state change is
logged to the debug channel.

#### Updated mtype table

| mtype | subtype | Name | Direction | Notes |
|-------|---------|------|-----------|-------|
| 8 | 101 | RecordSaved | DB→* | Char(table) Int(mtype) Int(subtype) — only when notify enabled |
| 8 | 102 | RecordError | DB→* | Char(table) Char(error) — always sent |
| 8 | 103 | SetNotify   | *→DB | Bool(enable) — toggle notifications |

---

### 4. Channel numbering correction

Documentation in `DESIGN_NOTES.md` and `HANDOVER.md` still reflected an earlier
channel scheme (APP=0, CONFIRM=1, … BRIDGE=6). Corrected to match `messages.py`:

| Value | Name | Notes |
|-------|------|-------|
| 0 | ALL | Wildcard — never sent |
| 1 | APP | Application bus |
| 2 | CONFIRM | Delivery confirmations |
| 3 | DEBUG | Runtime debug |
| 4 | META | Capability/version responses |
| 5 | HEARTBEAT | Supervisor liveness |
| 6 | SUPERVISOR | Supervisor control |
| 7 | BRIDGE | Inter-router bridge |
| 8–9 | — | Reserved |
| 10+ | — | User-defined |
| 128–255 | SIM | Simulation convention |

---

### Key files changed this session

| File | Change |
|------|--------|
| `umm/router.py` | `_svc_attach`: permanent re-attach detection, slot migration, post-confirm flush; `_flush_queue`: clears `EAS_REATTACH`, re-queues on mid-flush failure |
| `umm/modules/parser.py` | `MessageLog` upgraded (channel, ts_secs, ts_ms, tlvs_hex); `--record` added; `--log`/`--replay`/`--replay-delay` removed; `run_interactive()` removed |
| `umm/tools/send.py` | `replay_recording()` added; `--replay`/`--speed`/`--timestamps` added; dispatch reordered (`--file`/`--replay` before `--interactive`) |
| `umm/agent.py` | `send()`, `_async_send()`, `_make_msg()` gain optional `tm: UTime` param |
| `umm/modules/database.py` | `_notify` flag (default False); `--notify` CLI; `SetNotify(103)` handler; `RecordError` always fires |
| `umm.conf` | `--interactive` removed from `[agent.send]` and `[agent.send-trusted]` options |
| `DESIGN_NOTES.md` | Channel table corrected; re-attach flow documented; parser recording documented; database notify documented |

---

*Session 22: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 23 — Feed agent refactor; database message-driven config discussion

### Feed agent — sources via messages (COMPLETE)

`umm/modules/feed.py` refactored so feed URLs are no longer loaded from
`feed.conf`.  The agent starts with no sources and receives them entirely
via `AddFeed (14, 201)` messages.

**What changed:**
- `FeedConfig.sources` field removed — config holds only connection defaults
- `load_config()` — `[feed.*]` section parsing removed; stale sections produce
  a warning pointing to the new pattern
- `FeedModule.__init__` — `_sources` initialised as empty dict (was populated
  from config)
- `FeedModule.run()` — "announce configured sources" block removed; startup log
  updated to say "waiting for AddFeed messages"
- `_on_add_feed` — interval TLV changed from `TLV_UINT` to `TLV_INT` so the
  initiator can send `{int N}` without needing a separate `{uint N}` syntax

**New files:**
- `feed.conf` — settings only (`poll_interval`, `dedupe_window`, `user_agent`);
  no `[feed.*]` sections
- `feed_init.conf` — initiator script that sends AddFeed messages at startup;
  this is the canonical way to supply the initial URL list

**Startup pattern:**
The supervisor starts the feed agent, then runs the initiator with
`feed_init.conf` after a short wait.  The initiator connects, sends AddFeed
messages, and exits.  The same messages work at runtime from any agent or
the send tool — the API is identical regardless of when they're sent.

**supervisor.conf entry (example):**
```
[agent.feed-init]
module  = umm.modules.initiator
group   = feed
after   = feed
once    = true
options = --config feed_init.conf
```

---

### Database agent — message-driven subscription config (DISCUSSION, not implemented)

**Proposal:** Remove `[table.*]` sections from `database.conf` so that
subscriptions (mtype/subtype → table + column mapping) are also configured
via messages, following the same pattern as the feed agent.

**Why it fits UMM philosophy:**
The initiator becomes the configuration layer for all runtime-configurable
agents.  Static config files hold only what genuinely cannot change — connection
parameters, credentials, defaults.  Everything else is delivered as messages,
making the startup script and the runtime management API identical.

**Proposed message protocol (mtype=8):**

| Subtype | Name | Direction | Payload |
|---------|------|-----------|---------|
| 201 | AddSubscription | *→DB | `Char(table) Int(mtype) Int(subtype) Json(columns)` |
| 202 | RemoveSubscription | *→DB | `Char(table)` |
| 203 | CreateTable | *→DB | `Char(table)` — explicit schema creation |

The `columns` Json would use the same syntax as the current `database.conf`
column definitions, e.g.:
```json
[
  {"type": "Char", "mword": 0, "column": "source",    "sql_type": "TEXT"},
  {"type": "Char", "mword": 1, "column": "title",     "sql_type": "TEXT"},
  {"type": "UTime",            "column": "published",  "sql_type": "DATETIME"}
]
```

**Design decisions to make before implementing:**

1. **Table creation** — `--create-tables` currently runs at startup from config.
   With dynamic subscriptions, table creation needs to be triggered explicitly
   (via `CreateTable (8, 203)`) or implicitly (flag in `AddSubscription` payload,
   e.g. `Bool(create_if_missing)`).  Recommendation: add a `Bool` TLV to
   `AddSubscription` — `true` = CREATE TABLE IF NOT EXISTS before subscribing.

2. **Persistence on restart** — dynamic subscriptions are lost if the database
   agent restarts.  The initiator script is the persistence layer: replaying
   `feed_init.conf` equivalent after restart restores all subscriptions.
   This is by design — the initiator is the authoritative source of truth,
   not the agent's in-memory state.  Worth making explicit in docs.

3. **`database.conf` migration** — the existing `[table.*]` sections could be
   kept as a deprecated fallback (load at startup, warn that message-driven
   config is preferred), or removed immediately.  Given the feed agent
   precedent, immediate removal is cleaner.

4. **Column definition complexity** — the current `database.conf` column syntax
   (`Char[0] -> column_name TEXT`) is compact but not easily TLV-encodable.
   JSON is the right encoding for the columns definition.  The `JsonType`
   (TLV_JSON = 18) already exists in the type system.

**Implementation effort:** medium.  The subscription handling code in
`DatabaseModule` already exists as the `[table.*]` parsing + `register()` loop.
The main work is:
- Replace `load_config()` table parsing with `_on_add_subscription()` handler
- Write the JSON column parser
- Add `CreateTable` handler
- Update `database.conf` to settings-only (same pattern as `feed.conf`)
- Write `database_init.conf` initiator script

*Session 23: Phil Braham (design), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 23 (continued) — Initiator retired; send --file is the startup mechanism

### Decision

`umm/modules/initiator.py` and `umm_initiator.py` have been deleted.
`umm.tools.send --file` does everything the initiator did and more
(timer shortcuts, replay, trusted attach, full type registry).
Keeping both was pure duplication.

### Files deleted
- `umm/modules/initiator.py`
- `umm_initiator.py`
- `feed_init.conf` (consolidated into `init.conf`)

### Files changed

**`init.conf`** — rewritten in send-script format, now the single startup
script covering all agents:

```
wait 2.0
14 201 Char "bbc-world" Char "https://feeds.bbci.co.uk/news/world/rss.xml"
14 201 Char "hacker-news" Char "https://news.ycombinator.com/rss" Int 120
...
```

Old initiator syntax (`Message 14 201 {char "x"}`) replaced by send syntax
(`14 201 Char "x"`).  The type names come from the full registry so any
registered application type works, not just the hardcoded handful the
initiator supported.

**`supervisor.conf`** — startup entry updated:
```
# was:
# Start "python3 -m umm.modules.initiator --config init.conf ..."
# now:
Start "python3 -m umm.tools.send --file init.conf --router {router} --port {port}"
```

**`umm/modules/supervisor.py`** — docstring example updated to match.

**`feed.conf`** — comment updated to reference `init.conf` not `feed_init.conf`.

**`umm/modules/feed.py`** — docstring and `_on_add_feed` comments updated.

### Where feed.py lives

`umm/modules/feed.py` — same directory as all other service modules
(timer, database, supervisor, parser, bridge, etc).

### send --file exit behaviour

`send --file` runs the script then hits `finally: agent.disconnect()` and
exits cleanly.  No extra flags needed.  The `--interactive` fallback only
fires when no mode is specified, so it never interferes with `--file`.

### One init.conf — design note

The intent is one `init.conf` covering all agents, with future sections for
database subscriptions once that work is done (session 24).  If the file
grows unwieldy, `Include` support can be added to `send --file` as a small
self-contained feature — but that's not needed yet.

*Session 23 continued: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 23 (continued) — Bug fix and installation note

### Bug fix: msg.payload → msg.tdata.value

All four message handlers in `umm/modules/feed.py` were using `msg.payload`
which does not exist on `UMMMsg`.  The correct pattern (consistent with
database.py and other modules) is:

```python
tlvs = decode_all(msg.tdata.value) if msg.tdata and msg.tdata.value else []
```

`tdata` is the outer TLV wrapper; `.value` is the raw bytes passed to
`decode_all()`.  Affected handlers: `_on_add_feed`, `_on_remove_feed`,
`_on_poll_now`, `_on_list_feeds`.  All fixed in session23c archive.

### feedparser installation — needs a manual section

The feed agent depends on the third-party Python package `feedparser`.
This is the only external dependency UMM has added so far and needs a
section in the manual covering installation.

Key points for the manual:

- `brew install feedparser` does **not** work — feedparser is a Python
  package, not a Homebrew formula
- The correct command depends on which Python is running UMM:
  ```
  python3 -m pip install feedparser
  ```
- On macOS with Homebrew-managed Python the above may fail with an
  "externally managed environment" error; fix with:
  ```
  python3 -m pip install feedparser --break-system-packages
  ```
- If using a virtual environment, activate it first then `pip install feedparser`
- To verify: `python3 -c "import feedparser; print(feedparser.__version__)"`
- Suggested location in manual: §4 Installation, as a new sub-section
  "Optional dependencies" or alongside the feed agent in §5 System Components

### Next session — RSS feed format

The feed agent publishes every item from every configured source.  The next
piece of work is understanding RSS/Atom feed structure well enough to:

- Document what fields are reliably present across different feed providers
  (title, link, published, author, tags are common; summary/content vary)
- Decide whether additional TLV fields should be added to the item message
  (e.g. enclosures for podcasts, full content vs summary)
- Consider per-source field mapping if providers use non-standard extensions
- Review what the string-match plugin needs to support for useful title/
  category filtering

Starting point for next session: load the feed agent, send a few AddFeed
messages from init.conf, capture some real item messages with the parser,
and inspect the actual field values coming through.

*Session 23 final: Phil Braham (design), Claude Sonnet 4.6 (implementation). May 2026.*

---

## Session 24 — Feed Browser GUI

### Overview

This session built `umm_gui/feed_browser.html` — a live RSS/Atom feed browser that connects to the UMM router via WebSocket, subscribes to `FeedItem (15, 101)` messages, and displays them as a continuously updating article list with optional keyword filtering.

---

### New file: `umm_gui/feed_browser.html`

Accessible at `http://localhost:8766/feed` (served by the existing `server.py`).

**Features:**
- Auto-connects to `localhost:8765` on load
- Sidebar feed list populated by `ListFeeds (14, 204)` on connect and updated by lifecycle messages (`FeedAdded 14,101`, `FeedStatus 14,104`, etc.)
- Add/remove feeds at runtime (sends `AddFeed 14,201` / `RemoveFeed 14,202`)
- Filter bar: type a word or phrase and press Apply — re-subscribes with `CONTAINS` match on the title slot so the router does the filtering; client-side filtering also applied to already-received items immediately
- Sort by newest / oldest / source
- Article cards: source badge, relative timestamp, categories, clickable headline (opens in new tab), summary, author
- Podcast items with `enclosures[0]` get an inline HTML5 audio player with scrubber
- `PollNow (14, 203)` sent for all known feeds on connect (triggers a forced re-poll that bypasses the deduplication cache)

---

### Changes to `umm_gui/server.py`

Added route `/feed` → `feed_browser.html` (alongside existing `/conveyor` route).

---

### Changes to `umm/modules/feed.py`

**`SeenItems.clear_source(name)`** — new method. Removes all cached item IDs whose key starts with `"{name}:"`. Allows a forced re-poll to republish all current feed items as if they were new.

**`FeedModule._on_poll_now`** — now calls `self._seen.clear_source(src.name)` before resetting `last_poll`. A `PollNow (14, 203)` message now genuinely re-publishes all current feed items, not just ones that arrived after the previous poll.

---

### Changes to `umm_ctl.py`

**`cmd_agents`** — new command. Queries the live router (`ListAgents 1,110`) and supervisor (`ST_AGENT_STATUS 12,104`) simultaneously and displays a merged table of all attached agents including plugins. Run with `python3 umm_ctl.py agents`.

---

### Key bugs found and fixed during this session

#### 1. `value_text` vs `value` in WebSocket message format

`server.py`'s `format_tlv` puts the decoded string in `"value"`, not `"value_text"`. The browser code was reading `t.value_text` everywhere, so all TLV field extraction silently returned `undefined`. Fixed with a `tlvValue(t)` helper.

#### 2. WebSocket message nesting

`server.py` wraps every UMM message as `{"type":"message","data":{...},"count":N}`. The browser was reading `msg.mtype` directly off the outer envelope. Fixed by unwrapping: `const msg = outer.data`.

#### 3. IGNORE TLV type_id causes `build_tlvs` to truncate

An IGNORE subscription slot must use `type_id=8` (Char) not `type_id=0`. `type_id=0` is `TLV_TERM` — the terminator that ends TLV buffer encoding. `build_tlvs` in `server.py` hits `TLV_TERM` and stops encoding, so the `CONTAINS` TLV that follows is never written. The router and plugin both check `mword == MWORD_IGNORE_MATCH` before inspecting type_id, so using Char for the IGNORE slot is safe.

The IGNORE slot also needs a non-empty value (`' '`) because `build_tlvs` skips encoding when `val_text` is falsy.

#### 4. Filter subscription mword confusion

The IGNORE sentinel is `mword=0xFFFFFFFF` (MWORD_IGNORE_MATCH). `MatchOp.CONTAINS=6` goes in the mword of the CONTAINS slot. These were previously swapped (0 and 6), so the source was being matched with CONTAINS and the title was being matched with EQ.

#### 5. JSON TLV TYPE_NAME case

`JsonType.TYPE_NAME = "JSON"` (all caps). The browser was checking `t.type_name === 'Json'` (mixed case) and never finding the JSON TLV. Fixed to check `t.type_id === 18 || t.type_name === 'JSON'`.

#### 6. feedparser uses `link` not `url`

The JSON blob uses `j.link` for the article URL (feedparser's field name). The browser was reading `j.url` and getting `undefined` for all links.

#### 7. Duplicate feed sidebar entries

Multiple code paths (`handleFeedLifecycle` for subtypes 101 and 104, `handleFeedItem`) were independently creating entries in the `feeds{}` object. Consolidated into a single `upsertFeed(name, url, itemCount, ok, err)` function. The function normalises the name (strips surrounding quotes and whitespace) so encoding artefacts don't create false duplicate keys.

Lifecycle subscriptions `(14, 101–104)` were not unregistered on disconnect, so reconnecting added a second set of subscriptions. After two connects every lifecycle message triggered two callbacks. Fixed by tracking reg_ids in `lifecycleRegIds[]` and resetting on disconnect.

Adding a feed from the GUI was optimistically creating a sidebar entry immediately (before `FeedAdded` confirmation from the agent). If the feed agent wasn't running this produced a phantom entry. Fixed: sidebar entry is only created when the confirmation arrives.

#### 8. Timestamp display

BBC feed published timestamps (`~1778000000`) are close to `Date.now()/1000` in May 2026. Clock skew or slightly future-dated items produced negative diffs that fell through to `Math.round(diff/86400)` displaying as large negative numbers. Fixed: negative diffs show "just now"; items older than 7 days show an actual date rather than "N days ago".

#### 9. Links opening as `file://` paths

Opening `feed_browser.html` directly from disk (rather than via `http://localhost:8766/feed`) means the page origin is `file://...`. Any URL that isn't strictly `https://...` gets the file:// prefix prepended by the browser. Fixed by: (a) stripping surrounding quotes from all string fields via `stripQ()`, and (b) validating that the URL starts with `http(s)://` before using it as an `href`.

---

### Feed browser WebSocket protocol reference

All messages follow `server.py`'s standard envelope: `{"type":"message","data":{...},"count":N}` for UMM messages, `{"type":"registered","reg_id":N,"registration":{...}}` for confirmations.

**Subscriptions the browser registers:**

| mtype | subtype | match_tlvs | Purpose |
|-------|---------|------------|---------|
| 14 | 101 | none | FeedAdded |
| 14 | 102 | none | FeedRemoved |
| 14 | 103 | none | FeedError |
| 14 | 104 | none | FeedStatus |
| 15 | 101 | none (or Char[ignore], Char[contains] "word") | FeedItem |

**Messages the browser sends:**

| mtype | subtype | payload | Purpose |
|-------|---------|---------|---------|
| 14 | 201 | Char(name) Char(url) [Int(interval)] | AddFeed |
| 14 | 202 | Char(name) | RemoveFeed |
| 14 | 203 | Char(name) | PollNow — forces re-poll, bypasses dedup |
| 14 | 204 | (none) | ListFeeds — triggers FeedStatus for each source |

---

### IGNORE TLV encoding rule (important for all GUI clients)

When building a subscription with positional slots, the IGNORE slot must be encoded as:

```javascript
{ type_id: 8, mword: 4294967295, value: ' ' }  // type_id=8 (Char), mword=MWORD_IGNORE_MATCH
```

- `type_id=0` is `TLV_TERM` and truncates the buffer — never use it for IGNORE
- A non-empty `value` (`' '`) is needed because `build_tlvs` skips encoding when the value is empty/falsy
- The router and all plugins check `mword == MWORD_IGNORE_MATCH` before inspecting type_id, so Char is safe

---

### `cmd_agents` — live agent list

```bash
python3 umm_ctl.py agents
```

Connects briefly to the router, sends `ListAgents (1, 110)` and `ST_AGENT_STATUS (12, 104)` simultaneously, waits up to 3 seconds for responses, then displays a merged table showing every attached agent (including plugins started by supervisor) with name, mtype, attach_id, pid, restart policy, restart count, and kind (router / supervisor / plugin / supervised / agent).

This is the correct way to see everything running — `status` only knows about processes with pid files from `umm_ctl.py start`.

---

### Next priorities

1. **Database agent message-driven config** (Session 23 design discussion) — replace `database.conf` `[table.*]` sections with `AddSubscription (8, 201)` messages, following the feed agent pattern.
2. **`umm.conf` port alignment** — currently `port = 5300`; `DEFAULT_PORT = 5100`. Decide on one canonical port.
3. **Trusted agent** — supervisor should attach with `AttachFlag.TRUSTED` automatically.
4. **C0 infeed belt** — placeholder in `conveyor.html`.
5. **Manual §5 / §6** — system components and building-an-application chapters. Use Claude Opus 4.6.
6. **Feed browser improvements** — filter on summary as well as title (requires separate JSON match plugin or client-side-only); per-feed polling interval display; "mark as read" / persistence across sessions.

*Session 24: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 25 — TLV header redesign: match/meta split (May 2026)

### Summary

The 4-byte M-word in the TLV header has been replaced by two separate 4-byte fields: **match** and **meta**. This is a breaking wire-format change — all agents and the router must be updated together (they are all in this codebase, so this is straightforward).

Several parser and GUI improvements were also made in this session.

---

### 1. TLV wire format — `umm/core/tlv.py`

**Old header (12 bytes):** `type(4) + mword(4) + length(4)`

**New header (16 bytes):** `type(4) + match(4) + meta(4) + length(4)`

The `TLV` dataclass gains a `meta: int = 0` field alongside the renamed `match: int` (was `mword`). New constant `META_NONE = 0`. The struct format changes from `!III` to `!IIII`.

**Semantics:**
- `match` — in subscription TLVs: comparison operator index (EQ=0, GT=2, etc.). In published messages: passed through by the router unchanged. Agents may use it as a free sub-qualifier (e.g. to distinguish current/max/min readings of the same type). Special value `0xFFFFFFFF` (MWORD_IGNORE_MATCH) on a subscription TLV skips the positional slot entirely.
- `meta` — semantic qualifier for the type. `0` means absent (always matches). Meaning is type-dependent: for `Float`, `meta=1` means temperature; for `Char`, `meta=1` means filename. Router matching rule: if either side has `meta=0` it passes; otherwise both must carry the same non-zero value.

### 2. Meta registry — `umm/core/meta.py` (new file)

`MetaRegistry` maps `(type_id, meta_value) → name`. Module-level singleton `meta_registry`. Pre-populated with 40 entries:

- `Float`: temperature(1), pressure(2), humidity(3), speed(4), voltage(5), current(6), power(7), distance(8), mass(9), frequency(10), angle(11), flow-rate(12), luminance(13), concentration(14)
- `Char`: filename(1), url(2), email(3), hostname(4), json-string(5), mime-type(6), command(7), identifier(8)
- `Int`/`UInt`: status(1), error-code(2), count(3), index(4), priority(5), version(6), flags(7)
- `Bool`: enabled(1), alarm(2), connected(3), running(4)

Application code registers additional entries with `meta_registry.register(type_id, meta_value, name)`. Values 1–99 reserved for UMM built-ins, 100–999 for manufacturing, 1000+ free for applications.

### 3. Router meta matching — `umm/core/registry.py`

`TypeRegistry.match()` now has a meta check between type-id and value matching:
```python
if msg_tlv.meta != 0 and sub_tlv.meta != 0 and msg_tlv.meta != sub_tlv.meta:
    return False
```

### 4. FName type removed

`FNameType` (type_id=14) and all references removed from `builtin.py`, `plugins/string_match.py`, `modules/database.py`. Use `Char` with `meta=CHAR_META_FILENAME` (meta value 1) instead. The string plugin now only handles `TLV_STRING` (type_id=8).

### 5. Updated factory helpers — `umm/types/_base.py`

```python
make_tlv(value, match=0, meta=0)
make_subscription_tlv(value, op=MatchOp.EQ, meta=0)
```

Both accept `meta`. The `MetadataField` enum removed (superseded by meta registry). `BridgeOp` retained.

### 6. Display format

The agreed display format across all tools is:

```
TypeName[meta]{match} value
```

- `[meta]` — square brackets, shown only when meta ≠ 0. Named if registered, numeric otherwise: `Float[temperature]`, `Int[10]`
- `{match}` — curly brackets, shown only when match ≠ 0. Named operator symbol if known, numeric otherwise: `Float{>}`, `Int{30}`
- Both omitted when zero: `Float 25.3`, `Char "hello"`

Examples:
```
Float[temperature] 85.3          meta=temperature, no match-word
Float[temperature]{>} 80.0       subscription: temperature > 80
Int[10]{30} 456                  meta=10 (unknown), match-word=30 (unknown)
Char[filename] "data.csv"        filename string
```

### 7. Parser improvements — `umm/modules/parser.py`

- **Meta display** as `[name]` or `[n]` in square brackets
- **Match-word display** as `{symbol}` or `{n}` in curly brackets
- **`--json-decode` flag** — off by default; JSON TLVs show as quoted strings. With `--json-decode` they expand inline
- **Startup capability flood suppressed** — `(1, CAPABILITY_RESPONSE)` on ch=META consumed internally without printing
- **`MessageLog`** records an optional `tlvs_meta` field (human-readable list of meta names for TLVs that carry non-zero meta). `tlvs_hex` remains the authoritative round-trip source

### 8. `send.py` — `Float[temperature]` bracket syntax

`parse_tlv_args()` accepts `TypeName[meta]` notation directly on the type token:

```
Float[temperature] 25.3              # meta by name
Float[1] 85.3                        # meta by number
Float[temperature] > 80.0            # subscription with meta
Float[] 25.3                         # explicit no-meta
Float 25.3                           # same, brackets omitted
Char[filename] "sensor_1.log"
```

### 9. GUI changes — `umm_gui/gui.html`, `umm_gui/server.py`

**TLV row** now has combo-box controls for both match-word and meta. Each combo has a named dropdown (populated from the type registry / meta registry) and a small number input side by side. The number input is always the authoritative submitted value; the dropdown is a convenience alias. Row order is: `[type] [meta▼][meta#] [op▼][match#] [value] [✕]`

**Display format** in log and detail panel uses `TypeName[meta]{match} value` consistently.

**`server.py` `format_tlv()`** returns `match`, `meta`, `meta_name` fields. `op` is set only to a named operator symbol or empty string — never a raw number. The GUI uses `t.match` directly for `{n}` display when `t.op` is empty.

**`list_types` response** is augmented with `meta_entries: [{meta, name}, ...]` per type, sourced from `meta_registry`. Fetched automatically at connect time so meta dropdowns are populated before the user opens the Send tab.

**Timer tab** auto-subscribes to ch=2 (Confirm) for the timer mtype on first timer send, so outstanding timers are tracked and displayed without manual intervention.

---

### Updated quick reference — TLV types

| ID | Name | Notes |
|----|------|-------|
| 1 | Raw | raw bytes |
| 2 | Int | signed 32-bit NBO |
| 3 | UInt | unsigned 32-bit NBO |
| 4 | Short | signed 16-bit NBO |
| 5 | UShort | unsigned 16-bit NBO |
| 6 | Float | IEEE-754 64-bit NBO |
| 7 | Bool | 1 byte |
| 8 | Char | UTF-8 string, null-terminated — **string plugin**; use meta for filename/url/etc. |
| 9 | UTime | UMM timestamp |
| 10 | MDNum | metadata (field-ID based match) |
| 11 | Msg | nested message/subscription |
| 12 | AttId | attach ID (router+id) |
| 13 | CoOrd | 2D/3D coordinate — **coord plugin** |
| 15 | LogId | login credentials |
| 16 | MsgRef | message reference (router+attach+msg_id) |
| 17 | RouterId | inter-router addressing site(2)+node(2) |
| 18 | JSON | JSON data (wire-identical to Char) |
| 19 | SubSpec | subscription spec: mtype(4)+subtype(4)+match_bytes |

*Note: type_id 14 (FName) has been removed. Use `Char` with `meta=1` (filename) instead.*

---

### Updated quick reference — TLV meta values (built-in)

| Type | Meta | Name |
|------|------|------|
| Float (6) | 1 | temperature |
| Float (6) | 2 | pressure |
| Float (6) | 3 | humidity |
| Float (6) | 4 | speed |
| Float (6) | 5 | voltage |
| Float (6) | 6 | current |
| Float (6) | 7 | power |
| Float (6) | 8 | distance |
| Char (8) | 1 | filename |
| Char (8) | 2 | url |
| Char (8) | 3 | email |
| Char (8) | 4 | hostname |
| Int/UInt (2/3) | 1 | status |
| Int/UInt (2/3) | 2 | error-code |
| Int/UInt (2/3) | 3 | count |
| Bool (7) | 1 | enabled |
| Bool (7) | 2 | alarm |
| Bool (7) | 3 | connected |
| Bool (7) | 4 | running |

Full list in `umm/core/meta.py`. Application values start at 1000.

---

### Files changed this session

| File | Change |
|------|--------|
| `umm/core/tlv.py` | 16-byte header, `match`+`meta` fields, `META_NONE` constant |
| `umm/core/registry.py` | Meta matching step in `TypeRegistry.match()` |
| `umm/core/meta.py` | **New** — `MetaRegistry` with 40 built-in entries |
| `umm/types/_base.py` | Factory helpers accept `meta`, `MetadataField` removed |
| `umm/types/builtin.py` | `FNameType` removed |
| `umm/plugins/_base.py` | 4-field TLV tuples `(type_id, match, meta, value)` |
| `umm/plugins/string_match.py` | FName removed, `match` rename |
| `umm/plugins/coord_match.py` | `match` rename throughout |
| `umm/modules/parser.py` | Meta/match display, `--json-decode`, cap flood fix, `MessageLog` update |
| `umm/modules/feed.py` | `match` rename |
| `umm/modules/fsm.py` | `match` rename |
| `umm/modules/database.py` | `match` rename, FName/type-14 removed |
| `umm/tools/send.py` | `Float[temperature]` bracket syntax, `_parse_meta_token()` |
| `umm/__init__.py` | Exports `META_NONE` |
| `umm_gui/server.py` | `format_tlv` returns match/meta/meta_name, `build_tlvs` reads match+meta, meta_entries in list_types |
| `umm_gui/gui.html` | Combo-box TLV rows, meta registry, `[meta]{match}` display, timer auto-subscribe |

---

### Next priorities

1. **Bridge completion** — origin stamping, loop prevention, reconnect re-registration, heartbeat, status response (see Session 7 handover for details)
2. **Database agent message-driven config** — replace `database.conf` `[table.*]` sections with `AddSubscription (8, 201)` messages following the feed agent pattern
3. **`umm.conf` port alignment** — currently `port = 5300`; `DEFAULT_PORT = 5100`. Decide on one canonical port
4. **Trusted agent** — supervisor should attach with `AttachFlag.TRUSTED` automatically
5. **Manual §5 / §6** — system components and building-an-application chapters

*Session 25: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 26 — Documentation, DEFAULT_PORT from config, async callbacks, bug fixes

### Overview

This session focused on the tank level demo, writing agent code, and a series of bug fixes
discovered through actual use. No new protocol features were added. The documentation
volumes were consolidated and corrected.

---

### 1. Documentation overhaul

Two Word document volumes produced from the five original chapter files.

**Volume I — User Guide** (`UMM_Manual_Vol1_Complete.docx`): Chapters 1–5 merged into a
single document. Chapter 5 (Running the System) appended after Chapter 4; its standalone
cover page stripped.

**Volume II — Developer Guide** (`UMM_Manual_Vol2_Complete.docx`): Chapters 1–6 merged;
FSM chapter renumbered and moved to Appendix D (rationale: FSM requires no Python, is
self-contained, and is optional relative to the API chapters).

**Corrections applied across both volumes:**

- All references to negative mtypes (`-1 Confirm`, `-2 Debug`, `-3 Meta`) removed and
  replaced with channel-based equivalents. No negative mtypes exist in the current codebase.
- No negative subtypes — the old `SubtypeSpec` description saying "Negative subtypes are
  responses" was wrong and removed; correct text says application subtypes start at 100.
- `TLV (Type/Length/Match-word/Value)` → `TLV (Type/Match/Meta/Length/Value)` throughout,
  including the wire-format table which now shows all five fields with correct descriptions.
- New section 4.5 "Message Format" in Vol 1 — explains the message header, the channel
  byte, and how metadata routing works.
- Sections 4.5–4.9 renumbered 4.6–4.10 to accommodate the new section.
- All `python3 umm_ctl.py` and `python3 -m umm.modules.parser` invocations replaced with
  `runumm` equivalents throughout Vol 2.
- All port 5100 references corrected to 5300 (matching `umm.conf`).
- Note added in section 2.5 before the hello.py example: router must be running and port
  must match `umm.conf` (5300 by default); `UMMConnectionError` is raised otherwise.
- `--help` note added after section 2.4 parser examples:
  `runumm start parser --help` lists all parser options.
- Vol 2 chapter cross-references fixed: Chapter 8 → Chapter 4, Chapter 9 → Chapter 5.
- Typo `advertise5ent` fixed in Vol 2.
- FSM appendix section numbers updated D.1–D.9, internal cross-references corrected.

**README.md** corrections:
- TLV description updated to match new 5-field format.
- Timer subtype table: removed obsolete `-2 | Fired` row; correct subtypes 101–104 shown;
  note added that timer fires the user-configured mtype/subtype, not a separate Fired
  notification.
- Manufacturing type table: `M-word = unit` etc. → `meta = unit` / `meta = direction`.

---

### 2. DEFAULT_PORT reads from umm.conf and UMM_ROUTER env var

**`umm/core/messages.py`** — `DEFAULT_PORT = 5100` replaced with `_resolve_default_port()`
evaluated once at import time. Priority order:

1. `UMM_ROUTER=host:port` environment variable — port extracted from `:port` suffix
2. `umm.conf` `[settings] port =` — searched at `<project>/umm.conf`, one level up, and CWD
3. Hard-coded fallback `5300`

`DEFAULT_PORT` remains a plain `int` constant (set dynamically), so all existing
`from .core.messages import DEFAULT_PORT` imports continue to work unchanged. Running from
the project directory now correctly picks up port 5300 from `umm.conf` automatically.

**`umm/agent.py`** — docstring updated to describe the three-level resolution.

---

### 3. Async callbacks and `_dispatch_application` (`umm/agent.py`)

**Problem:** Calling `agent.send()` from inside a callback deadlocked. `send()` submits a
coroutine to the agent's event loop and blocks on `fut.result(timeout=5)`. Callbacks run on
that same loop thread, so the future can never complete. This caused the pump agent to
silently time out on every outgoing message.

**Fix:** `_dispatch_application` now detects async callbacks via `inspect.isawaitable` and
schedules them as tasks with `loop.create_task()`:

```python
result = reg.callback(msg)
if inspect.isawaitable(result):
    async def _run():
        try:
            await result
        except Exception as exc:
            logger.exception("Async callback error for reg %d ...", ...)
        finally:
            self._current_channel = 1
    self._loop.create_task(_run())
```

Exceptions inside async tasks are now logged rather than silently dropped (previously
`create_task` swallowed them with no output). Loop variables are captured in the closure to
avoid late-binding bugs across iterations.

**Pattern for agents that send from callbacks:** declare the callback as `async def` and use
`await agent.asend(...)`. Plain (non-async) callbacks continue to work exactly as before
and must not call `send()`.

---

### 4. Parser bug fixes (`umm/modules/parser.py`)

**FSM registrations appearing without `--show-control`:** REGISTER wire messages carry the
subscription channel in the header (that is how the router knows which channel to store the
subscription on). FSM registers with `channel=0` (ALL), so its REGISTER messages arrived at
the parser with `channel=0` and bypassed the suppression check `msg.channel == 1`. Pump/
tankLevel used the default `channel=1` so their REGISTER messages were correctly suppressed
— but inconsistently.

**Fix:** Removed the channel guard from the suppression check. `mtype=1` plus `subtype 1–9`
is sufficient to identify control messages regardless of channel.

**`--raw` not applied inside SubSpec/Msg TLVs:** `raw_mode` was only applied at the outer
message level (mtype/subtype display). `_format_one` never received it, so SubSpec and Msg
TLVs always looked up names from `umm_names.conf` even with `--raw`. Fixed by threading
`raw_mode` through `_format_tlvs` → `_format_one` and using raw `mtype,subtype` numbers in
both SubSpec and Msg formatters when `--raw` is active.

---

### 5. FSM config error messages (`umm/modules/fsm.py`, `umm/core/registry.py`)

**`self.log_warn` in module-level function:** `_parse_msg_line` is a module-level function
but called `self.log_warn("Unknown TLV type '%s'")` — `self` doesn't exist there, causing
a `NameError` that masked the actual config error. This was the crash seen with a
misspelled type name (`flaot` instead of `float`).

**Fix 1:** `_parse_msg_line` now raises `ValueError("Unknown TLV type 'Flaot'. Known
types: AttId, Bool, Char, ...")` listing all registered types.

**Fix 2:** `parse_config` wraps the entire line-processing loop in
`try/except ValueError` and re-raises with filename, line number, and the offending line
quoted:
```
examples/tankLevel/tankLevel.fsm, line 5: Unknown TLV type 'Flaot'. Known types: ...
  >>> RCV_MSG 5001,101 Flaot <= 20
```
All other `ValueError`s in the loop (e.g. `NEXT_STATE before STATE`) get the same context.

**`registry.all_names()`** added to `umm/core/registry.py` — returns sorted list of all
registered `TYPE_NAME` strings. Used by the error message above.

---

### 6. umm_ctl.py — startup messages for groups

**New config section `[group.<name>]`** — per-group configuration. Currently supports:

- `startup_delay` — seconds to wait after agents start before sending (default 0.5)
- `startup_msg`, `startup_msg_2`, ... — messages to send after the group starts, in the
  **same syntax as the Send tool's interactive mode** (not a separate format)

**Example:**
```ini
[group.tank]
startup_delay   = 1.0
startup_msg     = 5001 101 Bool false
startup_msg_2   = timer 10.0 -> 5000 201 Float 50.0
startup_msg_3   = wait 0.5
startup_msg_4   = 5000 202 Int 42
```

Supports: `mtype,subtype [TLVs]`, `timer interval [repeat N] -> mtype,subtype [TLVs]`,
`wait seconds`. Any line that works in `runumm start send` works here. Startup messages are
only sent when the group is named as an explicit target (`runumm start tank`); they don't
fire on `runumm start` (core only) or `runumm start all`.

**New dataclasses:** `StartupMessage(raw_line)`, `GroupDef(name, startup_messages,
startup_delay)`. `Config` gains `groups: Dict[str, GroupDef]`.

**New function `_send_startup_messages(cfg, group_name)`** — connects briefly to the router
as `umm_ctl-startup`, delegates each line to `send._handle_line()`, disconnects.

---

### 7. pump.py — tank level agent

New agent at `examples/tankLevel/pump.py` demonstrating the async callback pattern and
correct Bool TLV construction:

```python
async def on_scan(msg):
    for tlv in decode_all(msg.tdata.value):
        handler = registry.get_by_id(tlv.type_id)
        if handler and handler.TYPE_NAME == "Bool":
            value = handler.unpack(tlv.value)       # Python bool
            await agent.asend(
                mtype   = MT_PUMP,
                subtype = SND_START_STOP,
                tlvs    = [BoolType().make_tlv(value)],   # NOT handler.to_text(value)
            )
```

Key points:
- `handler.to_text(value)` returns `"true"` or `"false"` (string). Passing a non-empty
  string to `make_tlv()` always encodes as `true` (truthy). Pass the native Python `bool`
  directly.
- `agent.connect()` requires the router to be running on the configured port. If the port
  is wrong or the router is not started, `UMMConnectionError` is raised immediately.
- Capability awareness: add `from umm.capability import make_capability, SubtypeSpec,
  TLVSpec, register_capability_handler` and call `register_capability_handler(agent,
  PUMP_CAPABILITY)` after `agent.connect()`.

---

### Next priorities

1. **Database agent message-driven config** — `AddSubscription (8, 201)` messages,
   following the feed agent pattern (Session 23 design discussion).
2. **`umm.conf` port alignment** — currently `port = 5300`; `DEFAULT_PORT` fallback is
   5300. These now match. Verify `Config` dataclass fallback in `umm_ctl.py` also says 5300.
3. **Trusted agent** — supervisor should attach with `AttachFlag.TRUSTED` automatically.
4. **C0 infeed belt** — placeholder in `conveyor.html`.
5. **Manual §5 / §6** — system components and building-an-application chapters.
   Use Claude Opus 4.6 for long-form prose.

*Session 26: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and
documentation). May 2026.*
---

## Session 26 (continued) — Tank level demo, FSM subscription fixes, agent fixes

### Overview

This continuation of Session 26 completed the tank level demo, fixed FSM
subscription management, and fixed several bugs discovered through testing.

---

### 1. Tank level demo — new files

**`examples/tankLevel/tankLevel.py`** — complete rewrite
- Multi-tank capable: `--tanks N` runs N tanks (numbered 0..N-1) from a single
  agent process
- Every message carries `Int(tank_number)` as the FIRST TLV so the router can
  filter by tank using positional matching
- Async callbacks throughout (`async def req_level`, `pump_echo`, etc.) — calls
  `await agent.asend(...)` to avoid the send-from-callback deadlock
- `--name` and `--type` arguments accepted (passed by `umm_ctl` automatically)
- Subtypes: 102 LevelUpdate, 103 LevelLow (<10%), 104 LevelHigh (>90%),
  105 PumpStarted, 106 PumpStopped, 201 ForceFill, 202 ForceEmpty
- Error flags (`low_sent`, `high_sent`) prevent repeated alerts per excursion;
  both reset when level returns to normal band

**`examples/tankLevel/pump.py`** — rewrite
- Single agent handles all tanks; dispatches by `Int(tank_number)` first TLV
- Ignores duplicate commands (already ON/already OFF) — prevents spurious echos
  if FSM restarts mid-cycle
- `--name` and `--type` accepted

**`examples/tankLevel/tankLevel.fsm.template`** — new
- `{N}` placeholder substituted by `gen_tank_fsm.py` to produce per-tank FSM files
- No `Start` state — begins directly in `Emptying` to avoid a broad `Float > 20`
  catch-all subscription that would fire on every normal tick (see item 4 below)

**`examples/tankLevel/gen_tank_fsm.py`** — new
- Generates `tankLevel_tank0.fsm`, `tankLevel_tank1.fsm`, etc.
- Usage: `python3 examples/tankLevel/gen_tank_fsm.py --tanks N`
- Called automatically by the multi-tank setup instructions in `umm.conf`

**`examples/tankLevel/tankLevel_tank0.fsm`** — generated default (single tank)

**`examples/tankLevel/tank_database.conf`** — new, in `examples/tankLevel/`
- Six tables: tank_level_readings (102), tank_low_alerts (103),
  tank_high_alerts (104), pump_start_events (105), pump_stop_events (106),
  tank_event_log (all subtypes)
- Database agent mtype: 5008 (distinct from sorting demo database mtype 8)

**`umm_gui/tank_gui.html`** — new
- Animated SVG tank with fill/drain drips, threshold lines at 10/20/80/90%
- Spinning pump impeller indicator (pulses green when running)
- Rolling level history chart (last 60 readings)
- Flashing alert banner with Acknowledge button
- Force Fill / Force Empty controls (send Int(0) + Float to the tank agent)
- Stats panel: min/max, pump cycles, alert counts
- Alert history log

---

### 2. Database config files reorganised

**`examples/sorting/sorting_database.conf`** — new location (was `database.conf`
at project root)
- Sorting-specific tables: parcel_records, parcel_scans, bin_events,
  conveyor_state, control_events
- Database agent mtype: 8

**`database.conf`** (project root) — retained as generic reference/template

Both database agents changed to `after = manual` in `umm.conf` so they do NOT
start automatically with `runumm start` (core only) — they are part of their
respective demo groups.

---

### 3. `umm.conf` — tank group

```ini
[agent.tankLevel-agent]      # --tanks 1 by default
[agent.pump-agent]           # shared across all tanks
[agent.tank-fsm-0]           # per-tank FSM; add tank-fsm-1 etc. for multi-tank
[agent.tank-database]        # mtype=5008, after=manual
[agent.tank-database-setup]  # creates tables then exits

[group.tank]
startup_delay = 1.0
startup_msg   = timer 10.0 -> 5000 101    # no tank number — ticks all tanks
```

**`runumm start tank`** / **`runumm stop tank`** — start/stop the full tank group

**Multi-tank:**
```
python3 examples/tankLevel/gen_tank_fsm.py --tanks 3
# Edit umm.conf: set options = --tanks 3 on tankLevel-agent
# Uncomment tank-fsm-1 and tank-fsm-2 blocks
runumm start tank
```

---

### 4. FSM subscription management — `umm/modules/fsm.py`

**Problem:** `_register_all()` registered every subscription from every state at
startup and left them all active permanently. In state `Filling`, the `Float <= 20`
subscription (belonging to `Emptying`) was still live at the router — delivering
messages the FSM would discard.

**Fix:** Subscriptions are now registered and unregistered per state transition.

**New methods:**
- `_register_state(tuple)` — registers only subscriptions for STATE patterns
  matching the current tuple. Snapshots existing `_reg_map` keys into
  `_prev_reg_ids` before adding new subscriptions.
- `_unregister_state()` — unregisters all current subscriptions (used on restart).
- `_unregister_state_except_current()` — unregisters only `_prev_reg_ids`
  (the previous state's subscriptions), leaving the new state's intact.

**Transition ordering — register before unregister:**
On every state transition: `_register_state(new)` first, then
`_unregister_state_except_current()`. This eliminates the window at the router
where neither old nor new subscriptions are active and a message could be missed.
The brief overlap where both are live is harmless — `_find_matching_transition`
discards messages that don't match the (already updated) current state.

**Restart** (`_on_restart`) — unregisters first (safe: no new state yet), reloads
config, registers initial state.

**Force state** (`_on_force_state`) — registers new state before unregistering old.

**`_register_all()`** — now a thin wrapper over `_register_state(current_tuple)`;
retained for backward compatibility.

**Consequence:** The FSM callback is only invoked when a message can actually
trigger a transition from the current state. Mid-range level updates (20%–80%)
are filtered entirely at the router and never reach the FSM.

**Subscriptions per state (tank demo):**
- State `Filling`: 1 subscription — `5000,102 Int=0 Float>=80`
- State `Emptying`: 1 subscription — `5000,102 Int=0 Float<=20`

**FSM template — no Start state:**
A `Start → Emptying` transition using `Float > 20` would register a third
subscription matching everything above 20% — firing on almost every normal tick.
Eliminated by starting directly in `Emptying`. The FSM determines initial pump
state on the first tick that crosses a threshold.

---

### 5. Logging changes — `umm/modules/fsm.py`, `umm/modules/database.py`

- FSM state-transition log: `log_info` → `log_debug` (per-transition noise only
  visible with `--debug`)
- Database row-saved log: `log_info` → `log_debug` (same reason)
- Database missing-TLV-column log: `log_info` → `log_debug`
- FSM "no matching transition" log message: **removed entirely**. This fired on
  every mid-range level update (i.e. constantly during normal operation) and was
  not actionable. State-transition log_debug still fires when something happens.

---

### 6. `umm/agent.py` — `_closing` flag for clean disconnect

`self._closing = False` added to `__init__`.
`disconnect()` sets `self._closing = True` before scheduling async shutdown.
`_read_loop` only logs `"Connection to router lost"` when `not self._closing`.

Previously the send tool and any agent that called `disconnect()` cleanly would
print `WARNING umm.agent: Connection to router lost` — misleading and visible in
`runumm` output. Now suppressed for intentional disconnects; genuine unexpected
disconnections still log the warning.

---

### 7. Bug fix — `--name`/`--type` not accepted by tank agents

`umm_ctl` appends `--name <AgentName>` and `--type <mtype>` to every agent launch
command. `tankLevel.py` and `pump.py` only declared `--tanks`, `--router`, and
`--port` — argparse rejected the unknown arguments and the agents exited immediately.

**Fix:** Both agents now accept `--name` (stored, passed to `UMMAgent`) and
`--type` (stored, passed to `UMMAgent` as `agent_mtype`).

---

### 8. Bug fix — ForceFill/ForceEmpty not responding

After the multi-tank refactor, the GUI was sending `[Float(95.0)]` without the
required `Int(tank_number)` first TLV. `_parse_tank_num()` returned `None` and
both force callbacks returned immediately.

**Fix (two-pronged):**
- `tank_gui.html` — force functions now send `[Int(0), Float(95.0)]` and
  `[Int(0), Float(5.0)]`, matching the protocol
- `tankLevel.py` — `force_fill` and `force_empty` default to tank 0 when no
  Int TLV is present (defensive — handles test scripts that omit the tank number)

---

### 9. Documentation — `UMM_Appendix_E_Tank_Demo.docx`

Full appendix (Appendix E in Volume II) covering:
- E.1 Overview — three operating conditions, mtype allocation table
- E.2 Message Interface — full subtype tables with Int(tank) first TLV
- E.3 Simulation Model — fill/drain/wobble constants, tick rate note
- E.4 The FSM Controller — why one FSM per tank, template/generator workflow,
  generated FSM file shown with annotation
- E.5 The Pump Agent — single shared agent, duplicate command handling
- E.6 Database Logging — tables, setup commands, multi-tank note
- E.7 The Monitor GUI — display panels, controls
- E.8 Running the Demo — `runumm start tank` / stop; multi-tank setup steps
- E.9 Extending the Demo — four extension suggestions
- E.10 File Reference — all five files with descriptions

Styled to match Vol 2: A4, Arial headings with blue underline rule, Courier New
code blocks, shaded note boxes, data tables.

---

### Key files changed this session (continued)

| File | Change |
|------|--------|
| `examples/tankLevel/tankLevel.py` | Multi-tank rewrite; async callbacks; `--name`/`--type` |
| `examples/tankLevel/pump.py` | Multi-tank; `--name`/`--type` |
| `examples/tankLevel/tankLevel.fsm.template` | New — `{N}` placeholder, no Start state |
| `examples/tankLevel/gen_tank_fsm.py` | New — generates per-tank FSM files |
| `examples/tankLevel/tankLevel_tank0.fsm` | Generated default |
| `examples/tankLevel/tank_database.conf` | New location (from project root) |
| `examples/sorting/sorting_database.conf` | New (from `database.conf` at root) |
| `umm_gui/tank_gui.html` | New — full tank monitor GUI |
| `umm.conf` | Tank group agents; both database agents `after=manual`; mtype 5008 for tank-database |
| `supervisor.conf` | Removed `database.conf` reference |
| `umm/modules/fsm.py` | Per-state subscription management; no-match log removed; state-transition log demoted |
| `umm/modules/database.py` | Row-saved and missing-TLV logs demoted to debug |
| `umm/agent.py` | `_closing` flag; clean-disconnect warning suppressed |
| `UMM Documentation/UMM_Appendix_E_Tank_Demo.docx` | New — Appendix E |

---

*Session 26 continued: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Session 27 — C router, C agent library, binary agent support, meta word design (May 2026)

### Overview

This session produced a complete C implementation of the UMM router and agent library, extended `umm_ctl.py` to support compiled binary agents, diagnosed and fixed a wire-format bug in the C router's lifecycle events, and documented a design direction for systematic use of the TLV meta word.

---

### 1. C router and agent library — `umm-c/`

A new directory `umm-c/` contains a complete C implementation of the router and client library. It is wire-format compatible with the Python router — Python agents and C agents can connect to the same router interchangeably.

**Directory structure:**
```
umm-c/
├── include/
│   ├── umm_types.h     Wire format constants, enums, UMMHeader/UMMTLV structs
│   ├── umm_tlv.h       TLV encode/decode API
│   ├── umm_agent.h     Agent (client) library API
│   └── umm_router.h    Router API + UMMTransport/UMMListener vtables
├── src/
│   ├── umm_tlv.c       TLV encode/decode
│   ├── umm_msg.c       Message encode/decode + TCP/UNIX transport backends
│   ├── umm_agent.c     Agent connect/attach/register/send/run loop
│   ├── umm_router.c    Router: subscription table, match engine, poll() event loop
│   └── router_main.c   Standalone router binary (CLI, signal handling)
├── examples/
│   └── example_sensor.c  Publisher/subscriber demo
└── Makefile            Builds libumm.a + umm_router_bin + examples
```

**Building:**
```bash
cd umm-c && make
# Produces: build/libumm.a  build/umm_router_bin  build/example_sensor
```

**Running the C router:**
```bash
./build/umm_router_bin --port 5300 --id 1.31 --name MyRouter
./build/umm_router_bin --port 5300 --unix /tmp/umm.sock   # also listen on UNIX socket
```

**CLI flags** (all accepted by the C router binary):
- `--port N` — TCP port (default 5300)
- `--host ADDR` / `--router ADDR` — bind address (aliases; default all interfaces)
- `--id SITE.NODE` — router ID in site.node format (default: auto-detected from primary IP)
- `--name NAME` — router name
- `--unix PATH` — additionally listen on a UNIX domain socket
- `--debug` — verbose logging
- `--version` — print version and exit

**Transport abstraction:** The router and agent both use a vtable (`UMMListener` / `UMMTransport`) so new transports can be added without changing any other code. The TCP and UNIX socket backends are built in. Bluetooth RFCOMM on Linux is a straightforward addition — see `umm_router.h` / `umm_agent.h` for the vtable definitions, and enable with `-DUMM_HAVE_BLUETOOTH` in the Makefile.

**Writing a C agent:**
```c
#include "umm_agent.h"
#include "umm_tlv.h"

// Callback
void on_reading(UMMAgent *ag, const UMMMsg *msg, void *userdata) {
    UMMTLV tlv;
    double temp;
    if (tlv_find(msg->tdata.value, msg->tdata.length, TLV_FLOAT, &tlv))
        tlv_get_float(&tlv, &temp);
    printf("Temperature: %.1f\n", temp);
}

int main(void) {
    UMMAgent *ag = umm_agent_create("MyAgent", 100);
    umm_agent_connect_tcp(ag, "localhost", 5300);

    // Subscribe with content match: Float > 80.0
    uint8_t match[32]; size_t mlen = 0;
    tlv_encode_float(match, sizeof match, &mlen, 80.0, MATCH_GT);
    umm_agent_register(ag, 100, 1, CHAN_APP, on_reading, NULL, match, mlen);

    // Publish
    uint8_t pay[32]; size_t plen = 0;
    tlv_encode_float(pay, sizeof pay, &plen, 72.5, MWORD_NONE);
    umm_agent_send(ag, 100, 1, CHAN_APP, 0, pay, plen);

    umm_agent_run(ag);   // blocks, dispatching callbacks
    umm_agent_destroy(ag);
}
```

**What is and isn't implemented in the C router vs Python:**
- ✅ Full attach/detach/register/unregister protocol
- ✅ Positional TLV content matching with all numeric operators (EQ/NE/GT/LT/GE/LE) and string equality
- ✅ Channel matching (exact + wildcard)
- ✅ Lifecycle events (AgentAttached, AgentDetached, AgentReattached)
- ✅ PERM_KEEP offline queuing and re-attach
- ✅ ListAgents (1, 110) / (1, 111)
- ✅ Version request (1, 53) / (1, 54)
- ✅ Multiple simultaneous listeners (TCP + UNIX)
- ❌ External match plugins (string_match, coord_match) — not yet ported
- ❌ Match query dry-run (1, 57) / (1, 58) — not yet implemented
- ❌ ListTypes / ListSubs — not yet implemented

---

### 2. `umm_ctl.py` — binary agent support

Two new keys in `[agent.*]` config sections:

**`binary = true`** — `module` is treated as an executable path rather than a Python module name. Relative paths are resolved relative to the `umm.conf` directory. All standard arguments (`--router`, `--port`, `--name`, `--type`, `--debug`) are passed unless overridden.

**`router = true`** — marks an agent as playing the router role. Such agents receive `--port`, `--id`, `--host` (the router's own listen arguments) instead of `--router`, `--port` (the connect arguments that all other agents get). For `module = umm.router` this is set automatically; for binary routers it must be explicit.

**Example `umm.conf` entry for the C router:**
```ini
[agent.c-router]
module   = umm-c/build/umm_router_bin
binary   = true
router   = true
group    = core
after    = -
restart  = always
```

**`runumm validate`** checks that the executable exists and has the execute bit set. **`runumm show`** displays `[binary]` and `[router]` tags next to such agents.

The `build_command` logic in `ProcessManager` now branches on `agent.is_router` rather than string-matching `'umm.router'`, so the same router-argument set applies to both Python and C routers without duplication.

---

### 3. Bug fix — C router lifecycle event wire format

**Symptom:** When using the C router, the timer agent disconnected every ~5 seconds and was restarted in a loop by the supervisor. The `send` tool appeared to start but exited immediately.

**Diagnosis:** The supervisor reported the timer's mtype as 3, 6, 7, 8… (incrementing with each restart) rather than the fixed value 2. These were the router `attach_id` values. The supervisor uses the reported mtype to address heartbeat pings; with the wrong mtype the pong never arrived, so the supervisor killed the timer.

**Root cause:** The C router's `publish_lifecycle` function was encoding the attach_id as a plain `TLV_INT` (type 2). The Python router encodes it as `TLV_ATTID` (type 12, an 8-byte field containing `router_id + attach_id`). The payload layouts did not match:

```
Python router lifecycle payload:   TLV_ATTID(12)  TLV_INT(2)    TLV_STRING(8)
                                   attach_id      agent_mtype   process_name

C router (buggy):                  TLV_INT(2)     TLV_INT(2)    TLV_STRING(8)
                                   attach_id      agent_mtype   process_name
```

Since `TLV_INT` is type 2 — the same value as `MTYPE_TIMER` — the supervisor read the attach_id number as the mtype. The `send` tool stopping was a downstream effect: `init.conf` schedules a timer request, which was addressed to the wrong mtype and never delivered, so the send tool completed its script and exited cleanly.

**Fix:** `publish_lifecycle` in `umm_router.c` changed to use `tlv_encode_attid()` for the first TLV, exactly matching the Python router's wire format.

**Lesson:** Any time a message contains multiple TLVs of the same base type (here: two `TLV_INT`s), the receiver must distinguish them by position. If the sender uses a different type for the first TLV, the entire positional sequence shifts. Infrastructure messages in particular must have their wire format pinned precisely — a mismatch is silent and produces confusing symptoms at a distance. See the meta word section below for a design approach that avoids this class of bug.

---

### 4. Design direction — systematic use of the TLV meta word

**Background:** The meta word in the TLV header is a semantic qualifier for the base type. `meta=0` means absent and always matches; non-zero meta values allow subscriptions to filter by meaning rather than just by type and position. The matching rule: if either side carries `meta=0` the meta check passes; if both sides carry non-zero meta values they must be equal.

**The problem meta solves:** `TLV_INT` (type 2) appears in many messages with completely different meanings — attach_id, agent_mtype, tank_number, temperature alarm threshold, error code. Today these are distinguished only by position in the payload. Position is fragile: a sender that adds or reorders TLVs silently breaks receivers that rely on positional offsets. The lifecycle bug above is a direct consequence.

**Proposed convention — system/infrastructure meta values for Int:**

| Type | Meta | Name | Used in |
|------|------|------|---------|
| Int (2) | 10 | attach_id | Lifecycle events, ATTACH_CONFIRM |
| Int (2) | 11 | agent_mtype | Lifecycle events, capability queries |
| Int (2) | 12 | reg_id | Register, Unregister |
| Int (2) | 13 | router_id | Bridge messages |
| Int (2) | 14 | instance_id | Multi-instance agents (tank_number etc.) |
| Int (2) | 15 | error_code | Confirm/error responses |
| Int (2) | 16 | seq | Heartbeat ping/pong |

These would be registered in `umm/core/meta.py` alongside the existing Float/Char/Bool entries (which currently start at 1 for each type). System values would be in the range 10–99 to leave 1–9 free for the existing application-facing entries.

**What changes when adopted:**

Lifecycle event publishers stamp their TLVs with meta:
```python
# In router._publish_lifecycle():
buf.add(TLV(type_id=TLV_ATTID, value=..., meta=0))      # ATTID has no ambiguity
buf.add(TLV(type_id=TLV_INT,   value=..., meta=META_INT_AGENT_MTYPE))
buf.add(TLV(type_id=TLV_STRING, value=..., meta=0))
```

Subscribers can match by semantic meaning instead of position:
```python
# Subscribe to AgentAttached events for the timer specifically
agent.register(
    mtype    = MTYPE_UMM,
    subtype  = ST_AGENT_ATTACHED,
    callback = on_timer_attached,
    match_tlvs = [IntType().make_subscription_tlv(MTYPE_TIMER, MatchOp.EQ,
                                                   meta=META_INT_AGENT_MTYPE)],
)
```

This subscription works regardless of what other TLVs appear in the payload or what order they arrive in — the router matches on `(type=TLV_INT, meta=META_INT_AGENT_MTYPE, value==2)` positionally against the first TLV of matching type+meta.

**Priority:** High for infrastructure messages (lifecycle events, capability, heartbeat, confirm). Lower for application messages where the schema is stable and well-documented.

**Not yet implemented** — this is a design direction agreed in Session 27. The C router's `publish_lifecycle` was fixed to match the Python format as an immediate bug fix; adopting meta throughout infrastructure messages is a separate task for a future session.

---

### Updated quick reference — TLV meta values (proposed additions)

Existing entries in `umm/core/meta.py` cover Float (physical quantities) and Char/Bool (semantic variants). Proposed additions for Int — system infrastructure range 10–99:

| Type | Meta | Name | Notes |
|------|------|------|-------|
| Int (2) | 10 | attach_id | Router-assigned attach identity |
| Int (2) | 11 | agent_mtype | Primary mtype declared by agent |
| Int (2) | 12 | reg_id | Subscription registration ID |
| Int (2) | 13 | router_id | Numeric router identity |
| Int (2) | 14 | instance_id | Per-instance qualifier (tank number etc.) |
| Int (2) | 15 | error_code | Error/status code in confirm messages |
| Int (2) | 16 | seq | Sequence number (heartbeat, series) |

---

### Next priorities

1. **Meta word adoption in infrastructure messages** — stamp `agent_mtype`, `attach_id`, `reg_id`, `instance_id` meta values in lifecycle events, capability responses, heartbeat, and confirm messages. Update `umm/core/meta.py` with the Int system range. Update C router to match.
2. **C router: external match plugins** — port the plugin protocol (newline-delimited JSON on port+1) to C so string_match and coord_match work with the C router.
3. **C router: ListTypes / ListSubs / MatchQuery** — complete the query service set.
4. **Bridge completion** — origin stamping, loop prevention, reconnect re-registration, heartbeat, status response.
5. **Database agent message-driven config** — `AddSubscription (8, 201)` messages following the feed agent pattern.
6. **Trusted agent** — supervisor should attach with `AttachFlag.TRUSTED` automatically.
7. **Manual §5 / §6** — system components and building-an-application chapters. Use Claude Opus 4.6 for long-form prose.

*Session 27: Phil Braham (design/testing), Claude Sonnet 4.6 (implementation and documentation). May 2026.*

---

## Design discussion — UMM as an operating system substrate (May 2026)

*This section records a design discussion, not an implementation. Nothing described here has been built yet.*

---

### Background

The existence of a C router and the transport abstraction raised the question of whether UMM could serve as the communication backbone of an operating system — not as a replacement for the kernel, but as the layer above it through which all device drivers, peripherals, and services communicate.

---

### The proposed architecture

The kernel retains the functions it must own: interrupt handling, memory management, process scheduling, and DMA/hardware memory transactions. Everything above that boundary becomes a UMM agent.

```
┌─────────────────────────────────────────────────────┐
│              Applications and services               │
│   (each a UMM agent: filesystem, network stack,     │
│    display compositor, audio mixer, USB stack…)     │
├─────────────────────────────────────────────────────┤
│                   UMM Router                         │
│   (typed pub/sub bus — the IPC fabric)              │
├─────────────────────────────────────────────────────┤
│              Device driver agents                    │
│   (keyboard, mouse, display, disk, NIC, GPU…        │
│    each publishes typed events, subscribes to        │
│    typed commands — no direct inter-driver calls)    │
├─────────────────────────────────────────────────────┤
│                  Minimal kernel                      │
│   (interrupts, scheduling, memory, DMA)             │
└─────────────────────────────────────────────────────┘
```

The kernel services the hardware interrupt and hands the event to the appropriate driver agent as a UMM message. The driver agent publishes a typed message onto the bus. Any subscriber — application, service, logger, debugger — receives it without the driver knowing or caring who is listening.

This is essentially a microkernel architecture. It has direct precedents: QNX uses message-passing IPC for all driver/service communication; AUTOSAR in automotive ECUs uses a similar event-driven service model. UMM's content-based subscription matching would be a genuine improvement over those systems' relatively primitive message routing.

---

### Where UMM's model is a natural fit

**Content-based device subscription** is where UMM's matching engine provides real value that conventional OS driver models lack entirely. A conventional driver exposes a device file or ioctl interface; consumers poll or block. With UMM:

- An alarm agent subscribes to `Float[temperature] > 80.0` — no polling, no application-level filtering
- A power manager subscribes to "no input events for 30 seconds" — a genuine content-based sleep trigger
- A logging agent subscribes to everything with `(mtype=0, subtype=0)` — one registration, zero application changes needed
- Multiple displays are just multiple subscribers to the compositor's output stream, each with a different capability descriptor

**Self-describing devices** are a second advantage. The capability system means every device driver agent can be queried for what it publishes and subscribes to. A device manager can enumerate all attached drivers and their interfaces at runtime without a compiled-in device table.

**Fault isolation** improves because drivers are separate processes. A driver crash does not take down other drivers or the kernel. The supervisor module already handles exactly this — restart policy, heartbeat monitoring, and graceful re-attach are built in.

**Language independence** — the C router and library mean drivers can be written in C, C++, Rust, Python, or anything that can implement the wire protocol. The bus is the interface contract, not a shared-memory struct or a function pointer table.

---

### The fundamental tension — latency and preemption

An OS kernel's defining requirement is **latency predictability**. Hard real-time systems need microsecond-level response guarantees; even soft real-time requirements (audio at 48 kHz, display at 60 Hz) demand bounded delivery times.

The current UMM router has two properties that are incompatible with this:

1. **TCP as the transport** adds buffering, Nagle algorithm delays, and kernel network stack overhead. Local loopback is fast but not deterministic.
2. **The router itself is a single scheduling point** — all messages flow through one process. A slow match or a burst of traffic can delay unrelated messages.

Neither is insurmountable, but both require transport-layer work before UMM could run real-time drivers.

---

### What would need to change for real-time use

**Transport:** Replace TCP with shared-memory ring buffers for local (same-machine) agents. This is a new `UMMTransport` / `UMMListener` implementation — the vtable exists precisely for this. A shared-memory transport could deliver a message in tens of nanoseconds rather than microseconds, eliminating the network stack entirely.

**Priority scheduling in the router:** Interrupt-class messages (keyboard key pressed, DMA complete) must preempt lower-priority traffic. The router's `poll()` loop would become a priority-queue dispatcher — high-priority fds are checked first, their messages delivered before normal application traffic.

**Real-time scheduler beneath the router:** The router itself would need to run at an elevated OS scheduling priority (SCHED_FIFO on Linux) so it is not preempted by application processes while dispatching time-critical messages.

With these three changes, the router becomes a viable real-time IPC fabric. The kernel still owns the interrupt vector and fires the initial event; the router delivers it to the subscribed driver agent with bounded latency.

---

### The display subsystem as a concrete example

The display case illustrates both the strength and the boundary of the UMM model.

**What UMM handles cleanly:**

A window manager agent owns the compositor. Applications publish dirty-rect notifications (`mtype=DISPLAY, subtype=DIRTY_RECT, Int(x) Int(y) Int(w) Int(h)`). The compositor subscribes to these, composites on vsync, and publishes a vsync-complete event. Secondary displays are additional subscribers. An accessibility agent can subscribe to all text-render events without any application knowing it exists. A screenshot tool subscribes to vsync and reads the framebuffer — no special API needed.

**The split between UMM messages and shared memory:**

Raw pixel data cannot travel as UMM messages — a 4K frame at 60 Hz requires ~1 GB/s of pixel throughput. The practical architecture splits responsibility:

- **UMM messages** carry *signals and commands*: "window created", "dirty rect (x,y,w,h)", "vsync", "focus changed", "pointer at (320,240)". This is exactly what Wayland's compositor protocol does — commands and signals, not pixels.
- **Shared memory** carries *pixel data*: each application writes to its own framebuffer slice directly; the compositor reads them on vsync signal.

UMM would be a richer version of the Wayland protocol — typed content-based subscriptions instead of a fixed binary protocol, self-describing agents instead of compiled-in interfaces.

**The GPU boundary:**

Modern rendering bypasses the CPU almost entirely. The application writes a GPU command buffer into mapped memory and signals the driver. That signal could be a UMM message (`mtype=GPU, subtype=SUBMIT_CMDBUFS, Int(buffer_addr)`), but the driver agent receiving it needs kernel-level memory mapping privileges and direct hardware register access. This is the point where the bare-metal OS layer is irreplaceable. The boundary ends up being: UMM handles everything *above* the DMA/GPU memory mapping layer. The kernel handles the hardware transactions. The GPU driver agent is a thin shim that translates UMM compositor signals into GPU command buffer submissions.

This is arguably a cleaner boundary than how graphics drivers work today, where the split between userspace and kernel is blurry and driver bugs routinely crash the entire system.

---

### Verdict

**As a kernel replacement:** Theoretically possible but would require redesigning the transport and scheduler so fundamentally that the result would be a new system inspired by UMM rather than UMM itself.

**As a userspace services layer (microkernel model):** This is not just plausible — it is a good architectural fit and arguably better than most existing approaches for systems where devices are naturally event-driven and self-describing. The content-based subscription model is a genuine improvement over traditional device polling, fixed interrupt vectors, and the rigid IPC of existing microkernels.

**Immediate relevance:** The OS discussion directly motivated the C router work. A Python router cannot be a real-time IPC fabric; a C router with a shared-memory transport backend plausibly can. The transport vtable in the C implementation was designed with exactly this extension in mind.

---

### Relation to the C router transport abstraction

The `UMMTransport` and `UMMListener` vtables in `umm-c/include/umm_router.h` and `umm_agent.h` were designed with this discussion in mind. Adding a shared-memory transport requires implementing two structs:

- `UMMListener` with a `start()` that creates a shared ring buffer and an `accept()` that returns a client handle for each writer
- `UMMTransport` with `send()` / `recv()` that read and write the ring buffer with appropriate memory barriers

No other code changes. The router's `poll()` loop, subscription table, and match engine are transport-agnostic. A mixed-transport router — accepting connections over both TCP (for remote agents) and shared memory (for local drivers) — is a single `umm_router_add_listener()` call away once the shared-memory transport is implemented.

---

*Recorded: Session 27, May 2026.*

---

## Design discussion — UMM as a programming language substrate (May 2026)

*This section records a design discussion, not an implementation. Nothing described here has been built yet.*

---

### Background

The OS discussion established that UMM's typed pub/sub bus is a natural fit for a userspace services layer, with the C router as a plausible real-time IPC fabric. The next question is whether the same model could extend upward — past the OS services layer — into the programming language itself. Not as a scripting layer on top of a conventional language, but as the *semantic foundation* of the language: one in which function calls *are* messages, types *are* TLVs, and the runtime *is* the router.

---

### The central idea

In a conventional language, a function call is a CPU instruction: push arguments onto the stack, jump to the function address, receive the return value in a register. The caller and callee are tightly coupled — the callee's address is baked into the call site at compile time, the stack frame is a private contract between them, and the whole transaction is synchronous by default.

In a UMM language, a function call is a published message:

```python
caller.publish(mtype=SQRT_FN, subtype=CALL, payload=[Float(9.0)])
```

The function body is an agent subscribed to that mtype. The router delivers the message. The return value arrives as another message on the caller's return subscription. The caller and callee never exchange an address. They share only a type contract — the mtype and the TLV schema for arguments and results.

This is not a new idea in the abstract — Erlang's actor model and Smalltalk's message passing are in the same family — but UMM's *typed content-based matching* adds something those models lack: subscriptions can filter on the *content* of arguments, not just the destination.

---

### Calling conventions — synchronous, asynchronous, and fire-and-forget

Swift's `async/await` is retrofitted concurrency — the compiler transforms synchronous-looking code into a state machine, and `async` functions must be syntactically marked, infecting their callers transitively. A function must declare itself `async` and every caller across the call chain must follow suit.

In a UMM language, there is no boundary to mark. Every call is a message. Whether the caller awaits the response or registers a callback is purely a caller decision, not a property of the function being called. The callee does not even know which mode the caller chose:

- **Synchronous** — caller registers a one-shot return subscription, publishes, blocks. Thin layer over `send_confirmed()`.
- **Asynchronous** — caller publishes and returns immediately; result arrives via callback. Multiple results can arrive naturally (generator, streaming query, sensor feed) with no special syntax.
- **Fire-and-forget** — publish with no return subscription registered. The default.

Swift also requires `actor` isolation to prevent data races, because shared mutable state is the default. In a UMM language agents do not share state — actor isolation is the default, not an opt-in annotation.

---

### The meta word as parameter labels

In the current UMM system, TLV arguments are matched positionally. The meta field exists precisely to add semantic identity to a bare type. Applied to function calls, the meta word becomes the parameter name, baked into the wire format:

```python
# Without meta — positional, ambiguous
fn move(Float, Float, Float) -> None     # x? y? z? speed?

# With meta — labelled by semantic identity
fn move(Float[meta=X_COORD], Float[meta=Y_COORD], Float[meta=SPEED]) -> None
```

**Named arguments are native.** The caller publishes TLVs with the right meta values in any order; the router's match engine verifies them. No interpreter-level keyword matching needed.

**Optional parameters fall out naturally.** `meta=0` means "absent, always matches." A function accepting an optional `Float[meta=TIMEOUT]` simply has a subscription that matches whether or not that TLV is present.

**Overloading by semantic role.** `process(Float[meta=TEMPERATURE])` and `process(Float[meta=PRESSURE])` are two different dispatch targets without any type switch.

**Self-documenting wire format.** Because meta values are registered in `umm/core/meta.py`, any message on the bus is introspectable without a separate schema — not just "this is a Float" but "this is a Float representing a temperature."

---

### Type-independent semantic dispatch

This is worth spelling out explicitly because it has no direct equivalent in any mainstream language.

If meta is not scoped to a base type, then `meta=TEMPERATURE` is a semantic identity that floats free of the underlying representation. A function subscribed to `[meta=TEMPERATURE]` with no `type_id` constraint would match an Int temperature (a raw sensor count), a Float temperature (a calibrated reading), and a String temperature ("hot", "cold", "critical") — all through the same subscription. The function decides what to do with the value once it arrives.

This is duck typing at the semantic level rather than the structural level. Not "does this object have a `.read()` method" but "is this value semantically a temperature, regardless of how it is represented." The caller does not need to know or specify the representation; the semantic contract is the only contract.

The corollary is also useful: a function can register *multiple* subscriptions on the same mtype, one per representation it handles — the Float handler does precise arithmetic, the Int handler does integer arithmetic, the String handler does lookup in a table of named ranges. All three are the "process temperature" function from the caller's point of view; the router picks the right implementation based on what the caller actually sent.

**Meta namespace for parameters.** Meta values are currently scoped per base type in `meta.py`. Extending to parameter labelling would probably want a broader namespace — a dedicated meta range for function parameters separate from the physical-quantity metas, or the function's mtype as implicit scope (`meta=1` means different things in `SQRT_FN` than in `MOVE_FN`, and the router's per-subscription matching already keeps them separate).

---

### All types are TLVs

In a conventional language, an integer is 32 bits in a register. In a UMM language, an integer is `TLV(type_id=TLV_INT, value=42)` — every value carries its type at all times. Consequences:

- **Type checking is structural and runtime.** Passing a Float to a function expecting an Int fails at the router's match engine. Type errors are misdelivered messages, not compile errors.
- **Content-based dispatch replaces overloading.** Multiple agents subscribe to the same mtype with different content-match criteria; the router picks at dispatch time.
- **Pattern matching is native.** A function that only applies when `Float(temperature) > 80.0` registers that as its subscription. No `if` statement needed at the call site.
- **Values are introspectable without reflection.** Every value carries `type_id` and `meta`; the runtime can answer "what type is this?" and "what semantic role does it play?" without any reflection API.

---

### Advantages over conventional languages

**1. Decoupling as a first-class property.** In a conventional language, a function call couples the caller to a specific implementation at a specific address. In a UMM language, decoupling is the default. Replacing an implementation means starting a new agent with the same mtype subscription. Mocking for tests means starting a test agent. Hot-swap happens at the router level with no recompilation.

**2. Distributed by default.** A conventional function call is local by default; making it remote requires RPC frameworks, serialization, and network error handling. In a UMM language, local and remote calls are not just syntactically identical — they are *mechanically* identical. An agent connecting to a remote router over TCP is just a normal agent connection; the router does not know or care whether the connecting client is on the same machine or across a network.

The bridge module is a separate concern. It is only needed when two *routers* need to exchange messages — when subscribers on one router need to receive messages published on another. For a single router with agents spread across many machines, no bridge is involved at all. A function running on another machine is indistinguishable from one running locally.

**3. Observability for free.** Any computation is visible to any subscriber. A debugger is a subscriber. A profiler is a subscriber. A test harness is a subscriber that injects messages and asserts on responses. None of these require touching the code under observation.

**4. Reactive programming is the default model.** A function that fires whenever `Float(temperature) > 80.0` is not a special reactive construct — it is a normal subscription. Chaining transformations is done by agents that subscribe to one mtype and publish to another. The dataflow graph *is* the subscription graph.

**5. Concurrency without synchronisation primitives.** Agents do not share memory. Parallelism scales by adding subscribers. No mutexes, semaphores, or race conditions in the common case.

---

### The harder problems

**Performance.** A message through the router is orders of magnitude slower than a stack-frame call. The answer is the same as for the OS discussion: shared-memory transport for local agents, and a compiled escape hatch for performance-critical inner loops (as Erlang has NIFs).

**Stack traces.** The "call stack" is a chain of in-flight messages distributed across agents. Reconstructing it requires tracing `MsgRef` chains — the type is already defined; the tooling needs building. The parser module is a starting point.

**Exception handling.** The equivalent of stack unwinding is the Confirm channel (`mtype=-1`): a callee that fails publishes a Confirm/Error. For async calls there is no stack to unwind; error handling becomes more like the supervisor module's restart policy than try/catch.

**Closures.** "Scope" is the set of subscriptions an agent holds. A closure is an agent created with specific subscriptions, capturing mtype and match criteria of its creation context. This maps onto the supervisor's `StartAgent` message.

---

### Speculative syntax

Conceptual only — not a real language:

```python
# Function definition — declares an mtype and subscribes to it
fn sqrt(x: Float[meta=INPUT]) -> Float:
    return Float(math.sqrt(x.value))

# Synchronous call
result = await sqrt(Float[meta=INPUT](9.0))

# Async call
sqrt(Float[meta=INPUT](9.0)).then(|r| print(r))

# Content-filtered function — only fires when condition matches
fn high_temp_alarm(temp: Float[meta=TEMPERATURE] where temp > 80.0) -> None:
    alert(f"Temperature critical: {temp}")

# Type-independent semantic dispatch — handles any representation of temperature
fn log_temperature(t: [meta=TEMPERATURE]) -> None:
    db.write(t)        # works for Int, Float, or String temperature

# Streaming function — returns multiple values
fn read_sensor() -> Float[meta=TEMPERATURE] yields:
    while running:
        yield Float(sensor.read())
        sleep(1.0)

# Reactive subscription — fires on any matching message
on sqrt(x: Float[meta=INPUT] where x < 0.0):
    raise DomainError("sqrt of negative")
```

---

### Mapping to existing UMM concepts

Nothing in this design requires new infrastructure:

| Language concept | UMM concept |
|---|---|
| Function definition | mtype + SubtypeSpec (capability descriptor) |
| Function call | publish(mtype=fn, subtype=CALL, payload=args) |
| Synchronous return | one-shot return subscription + send_confirmed() |
| Async return | callback on return subscription |
| Streaming return | multiple published responses |
| Argument types | TLV type_id |
| Argument constraints | match TLV (EQ, GT, CONTAINS, etc.) |
| Named / labelled parameters | TLV meta field |
| Optional parameters | meta=0 wildcard match |
| Semantic type (representation-independent) | TLV meta, type_id unconstrained |
| Method dispatch | content-match on type_id or meta |
| Module / namespace | mtype range |
| Remote function (same router) | agent on remote machine, no bridge needed |
| Remote function (different router) | bridge subscription between routers |
| Reflection | LIST_TYPES + MATCH_QUERY + capability query |
| Debugger | parser module + MsgRef chain tracing |
| Profiler | bus monitor counting mtype traffic |
| Test mock | substitute agent on same mtype |
| Actor isolation | default (agents share no state) |
| async/await | caller choice, not function property |

---

### Verdict

**As a general-purpose language:** The performance and debuggability gaps are real. Competitive for event-driven, distributed, reactive workloads (the domains where Erlang and Akka are used) but needs shared-memory transport and a compiled inner-loop escape hatch before it can touch performance-sensitive applications.

**As a domain-specific language for control systems:** The natural fit. Manufacturing control, IoT coordination, real-time monitoring, robotics coordination — the domains UMM already targets — are exactly the domains where reactive, decoupled, observable, distributed-by-default are competitive advantages rather than compromises. Closer to IEC 61131 or SCADE than to Python or Java, but with far more expressive matching and far better introspection.

**Immediate relevance:** The capability system (`SubtypeSpec`, `input_tlvs`, `output_tlvs`) is already a rudimentary function signature. `MATCH_QUERY` is already a form of type-directed dispatch query. `LIST_TYPES` is already a runtime type directory. The language discussion is less a proposal for new infrastructure and more a recognition that the existing infrastructure already has most of the semantic machinery of a language runtime — it just has not been exposed as one yet.

---

*Recorded: Session 28, May 2026.*
*Authors: Phil Braham (design), Claude Sonnet 4.6 (elaboration).*


---

## Bug fixes — Session 28 (May 2026)

### umm_ctl.py — Windows compatibility

Three Windows-incompatible patterns were fixed in `umm_ctl.py`:

**ANSI colour codes** — Windows terminals require VT processing mode to be enabled before ANSI escape sequences work. Added `os.system('')` (a no-op shell call that triggers VT mode) under `if sys.platform == 'win32'` just before the colour definitions. No-op on macOS/Linux.

**`os.kill(pid, 0)` — process existence check** — On Linux/macOS, sending signal 0 tests whether a PID is alive without disturbing it. On Windows, `os.kill` does not support this and raises `OSError`, which was not caught, causing `umm_ctl stop` and `status()` to crash immediately after the router started. Replaced throughout with a `_proc_is_running(pid)` helper that uses `OpenProcess` + `GetExitCodeProcess` via `ctypes` on Windows, and `os.kill(pid, 0)` on Unix.

**`signal.SIGKILL` and `signal.SIGTERM` via `os.kill`** — `SIGKILL` does not exist on Windows. Replaced all terminate/force-kill calls with `_proc_terminate(pid)` and `_proc_kill(pid)` helpers that use `TerminateProcess` via `ctypes` on Windows and the appropriate signals on Unix.

**`pgrep` / `ps` in `cmd_killall`** — These Unix utilities are unavailable on Windows. The killall function now branches on `sys.platform`: Unix uses the existing `pgrep`/`ps` path; Windows uses `wmic` to enumerate Python processes and match by command line.

All four helpers (`_proc_is_running`, `_proc_terminate`, `_proc_kill`, `_get_ppid`, `_is_launcher_process`) are collected in a `# cross-platform process utilities` block near the top of the file, before the output helpers.

---

### umm_ctl.py — Launcher orphan processes

**Problem:** Every agent is started as a pair: the real agent process (whose PID is written to the `.pid` file) and a launcher wrapper (the inline `-c "import subprocess, sys, os..."` script that spawns the agent and tails its log). When `stop()` terminated the real agent using its PID file, the launcher was left alive — now orphaned with PPID 1, blocking on `proc.stdout` of a dead process indefinitely. Repeated start/stop cycles accumulate launcher orphans that survive across restarts.

**Fix:** `stop()` now reads the real agent's PPID before terminating it. After the agent dies, if the parent process is still alive and its command line matches the launcher signature (`import subprocess, sys, os` + `pid_file`), it is terminated too. The same launcher-parent kill is applied in `cmd_killall` for each matched agent PID.

Two new helpers support this: `_get_ppid(pid)` (uses `ps -p PID -o ppid=` on Unix, `wmic` on Windows) and `_is_launcher_process(pid)` (inspects the command line for the launcher signature).

**`examples.` pattern added to killall:** Processes matching `-m examples.*` (sorting demo, tank level, etc.) were not being caught by `cmd_killall` because `'examples.'` was absent from the pattern list. Added. This also covers directly-launched example agents that have no PID file.

---

### umm/router.py — Router binds to loopback only when UMM_ROUTER=localhost

**Problem:** When `UMM_ROUTER=localhost:5300` is set on the host machine (the typical setting for agents running locally), the router's startup code was reading this env var and using `localhost` as both the agent connect address and the TCP bind address. `asyncio.start_server(host='localhost', ...)` binds only to `127.0.0.1`, making the router invisible to the network. Agents on remote machines (e.g. a Raspberry Pi at `192.168.0.120` connecting to `192.168.0.131:5300`) received "connection refused".

**Fix:** In the `UMM_ROUTER` env var parsing block in `router.py`, loopback values (`localhost`, `127.0.0.1`, `::1`) are now skipped when determining the bind address. The router falls back to `host=''`, which causes `asyncio.start_server` to bind to all interfaces (`0.0.0.0`). An explicit `--host` CLI argument still overrides this for deployments that want to restrict binding to a specific interface.

**No changes needed on remote machines.** The Pi's `UMM_ROUTER=192.168.0.131:5300` is the correct connect address for agents and is used only as such — the bind-address fix is only in the router startup path.

---

*Session 28 bug fixes recorded May 2026.*

---

## Session 29 — Cross-platform fixes, send tool format, GUI server (May/June 2026)

### Overview

This session covered a broad range of fixes and small changes, mostly driven by running UMM on Windows for the first time alongside the existing Mac development environment. Several latent bugs were also uncovered in the process.

---

### send tool — `mtype,subtype` format and case-insensitive TLV types

**Change:** The send tool interactive mode, script file format, and REPL help text were updated to use `mtype,subtype` (comma-separated) rather than `mtype subtype` (space-separated), consistent with the parser and other parts of the system.

**Files changed:** `umm/tools/send.py`, `init.conf`, `HANDOVER.md`, `UMM_Manual_Vol1.docx`, `UMM_Manual_Vol2.docx`

**Backward compatibility:** The old space-separated `mtype subtype` format is still accepted as a legacy fallback via `_parse_mtype_subtype()`. Existing scripts continue to work.

**Case-insensitive TLV types:** `parse_tlv_args` now does a case-insensitive fallback lookup if `registry.get_by_name()` returns `None`. `int`, `INT`, `Float`, `BOOL` etc. all work.

---

### Documentation — `UMM_ROUTER` environment variable

Added coverage of `UMM_ROUTER` to both manual volumes:

- **Vol 1 §5.2** — new paragraphs after the startup status output explaining the env var, showing `export UMM_ROUTER=192.168.1.31:5300`, and noting it applies to all tools and agents on the machine.
- **Vol 2 §2.2** — similar note after the healthy-status output, before §2.3.
- **Vol 2 §3.1** — after the `UMMAgent` constructor parameter table, explaining `UMM_ROUTER` as the alternative to explicit `host`/`port` arguments, with the full priority order: constructor argument → `UMM_ROUTER` → `umm.conf` → default 5300.

---

### TLV filesystem metadata — design document

A speculative design document was written up: **TLV-Based File Metadata** (`TLV_File_Metadata.docx`). The proposal uses TLV blobs as a universal, typed, schema-free metadata format for files, with the actual file data held by reference (path or hash). Key points: no central schema, unlimited typed fields via TLV, semantic qualification via the meta word, rich query operators reusing the UMM match system, sidecar or central-index storage, full coexistence with existing filesystems.

---

### Windows compatibility fixes

#### `umm/tools/send.py`, `umm/modules/parser.py`, `umm_ctl.py` — UTF-8 output

Windows terminals default to cp1252/cp437, which cannot encode the Unicode characters used in UMM output (`✓`, `─`, `→`, `∞`, `×`, `—`). Added `sys.stdout.reconfigure(encoding='utf-8', errors='replace')` under `if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure')`. Uses `reconfigure()` only — the `TextIOWrapper`-replacement approach was tried first but breaks `input()` on Windows by replacing the console handle. `reconfigure()` adjusts encoding in place without disturbing the console.

#### `umm_ctl.py` — `os.execvp` on Windows

`start_foreground()` used `os.execvp()` to replace the current process with the agent process, which gives clean terminal handover on Unix. On Windows, `os.execvp` spawns a child and continues running the parent alongside it, corrupting the terminal. Fixed: on Windows, `subprocess.call(cmd)` is used instead, which runs the child attached to the current terminal and blocks until it exits.

#### `umm_ctl.py` — `_proc_is_running` on Windows

The previous implementation used `GetExitCodeProcess` and checked for `STILL_ACTIVE` (259). This is unreliable: 259 is a valid application exit code, and Windows keeps process handles in a signaled state for a period after exit. Fixed: uses `WaitForSingleObject` with timeout=0 — `WAIT_TIMEOUT` means still running, `WAIT_OBJECT_0` means exited. This is the correct Windows idiom for non-blocking process existence checks.

#### `umm_ctl.py` — `wmic` deprecation

`wmic` was deprecated in Windows 10 21H1 and removed from Windows 11. `_get_ppid()`, `_is_launcher_process()`, and `cmd_killall()` all used `wmic` to enumerate processes. Added PowerShell `Get-Process` as a fallback in each case.

---

### GUI server — single-port HTTP + WebSocket

**Problem:** The server previously ran HTTP on `gui_port+1` (8766) and WebSocket on `gui_port` (8765). Opening `http://localhost:8765` produced `InvalidUpgrade: invalid Connection header: keep-alive` because that port only spoke WebSocket. The two-port design also used `lsof` for port cleanup, which doesn't exist on Windows.

**Fix:** HTTP and WebSocket now share a single port (`gui_port`, default 8765) using the websockets `process_request` hook. Plain GET requests are served as HTML/JSON; WebSocket upgrade requests (`Upgrade: websocket` header present) pass through to the normal WebSocket handler. The `lsof` port-cleanup code was removed entirely. `http://localhost:8765` now opens the GUI directly.

**`process_request` fix:** Initial implementation returned a 200 Response for all requests including WebSocket upgrades (because both arrive on path `/`). Fixed by checking for `Upgrade: websocket` header at the top of `process_request` and returning `None` (pass-through) immediately for WebSocket connections.

---

### Process management fixes

#### `cmd_stop` — supervisor killed first

When stopping everything, the supervisor was stopped in reverse dependency order along with the other agents. This created a race: agents with `restart=always` were detected as detached by the supervisor and relaunched with new PIDs before `cmd_stop` could reach them. Fixed by stopping the supervisor explicitly first in a full stop, before iterating the remaining agents. The supervisor cannot restart agents it has already been stopped.

#### `cmd_stop` — `cmd_killall` after tracked agents

After stopping all PID-file-tracked agents, `cmd_stop` now calls `cmd_killall(quiet=True)` to catch any processes spawned by the supervisor (timer, typedir, plugins, GUI server, demo agents) that have no PID files. Previously these were left running after `runumm stop`.

#### `cmd_killall` — `pgrep` scope too narrow

`pgrep -f umm` only matches processes with `umm` in their command line. Demo agents (`examples.tankLevel.*`, `examples.sorting.*`) have no `umm` in their command — `pgrep` never returned them. Fixed: `cmd_killall` now runs multiple `pgrep` passes (`umm`, `examples.tankLevel`, `examples.sorting`, project directory path) and unions the results.

#### `cmd_killall` — wait for processes to actually exit

Previously, `cmd_killall` sent SIGTERM/TerminateProcess and then did `time.sleep(1)` before returning. If any process took longer than 1 second to exit, the subsequent `cmd_start` would find ports still in use or PID files still valid. Fixed: after sending terminate signals, polls `_proc_is_running()` for up to 5 seconds, then force-kills anything still alive, then waits a final 0.3 seconds for the OS to release ports.

---

### `agent.py` — `match_tlvs` lost on reconnect

**Bug:** The `Registration` dataclass did not store `match_tlvs`. In `_attempt_reconnect`, subscriptions were re-registered with `match_tlvs=None` — losing all content-matching criteria (range operators, positional filters, etc.). Any agent using `reconnect=True` (e.g. permanent agents) would reconnect with unfiltered subscriptions.

**Fix:** Added `match_tlvs: Optional[List[TLV]] = None` to `Registration`. Stored on creation in `_async_register`. Used in `_attempt_reconnect` replay.

---

### `fsm.py` — `on_reconnect` re-registers state subscriptions

Added an `on_reconnect` callback in `FSMModule.run()` that clears `_reg_map` and re-runs `_register_state(self._current_tuple)` after reconnect. This is more robust than relying on the agent's generic registration replay, which only replays whatever was in `_registrations` at disconnect time (which may be incomplete if the connection dropped mid-registration).

---

### Root cause of tank demo FSM problem

The tank demo FSM was not firing transitions. Investigation through parser output, code inspection, and router log analysis took several sessions before the actual cause was found: `umm.conf` on the development machine had an old `[agent.tankLevel-fsm]` entry pointing to `tankLevel.fsm` (the simple single-tank version with no `Int=0` positional filter and only one `Start` transition: `Float <= 20`). The correct file is `tankLevel_tank0.fsm` (with `Int = 0` tank filter and two `Start` transitions: `Float <= 20` → Filling, `Float > 20` → Emptying).

The fix was a one-line change in `umm.conf`:
```
options = --config examples/tankLevel/tankLevel.fsm
→
options = --config examples/tankLevel/tankLevel_tank0.fsm
```
With `name = TankFSM-0` and `[agent.tank-fsm-0]` as the section name.

All code changes made during the investigation (`agent.py` reconnect fix, `fsm.py` on_reconnect callback) are genuine improvements and were kept.

Also fixed in `umm.conf`: `startup_msg_confirm` was an unrecognised key and was silently dropped. Renamed to `startup_msg_2`. Both startup_msg lines updated to use `mtype,subtype` comma format.

---

### `umm_gui/server.py` — further Windows fixes (post-session)

Two additional fixes applied after the main session:

**Stale `server.py` on Windows** — the Windows machine still had the old two-port `server.py` which crashed immediately with `UnicodeEncodeError` on `→` in the ready message. Fixed by deploying the current `server.py`.

**`WindowsSelectorEventLoopPolicy`** — Python 3.8+ defaults to `ProactorEventLoop` on Windows, which has known issues with websockets alongside `run_in_executor` calls. Added `asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())` under `if sys.platform == 'win32'` at module level.

**Exception logging in `serve()`** — wrapped `websockets.serve(...)` in `try/except` so crashes are logged with full traceback before re-raising, rather than disappearing silently into the supervisor log.

---

### Note — GUI WebSocket reconnect loop in browser

When the UMM system is stopped while a browser tab with the GUI is open, the GUI JavaScript will continue attempting to reconnect every 3 seconds indefinitely. This is normal behaviour — the browser tab is trying to reach a server that is no longer running. It is not an error and stops as soon as the system is restarted or the tab is closed.

---

*Session 29 recorded May/June 2026.*
*Authors: Phil Braham (development, testing), Claude Sonnet 4.6 (implementation).*

---

## Session 30 — June 2026: FSM transition deadlock, EStop, restart, Windows/Ctrl-C fixes

A run of bugs found while exercising the sorting demo and running on Windows. Full per-fix write-ups are in `/mnt/user-data/outputs/*_notes.txt`.

### 1. FSM state-transition deadlock (`umm/agent.py`)
A plain (non-async) callback runs on the agent's event-loop thread. The FSM's `_on_message` callback called the *synchronous* `register()`/`unregister()` on a transition, which does `run_coroutine_threadsafe(...).result(timeout=5)` — blocking the very loop thread that must run the coroutine. Result: `TimeoutError` on the first transition. Fixed in `agent.py` so registration/unregistration from within a callback no longer deadlocks (detects it is on the loop thread and schedules without blocking). Affects any agent that calls blocking `register()`/`send()`/`unregister()` from a plain callback, not just the FSM.

### 2. EStop "belt keeps running" (`umm/modules/fsm.py`)
Depends on fix 1. The sorting machine's safety subscriptions (EStop `1001,102`, belt stalls `1002,107/108`, bin-full `1006,101`) are declared under always-on `(*, Running, *)` states, so they are present both before and after a transition. The FSM's "register new before unregister old" logic re-registered an identical subscription; the router collapsed it onto the existing `reg_id` (duplicate ignored), and the FSM then unregistered that `reg_id` as "the old one" — deleting the safety subscription outright. After the first transition there was no EStop subscription at the router, so EStop was never delivered. Fixed so subscriptions that persist across a transition are not unregistered.

### 3. "Belt won't restart after EStop" (`umm_gui/conveyor.html`, GUI only)
The restart sequence `EStopped →(RESTART 1001,103)→ RestartPending →(CLEAR 1001,104)→ (Idle,Running) →(START 1001,101)→ Running` requires a `CTRL_CLEAR (104)`, but only the ALL CLEAR button sent it and it was never revealed during the EStop/Restart flow. Fixes: the RESTART handler now reveals the ALL CLEAR button; the START button sends a plain `CTRL_START (101)` instead of scripting the whole cycle (and correctly does nothing while in EStop — the interlock is preserved); ALL CLEAR hides the RESTART/CLEAR PARCELS buttons once confirmed.

### 4. Ctrl-C aborts a foreground agent on Windows (`umm/agent.py`, `umm_ctl.py`)
`run()` now catches `KeyboardInterrupt` and calls `disconnect()` (stopping the loop and joining the daemon thread) before re-raising, so the interpreter does not finalise while the loop thread holds the stdout `BufferedWriter` lock (the `_enter_buffered_busy` fatal error). The Windows foreground launcher in `umm_ctl.py` runs the child via `Popen` and swallows its own Ctrl-C traceback.

### 5. Ctrl-C takes the router down with the foreground agent on Windows (`umm/modules/supervisor.py`, `umm_ctl.py`)
A Windows console delivers Ctrl-C to every process attached to it. `start_new_session=True` is a no-op on Windows, so background agents stayed attached. Fixed: background launches use `CREATE_NEW_PROCESS_GROUP` on Windows (the equivalent of POSIX `setsid`) and keep `start_new_session=True` on POSIX. Applied in both the supervisor's per-agent `Popen` and the `umm_ctl.py` background launcher.

### 6. "List agents" takes the router down on Windows (`umm/modules/supervisor.py`)
Root cause: `ManagedAgent.is_running` used `os.kill(pid, 0)` as a liveness probe. On Windows signal 0 is `CTRL_C_EVENT`, and `os.kill` with that signal calls `GenerateConsoleCtrlEvent` — i.e. it fired a console Ctrl-C into the process group on every "List agents" (the only GUI action that queries the supervisor for `ST_AGENT_STATUS`). Fixed `_pid_alive()` to a platform-correct, non-destructive check (`OpenProcess(SYNCHRONIZE)` + `WaitForSingleObject(handle, 0)` on Windows; `os.kill(pid, 0)` on POSIX).

### 7. One-shot agents shown as "stopped / crashed" (`umm/modules/supervisor.py`, `supervisor.conf`, `umm_gui/gui.html`)
The init sender (`umm.tools.send --file init.conf`) runs once and exits; the supervisor reported it as "stopped", which the GUI rendered as "⚠ stopped / crashed". Added an explicit one-shot marker (`O` flag) so a finished one-shot agent renders as idle rather than crashed — and, crucially, "no restart policy" is *not* used as the idle test (the GUI server and match plugins are long-running daemons without a restart flag and must still show a real crash).

*Session 30: Phil Braham (design/testing), Claude (implementation and notes). June 2026.*

---

## Session 31 — June 2026: meta-keyed content matching (Python + C) and sorting-demo rework

This session designed and implemented **meta-keyed content matching** — the headline behavioural change — and reworked the sorting demo around it. Full write-ups in `/mnt/user-data/outputs/{meta_keyed_matching,c_meta_keyed,readonthefly,gui_and_bcrecord,pulse_channel_and_failrate}_notes.txt`.

### 1. Meta-keyed matching — Python (`umm/router.py`, `umm/modules/fsm.py`)
A subscription condition with `meta == 0` is matched **positionally**, exactly as before (nothing changes for existing filters). A condition with a **non-zero meta** is matched **by key** — tested against the message field carrying the same `(type_id, meta)`, regardless of position. Several conditions that share one `(type, meta)` therefore AND together against that single field, which is how a **range** is expressed in **one registration**:
```
Int meta=100 >= 0       ┐ both test the meta=100 field
Int meta=100 <= 1999    ┘ → AND → 0 <= v <= 1999
```
OR is still "several registrations"; a range is "several conditions, one registration." Both content-match loops in `router.py` (`_matches` and the plugin-path `find_candidates_split`) were updated; `find_matches` and the match-query service reuse them, so no other router code changed. The `.fsm` parser now accepts a `meta=N` qualifier on a condition (e.g. `Int meta=100 >= 0`).

**Why it matters:** positional matching silently dropped the sorting demo's bin scans (only rejects ever reached the FSM, because the controller subscribed to several overlapping ranges and position could not disambiguate). Keyed matching fixes this and is the matching model documented in Manual Vol 2 §5.

### 2. Meta-keyed matching — C parity (`umm-c/src/umm_router.c`, `umm_tlv.c`, `include/umm_tlv.h`, `umm_agent.c`, `examples/example_sensor.c`)
Same rule in the C router: `tlv_content_match()` rewritten so a positional cursor advances only on `meta==0`/`MWORD_IGNORE` conditions, while a `meta!=0` condition does a keyed lookup and does not advance the cursor; all conditions AND. No wire-format change (meta is already the 3rd TLV header word). The typed encoders `tlv_encode_int/float/string` gained a `meta` parameter (threaded through); `tlv_encode_bool` is unchanged. All call sites pass `META_NONE` so existing fields are untagged and behaviour is unchanged. C and Python routers/agents remain fully wire-compatible.

### 3. Sorting demo rework
- **Sort code keyed** (`examples/sorting/capabilities.py`, `sorting_demo.py`, `sorting.fsm`): new `META_SORTCODE = 100` (registered with a readable "sort-code" name); the barcode reader tags the `ScanSuccess` sort code with `meta=100`; the FSM's bin/reject rules key their range conditions on it.
- **Read-on-the-fly belt** (`sorting.fsm`, `sorting_demo.py`): the belt runs continuously and the scanner reads on the fly (a missed read routes to reject). Removed the redundant per-parcel `SND_MSG 1002,101 Bool true` from all six routing rules (the belt is started by the START transition and a bin-clear, stopped only by safety rules); made the `ConveyorSim` belt start **idempotent** (a "start" to an already-running belt is a no-op, subsuming the old double-speed guard). Net effect: no per-parcel `ConveyorTimer` Cancel→Request churn.
- **GUI reconciliation + BC_RECORD fix** (`umm_gui/conveyor.html`, `sorting_demo.py`): the GUI no longer runs its own `sortBin()` — the diverter's `DIV_FIRED` is now the single source of truth (bound FIFO to the oldest pending parcel on C2). Bin thresholds now live in exactly one place (`sorting.fsm`). Separately, the barcode audit record was building TLVs with a non-existent `mword=` kwarg (silently raising `TypeError` and never emitting); fixed by tagging each `Int` with a `meta` (matching the field-identifier intent), which also exercises keyed selection.
- **Pulse channel + fail rate** (`examples/sorting/capabilities.py`, `sorting_demo.py`): belt-encoder `PulseC1/PulseC2` now publish on a dedicated `PULSE_CHANNEL = 127` instead of the app bus, so `parser --channel 1` shows parcel-level events without the pulse flood. `SCAN_FAIL_RATE` lowered `0.15 → 0.02`. (Note: the parcel-sorting demo is the origin of the "channels 127/128" idea — pulses on 127, simulation scaffolding on 128 — which is why it does not belong in the tank-demo chapter of the manual.)

*Session 31: Phil Braham (design/testing), Claude (implementation and notes). June 2026.*

---

## Session 32 — June 2026: three-volume manual set (documentation)

Produced the UMM documentation set as three Word volumes. This is a documentation session — no code changes to the library, router, or demos.

- **Vol 1 — Introduction & Concepts** (≈19 pp): concepts, messaging model, a hands-on Getting Started built up incrementally (base system → parser + send → console → tank demo → drive pump), a first look at content matching, agents & capabilities, appendices. Contains four screenshot **placeholders** (Figures 3.1–3.4) for Phil to drop images into.
- **Vol 2 — The UMM System (Reference)** (≈17 pp): architecture & attach, channels, the wire format, the type system, the authoritative content-matching rules (positional vs **meta-keyed**, ranges, operator tables — matching the Session 31 implementation), the router and its plugin port, standard services & the system mtype range, and the service modules.
- **Vol 3 — Building UMM Agents (Developer Guide)** (≈15 pp): writing a Python agent, capabilities, defining custom types, writing match criteria, the standard mixins, FSMs, cooperating with supervision, and the C implementation; appendices for the sorting demo and code skeletons.



---

## Session 33 — June 2026: FSM subscription model, reg_id reuse, tank robustness

### FSM subscriptions are now static (register-once), not per-state

**Background.** The FSM used to subscribe only to the *current* state's RCV_MSG
triggers and re-synchronise that set on every transition (`_register_state`
diffed the desired vs active subscriptions). The router therefore content-filtered
per state and delivered only messages that could fire a transition from the
current state. The cost was register/unregister churn on every transition.

Switching to register-once was first floated back in Session ~10 (the "register
one (mtype,subtype) and let `_find_matching_transition` check content" idea, once
content matching was added to the dispatcher) but was deferred as "a bigger
refactor; the current fix is sufficient" and never recorded — hence this note.

**What it does now.** `_register_triggers()` registers **one subscription per
distinct `(mtype, subtype)`** that appears as a trigger in *any* state, once at
startup (and on reconnect / after a config reload). No content filter, no
re-subscription on transitions. `_find_matching_transition` already gates on the
current state *and* content-matches the TLVs, so dispatch is unchanged.
`_register_state(tuple)` is retained as a thin alias for older call sites.

**Trade-off (decided: accept, with an opt-in).** The router no longer
content-filters per state, so the FSM receives every message on its trigger
`(mtype, subtype)` pairs and discards the ones that don't match the current
state. For FSM trigger types this traffic is small and the in-process check is
cheap. For the case where a trigger *is* high-rate and router-side filtering is
worth the churn, the old per-state model is available as an opt-in:

* `.fsm` directive (authoritative per machine, recommended):
  `SUBSCRIPTIONS per-state` — placed before the first STATE. `SUBSCRIPTIONS all`
  forces the default explicitly.
* launch flag: `--subscriptions per-state` (default `all`).

Precedence: a directive in the `.fsm` file overrides the launch flag. In
per-state mode the FSM re-syncs the current state's content-filtered
subscriptions on each transition (diffing so shared subscriptions aren't
churned); selective filtering is possible because dispatch always goes through
`_find_matching_transition`. The reg_id-reuse fix below means even per-state mode
no longer leaks ids on a long run.

**Why it mattered.** Re-registering on every transition was slowly leaking
registration ids (see below), which is what made a tank demo left running
overnight stop controlling its pump and overflow to 100%.

### reg_id reuse — `umm/agent.py`

reg_ids are chosen by the *client* and the router rejects `reg_id >=
MAX_REGISTRATIONS (64)`. `_register_local` used a monotonic counter that never
reused freed slots, so any agent that re-subscribed over time would eventually
hit 64 and have every new subscription rejected (`Invalid reg_id 64`). It now
allocates the lowest free id and reuses freed slots, so the id is bounded by the
number of *concurrently active* subscriptions, not the total ever created. This
is the base-class fix; all agents benefit (timers/feeds that add/remove subs over
long runs were equally exposed).

### Tank agent crash logging — `examples/tankLevel/tankLevel.py`

The overnight overflow left no cause in the log because unhandled exceptions in
async callbacks / the run loop went to stderr (not captured by the runumm log
wrapper). The tank agent now routes logging to stdout, wraps each message
callback so exceptions are logged with a full traceback (and the agent keeps
running), installs an asyncio loop exception handler, and logs the traceback if
`agent.run()` exits with an exception before it is restarted.

*Session 33: Phil Braham (design/testing), Claude (implementation and notes). June 2026.*

### Parser display — line truncation & colour (`umm/modules/parser.py`)

The startup `agentsResponse` (UMM,LIST_AGENTS_RESPONSE = 1,111) carries a large
JSON payload that used to wrap over many lines and push the header off-screen.

* **Truncation:** lines longer than the terminal width are now cut with a single
  `…`. On by default; `--dont-truncate` keeps full lines. Truncation only applies
  when stdout is a terminal — piped output (e.g. the runumm per-agent log) keeps
  full lines. Truncation is done on the plain text before colour so escape codes
  are never counted in the width.
* **Colour (terminal only):** auto-enabled when stdout is a tty and `NO_COLOR` is
  unset; `--no-color` / `--no-colour` / `--no-colors` / `--no-colours` force it
  off while keeping all other formatting (truncation, column layout) — only the
  ANSI is dropped, like `ls --color=never`. Whole-line colour by kind, earlier
  rule wins: agentsResponse → light grey; other mtype=1 → cyan; Debug channel →
  light grey; Confirm channel → green; Meta channel → magenta; subtype < 20 →
  yellow. The banner and (with `--heading`) the column header are shown bold.
  Piped output is never coloured, so logs stay clean.

### Parser colour configuration — `parser.conf` (`umm/modules/parser.py`)

Colours are now data-driven, from a single config file: `--config-file FILE`
(alias `--config`), or else `parser.conf` in the working directory by default.
A missing *explicitly-named* file warns at startup; a missing default
`parser.conf` is silent (built-ins used). An absent/empty file reproduces the
built-in defaults exactly, and unparseable lines are reported at startup and
skipped (never fatal). Colour is still emitted only when stdout is a terminal.

`[colors]` section, one rule per line, most-specific selector wins, file
overrides built-in at each tier:
`mtype <M> <S>` > `mtype <M>` > built-in `agentsResponse`/`control` >
`channel <C>` > built-in `debug`/`confirm`/`meta` > `subtype <S>` > built-in
`low-subtype` > `default`. Category keywords (`agentsResponse`, `control`,
`debug`, `confirm`, `meta`, `low-subtype`, `default`, `header`) recolour the
built-in rules. Colour tokens: the 8 base colours + `grey`/`bright_*`, plus
attributes `bold`/`dim`/`underline`/`reverse`, combinable ("bold green"), or
`none`. The loader (`load_parser_config`) fills a `color_rules` dict consumed by
`MessageFormatter._line_color`. A documented `parser.conf.example` is at the repo
root. Other sections (e.g. `[display]` for JSON rendering) are reserved and
currently ignored — the structure is in place to add them without touching the
colour logic.

## Session 34 — July 2026: chess demo (rules agent, board GUI, engine), two confirm-path core fixes

The first non-control-loop demo: two-player chess over UMM, human-vs-machine,
and engine self-play. Full protocol in `chess_protocol_spec.md`. Everything
below is integration-tested against a live router (three test suites at the
project root: `test_chess_rules.py` 10 tests, `test_chess_gui.py` two-board
WebSocket suite, `test_chess_engine.py` 4 parts) plus browser-tested by Phil.

### Protocol and allocation

mtypes 2000 ChessGame / 2001 ChessRules / 2002 ChessEngine / 2003
ChessPlayback (playback agent not yet built). Game traffic on Channel.APP (1);
legal-move request/response on user channel 11 (`CHESS_SVC_CHANNEL`) so
`parser --channel 1` shows exactly the story of the game. Application metas
(1000+): Char fen/uci-move/san-move/result/reason/pgn-path/backend, Int
game-id/colour/game-status/square/move-number, Float seconds. Every message
carries `Int(game_id)` — multi-game is a pure meta-keyed subscription exercise
(Session 31 feature). Pipeline invariant: proposer → MoveProposed → rules
agent → MoveConfirmed/MoveRejected; everything downstream subscribes only to
confirmed moves (single source of truth, like the sorting demo's DIV_FIRED).

**Attach identity vs protocol address** (umm.conf lesson): `type` in an
[agent.*] section is the instance's attach identity and must be unique
(umm_ctl validates); the mtypes an agent serves are independent. The two
configured engine instances attach as 2005/2006 while both subscribe to the
2002 control protocol — corollary: EngineStop (2002,102) stops both engines of
a pair; per-instance control would need an identity match TLV (future).

### Two latent core bugs — the Session 7 confirm machinery never worked

The chess GUI's presence detection is the first real consumer of
CONFIRM_RTR / `send_confirmed`, and it exposed two independent, stacked bugs
that made the confirm callbacks a guaranteed 100% loss since Session 7:

1. **Router (`umm/router.py`, `_send_confirm`)**: confirms were
   direct-delivered with `reg_id=0`, but agents dispatch incoming messages by
   reg_id — every confirm was silently dropped client-side ("No callback for
   reg_id=0"). Fix: `_stamp_reg_id()` runs `self._lookup.find_matches(resp)`
   filtered to the origin attach and stamps the matching registration's reg_id
   before delivery, preserving the invariant *reg_id > 0 ⇔ router matched a
   subscription*. Router-side fix so all clients benefit. **The C router port
   needs the same fix — not yet done.**
2. **Agent (`umm/agent.py`, `send_confirmed`)**: it sent the message *before*
   registering the confirm subscriptions; the router generates the confirm
   immediately after routing, so the confirm always beat the registration.
   Fix: registrations moved before the send — REGISTER and the send travel the
   same ordered TCP stream, so the router processes them in order.

Verified: `on_router_confirm` fires with count 0 (no subscribers) and ≥1.

**Confirm-count semantics** (spec §7a, learned the hard way): the delivered
count says how many subscribers heard a message, never *who*. A proposal with
a second board attached confirms count=1 even with no rules agent; and any
wildcard monitor (a running parser!) also counts — which masked the GUI's
"no rules agent" banner on Phil's machine. count=0 is definitive absence;
positive counts are circumstantial; the 2.5 s proposal timeout is the
backstop. A definitive identity-based check (capability query / heartbeat) is
a noted student exercise.

### Components

* **`examples/chess/rules_agent.py`** — the single legality/state authority,
  wrapping python-chess (PyPI dep, GPL-3, imported not vendored — BUSL
  posture; install notes incl. PEP 668/Homebrew in spec §8.1 and in the
  agent's own ImportError message). Validates NEW_GAME FENs
  (`Board.status()`), answers LegalReq per-square or all on channel 11,
  adjudicates mate/stalemate/draws/resignation. Handlers `_guard`-wrapped,
  logging to stdout (both Session 33 lessons applied).
* **`umm_gui/chess.html`** — board GUI in the tank/conveyor design language.
  Drag or click-select with legal-target highlighting (LegalReq on pick-up),
  Setup-mode position editor (piece tray, castling checkboxes auto-disabled
  off home squares, side-to-move, FEN paste/copy as the escape hatch),
  rotate, roles white/black/observer, SAN move list, promotion chooser, draw
  offer/accept, resign. **Browser lesson:** HTML5 aborts a drag the moment its
  source element leaves the DOM — the legal-move highlight pass was rebuilding
  the board on dragstart, killing every drag invisibly. chess.html separates
  `render()` (DOM rebuild, position/orientation changes only) from `paint()`
  (class-only highlight updates, safe mid-drag). Char TLV values arrive from
  the GUI server wrapped in one pair of quotes (to_text convention) — getTlv
  strips exactly that pair.
* **`examples/chess/engine_agent.py`** — a machine player, architecturally a
  headless board: subscribes to BoardState/MoveConfirmed, proposes when the
  FEN side-to-move equals its colour (0/1, or 2=both for self-play).
  Search on a worker thread (callbacks only record + poke); latest-position-
  wins with a stale-FEN check; a rejected proposal is logged and never
  retried. Runtime control: EngineConfig/Go/Stop/Status (2002,100–103).
  Backends in `examples/chess/engines/`: `minimax.py` (bundled, original
  code) and `uci_backend.py` (Stockfish etc. via python-chess —
  **not yet run against a real binary**).

### Engine-vs-engine fivefold fix (field bug from Phil's parser log)

Two deterministic engines with a symmetric eval are a repetition machine —
the log showed a rook shuttle (burning castling rights, visible in the FEN)
until the rules agent correctly adjudicated fivefold at move 12. Fixes:
(1) the engine agent keeps a **history-synced board** (pushes each confirmed
move; FEN alone carries no history — spec Appendix A — so a rebuilt board
cannot see repetitions); (2) minimax scores a looming repetition at −25
(contempt) while stalemate/material draws keep their true 0; (3) root picks
randomly among moves within 15 cp of best — implementation trap: root moves
must be searched with the FULL window, since alpha-narrowed results are
bounds, not exact scores (caught by the mate-in-one regression test).
Verified: 40-ply self-play with real fighting chess, shuttle detector
negative, opening variety across runs.

### GUI server extensions — `umm_gui/server.py` (generic, all demos benefit)

* `send` action accepts optional `channel` (default −1 = agent default) and
  `flags` (MsgFlag bits) — needed for channel-11 traffic and CONFIRM_RTR from
  the browser.
* `/chess` and `/chess.html` routes added (explicit-route convention).
* Project-file support matching the parser: auto-loads the top-level
  `project.conf`, and `--project FILE` (repeatable) applies `[names]` +
  `[meta]` to the GUI message display ([colors] is parser-only).

### Configuration

* **`examples/chess/chess.conf`** — consolidated project file
  (sorting.conf format): [names] for all four mtypes and every subtype,
  [meta] for the thirteen chess metas, [colors] (MoveConfirmed bright green,
  rejections yellow, channel-11 plumbing dimmed). Use:
  `runumm start parser -- --project examples/chess/chess.conf`.
* **`umm.conf`** — chess group + engines, all validated and stack-tested:
  `runumm start chess` (rules agent), `start chess-engine-black` /
  `chess-engine-white`, `start chess-engines` (engine vs engine).
* RULES_CAPABILITY `what` renamed **ChessGame** — capability names derive the
  parser's default mtype display, and the capability names the protocol
  (mtype 2000), not the agent.
* Shared decode helpers extracted to `examples/chess/tlvutil.py` (used by
  rules and engine agents).

### Open items

1. **C router port: apply the `_send_confirm` reg_id fix** (highest priority —
   the Python fix restores a documented feature the C port still lacks).
2. Playback agent (PGN, spec §6.5); `sunfish_backend.py` optional/deferred.
3. Run `uci_backend.py` against a real Stockfish
   (`brew install stockfish`, `--backend uci --uci-path $(which stockfish)`).
4. Per-instance engine control (identity/colour match TLV on 2002).
5. Identity-based rules-agent liveness (capability query or heartbeat) to
   replace the count-based probe where wildcard monitors defeat it.
6. Teacher's manual and the graded student ladder (logger → playback →
   observer → rules → clock → engine) — chess appendix for the manuals when
   the demo settles.

*Session 34: Phil Braham (design, browser and field testing — the fivefold
log and the drag bug were his catches), Claude (implementation and notes).
July 2026.*

## Sessions 35–37 — July 2026 (detail in SESSION_35/36/37_NOTES.md, shipped alongside this file)

**Session 35** — chess playback agent (mtype 2003) + GUI playback panel
(49 tests); FEN-on-LegalResp divergence detection in rules agent and
chess.html; Vol 3 Appendix C; six-project teaching ladder document.

**Session 36** — Vol 3 **Chapter 8 Writing a GUI** (C Implementation →9,
Match Plugin →10; pasted by Phil); `umm_gui/template.html` (mtype 900)
+ test_template_gui.py; **C router CONFIRM_RTR/CONFIRM_RCV** — a port,
not a fix: the C router had no message-confirm machinery, implemented
with the Session 34 reg_id stamping correct from the start
(test_c_router_confirm.py, 20 checks).

**Session 37** — capability queries fixed for config-driven agents.
FSM/database capability descriptors were import-time snapshots
(mtype 5/8), so every `type`-overridden instance in umm.conf (1055,
1056, 5055, 1008, 5008) ignored targeted queries and mis-advertised in
discovery. Applied timer's `replace(cap, mtype=...)` patch in fsm.py
and database.py (database also gains `instance=process_name`). Plus
two capability.py bugs: `query_capability()`/`discover_agents()`
subscribed on channel 1 but responses travel on META (4) — the CLI
timed out against every agent (GUI unaffected, it subscribes ch 4);
and targeted queries produced duplicate responses (both mixin
subscriptions fired) — broadcast handler now ignores Int-payload
queries. All verified live at overridden and default mtypes.

**Standing open items:** teaching ladder → Teacher's Manual; C agent
send_confirmed() helper; Appendix C paragraph styles in Word export;
chess names in umm_names.conf; docs check for capability-query
behaviour changes (S37 notes §5).
