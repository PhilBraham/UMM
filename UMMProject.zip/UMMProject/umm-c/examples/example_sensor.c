/**
 * example_sensor.c  —  Example UMM agent in C.
 *
 * Demonstrates:
 *   - Publishing typed messages (temperature readings as TLV_FLOAT)
 *   - Subscribing with a content-based match (float > threshold)
 *   - The transport abstraction (TCP by default)
 *
 * Compile:
 *   gcc -I../include example_sensor.c ../src/umm_tlv.c \
 *       ../src/umm_msg.c ../src/umm_agent.c -o sensor
 *
 * Run alongside a running UMM router (Python or C):
 *   ./sensor --host localhost --port 5300 --mode publish
 *   ./sensor --host localhost --port 5300 --mode subscribe --threshold 80.0
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#include "umm_agent.h"
#include "umm_tlv.h"
#include "umm_types.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>

/* Application mtype and subtypes */
#define MT_SENSOR     100
#define ST_READING    1     /* Float(temperature_celsius) */

static volatile bool g_running = true;

/* ── subscriber callback ──────────────────────────────────────────────────── */

static void on_high_temp(UMMAgent *ag, const UMMMsg *msg, void *userdata) {
    double threshold = *(double *)userdata;
    double temp = 0.0;
    UMMTLV tlv;

    if (tlv_find(msg->tdata.value, msg->tdata.length, TLV_FLOAT, &tlv))
        tlv_get_float(&tlv, &temp);

    printf("ALERT: Temperature %.1f°C exceeds threshold %.1f°C\n",
           temp, threshold);
    (void)ag;
}

/* ── publisher mode ───────────────────────────────────────────────────────── */

static void run_publisher(const char *host, uint16_t port) {
    UMMAgent *ag = umm_agent_create("TempSensor", MT_SENSOR);
    if (!ag) { fprintf(stderr, "Failed to create agent\n"); return; }

    if (!umm_agent_connect_tcp(ag, host, port)) {
        fprintf(stderr, "Failed to connect to %s:%u\n", host, port);
        umm_agent_destroy(ag);
        return;
    }
    printf("Publisher connected (attach_id=%u)\n", umm_agent_attach_id(ag));

    double base_temp = 70.0;
    int    tick      = 0;

    while (g_running) {
        /* Simulate a sensor with some drift */
        double temp = base_temp + 15.0 * sin(tick * 0.1);
        tick++;

        uint8_t payload[32]; size_t plen = 0;
        tlv_encode_float(payload, sizeof payload, &plen, temp, MWORD_NONE, META_NONE);

        bool ok = umm_agent_send(ag, MT_SENSOR, ST_READING,
                                  CHAN_APP, 0, payload, plen);
        printf("Published: %.1f°C  %s\n", temp, ok ? "OK" : "FAIL");

        sleep(1);
    }

    umm_agent_disconnect(ag);
    umm_agent_destroy(ag);
}

/* ── subscriber mode ──────────────────────────────────────────────────────── */

static void run_subscriber(const char *host, uint16_t port, double threshold) {
    UMMAgent *ag = umm_agent_create("AlarmConsole", 0);
    if (!ag) { fprintf(stderr, "Failed to create agent\n"); return; }

    if (!umm_agent_connect_tcp(ag, host, port)) {
        fprintf(stderr, "Failed to connect to %s:%u\n", host, port);
        umm_agent_destroy(ag);
        return;
    }
    printf("Subscriber connected (attach_id=%u), threshold=%.1f°C\n",
           umm_agent_attach_id(ag), threshold);

    /* Build match TLVs: Float > threshold  (MATCH_GT = 2) */
    uint8_t match[32]; size_t mlen = 0;
    tlv_encode_float(match, sizeof match, &mlen, threshold, MATCH_GT, META_NONE);

    int reg = umm_agent_register(ag, MT_SENSOR, ST_READING,
                                   CHAN_APP, on_high_temp, &threshold,
                                   match, mlen);
    if (!reg) {
        fprintf(stderr, "Registration failed\n");
        umm_agent_destroy(ag);
        return;
    }
    printf("Registered subscription id=%d (Float > %.1f)\n", reg, threshold);

    umm_agent_run(ag);   /* blocks dispatching callbacks */

    umm_agent_destroy(ag);
}

/* ── main ─────────────────────────────────────────────────────────────────── */

int main(int argc, char *argv[]) {
    const char *host      = "localhost";
    uint16_t    port      = UMM_DEFAULT_PORT;
    const char *mode      = "publish";
    double      threshold = 80.0;

    for (int i = 1; i < argc; i++) {
        if      (!strcmp(argv[i], "--host")      && i+1<argc) host      = argv[++i];
        else if (!strcmp(argv[i], "--port")      && i+1<argc) port      = (uint16_t)atoi(argv[++i]);
        else if (!strcmp(argv[i], "--mode")      && i+1<argc) mode      = argv[++i];
        else if (!strcmp(argv[i], "--threshold") && i+1<argc) threshold = atof(argv[++i]);
    }

    if (!strcmp(mode, "publish"))
        run_publisher(host, port);
    else if (!strcmp(mode, "subscribe"))
        run_subscriber(host, port, threshold);
    else {
        fprintf(stderr, "Unknown mode '%s' (use publish or subscribe)\n", mode);
        return 1;
    }
    return 0;
}
