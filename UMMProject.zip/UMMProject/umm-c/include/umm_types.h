/**
 * umm_types.h  —  UMM wire format constants, enumerations, and structs.
 *
 * This header defines the complete UMM protocol as C types.  It is the
 * authoritative reference for the wire format and is shared by both the
 * router and agent library.
 *
 * Wire layout of UMMMsg
 * ---------------------
 *   VersionId   4   ummIdent(1) msgVersion(1) major(1) minor(1)
 *   AttachId    8   router_id(4,NBO) + id(4,NBO)
 *   Origin      8   router_id(4,NBO) + id(4,NBO)
 *   UTime      12   secs(4,NBO) + ms(2,NBO) + tz(2,NBO) + dst(2,NBO) + pad(2)
 *   Flags       4   NBO
 *   RegId       4   NBO
 *   MsgId       4   NBO
 *   Mtype       4   NBO (signed)
 *   SubType     4   NBO (signed)
 *   Channel     1
 *   Reserved    3   (zero on send, ignored on receive)
 *   TData      16+  TLV header (16 bytes) + value
 *
 *   Fixed header  = 56 bytes
 *   TData min     = 16 bytes  (TLV_TERM, length=0)
 *   Minimum msg   = 72 bytes
 *
 * Wire layout of a TLV
 * --------------------
 *   Type    4   uint32, NBO
 *   Match   4   uint32, NBO  (operator index in subscriptions; qualifier in messages)
 *   Meta    4   uint32, NBO  (0 = absent, always matches)
 *   Length  4   uint32, NBO  (byte count of Value)
 *   Value   Length bytes
 *   Padding 0–3 bytes  (zero-padded to next 4-byte boundary)
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#pragma once
#ifndef UMM_TYPES_H
#define UMM_TYPES_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── version ──────────────────────────────────────────────────────────────── */

#define UMM_IDENT          'U'
#define UMM_MSG_VERSION    'C'
#define UMM_VERSION_MAJOR   1
#define UMM_VERSION_MINOR   4

#define UMM_VERSION_STR    "1.4"

/* ── limits ───────────────────────────────────────────────────────────────── */

#define UMM_MAX_ATTACHES      1024
#define UMM_MAX_REGISTRATIONS   64
#define UMM_MAX_BUFF_SIZE     (32 * 1024)
#define UMM_MAX_NAME_LEN        64
#define UMM_DEFAULT_PORT      5300

/* ── TLV type IDs ─────────────────────────────────────────────────────────── */

#define TLV_TERM       0
#define TLV_RAW        1
#define TLV_INT        2
#define TLV_UINT       3
#define TLV_SHORT      4
#define TLV_USHORT     5
#define TLV_FLOAT      6
#define TLV_BOOL       7
#define TLV_STRING     8
#define TLV_UTIME      9
#define TLV_METADATA  10
#define TLV_MSG       11
#define TLV_ATTID     12
#define TLV_COORD     13
#define TLV_FNAME     14
#define TLV_LOGID     15
#define TLV_MSGREF    16
#define TLV_ROUTER_ID 17
#define TLV_JSON      18
#define TLV_SUBSPEC   19

/* ── TLV constants ────────────────────────────────────────────────────────── */

#define TLV_HEADER_SIZE   16            /* Type(4)+Match(4)+Meta(4)+Length(4) */
#define TLV_ALIGN         4
#define MWORD_NONE        0
#define META_NONE         0
#define MWORD_IGNORE      0xFFFFFFFFu   /* subscription: skip this positional slot */

/* Match operators (match word in subscription TLVs) */
typedef enum {
    MATCH_EQ        = 0,
    MATCH_NE        = 1,
    MATCH_GT        = 2,
    MATCH_LT        = 3,
    MATCH_GE        = 4,
    MATCH_LE        = 5,
    MATCH_CONTAINS  = 6,
    MATCH_WILDCARD  = 7,
    MATCH_SOUNDSLIKE= 8,
    MATCH_WITHIN    = 11,
    MATCH_WITHIN_3D = 12,
    MATCH_BBOX      = 13,
} UMMMatchOp;

/* ── message fixed header size ────────────────────────────────────────────── */

#define UMM_FIXED_HEADER_SIZE  56  /* bytes before TData */

/* ── channel numbers ──────────────────────────────────────────────────────── */

typedef enum {
    CHAN_ALL        = 0,   /* subscription wildcard — matches any channel */
    CHAN_APP        = 1,   /* application bus (default) */
    CHAN_CONFIRM    = 2,   /* delivery confirmations */
    CHAN_DEBUG      = 3,   /* runtime debug output */
    CHAN_META       = 4,   /* capability and version responses */
    CHAN_HEARTBEAT  = 5,   /* supervisor liveness */
    CHAN_SUPERVISOR = 6,   /* supervisor control */
    CHAN_BRIDGE     = 7,   /* inter-router bridge */
    CHAN_SIM        = 128, /* simulation traffic */
} UMMChannel;

/* ── mtypes ───────────────────────────────────────────────────────────────── */

typedef enum {
    /* infrastructure channels (negative) */
    MTYPE_CONFIRM    = -1,
    MTYPE_DEBUG      = -2,
    MTYPE_META       = -3,
    MTYPE_HEARTBEAT  = -4,
    /* system services */
    MTYPE_NULL       =  0,
    MTYPE_UMM        =  1,   /* router control — RESERVED */
    MTYPE_TIMER      =  2,
    MTYPE_COMMAND    =  3,
    MTYPE_METADATA   =  4,
    MTYPE_FSM        =  5,
    MTYPE_FILESEND   =  6,
    MTYPE_FILERECV   =  7,
    MTYPE_DATABASE   =  8,
    MTYPE_MICROBILL  =  9,
    MTYPE_TYPEDIR    = 10,
    MTYPE_BRIDGE     = 11,
    MTYPE_SUPERVISOR = 12,
    MTYPE_GUI        = 13,
    MTYPE_FEED       = 14,
    MTYPE_FEED_ITEM  = 15,
    /* user start */
    MTYPE_USER_START = 1000,
} UMMMType;

/* ── UMM system subtypes (mtype=1) ────────────────────────────────────────── */

typedef enum {
    /* wire protocol (1–50) */
    ST_VERSION          = -1,   /* legacy: request router version */
    ST_INIT             =  0,   /* R→C  acknowledge connection */
    ST_ATTACH           =  1,   /* C→R  attach with flags/login */
    ST_ATTACH_CONFIRM   =  2,   /* R→C  attach confirmed */
    ST_DETACH           =  3,   /* C→R  detach */
    ST_REGISTER         =  4,   /* C→R  register a subscription */
    ST_UNREGISTER       =  5,   /* C→R  unregister */
    ST_SHUTDOWN         =  6,   /* C→R  initiate router/agent shutdown */
    ST_AGENT_ATTACHED   =  7,   /* R→*  lifecycle: agent joined */
    ST_AGENT_DETACHED   =  8,   /* R→*  lifecycle: agent left */
    ST_AGENT_REATTACHED =  9,   /* R→*  lifecycle: agent reconnected */
    /* router query services (51–99) */
    ST_CAPABILITY_QUERY    = 51,
    ST_CAPABILITY_RESPONSE = 52,
    ST_VERSION_REQUEST     = 53,
    ST_VERSION_RESPONSE    = 54,
    ST_STATUS_REQUEST      = 55,
    ST_STATUS_RESPONSE     = 56,
    ST_MATCH_QUERY         = 57,
    ST_MATCH_RESULT        = 58,
    ST_SYSTEM_SHUTDOWN     = 59,
    /* system messages (100+) */
    ST_SYS_ERROR              = 100,
    ST_SYS_INFO               = 101,
    ST_SYS_WARN               = 102,
    ST_SYS_DENIED             = 103,
    ST_LIST_AGENTS            = 110,
    ST_LIST_AGENTS_RESPONSE   = 111,
    ST_LIST_TYPES             = 112,
    ST_LIST_TYPES_RESPONSE    = 113,
    ST_LIST_SUBS              = 114,
    ST_LIST_SUBS_RESPONSE     = 115,
} UMMSubType;

/* ── confirm subtypes (mtype = MTYPE_CONFIRM, channel = CHAN_CONFIRM) ─────── */

typedef enum {
    CST_ERROR          = 1,   /* Int(source_mtype) MsgRef Int(code) Char(desc) */
    CST_ROUTER_CONFIRM = 2,   /* MSG_CONFIRM_RTR: Int(source_mtype) MsgRef Int(receiver_count) */
    CST_RECEIVER_ACK   = 3,   /* MSG_CONFIRM_RCV: Int(source_mtype) MsgRef */
    CST_APP_ACK        = 4,   /* MSG_CONFIRM_APP: Int(source_mtype) MsgRef */
} UMMConfirmSubType;

/* ── standard reserved subtypes (all positive mtypes) ────────────────────── */

#define RST_GET_CAPABILITY   1
#define RST_GET_VERSION      2
#define RST_SET_DEBUG        3
#define RST_SHUTDOWN         4

/* ── flags ────────────────────────────────────────────────────────────────── */

typedef enum {
    ATTACH_NORMAL        = 0x00000,
    ATTACH_PERM_KEEP     = 0x00001,   /* critical — queue msgs if offline */
    ATTACH_TRANS_KEEP    = 0x00002,   /* may disconnect temporarily */
    ATTACH_MONITOR       = 0x00004,   /* non-intrusive monitor */
    ATTACH_TRUSTED       = 0x00008,   /* privileged — may issue system commands */
    ATTACH_MULTI_REG     = 0x00010,   /* multi-match delivery */
} UMMAttachFlag;

typedef enum {
    DETACH_NORMAL  = 0x00100,
    DETACH_FORCED  = 0x00200,
} UMMDetachFlag;

typedef enum {
    ATTACH_CONF_NORMAL     = 0x01000,
    ATTACH_CONF_PERM_NEW   = 0x02000,
    ATTACH_CONF_PERM_REATT = 0x04000,
    ATTACH_CONF_PERM_DUP   = 0x08000,
} UMMAttachConfFlag;

typedef enum {
    REQ_DONT_SEND_SELF = 0x80000,   /* don't echo back to sender */
    REQ_LAST_REQUEST   = 0x40000,   /* final registration — flush queue */
} UMMRequestFlag;

typedef enum {
    MSG_SEND_RCVS    = 0x00001,   /* router sends back receiver count */
    MSG_CONFIRM_RTR  = 0x00002,   /* router confirms receipt */
    MSG_CONFIRM_RCV  = 0x00004,   /* receiver sends confirmation */
    MSG_CONFIRM_APP  = 0x00008,   /* application sends confirmation */
    MSG_SERIES       = 0x00010,
    MSG_SERIES_START = 0x00020,
    MSG_SERIES_END   = 0x00040,
} UMMMsgFlag;

/* ── attach status (internal router use) ──────────────────────────────────── */

#define EAS_UNUSED          0x00
#define EAS_INUSE           0x01
#define EAS_UNCLEARED_STATS 0x02
#define EAS_DETACHED        0x04
#define EAS_OFFLINE         0x08
#define EAS_REATTACH        0x10
#define EAS_RUNNING         0x20

/* ── wire structs ─────────────────────────────────────────────────────────── */

/**
 * UMM TLV header (16 bytes, all fields NBO).
 * Immediately followed by Length bytes of value, then 0–3 padding bytes.
 */
typedef struct __attribute__((packed)) {
    uint32_t type_id;
    uint32_t match;
    uint32_t meta;
    uint32_t length;
} UMMTLVHeader;

/**
 * UMM message fixed header (56 bytes, all multibyte fields NBO).
 */
typedef struct __attribute__((packed)) {
    /* VersionId — 4 bytes */
    uint8_t  umm_ident;
    uint8_t  msg_version;
    uint8_t  major;
    uint8_t  minor;
    /* AttachId — 8 bytes */
    uint32_t attach_router;
    uint32_t attach_id;
    /* Origin — 8 bytes */
    uint32_t origin_router;
    uint32_t origin_id;
    /* UTime — 12 bytes */
    uint32_t time_secs;
    uint16_t time_ms;
    int16_t  time_tz;
    int16_t  time_dst;
    uint16_t time_pad;
    /* scalars — 20 bytes */
    int32_t  flags;
    int32_t  reg_id;
    int32_t  msg_id;
    int32_t  mtype;
    int32_t  subtype;
    /* channel + reserved — 4 bytes */
    uint8_t  channel;
    uint8_t  reserved[3];
} UMMHeader;

/* Compile-time check that our struct matches the documented wire layout */
_Static_assert(sizeof(UMMHeader) == UMM_FIXED_HEADER_SIZE,
               "UMMHeader must be exactly 56 bytes");

/**
 * In-memory representation of a TLV.
 * value points into a larger buffer — do not free individually.
 */
typedef struct {
    uint32_t       type_id;
    uint32_t       match;
    uint32_t       meta;
    uint32_t       length;
    const uint8_t *value;   /* points into owning buffer */
} UMMTLV;

/**
 * In-memory representation of a UMM message.
 * The header is a copy; tdata_value points into the read buffer.
 */
typedef struct {
    UMMHeader      hdr;
    UMMTLV         tdata;
} UMMMsg;

#ifdef __cplusplus
}
#endif

#endif /* UMM_TYPES_H */
