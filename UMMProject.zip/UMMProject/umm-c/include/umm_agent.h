/**
 * umm_agent.h  —  UMM agent (client) library.
 *
 * Provides a synchronous, callback-driven API for writing UMM agents in C.
 * The transport layer is abstracted so the same agent code can run over
 * TCP/IP, a UNIX domain socket, or Bluetooth RFCOMM — see UMMTransport.
 *
 * Typical usage:
 *
 *   UMMAgent *ag = umm_agent_create("MySensor", 100);
 *   umm_agent_connect_tcp(ag, "localhost", 5300);
 *
 *   // Subscribe to a message type
 *   umm_agent_register(ag, 200, 1, CHAN_APP, on_data, NULL, NULL, 0);
 *
 *   // Publish a message
 *   uint8_t payload[64]; size_t plen = 0;
 *   tlv_encode_float(payload, sizeof payload, &plen, 72.5, MWORD_NONE, META_NONE);
 *   umm_agent_send(ag, 100, 1, CHAN_APP, 0, payload, plen);
 *
 *   umm_agent_run(ag);   // blocks dispatching callbacks
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#pragma once
#ifndef UMM_AGENT_H
#define UMM_AGENT_H

#include "umm_types.h"
#include "umm_tlv.h"

#ifdef __cplusplus
extern "C" {
#endif

/* forward declarations */
typedef struct UMMAgent     UMMAgent;
typedef struct UMMTransport UMMTransport;

/* ── callback types ───────────────────────────────────────────────────────── */

/**
 * Message callback.
 * Called for every delivered message that matches a registration.
 *
 * @param agent  The receiving agent.
 * @param msg    The delivered message.  Valid only for the duration of the call.
 * @param userdata  The pointer passed to umm_agent_register().
 */
typedef void (*UMMCallback)(UMMAgent *agent, const UMMMsg *msg, void *userdata);

/**
 * Connection state callback.
 * Called when the agent attaches to or detaches from the router.
 */
typedef void (*UMMStateCallback)(UMMAgent *agent, bool connected, void *userdata);

/* ── transport abstraction ────────────────────────────────────────────────── */

/**
 * Transport vtable.  Implement this struct to add a new transport backend
 * (TCP, UNIX socket, Bluetooth RFCOMM, SPI, etc.).
 *
 * All functions are mandatory unless noted.
 */
struct UMMTransport {
    /** Human-readable name (e.g. "tcp", "rfcomm", "unix"). */
    const char *name;

    /**
     * Connect/open the transport.
     * @param xp        This transport instance.
     * @param address   Address string (interpretation is transport-specific:
     *                  "host:port" for TCP, device path for RFCOMM/serial).
     * @return          true on success.
     */
    bool (*connect)(UMMTransport *xp, const char *address);

    /**
     * Disconnect/close the transport.
     */
    void (*disconnect)(UMMTransport *xp);

    /**
     * Send exactly len bytes.
     * @return  true on success, false on error.
     */
    bool (*send)(UMMTransport *xp, const uint8_t *data, size_t len);

    /**
     * Receive exactly len bytes (blocking).
     * @return  true on success, false on EOF or error.
     */
    bool (*recv)(UMMTransport *xp, uint8_t *data, size_t len);

    /**
     * Return a file descriptor suitable for select()/poll(), or -1 if not
     * applicable.  Optional — return -1 if unsupported.
     */
    int  (*fd)(UMMTransport *xp);

    /** True if the transport is currently open. */
    bool (*is_connected)(UMMTransport *xp);

    /** Free any resources allocated by this transport instance. */
    void (*destroy)(UMMTransport *xp);
};

/* ── built-in transport constructors ──────────────────────────────────────── */

/**
 * Create a TCP/IP transport.
 * @param host  Hostname or IP address.
 * @param port  Port number (0 → UMM_DEFAULT_PORT).
 */
UMMTransport *umm_transport_tcp_create(const char *host, uint16_t port);

/**
 * Create a UNIX domain socket transport.
 * @param path  Socket path (e.g. "/tmp/umm.sock").
 */
UMMTransport *umm_transport_unix_create(const char *path);

/**
 * Create a Bluetooth RFCOMM transport.
 * @param address  Bluetooth device address (e.g. "AA:BB:CC:DD:EE:FF").
 * @param channel  RFCOMM channel number (1–30).
 *
 * Only compiled when UMM_HAVE_BLUETOOTH is defined.  On Linux this uses
 * the BlueZ socket API directly (no external library needed).
 */
#ifdef UMM_HAVE_BLUETOOTH
UMMTransport *umm_transport_rfcomm_create(const char *address, uint8_t channel);
#endif

/** Free a transport created by any of the above constructors. */
void umm_transport_destroy(UMMTransport *xp);

/* ── agent lifecycle ──────────────────────────────────────────────────────── */

/**
 * Create a new agent.
 *
 * @param process_name  Human-readable name for this agent (max 63 chars).
 * @param agent_mtype   Primary mtype handled by this agent (0 = none).
 * @return              New agent, or NULL on allocation failure.
 */
UMMAgent *umm_agent_create(const char *process_name, int32_t agent_mtype);

/**
 * Free all resources held by the agent.
 * Disconnects first if still connected.
 */
void umm_agent_destroy(UMMAgent *ag);

/**
 * Set the transport.  Must be called before umm_agent_connect().
 * Takes ownership of xp (will call umm_transport_destroy on destroy).
 */
void umm_agent_set_transport(UMMAgent *ag, UMMTransport *xp);

/**
 * Convenience: create a TCP transport and connect.
 * Equivalent to umm_agent_set_transport + umm_agent_connect.
 */
bool umm_agent_connect_tcp(UMMAgent *ag, const char *host, uint16_t port);

/**
 * Connect using the currently set transport and perform the UMM attach
 * handshake (ATTACH → ATTACH_CONFIRM).
 *
 * @param flags  UMMAttachFlag bitfield (0 = ATTACH_NORMAL).
 * @return       true if attached successfully.
 */
bool umm_agent_connect(UMMAgent *ag, uint32_t flags);

/**
 * Gracefully detach from the router and close the transport.
 */
void umm_agent_disconnect(UMMAgent *ag);

/**
 * Return true if the agent is currently attached to a router.
 */
bool umm_agent_is_connected(const UMMAgent *ag);

/**
 * Set a state-change callback (called on connect/disconnect).
 */
void umm_agent_set_state_callback(UMMAgent *ag,
                                   UMMStateCallback cb, void *userdata);

/* ── subscriptions ────────────────────────────────────────────────────────── */

/**
 * Register a subscription.
 *
 * @param ag          Agent.
 * @param mtype       Message type to subscribe to (0 = wildcard).
 * @param subtype     Sub-type (0 = all of mtype).
 * @param channel     Channel (CHAN_ALL = any channel).
 * @param callback    Function to call when a matching message arrives.
 * @param userdata    Passed through to callback unchanged.
 * @param match_tlvs  Raw encoded match TLVs (content-based filter), or NULL.
 * @param match_len   Byte length of match_tlvs.
 * @return            Registration ID (>0 on success, 0 on failure).
 */
int umm_agent_register(UMMAgent *ag,
                        int32_t   mtype,
                        int32_t   subtype,
                        int       channel,
                        UMMCallback callback,
                        void     *userdata,
                        const uint8_t *match_tlvs,
                        size_t         match_len);

/**
 * Remove a subscription by its registration ID.
 * @return  true if the registration was found and removed.
 */
bool umm_agent_unregister(UMMAgent *ag, int reg_id);

/* ── sending ──────────────────────────────────────────────────────────────── */

/**
 * Send a message.
 *
 * @param ag        Agent.
 * @param mtype     Message type.
 * @param subtype   Sub-type.
 * @param channel   Logical channel (CHAN_APP for normal traffic).
 * @param flags     UMMMsgFlag bitfield (0 = no flags).
 * @param payload   Encoded TLV bytes (may be NULL for no payload).
 * @param pay_len   Byte length of payload.
 * @return          true on success.
 */
bool umm_agent_send(UMMAgent *ag,
                    int32_t   mtype,
                    int32_t   subtype,
                    int       channel,
                    uint32_t  flags,
                    const uint8_t *payload,
                    size_t         pay_len);

/**
 * Convenience: send with no payload.
 */
static inline bool umm_agent_send_empty(UMMAgent *ag,
                                         int32_t mtype, int32_t subtype) {
    return umm_agent_send(ag, mtype, subtype, CHAN_APP, 0, NULL, 0);
}

/* ── event loop ───────────────────────────────────────────────────────────── */

/**
 * Receive and dispatch one message (blocking).
 *
 * Reads one complete message from the transport, finds matching
 * subscriptions, and calls their callbacks.
 *
 * @return  true on success, false on disconnect or error.
 */
bool umm_agent_poll(UMMAgent *ag);

/**
 * Run the agent's receive loop until disconnected or umm_agent_stop() called.
 * Blocks the calling thread.
 */
void umm_agent_run(UMMAgent *ag);

/**
 * Signal umm_agent_run() to return on next iteration.
 * Safe to call from a signal handler or another thread.
 */
void umm_agent_stop(UMMAgent *ag);

/* ── query helpers ────────────────────────────────────────────────────────── */

/**
 * Return the attach_id assigned by the router (valid after connect).
 */
uint32_t umm_agent_attach_id(const UMMAgent *ag);

/**
 * Return the router_id of the connected router (valid after connect).
 */
uint32_t umm_agent_router_id(const UMMAgent *ag);

/**
 * Return the next available message ID (auto-incremented on each send).
 */
int32_t umm_agent_next_msg_id(UMMAgent *ag);

/* ── standard query helpers ───────────────────────────────────────────────── */

/**
 * Send a GetCapability query.
 * @param mtype  Target mtype, or 0 for broadcast.
 */
bool umm_agent_query_capability(UMMAgent *ag, int32_t mtype);

/**
 * Send a ListAgents request.
 */
bool umm_agent_list_agents(UMMAgent *ag);

#ifdef __cplusplus
}
#endif

#endif /* UMM_AGENT_H */
