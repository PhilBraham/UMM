/**
 * umm_tlv.h  —  TLV encode / decode functions.
 *
 * All encode functions write into a caller-supplied buffer.
 * All decode functions read from a const byte buffer.
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#pragma once
#ifndef UMM_TLV_H
#define UMM_TLV_H

#include "umm_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ── size helpers ─────────────────────────────────────────────────────────── */

/** Round value_len up to the next 4-byte boundary. */
static inline uint32_t tlv_padded_len(uint32_t value_len) {
    return (value_len + 3u) & ~3u;
}

/** Total encoded byte count of a TLV with value_len value bytes. */
static inline uint32_t tlv_encoded_size(uint32_t value_len) {
    return TLV_HEADER_SIZE + tlv_padded_len(value_len);
}

/* ── encode ───────────────────────────────────────────────────────────────── */

/**
 * Encode one TLV into buf[offset].
 *
 * @param buf        Destination buffer.
 * @param buf_size   Total size of buf.
 * @param offset     Current write position (updated on success).
 * @param type_id    TLV type.
 * @param match      Match word (MWORD_NONE for published messages).
 * @param meta       Meta word (META_NONE if absent).
 * @param value      Value bytes (may be NULL if value_len==0).
 * @param value_len  Number of value bytes.
 * @return           true on success, false if buffer too small.
 */
bool tlv_encode(uint8_t *buf, size_t buf_size, size_t *offset,
                uint32_t type_id, uint32_t match, uint32_t meta,
                const uint8_t *value, uint32_t value_len);

/**
 * Encode a TLV_TERM (type=0, all zeros).
 */
bool tlv_encode_term(uint8_t *buf, size_t buf_size, size_t *offset);

/**
 * Encode a 32-bit signed integer TLV (TLV_INT, big-endian).
 */
bool tlv_encode_int(uint8_t *buf, size_t buf_size, size_t *offset,
                    int32_t value, uint32_t match, uint32_t meta);

/**
 * Encode a 64-bit IEEE-754 double TLV (TLV_FLOAT, big-endian).
 */
bool tlv_encode_float(uint8_t *buf, size_t buf_size, size_t *offset,
                      double value, uint32_t match, uint32_t meta);

/**
 * Encode a null-terminated UTF-8 string TLV (TLV_STRING).
 * The null terminator IS included in the wire encoding.
 */
bool tlv_encode_string(uint8_t *buf, size_t buf_size, size_t *offset,
                       const char *str, uint32_t match, uint32_t meta);

/**
 * Encode a boolean TLV (TLV_BOOL, 1 byte: 0x00 or 0x01).
 */
bool tlv_encode_bool(uint8_t *buf, size_t buf_size, size_t *offset,
                     bool value);

/**
 * Encode an AttachId TLV (TLV_ATTID: router_id(4,NBO) + id(4,NBO)).
 */
bool tlv_encode_attid(uint8_t *buf, size_t buf_size, size_t *offset,
                      uint32_t router_id, uint32_t attach_id);

/**
 * Encode a LogId TLV (TLV_LOGID: three null-terminated strings).
 */
bool tlv_encode_logid(uint8_t *buf, size_t buf_size, size_t *offset,
                      const char *process_name,
                      const char *login_name,
                      const char *password);

/**
 * Encode a subscription spec TLV (TLV_SUBSPEC):
 *   mtype(4,NBO,signed) + subtype(4,NBO,signed) + match_bytes
 */
bool tlv_encode_subspec(uint8_t *buf, size_t buf_size, size_t *offset,
                        int32_t mtype, int32_t subtype,
                        const uint8_t *match_bytes, uint32_t match_len);

/* ── decode ───────────────────────────────────────────────────────────────── */

/**
 * Decode one TLV from buf starting at *offset.
 *
 * On success, tlv->value points into buf (zero-copy).
 * *offset is advanced past the header, value, and padding.
 *
 * @return  true on success, false if buffer too small or malformed.
 */
bool tlv_decode_one(const uint8_t *buf, size_t buf_len, size_t *offset,
                    UMMTLV *tlv);

/**
 * Decode all TLVs from buf into the tlvs array (stopping at TLV_TERM
 * or end of buffer).
 *
 * @param buf      Source buffer.
 * @param buf_len  Length of buf.
 * @param tlvs     Output array (caller-owned).
 * @param max_tlvs Capacity of tlvs array.
 * @return         Number of TLVs decoded (not counting TERM).
 */
int tlv_decode_all(const uint8_t *buf, size_t buf_len,
                   UMMTLV *tlvs, int max_tlvs);

/**
 * Find the first TLV with the given type_id in buf.
 * Returns true and fills *out if found; false otherwise.
 */
bool tlv_find(const uint8_t *buf, size_t buf_len,
              uint32_t type_id, UMMTLV *out);

/* ── value extractors ─────────────────────────────────────────────────────── */

/** Extract signed 32-bit int from a TLV_INT value.  Returns false if wrong size. */
bool tlv_get_int(const UMMTLV *tlv, int32_t *out);

/** Extract double from a TLV_FLOAT value (8 bytes, big-endian IEEE-754). */
bool tlv_get_float(const UMMTLV *tlv, double *out);

/**
 * Extract string from a TLV_STRING value.
 * Copies at most (out_size-1) bytes and always null-terminates.
 * Returns false if tlv is NULL or has zero length.
 */
bool tlv_get_string(const UMMTLV *tlv, char *out, size_t out_size);

/** Extract bool from a TLV_BOOL value (1 byte). */
bool tlv_get_bool(const UMMTLV *tlv, bool *out);

#ifdef __cplusplus
}
#endif

#endif /* UMM_TLV_H */
