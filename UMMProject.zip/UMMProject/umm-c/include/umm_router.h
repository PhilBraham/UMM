/**
 * umm_router.h  —  UMM Router public API.
 *
 * The router is the central message broker.  It can be run as a standalone
 * process (see umm_router_main() in src/router_main.c) or embedded in a
 * larger application.
 *
 * The transport is abstracted: the router listens on one or more
 * UMMListener objects.  Use umm_listener_tcp() for TCP/IP (the default)
 * or implement the UMMListener vtable for other transports (Bluetooth,
 * UNIX sockets, shared memory).
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#pragma once
#ifndef UMM_ROUTER_H
#define UMM_ROUTER_H

#include "umm_types.h"
#include "umm_tlv.h"

#ifdef __cplusplus
extern "C" {
#endif

/* forward declarations */
typedef struct UMMRouter   UMMRouter;
typedef struct UMMListener UMMListener;
typedef struct UMMClient   UMMClient;

/* ── listener abstraction ─────────────────────────────────────────────────── */

/**
 * Listener vtable.  One listener = one "network interface" the router
 * accepts connections on.  Multiple listeners can be added to a router.
 *
 * Example: TCP listener on port 5300 + RFCOMM listener on channel 1.
 */
struct UMMListener {
    const char *name;       /* e.g. "tcp:5300", "rfcomm:1" */

    /**
     * Start listening.
     * @param listener  This instance.
     * @param router    The owning router (for umm_router_accept_client()).
     * @return          true on success.
     */
    bool (*start)(UMMListener *listener, UMMRouter *router);

    /**
     * Stop listening (close server socket / stop advertising).
     */
    void (*stop)(UMMListener *listener);

    /**
     * Return a file descriptor suitable for poll()/select() to detect
     * incoming connections, or -1 if not applicable.
     */
    int  (*accept_fd)(UMMListener *listener);

    /**
     * Accept a new incoming connection and return a new UMMClient,
     * or NULL on failure.
     * Called by the router when accept_fd becomes readable.
     */
    UMMClient *(*accept)(UMMListener *listener, UMMRouter *router);

    /**
     * Free listener resources.
     */
    void (*destroy)(UMMListener *listener);
};

/* ── client I/O abstraction ───────────────────────────────────────────────── */

/**
 * One connected client.  Created by UMMListener.accept().
 * The router calls these to read/write messages for each client.
 */
struct UMMClient {
    /**
     * Return a file descriptor for poll()/select(), or -1.
     */
    int (*fd)(UMMClient *client);

    /**
     * Read exactly len bytes.
     * @return  true on success, false on EOF or error.
     */
    bool (*recv)(UMMClient *client, uint8_t *buf, size_t len);

    /**
     * Send exactly len bytes.
     * @return  true on success, false on error.
     */
    bool (*send)(UMMClient *client, const uint8_t *buf, size_t len);

    /**
     * Return a human-readable address string (e.g. "192.168.1.5:42001").
     */
    const char *(*peer_addr)(UMMClient *client);

    /**
     * Close and free all resources for this client.
     */
    void (*destroy)(UMMClient *client);
};

/* ── built-in listener constructors ──────────────────────────────────────── */

/**
 * Create a TCP listener.
 * @param host  Bind address ("" or "0.0.0.0" = all interfaces).
 * @param port  Port number (0 → UMM_DEFAULT_PORT).
 */
UMMListener *umm_listener_tcp(const char *host, uint16_t port);

/**
 * Create a UNIX domain socket listener.
 * @param path  Socket path.
 */
UMMListener *umm_listener_unix(const char *path);

/**
 * Create a Bluetooth RFCOMM listener.
 * @param channel  RFCOMM channel (1–30, or 0 for auto).
 *
 * Only compiled when UMM_HAVE_BLUETOOTH is defined.
 */
#ifdef UMM_HAVE_BLUETOOTH
UMMListener *umm_listener_rfcomm(uint8_t channel);
#endif

void umm_listener_destroy(UMMListener *l);

/* ── router lifecycle ─────────────────────────────────────────────────────── */

/**
 * Create a new router.
 *
 * @param router_id  Numeric ID for this router (used in attach IDs).
 *                   Pass 0 to auto-detect from the primary network interface.
 * @param name       Human-readable name (max 63 chars).
 */
UMMRouter *umm_router_create(uint32_t router_id, const char *name);

/**
 * Free all resources.  Call umm_router_stop() first.
 */
void umm_router_destroy(UMMRouter *r);

/**
 * Add a listener to the router.  May be called multiple times to
 * support multiple transports simultaneously.
 * Ownership of the listener passes to the router.
 */
bool umm_router_add_listener(UMMRouter *r, UMMListener *listener);

/**
 * Run the router's main loop (blocks until umm_router_stop() is called).
 *
 * The loop uses poll() to multiplex all listener and client file descriptors.
 * Internally calls umm_router_step() repeatedly.
 */
void umm_router_run(UMMRouter *r);

/**
 * Process one round of pending I/O (non-blocking when timeout_ms == 0).
 * Useful for embedding the router in an existing event loop.
 *
 * @param timeout_ms  poll() timeout in milliseconds (-1 = block forever).
 */
void umm_router_step(UMMRouter *r, int timeout_ms);

/**
 * Signal umm_router_run() to return.
 * Safe to call from a signal handler.
 */
void umm_router_stop(UMMRouter *r);

/* ── router info ──────────────────────────────────────────────────────────── */

/** Return the router ID. */
uint32_t umm_router_id(const UMMRouter *r);

/** Return the number of currently attached clients. */
int umm_router_client_count(const UMMRouter *r);

/* ── advanced: programmatic attach for embedded modules ──────────────────── */

/**
 * Accept a client that was accepted externally (e.g. from a custom listener).
 * The router takes ownership of the UMMClient and sends it an INIT message.
 */
void umm_router_accept_client(UMMRouter *r, UMMClient *client);

#ifdef __cplusplus
}
#endif

#endif /* UMM_ROUTER_H */
