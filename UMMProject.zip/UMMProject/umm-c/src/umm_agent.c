/**
 * umm_agent.c  —  UMM agent (client) library implementation.
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#include "umm_agent.h"
#include "umm_types.h"
#include "umm_tlv.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <arpa/inet.h>

/* forward declared from umm_msg.c */
size_t umm_msg_encode(uint8_t *, size_t, const UMMHeader *, const uint8_t *, size_t);
bool   umm_msg_decode_header(const uint8_t *, size_t, UMMHeader *);
void   umm_header_init(UMMHeader *, uint32_t, int32_t, int32_t,
                       int32_t, int32_t, int32_t, uint8_t);
void   umm_utime_now(UMMHeader *);

/* ── registration record ──────────────────────────────────────────────────── */

typedef struct {
    int         reg_id;
    int32_t     mtype;
    int32_t     subtype;
    int         channel;
    UMMCallback callback;
    void       *userdata;
    uint8_t     match_tlvs[512];
    size_t      match_len;
    bool        active;
} RegSlot;

/* ── UMMAgent ─────────────────────────────────────────────────────────────── */

struct UMMAgent {
    char             process_name[UMM_MAX_NAME_LEN];
    int32_t          agent_mtype;

    UMMTransport    *transport;
    bool             owns_transport;

    uint32_t         router_id;
    uint32_t         attach_id;
    int32_t          msg_id;       /* auto-incremented */
    int              next_reg_id;

    bool             connected;
    volatile bool    stopping;

    RegSlot          regs[UMM_MAX_REGISTRATIONS];

    UMMStateCallback state_cb;
    void            *state_userdata;

    /* scratch buffer for encoding outgoing messages */
    uint8_t          send_buf[UMM_MAX_BUFF_SIZE];
    /* scratch buffer for reading incoming messages */
    uint8_t          recv_buf[UMM_MAX_BUFF_SIZE];
};

/* ── constructor / destructor ─────────────────────────────────────────────── */

UMMAgent *umm_agent_create(const char *process_name, int32_t agent_mtype) {
    UMMAgent *ag = calloc(1, sizeof *ag);
    if (!ag) return NULL;

    snprintf(ag->process_name, sizeof ag->process_name,
             "%s", process_name ? process_name : "UMMAgent");
    ag->agent_mtype  = agent_mtype;
    ag->next_reg_id  = 1;
    ag->msg_id       = 1;
    ag->connected    = false;
    ag->stopping     = false;
    return ag;
}

void umm_agent_destroy(UMMAgent *ag) {
    if (!ag) return;
    if (ag->connected) umm_agent_disconnect(ag);
    if (ag->transport && ag->owns_transport)
        umm_transport_destroy(ag->transport);
    free(ag);
}

void umm_agent_set_transport(UMMAgent *ag, UMMTransport *xp) {
    if (ag->transport && ag->owns_transport)
        umm_transport_destroy(ag->transport);
    ag->transport      = xp;
    ag->owns_transport = true;
}

/* ── connect ──────────────────────────────────────────────────────────────── */

bool umm_agent_connect_tcp(UMMAgent *ag, const char *host, uint16_t port) {
    UMMTransport *xp = umm_transport_tcp_create(host, port);
    if (!xp) return false;
    umm_agent_set_transport(ag, xp);
    return umm_agent_connect(ag, ATTACH_NORMAL);
}

bool umm_agent_connect(UMMAgent *ag, uint32_t flags) {
    if (!ag->transport) return false;

    /* open the transport connection */
    if (!ag->transport->connect(ag->transport, NULL))
        return false;

    /* ── receive INIT (router sends this immediately on connect) ── */
    uint8_t hdr_buf[UMM_FIXED_HEADER_SIZE];
    if (!ag->transport->recv(ag->transport, hdr_buf, UMM_FIXED_HEADER_SIZE))
        goto fail;

    UMMHeader hdr;
    if (!umm_msg_decode_header(hdr_buf, UMM_FIXED_HEADER_SIZE, &hdr))
        goto fail;

    /* read TData TLV header */
    uint8_t tlv_hdr[TLV_HEADER_SIZE];
    if (!ag->transport->recv(ag->transport, tlv_hdr, TLV_HEADER_SIZE))
        goto fail;

    uint32_t tlv_len;
    {
        uint32_t t, m, e, l;
        memcpy(&t, tlv_hdr,      4);  (void)t;
        memcpy(&m, tlv_hdr + 4,  4);
        memcpy(&e, tlv_hdr + 8,  4);
        memcpy(&l, tlv_hdr + 12, 4);  tlv_len = ntohl(l);
        (void)m; (void)e;
    }

    uint32_t padded = tlv_padded_len(tlv_len);
    if (padded > UMM_MAX_BUFF_SIZE) goto fail;

    if (padded > 0) {
        if (!ag->transport->recv(ag->transport, ag->recv_buf, padded))
            goto fail;
    }

    /* extract attach_id from the ATTID TLV in the INIT payload */
    if (hdr.mtype == MTYPE_UMM && hdr.subtype == ST_INIT && tlv_len >= 8) {
        UMMTLV attid;
        if (tlv_find(ag->recv_buf, tlv_len, TLV_ATTID, &attid) && attid.length >= 8) {
            uint32_t r, a;
            memcpy(&r, attid.value,     4);  ag->router_id = ntohl(r);
            memcpy(&a, attid.value + 4, 4);  ag->attach_id = ntohl(a);
        }
    }

    /* ── send ATTACH ── */
    {
        uint8_t  pay[256]; size_t plen = 0;

        /* LogId TLV: process_name + "" + "" */
        tlv_encode_logid(pay, sizeof pay, &plen,
                         ag->process_name, "", "");

        /* Int(agent_mtype) if set */
        if (ag->agent_mtype != 0)
            tlv_encode_int(pay, sizeof pay, &plen, ag->agent_mtype, MWORD_NONE, META_NONE);

        UMMHeader out_hdr;
        umm_header_init(&out_hdr, ag->router_id,
                        MTYPE_UMM, ST_ATTACH,
                        (int32_t)flags, 0, ag->msg_id++, CHAN_APP);
        out_hdr.attach_id = ag->attach_id;

        size_t bytes = umm_msg_encode(ag->send_buf, sizeof ag->send_buf,
                                      &out_hdr, pay, plen);
        if (!bytes) goto fail;
        if (!ag->transport->send(ag->transport, ag->send_buf, bytes))
            goto fail;
    }

    /* ── receive ATTACH_CONFIRM ── */
    {
        if (!ag->transport->recv(ag->transport, hdr_buf, UMM_FIXED_HEADER_SIZE))
            goto fail;
        if (!umm_msg_decode_header(hdr_buf, UMM_FIXED_HEADER_SIZE, &hdr))
            goto fail;

        uint8_t tc[TLV_HEADER_SIZE];
        if (!ag->transport->recv(ag->transport, tc, TLV_HEADER_SIZE))
            goto fail;
        uint32_t cl;
        memcpy(&cl, tc + 12, 4); cl = ntohl(cl);
        uint32_t cp = tlv_padded_len(cl);
        if (cp > 0) {
            if (!ag->transport->recv(ag->transport, ag->recv_buf, cp))
                goto fail;
        }

        if (hdr.mtype != MTYPE_UMM || hdr.subtype != ST_ATTACH_CONFIRM)
            goto fail;
    }

    ag->connected = true;

    if (ag->state_cb)
        ag->state_cb(ag, true, ag->state_userdata);

    return true;

fail:
    ag->transport->disconnect(ag->transport);
    return false;
}

void umm_agent_disconnect(UMMAgent *ag) {
    if (!ag->connected) return;

    /* send DETACH */
    UMMHeader h;
    umm_header_init(&h, ag->router_id,
                    MTYPE_UMM, ST_DETACH,
                    DETACH_NORMAL, 0, ag->msg_id++, CHAN_APP);
    h.attach_id = ag->attach_id;

    size_t bytes = umm_msg_encode(ag->send_buf, sizeof ag->send_buf, &h, NULL, 0);
    if (bytes && ag->transport)
        ag->transport->send(ag->transport, ag->send_buf, bytes);

    if (ag->transport)
        ag->transport->disconnect(ag->transport);

    ag->connected = false;
    if (ag->state_cb)
        ag->state_cb(ag, false, ag->state_userdata);
}

bool umm_agent_is_connected(const UMMAgent *ag) {
    return ag && ag->connected;
}

void umm_agent_set_state_callback(UMMAgent *ag,
                                   UMMStateCallback cb, void *userdata) {
    ag->state_cb       = cb;
    ag->state_userdata = userdata;
}

/* ── register / unregister ────────────────────────────────────────────────── */

int umm_agent_register(UMMAgent *ag,
                        int32_t   mtype,
                        int32_t   subtype,
                        int       channel,
                        UMMCallback callback,
                        void     *userdata,
                        const uint8_t *match_tlvs,
                        size_t         match_len)
{
    if (!ag->connected) return 0;

    /* find a free slot */
    int reg_id = ag->next_reg_id;
    RegSlot *slot = NULL;
    for (int i = 0; i < UMM_MAX_REGISTRATIONS; i++) {
        if (!ag->regs[i].active) { slot = &ag->regs[i]; break; }
    }
    if (!slot) return 0;
    ag->next_reg_id++;

    /* store locally */
    slot->reg_id   = reg_id;
    slot->mtype    = mtype;
    slot->subtype  = subtype;
    slot->channel  = channel;
    slot->callback = callback;
    slot->userdata = userdata;
    slot->match_len = 0;
    if (match_tlvs && match_len && match_len <= sizeof slot->match_tlvs) {
        memcpy(slot->match_tlvs, match_tlvs, match_len);
        slot->match_len = match_len;
    }
    slot->active = true;

    /* encode REGISTER message:
       payload = TLV_SUBSPEC(mtype, subtype, match_bytes) */
    uint8_t  pay[1024]; size_t plen = 0;
    tlv_encode_subspec(pay, sizeof pay, &plen,
                       mtype, subtype,
                       match_tlvs, (uint32_t)match_len);

    UMMHeader h;
    umm_header_init(&h, ag->router_id,
                    MTYPE_UMM, ST_REGISTER,
                    0, reg_id, ag->msg_id++,
                    (uint8_t)channel);
    h.attach_id = ag->attach_id;

    size_t bytes = umm_msg_encode(ag->send_buf, sizeof ag->send_buf, &h, pay, plen);
    if (!bytes || !ag->transport->send(ag->transport, ag->send_buf, bytes)) {
        slot->active = false;
        return 0;
    }
    return reg_id;
}

bool umm_agent_unregister(UMMAgent *ag, int reg_id) {
    RegSlot *slot = NULL;
    for (int i = 0; i < UMM_MAX_REGISTRATIONS; i++) {
        if (ag->regs[i].active && ag->regs[i].reg_id == reg_id) {
            slot = &ag->regs[i]; break;
        }
    }
    if (!slot) return false;
    slot->active = false;

    if (!ag->connected) return true;

    UMMHeader h;
    umm_header_init(&h, ag->router_id,
                    MTYPE_UMM, ST_UNREGISTER,
                    0, reg_id, ag->msg_id++, CHAN_APP);
    h.attach_id = ag->attach_id;

    size_t bytes = umm_msg_encode(ag->send_buf, sizeof ag->send_buf, &h, NULL, 0);
    if (bytes) ag->transport->send(ag->transport, ag->send_buf, bytes);
    return true;
}

/* ── send ─────────────────────────────────────────────────────────────────── */

bool umm_agent_send(UMMAgent *ag,
                    int32_t   mtype,
                    int32_t   subtype,
                    int       channel,
                    uint32_t  flags,
                    const uint8_t *payload,
                    size_t         pay_len)
{
    if (!ag->connected) return false;

    UMMHeader h;
    umm_header_init(&h, ag->router_id,
                    mtype, subtype,
                    (int32_t)flags, 0, ag->msg_id++,
                    (uint8_t)channel);
    h.attach_id     = ag->attach_id;
    h.origin_id     = ag->attach_id;
    h.origin_router = ag->router_id;

    size_t bytes = umm_msg_encode(ag->send_buf, sizeof ag->send_buf,
                                  &h, payload, pay_len);
    if (!bytes) return false;
    return ag->transport->send(ag->transport, ag->send_buf, bytes);
}

/* ── poll / run ───────────────────────────────────────────────────────────── */

bool umm_agent_poll(UMMAgent *ag) {
    if (!ag->connected) return false;

    /* read fixed header */
    uint8_t hdr_buf[UMM_FIXED_HEADER_SIZE];
    if (!ag->transport->recv(ag->transport, hdr_buf, UMM_FIXED_HEADER_SIZE)) {
        ag->connected = false;
        if (ag->state_cb) ag->state_cb(ag, false, ag->state_userdata);
        return false;
    }

    /* read TData TLV header */
    uint8_t tlv_hdr[TLV_HEADER_SIZE];
    if (!ag->transport->recv(ag->transport, tlv_hdr, TLV_HEADER_SIZE))
        return false;

    uint32_t tlv_type, tlv_len;
    {
        uint32_t t, l;
        memcpy(&t, tlv_hdr,      4); tlv_type = ntohl(t);
        memcpy(&l, tlv_hdr + 12, 4); tlv_len  = ntohl(l);
    }

    uint32_t padded = tlv_padded_len(tlv_len);
    uint8_t *payload_buf = ag->recv_buf;

    if (padded > 0) {
        if (padded > UMM_MAX_BUFF_SIZE) return false;
        if (!ag->transport->recv(ag->transport, payload_buf, padded))
            return false;
    }

    /* decode header */
    UMMHeader hdr;
    if (!umm_msg_decode_header(hdr_buf, UMM_FIXED_HEADER_SIZE, &hdr))
        return true; /* skip malformed */

    /* build UMMMsg for callbacks */
    UMMMsg msg;
    msg.hdr = hdr;
    msg.tdata.type_id = tlv_type;
    msg.tdata.match   = 0;
    msg.tdata.meta    = 0;
    msg.tdata.length  = tlv_len;
    msg.tdata.value   = payload_buf;

    /* dispatch to registered callbacks */
    for (int i = 0; i < UMM_MAX_REGISTRATIONS; i++) {
        RegSlot *s = &ag->regs[i];
        if (!s->active) continue;
        if (s->reg_id != hdr.reg_id) continue;
        if (s->callback) s->callback(ag, &msg, s->userdata);
    }

    return true;
}

void umm_agent_run(UMMAgent *ag) {
    ag->stopping = false;
    while (!ag->stopping && ag->connected)
        umm_agent_poll(ag);
}

void umm_agent_stop(UMMAgent *ag) {
    ag->stopping = true;
}

/* ── accessors ────────────────────────────────────────────────────────────── */

uint32_t umm_agent_attach_id(const UMMAgent *ag) { return ag->attach_id; }
uint32_t umm_agent_router_id(const UMMAgent *ag) { return ag->router_id; }

int32_t umm_agent_next_msg_id(UMMAgent *ag) {
    return ag->msg_id++;
}

/* ── convenience queries ──────────────────────────────────────────────────── */

bool umm_agent_query_capability(UMMAgent *ag, int32_t mtype) {
    if (mtype == 0)
        return umm_agent_send(ag, MTYPE_UMM, ST_CAPABILITY_QUERY,
                               CHAN_APP, 0, NULL, 0);
    uint8_t pay[32]; size_t plen = 0;
    tlv_encode_int(pay, sizeof pay, &plen, mtype, MWORD_NONE, META_NONE);
    return umm_agent_send(ag, MTYPE_UMM, ST_CAPABILITY_QUERY,
                           CHAN_APP, 0, pay, plen);
}

bool umm_agent_list_agents(UMMAgent *ag) {
    return umm_agent_send(ag, MTYPE_UMM, ST_LIST_AGENTS,
                           CHAN_APP, 0, NULL, 0);
}
