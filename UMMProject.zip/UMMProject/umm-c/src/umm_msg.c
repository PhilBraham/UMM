/**
 * umm_msg.c  —  UMM message encode / decode, and built-in transport implementations.
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#include "umm_types.h"
#include "umm_tlv.h"
#include "umm_router.h"
#include "umm_agent.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/un.h>
#include <time.h>
#include <sys/time.h>

/* ── byte-order helpers ───────────────────────────────────────────────────── */

static inline uint32_t u32be(uint32_t v) { return htonl(v); }
static inline uint32_t u32h(uint32_t v)  { return ntohl(v); }
static inline int32_t  i32be(int32_t v)  { return (int32_t)htonl((uint32_t)v); }
static inline int32_t  i32h(int32_t v)   { return (int32_t)ntohl((uint32_t)v); }
static inline uint16_t u16be(uint16_t v) { return htons(v); }

/* ── UTime ────────────────────────────────────────────────────────────────── */

void umm_utime_now(UMMHeader *hdr) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    hdr->time_secs = u32be((uint32_t)tv.tv_sec);
    hdr->time_ms   = u16be((uint16_t)(tv.tv_usec / 1000));
    hdr->time_tz   = 0;
    hdr->time_dst  = 0;
    hdr->time_pad  = 0;
}

/* ── Message encode ───────────────────────────────────────────────────────── */

/**
 * Encode a complete UMM message into buf.
 *
 * @param buf       Destination buffer.
 * @param buf_size  Size of buf.
 * @param hdr       Fixed header (fields in host byte order, converted here).
 * @param payload   TLV payload bytes (the TData value).  May be NULL.
 * @param pay_len   Length of payload.
 * @return          Total bytes written, or 0 on failure.
 */
size_t umm_msg_encode(uint8_t *buf, size_t buf_size,
                      const UMMHeader *hdr,
                      const uint8_t *payload, size_t pay_len)
{
    /* We need fixed header (56) + TLV header (16) + padded payload */
    uint32_t padded  = tlv_padded_len((uint32_t)pay_len);
    size_t   total   = UMM_FIXED_HEADER_SIZE + TLV_HEADER_SIZE + padded;

    if (total > buf_size) return 0;

    /* ── fixed header ── all multibyte fields → NBO ── */
    UMMHeader *h = (UMMHeader *)buf;
    h->umm_ident    = hdr->umm_ident;
    h->msg_version  = hdr->msg_version;
    h->major        = hdr->major;
    h->minor        = hdr->minor;
    h->attach_router = u32be(hdr->attach_router);
    h->attach_id     = u32be(hdr->attach_id);
    h->origin_router = u32be(hdr->origin_router);
    h->origin_id     = u32be(hdr->origin_id);
    /* UTime is already NBO (set by umm_utime_now) */
    h->time_secs    = hdr->time_secs;
    h->time_ms      = hdr->time_ms;
    h->time_tz      = hdr->time_tz;
    h->time_dst     = hdr->time_dst;
    h->time_pad     = hdr->time_pad;
    h->flags        = i32be(hdr->flags);
    h->reg_id       = i32be(hdr->reg_id);
    h->msg_id       = i32be(hdr->msg_id);
    h->mtype        = i32be(hdr->mtype);
    h->subtype      = i32be(hdr->subtype);
    h->channel      = hdr->channel;
    memset(h->reserved, 0, 3);

    /* ── TData TLV ── */
    size_t off = UMM_FIXED_HEADER_SIZE;
    uint32_t tdata_type = pay_len > 0 ? TLV_MSG : TLV_TERM;
    /* Use the low-level encode to write the TLV header */
    bool ok = tlv_encode(buf, buf_size, &off,
                         tdata_type, MWORD_NONE, META_NONE,
                         payload, (uint32_t)pay_len);
    if (!ok) return 0;
    return off;
}

/**
 * Decode the fixed header from buf.
 * All multibyte fields are converted from NBO to host order.
 *
 * @return  true on success.
 */
bool umm_msg_decode_header(const uint8_t *buf, size_t buf_len, UMMHeader *out)
{
    if (buf_len < UMM_FIXED_HEADER_SIZE) return false;

    const UMMHeader *h = (const UMMHeader *)buf;
    out->umm_ident    = h->umm_ident;
    out->msg_version  = h->msg_version;
    out->major        = h->major;
    out->minor        = h->minor;
    out->attach_router = u32h(h->attach_router);
    out->attach_id     = u32h(h->attach_id);
    out->origin_router = u32h(h->origin_router);
    out->origin_id     = u32h(h->origin_id);
    /* UTime: keep NBO (applications rarely inspect it) */
    out->time_secs    = h->time_secs;
    out->time_ms      = h->time_ms;
    out->time_tz      = h->time_tz;
    out->time_dst     = h->time_dst;
    out->time_pad     = h->time_pad;
    out->flags        = i32h(h->flags);
    out->reg_id       = i32h(h->reg_id);
    out->msg_id       = i32h(h->msg_id);
    out->mtype        = i32h(h->mtype);
    out->subtype      = i32h(h->subtype);
    out->channel      = h->channel;
    memset(out->reserved, 0, 3);
    return true;
}

/**
 * Build a default header for a router-originated message.
 */
void umm_header_init(UMMHeader *h, uint32_t router_id,
                     int32_t mtype, int32_t subtype,
                     int32_t flags, int32_t reg_id, int32_t msg_id,
                     uint8_t channel)
{
    h->umm_ident    = UMM_IDENT;
    h->msg_version  = UMM_MSG_VERSION;
    h->major        = UMM_VERSION_MAJOR;
    h->minor        = UMM_VERSION_MINOR;
    h->attach_router = router_id;
    h->attach_id     = 0;
    h->origin_router = router_id;
    h->origin_id     = 0;
    umm_utime_now(h);
    h->flags   = flags;
    h->reg_id  = reg_id;
    h->msg_id  = msg_id;
    h->mtype   = mtype;
    h->subtype = subtype;
    h->channel = channel;
    memset(h->reserved, 0, 3);
}

/* ── recv-exactly helper ──────────────────────────────────────────────────── */

/**
 * Read exactly `len` bytes from a file descriptor, handling partial reads.
 */
bool fd_recv_exact(int fd, uint8_t *buf, size_t len)
{
    size_t got = 0;
    while (got < len) {
        ssize_t n = read(fd, buf + got, len - got);
        if (n <= 0) return false;
        got += (size_t)n;
    }
    return true;
}

bool fd_send_exact(int fd, const uint8_t *buf, size_t len)
{
    size_t sent = 0;
    while (sent < len) {
        ssize_t n = write(fd, buf + sent, len - sent);
        if (n <= 0) return false;
        sent += (size_t)n;
    }
    return true;
}

/* ── TCP transport ────────────────────────────────────────────────────────── */

typedef struct {
    UMMTransport  base;
    int           fd;
    char          host[256];
    uint16_t      port;
    char          addr_str[280];
} TCPTransport;

static bool tcp_connect(UMMTransport *xp, const char *address) {
    TCPTransport *t = (TCPTransport *)xp;

    /* address may override host:port */
    if (address && *address) {
        const char *colon = strrchr(address, ':');
        if (colon) {
            size_t hlen = (size_t)(colon - address);
            if (hlen >= sizeof t->host) hlen = sizeof t->host - 1;
            memcpy(t->host, address, hlen);
            t->host[hlen] = '\0';
            t->port = (uint16_t)atoi(colon + 1);
        } else {
            snprintf(t->host, sizeof t->host, "%s", address);
        }
    }

    struct addrinfo hints = {0}, *res = NULL;
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    char portstr[8];
    snprintf(portstr, sizeof portstr, "%u", t->port ? t->port : UMM_DEFAULT_PORT);

    if (getaddrinfo(t->host[0] ? t->host : "localhost", portstr, &hints, &res) != 0)
        return false;

    int fd = socket(res->ai_family, res->ai_socktype, 0);
    if (fd < 0) { freeaddrinfo(res); return false; }

    int flag = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof flag);

    if (connect(fd, res->ai_addr, res->ai_addrlen) != 0) {
        close(fd); freeaddrinfo(res); return false;
    }
    freeaddrinfo(res);
    t->fd = fd;
    snprintf(t->addr_str, sizeof t->addr_str, "%s:%u", t->host, t->port);
    return true;
}

static void tcp_disconnect(UMMTransport *xp) {
    TCPTransport *t = (TCPTransport *)xp;
    if (t->fd >= 0) { close(t->fd); t->fd = -1; }
}

static bool tcp_send(UMMTransport *xp, const uint8_t *buf, size_t len) {
    TCPTransport *t = (TCPTransport *)xp;
    return t->fd >= 0 && fd_send_exact(t->fd, buf, len);
}

static bool tcp_recv(UMMTransport *xp, uint8_t *buf, size_t len) {
    TCPTransport *t = (TCPTransport *)xp;
    return t->fd >= 0 && fd_recv_exact(t->fd, buf, len);
}

static int tcp_fd(UMMTransport *xp) {
    return ((TCPTransport *)xp)->fd;
}

static bool tcp_is_connected(UMMTransport *xp) {
    return ((TCPTransport *)xp)->fd >= 0;
}

static void tcp_destroy(UMMTransport *xp) {
    TCPTransport *t = (TCPTransport *)xp;
    if (t->fd >= 0) close(t->fd);
    free(t);
}

UMMTransport *umm_transport_tcp_create(const char *host, uint16_t port) {
    TCPTransport *t = calloc(1, sizeof *t);
    if (!t) return NULL;
    t->base.name         = "tcp";
    t->base.connect      = tcp_connect;
    t->base.disconnect   = tcp_disconnect;
    t->base.send         = tcp_send;
    t->base.recv         = tcp_recv;
    t->base.fd           = tcp_fd;
    t->base.is_connected = tcp_is_connected;
    t->base.destroy      = tcp_destroy;
    t->fd                = -1;
    t->port              = port ? port : UMM_DEFAULT_PORT;
    if (host) snprintf(t->host, sizeof t->host, "%s", host);
    return &t->base;
}

/* ── UNIX socket transport ────────────────────────────────────────────────── */

typedef struct {
    UMMTransport  base;
    int           fd;
    char          path[108];
} UnixTransport;

static bool unix_connect(UMMTransport *xp, const char *address) {
    UnixTransport *t = (UnixTransport *)xp;
    const char *p = (address && *address) ? address : t->path;

    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return false;

    struct sockaddr_un sa = {0};
    sa.sun_family = AF_UNIX;
    snprintf(sa.sun_path, sizeof sa.sun_path, "%s", p);

    if (connect(fd, (struct sockaddr *)&sa, sizeof sa) != 0) {
        close(fd); return false;
    }
    t->fd = fd;
    return true;
}

static void unix_disconnect(UMMTransport *xp) {
    UnixTransport *t = (UnixTransport *)xp;
    if (t->fd >= 0) { close(t->fd); t->fd = -1; }
}

static bool unix_send_fn(UMMTransport *xp, const uint8_t *buf, size_t len) {
    UnixTransport *t = (UnixTransport *)xp;
    return t->fd >= 0 && fd_send_exact(t->fd, buf, len);
}

static bool unix_recv_fn(UMMTransport *xp, uint8_t *buf, size_t len) {
    UnixTransport *t = (UnixTransport *)xp;
    return t->fd >= 0 && fd_recv_exact(t->fd, buf, len);
}

static int  unix_fd(UMMTransport *xp) { return ((UnixTransport *)xp)->fd; }
static bool unix_is_connected(UMMTransport *xp) {
    return ((UnixTransport *)xp)->fd >= 0;
}
static void unix_destroy(UMMTransport *xp) {
    UnixTransport *t = (UnixTransport *)xp;
    if (t->fd >= 0) close(t->fd);
    free(t);
}

UMMTransport *umm_transport_unix_create(const char *path) {
    UnixTransport *t = calloc(1, sizeof *t);
    if (!t) return NULL;
    t->base.name         = "unix";
    t->base.connect      = unix_connect;
    t->base.disconnect   = unix_disconnect;
    t->base.send         = unix_send_fn;
    t->base.recv         = unix_recv_fn;
    t->base.fd           = unix_fd;
    t->base.is_connected = unix_is_connected;
    t->base.destroy      = unix_destroy;
    t->fd                = -1;
    if (path) snprintf(t->path, sizeof t->path, "%s", path);
    return &t->base;
}

void umm_transport_destroy(UMMTransport *xp) {
    if (xp && xp->destroy) xp->destroy(xp);
}
