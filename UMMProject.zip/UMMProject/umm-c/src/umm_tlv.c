/**
 * umm_tlv.c  —  TLV encode / decode implementation.
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#include "umm_tlv.h"

#include <string.h>
#include <arpa/inet.h>   /* htonl / ntohl */

/* ── byte-order helpers ───────────────────────────────────────────────────── */

/* htonl/ntohl handle uint32.  We also need 64-bit and signed-32. */

static inline uint32_t u32_to_be(uint32_t v) { return htonl(v); }
static inline uint32_t u32_from_be(uint32_t v) { return ntohl(v); }

static inline int32_t i32_to_be(int32_t v) {
    return (int32_t)htonl((uint32_t)v);
}
static inline int32_t i32_from_be(int32_t v) {
    return (int32_t)ntohl((uint32_t)v);
}

/* 64-bit big-endian (IEEE-754 double) */
static inline void f64_to_be(double v, uint8_t out[8]) {
    uint8_t src[8];
    memcpy(src, &v, 8);
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    for (int i = 0; i < 8; i++) out[i] = src[7 - i];
#else
    memcpy(out, src, 8);
#endif
}

static inline double f64_from_be(const uint8_t in[8]) {
    uint8_t tmp[8];
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    for (int i = 0; i < 8; i++) tmp[i] = in[7 - i];
#else
    memcpy(tmp, in, 8);
#endif
    double v;
    memcpy(&v, tmp, 8);
    return v;
}

/* ── encode helpers ───────────────────────────────────────────────────────── */

bool tlv_encode(uint8_t *buf, size_t buf_size, size_t *offset,
                uint32_t type_id, uint32_t match, uint32_t meta,
                const uint8_t *value, uint32_t value_len)
{
    uint32_t padded  = tlv_padded_len(value_len);
    size_t   needed  = TLV_HEADER_SIZE + padded;

    if (*offset + needed > buf_size)
        return false;

    uint8_t *p = buf + *offset;

    /* header: Type | Match | Meta | Length  — all NBO */
    uint32_t t = u32_to_be(type_id);
    uint32_t m = u32_to_be(match);
    uint32_t e = u32_to_be(meta);
    uint32_t l = u32_to_be(value_len);

    memcpy(p,      &t, 4);
    memcpy(p +  4, &m, 4);
    memcpy(p +  8, &e, 4);
    memcpy(p + 12, &l, 4);
    p += TLV_HEADER_SIZE;

    if (value_len > 0 && value)
        memcpy(p, value, value_len);

    /* zero-pad to alignment */
    uint32_t pad = padded - value_len;
    if (pad > 0)
        memset(p + value_len, 0, pad);

    *offset += needed;
    return true;
}

bool tlv_encode_term(uint8_t *buf, size_t buf_size, size_t *offset) {
    return tlv_encode(buf, buf_size, offset, TLV_TERM, 0, 0, NULL, 0);
}

bool tlv_encode_int(uint8_t *buf, size_t buf_size, size_t *offset,
                    int32_t value, uint32_t match, uint32_t meta)
{
    int32_t be = i32_to_be(value);
    return tlv_encode(buf, buf_size, offset, TLV_INT, match, meta,
                      (const uint8_t *)&be, sizeof be);
}

bool tlv_encode_float(uint8_t *buf, size_t buf_size, size_t *offset,
                      double value, uint32_t match, uint32_t meta)
{
    uint8_t be[8];
    f64_to_be(value, be);
    return tlv_encode(buf, buf_size, offset, TLV_FLOAT, match, meta, be, 8);
}

bool tlv_encode_string(uint8_t *buf, size_t buf_size, size_t *offset,
                       const char *str, uint32_t match, uint32_t meta)
{
    if (!str) str = "";
    uint32_t len = (uint32_t)strlen(str) + 1u;  /* include null terminator */
    return tlv_encode(buf, buf_size, offset, TLV_STRING, match, meta,
                      (const uint8_t *)str, len);
}

bool tlv_encode_bool(uint8_t *buf, size_t buf_size, size_t *offset, bool value)
{
    uint8_t b = value ? 1 : 0;
    return tlv_encode(buf, buf_size, offset, TLV_BOOL, 0, 0, &b, 1);
}

bool tlv_encode_attid(uint8_t *buf, size_t buf_size, size_t *offset,
                      uint32_t router_id, uint32_t attach_id)
{
    uint8_t v[8];
    uint32_t r = u32_to_be(router_id);
    uint32_t a = u32_to_be(attach_id);
    memcpy(v,     &r, 4);
    memcpy(v + 4, &a, 4);
    return tlv_encode(buf, buf_size, offset, TLV_ATTID, 0, 0, v, 8);
}

bool tlv_encode_logid(uint8_t *buf, size_t buf_size, size_t *offset,
                      const char *process_name,
                      const char *login_name,
                      const char *password)
{
    if (!process_name) process_name = "";
    if (!login_name)   login_name   = "";
    if (!password)     password     = "";

    /* value = process_name\0 + login_name\0 + password\0 */
    size_t plen = strlen(process_name) + 1;
    size_t llen = strlen(login_name)   + 1;
    size_t wlen = strlen(password)     + 1;
    size_t total = plen + llen + wlen;

    if (*offset + TLV_HEADER_SIZE + tlv_padded_len((uint32_t)total) > buf_size)
        return false;

    uint8_t tmp[256];
    if (total > sizeof tmp) return false;

    memcpy(tmp,             process_name, plen);
    memcpy(tmp + plen,      login_name,   llen);
    memcpy(tmp + plen+llen, password,     wlen);

    return tlv_encode(buf, buf_size, offset, TLV_LOGID, 0, 0,
                      tmp, (uint32_t)total);
}

bool tlv_encode_subspec(uint8_t *buf, size_t buf_size, size_t *offset,
                        int32_t mtype, int32_t subtype,
                        const uint8_t *match_bytes, uint32_t match_len)
{
    uint32_t total = 8u + match_len;
    if (*offset + TLV_HEADER_SIZE + tlv_padded_len(total) > buf_size)
        return false;

    uint8_t  tmp[1024];
    if (total > sizeof tmp) return false;

    int32_t mt = i32_to_be(mtype);
    int32_t st = i32_to_be(subtype);
    memcpy(tmp,     &mt, 4);
    memcpy(tmp + 4, &st, 4);
    if (match_len && match_bytes)
        memcpy(tmp + 8, match_bytes, match_len);

    return tlv_encode(buf, buf_size, offset, TLV_SUBSPEC, 0, 0,
                      tmp, total);
}

/* ── decode ───────────────────────────────────────────────────────────────── */

bool tlv_decode_one(const uint8_t *buf, size_t buf_len, size_t *offset,
                    UMMTLV *tlv)
{
    if (*offset + TLV_HEADER_SIZE > buf_len)
        return false;

    const uint8_t *p = buf + *offset;

    uint32_t t, m, e, l;
    memcpy(&t, p,      4);  t = u32_from_be(t);
    memcpy(&m, p + 4,  4);  m = u32_from_be(m);
    memcpy(&e, p + 8,  4);  e = u32_from_be(e);
    memcpy(&l, p + 12, 4);  l = u32_from_be(l);

    size_t padded = tlv_padded_len(l);

    if (*offset + TLV_HEADER_SIZE + padded > buf_len)
        return false;

    tlv->type_id = t;
    tlv->match   = m;
    tlv->meta    = e;
    tlv->length  = l;
    tlv->value   = p + TLV_HEADER_SIZE;  /* zero-copy pointer into buf */

    *offset += TLV_HEADER_SIZE + padded;
    return true;
}

int tlv_decode_all(const uint8_t *buf, size_t buf_len,
                   UMMTLV *tlvs, int max_tlvs)
{
    int     count  = 0;
    size_t  offset = 0;
    UMMTLV  tlv;

    while (count < max_tlvs && offset < buf_len) {
        if (!tlv_decode_one(buf, buf_len, &offset, &tlv))
            break;
        if (tlv.type_id == TLV_TERM)
            break;
        tlvs[count++] = tlv;
    }
    return count;
}

bool tlv_find(const uint8_t *buf, size_t buf_len,
              uint32_t type_id, UMMTLV *out)
{
    UMMTLV  tlv;
    size_t  offset = 0;

    while (offset < buf_len) {
        if (!tlv_decode_one(buf, buf_len, &offset, &tlv))
            break;
        if (tlv.type_id == TLV_TERM)
            break;
        if (tlv.type_id == type_id) {
            if (out) *out = tlv;
            return true;
        }
    }
    return false;
}

/* ── value extractors ─────────────────────────────────────────────────────── */

bool tlv_get_int(const UMMTLV *tlv, int32_t *out) {
    if (!tlv || tlv->length < 4) return false;
    int32_t v;
    memcpy(&v, tlv->value, 4);
    *out = i32_from_be(v);
    return true;
}

bool tlv_get_float(const UMMTLV *tlv, double *out) {
    if (!tlv || tlv->length < 8) return false;
    *out = f64_from_be(tlv->value);
    return true;
}

bool tlv_get_string(const UMMTLV *tlv, char *out, size_t out_size) {
    if (!tlv || !tlv->length || !out || !out_size) return false;
    size_t copy = tlv->length < out_size ? tlv->length : out_size - 1;
    memcpy(out, tlv->value, copy);
    out[copy] = '\0';
    /* strip embedded null terminator if present */
    return true;
}

bool tlv_get_bool(const UMMTLV *tlv, bool *out) {
    if (!tlv || tlv->length < 1) return false;
    *out = tlv->value[0] != 0;
    return true;
}
