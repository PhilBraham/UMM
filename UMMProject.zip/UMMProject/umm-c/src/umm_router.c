/**
 * umm_router.c  —  UMM Router implementation.
 *
 * Functionally equivalent to the Python umm.router module.
 *
 * Design:
 *   - Single-threaded event loop using poll().
 *   - One poll() fd per listener (accept) and per client (read).
 *   - Subscription store: table[channel][mtype_bucket][subtype_bucket]
 *     Each entry is a linked list of RegEntry.
 *   - TLV content matching (same as Python): conditions with meta==0 match
 *     positionally; conditions with a non-zero meta match by (type_id, meta)
 *     key, so several conditions on one key AND together (e.g. a range).
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#include "umm_router.h"
#include "umm_types.h"
#include "umm_tlv.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netdb.h>
#include <time.h>
#include <sys/time.h>

/* forward from umm_msg.c */
size_t umm_msg_encode(uint8_t *, size_t, const UMMHeader *, const uint8_t *, size_t);
bool   umm_msg_decode_header(const uint8_t *, size_t, UMMHeader *);
void   umm_header_init(UMMHeader *, uint32_t, int32_t, int32_t,
                       int32_t, int32_t, int32_t, uint8_t);
void   umm_utime_now(UMMHeader *);
bool   fd_recv_exact(int fd, uint8_t *buf, size_t len);
bool   fd_send_exact(int fd, const uint8_t *buf, size_t len);

/* ── subscription entry ───────────────────────────────────────────────────── */

typedef struct RegEntry {
    int             reg_id;
    int             attach_idx;   /* index into router->attaches[] */
    int32_t         mtype;
    int32_t         subtype;
    int             channel;
    uint32_t        flags;
    uint8_t         match_tlvs[512];
    size_t          match_len;
    struct RegEntry *next;        /* linked list within hash bucket */
} RegEntry;

/* ── subscription table ───────────────────────────────────────────────────── */

/*
 * Three-level structure:
 *   _table[channel_index][mtype_bucket][subtype_bucket] → linked list
 *
 * channel_index: we store a few common channels directly; others hash.
 * mtype_bucket / subtype_bucket: simple modulo hash (256 buckets each).
 *
 * Wildcard handling (same as Python):
 *   channel=0 (ALL) matches any incoming channel.
 *   mtype=0 matches any mtype.
 *   subtype=0 matches any subtype.
 *
 * We store wildcard entries under bucket 0.
 */

#define CHAN_BUCKETS     16
#define MTYPE_BUCKETS   256
#define SUB_BUCKETS     256

#define CHAN_BUCKET(ch)   ((unsigned)(ch) % CHAN_BUCKETS)
#define MTYPE_BUCKET(mt)  ((unsigned)(mt) % MTYPE_BUCKETS)
#define SUB_BUCKET(st)    ((unsigned)(st) % SUB_BUCKETS)

typedef struct {
    RegEntry *head[CHAN_BUCKETS][MTYPE_BUCKETS][SUB_BUCKETS];
} SubTable;

static void sub_table_init(SubTable *t) {
    memset(t, 0, sizeof *t);
}

static void sub_table_add(SubTable *t, RegEntry *e) {
    unsigned cb  = CHAN_BUCKET(e->channel);
    unsigned mb  = MTYPE_BUCKET(e->mtype);
    unsigned sb  = SUB_BUCKET(e->subtype);
    e->next = t->head[cb][mb][sb];
    t->head[cb][mb][sb] = e;
}

static bool sub_table_remove(SubTable *t, int attach_idx, int reg_id) {
    for (int c = 0; c < CHAN_BUCKETS; c++)
    for (int m = 0; m < MTYPE_BUCKETS; m++)
    for (int s = 0; s < SUB_BUCKETS; s++) {
        RegEntry **pp = &t->head[c][m][s];
        while (*pp) {
            if ((*pp)->attach_idx == attach_idx && (*pp)->reg_id == reg_id) {
                RegEntry *del = *pp;
                *pp = del->next;
                free(del);
                return true;
            }
            pp = &(*pp)->next;
        }
    }
    return false;
}

static void sub_table_remove_all(SubTable *t, int attach_idx) {
    for (int c = 0; c < CHAN_BUCKETS; c++)
    for (int m = 0; m < MTYPE_BUCKETS; m++)
    for (int s = 0; s < SUB_BUCKETS; s++) {
        RegEntry **pp = &t->head[c][m][s];
        while (*pp) {
            if ((*pp)->attach_idx == attach_idx) {
                RegEntry *del = *pp;
                *pp = del->next;
                free(del);
            } else {
                pp = &(*pp)->next;
            }
        }
    }
}

static void sub_table_free(SubTable *t) {
    for (int c = 0; c < CHAN_BUCKETS; c++)
    for (int m = 0; m < MTYPE_BUCKETS; m++)
    for (int s = 0; s < SUB_BUCKETS; s++) {
        RegEntry *e = t->head[c][m][s];
        while (e) { RegEntry *nx = e->next; free(e); e = nx; }
        t->head[c][m][s] = NULL;
    }
}

/* ── TLV content match ────────────────────────────────────────────────────── */

/*
 * Compare one message TLV against one subscription condition using the match
 * operator.  (Which message field a condition is tested against — positional or
 * meta-keyed — is decided by the caller, tlv_content_match.)
 *
 * MWORD_IGNORE in a subscription TLV → always passes.
 *
 * Exact equality for scalar types and string prefix; numeric comparison
 * operators (GT/LT/GE/LE) are implemented for Int and Float.
 */

static bool match_tlv_values(const UMMTLV *msg_tlv, const UMMTLV *sub_tlv) {
    if (sub_tlv->match == MWORD_IGNORE) return true;

    uint32_t tid    = sub_tlv->type_id;
    uint32_t op     = sub_tlv->match;   /* UMMMatchOp */

    if (tid != msg_tlv->type_id) return false;

    switch (tid) {
    case TLV_INT:
    case TLV_UINT:
    case TLV_SHORT:
    case TLV_USHORT: {
        if (msg_tlv->length < 4 || sub_tlv->length < 4) return false;
        int32_t mv, sv;
        int32_t t;
        memcpy(&t, msg_tlv->value, 4); mv = (int32_t)ntohl((uint32_t)t);
        memcpy(&t, sub_tlv->value, 4); sv = (int32_t)ntohl((uint32_t)t);
        switch (op) {
        case MATCH_EQ: return mv == sv;
        case MATCH_NE: return mv != sv;
        case MATCH_GT: return mv >  sv;
        case MATCH_LT: return mv <  sv;
        case MATCH_GE: return mv >= sv;
        case MATCH_LE: return mv <= sv;
        default:       return false;
        }
    }
    case TLV_FLOAT: {
        if (msg_tlv->length < 8 || sub_tlv->length < 8) return false;
        /* big-endian double decode */
        double mv, sv;
        uint8_t tmp[8];
        memcpy(tmp, msg_tlv->value, 8);
        uint8_t *p = (uint8_t *)&mv;
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
        for (int i = 0; i < 8; i++) p[i] = tmp[7-i];
        memcpy(tmp, sub_tlv->value, 8);
        p = (uint8_t *)&sv;
        for (int i = 0; i < 8; i++) p[i] = tmp[7-i];
#else
        memcpy(&mv, msg_tlv->value, 8);
        memcpy(&sv, sub_tlv->value, 8);
#endif
        switch (op) {
        case MATCH_EQ: return mv == sv;
        case MATCH_NE: return mv != sv;
        case MATCH_GT: return mv >  sv;
        case MATCH_LT: return mv <  sv;
        case MATCH_GE: return mv >= sv;
        case MATCH_LE: return mv <= sv;
        default:       return false;
        }
    }
    case TLV_BOOL: {
        if (!msg_tlv->length || !sub_tlv->length) return false;
        bool mv = msg_tlv->value[0] != 0;
        bool sv = sub_tlv->value[0] != 0;
        return (op == MATCH_EQ) ? (mv == sv) : (mv != sv);
    }
    case TLV_STRING:
    case TLV_FNAME: {
        if (!msg_tlv->length || !sub_tlv->length) return false;
        /* both are null-terminated; compare as C strings */
        const char *ms = (const char *)msg_tlv->value;
        const char *ss = (const char *)sub_tlv->value;
        int cmp = strcmp(ms, ss);
        switch (op) {
        case MATCH_EQ: return cmp == 0;
        case MATCH_NE: return cmp != 0;
        default:       return false;
        }
    }
    case TLV_RAW:
    default:
        /* default: EQ = byte-for-byte comparison */
        if (msg_tlv->length != sub_tlv->length) return (op == MATCH_NE);
        int eq = memcmp(msg_tlv->value, sub_tlv->value, sub_tlv->length) == 0;
        return (op == MATCH_EQ) ? eq : !eq;
    }
}

/*
 * Match a subscription's content filter against a message payload.
 *
 * A condition whose meta is 0 (META_NONE) is matched POSITIONALLY: condition N
 * against message field N, exactly as before.  A condition with a non-zero meta
 * is matched by KEY: it is tested against the message field carrying the same
 * (type_id, meta).  Several conditions sharing one (type, meta) therefore AND
 * together against that single field — e.g. a range
 *     Int meta=K >= lo   and   Int meta=K <= hi.
 * Every condition must pass (a single registration is a conjunction).
 *
 * MWORD_IGNORE in a subscription TLV skips that positional slot (always passes).
 * Kept identical to the Python router (umm/router.py).
 */
static bool tlv_content_match(const uint8_t *msg_payload, size_t msg_len,
                               const uint8_t *sub_payload, size_t sub_len)
{
    if (!sub_len) return true;   /* no match criteria → match on mtype/subtype only */

    UMMTLV msg_tlvs[32], sub_tlvs[32];
    int    nm = tlv_decode_all(msg_payload, msg_len, msg_tlvs, 32);
    int    ns = tlv_decode_all(sub_payload, sub_len, sub_tlvs, 32);

    int pos = 0;   /* positional cursor — advances only for meta==0 conditions */
    for (int i = 0; i < ns; i++) {
        if (sub_tlvs[i].type_id == TLV_TERM) break;
        if (sub_tlvs[i].match == MWORD_IGNORE) {
            pos++;                 /* positional wildcard — skip this slot */
            continue;
        }
        if (sub_tlvs[i].meta == META_NONE) {
            /* positional match (unchanged behaviour) */
            if (pos >= nm) return false;
            if (!match_tlv_values(&msg_tlvs[pos], &sub_tlvs[i])) return false;
            pos++;
        } else {
            /* meta-keyed: test against the field with the same (type_id, meta) */
            const UMMTLV *target = NULL;
            for (int j = 0; j < nm; j++) {
                if (msg_tlvs[j].type_id == sub_tlvs[i].type_id &&
                    msg_tlvs[j].meta    == sub_tlvs[i].meta) {
                    target = &msg_tlvs[j];
                    break;
                }
            }
            if (!target || !match_tlv_values(target, &sub_tlvs[i])) return false;
        }
    }
    return true;
}

/* ── attach info ──────────────────────────────────────────────────────────── */

#define MAX_PROCESS_NAME  UMM_MAX_NAME_LEN
#define MAX_QUEUE_MSGS    256
#define MAX_QUEUE_MSGSIZE UMM_MAX_BUFF_SIZE

typedef struct {
    bool     active;
    uint32_t status;           /* EAS_* flags */
    uint32_t attach_flags;
    uint32_t attach_id;
    int32_t  agent_mtype;
    char     process_name[MAX_PROCESS_NAME];
    UMMClient *client;

    /* offline message queue for PERM_KEEP agents */
    uint8_t **queue_msgs;
    size_t   *queue_lens;
    int       queue_head, queue_tail, queue_count;

    /* reg_ids owned by this attach */
    int       reg_ids[UMM_MAX_REGISTRATIONS];
    int       reg_count;
} AttachInfo;

static void attach_enqueue(AttachInfo *a, const uint8_t *buf, size_t len) {
    if (a->queue_count >= MAX_QUEUE_MSGS) return;
    if (!a->queue_msgs) {
        a->queue_msgs = calloc(MAX_QUEUE_MSGS, sizeof(uint8_t *));
        a->queue_lens = calloc(MAX_QUEUE_MSGS, sizeof(size_t));
        if (!a->queue_msgs) return;
    }
    uint8_t *copy = malloc(len);
    if (!copy) return;
    memcpy(copy, buf, len);
    a->queue_msgs[a->queue_tail] = copy;
    a->queue_lens[a->queue_tail] = len;
    a->queue_tail = (a->queue_tail + 1) % MAX_QUEUE_MSGS;
    a->queue_count++;
}

static void attach_flush_queue(AttachInfo *a) {
    if (!a->queue_msgs) return;
    while (a->queue_count > 0) {
        uint8_t *buf = a->queue_msgs[a->queue_head];
        size_t   len = a->queue_lens[a->queue_head];
        if (a->client && buf)
            a->client->send(a->client, buf, len);
        free(buf);
        a->queue_msgs[a->queue_head] = NULL;
        a->queue_head = (a->queue_head + 1) % MAX_QUEUE_MSGS;
        a->queue_count--;
    }
    a->status &= ~(EAS_OFFLINE | EAS_REATTACH);
}

static void attach_free_queue(AttachInfo *a) {
    if (!a->queue_msgs) return;
    for (int i = 0; i < MAX_QUEUE_MSGS; i++) {
        free(a->queue_msgs[i]);
        a->queue_msgs[i] = NULL;
    }
    free(a->queue_msgs); a->queue_msgs = NULL;
    free(a->queue_lens); a->queue_lens = NULL;
    a->queue_head = a->queue_tail = a->queue_count = 0;
}

/* ── listener: TCP ────────────────────────────────────────────────────────── */

typedef struct {
    UMMListener base;
    int         server_fd;
    char        host[64];
    uint16_t    port;
    UMMRouter  *router;         /* set on start */
} TCPListener;

static bool tcp_listener_start(UMMListener *l, UMMRouter *r) {
    TCPListener *tl = (TCPListener *)l;
    tl->router = r;

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return false;

    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof opt);

    struct sockaddr_in sa = {0};
    sa.sin_family      = AF_INET;
    sa.sin_port        = htons(tl->port ? tl->port : UMM_DEFAULT_PORT);
    if (tl->host[0] && strcmp(tl->host, "0.0.0.0") != 0)
        inet_pton(AF_INET, tl->host, &sa.sin_addr);
    else
        sa.sin_addr.s_addr = INADDR_ANY;

    if (bind(fd, (struct sockaddr *)&sa, sizeof sa) != 0) {
        close(fd); return false;
    }
    if (listen(fd, 32) != 0) {
        close(fd); return false;
    }
    tl->server_fd = fd;
    fprintf(stderr, "[UMMRouter] TCP listener on %s:%u\n",
            tl->host[0] ? tl->host : "*", tl->port ? tl->port : UMM_DEFAULT_PORT);
    return true;
}

static void tcp_listener_stop(UMMListener *l) {
    TCPListener *tl = (TCPListener *)l;
    if (tl->server_fd >= 0) { close(tl->server_fd); tl->server_fd = -1; }
}

static int tcp_listener_accept_fd(UMMListener *l) {
    return ((TCPListener *)l)->server_fd;
}

/* ── per-client wrapper: TCP ──────────────────────────────────────────────── */

typedef struct {
    UMMClient  base;
    int        fd;
    char       peer[64];
} TCPClient;

static int  tcc_fd(UMMClient *c) { return ((TCPClient *)c)->fd; }
static bool tcc_recv(UMMClient *c, uint8_t *buf, size_t len) {
    return fd_recv_exact(((TCPClient *)c)->fd, buf, len);
}
static bool tcc_send(UMMClient *c, const uint8_t *buf, size_t len) {
    return fd_send_exact(((TCPClient *)c)->fd, buf, len);
}
static const char *tcc_peer(UMMClient *c) { return ((TCPClient *)c)->peer; }
static void tcc_destroy(UMMClient *c) {
    TCPClient *tc = (TCPClient *)c;
    if (tc->fd >= 0) { close(tc->fd); tc->fd = -1; }
    free(tc);
}

static UMMClient *tcp_listener_accept(UMMListener *l, UMMRouter *router) {
    TCPListener *tl = (TCPListener *)l;
    struct sockaddr_in sa; socklen_t slen = sizeof sa;
    int fd = accept(tl->server_fd, (struct sockaddr *)&sa, &slen);
    if (fd < 0) return NULL;

    TCPClient *c = calloc(1, sizeof *c);
    if (!c) { close(fd); return NULL; }
    c->base.fd        = tcc_fd;
    c->base.recv      = tcc_recv;
    c->base.send      = tcc_send;
    c->base.peer_addr = tcc_peer;
    c->base.destroy   = tcc_destroy;
    c->fd             = fd;
    snprintf(c->peer, sizeof c->peer, "%s:%u",
             inet_ntoa(sa.sin_addr), ntohs(sa.sin_port));
    (void)router;
    return &c->base;
}

static void tcp_listener_destroy(UMMListener *l) {
    TCPListener *tl = (TCPListener *)l;
    if (tl->server_fd >= 0) close(tl->server_fd);
    free(tl);
}

UMMListener *umm_listener_tcp(const char *host, uint16_t port) {
    TCPListener *l = calloc(1, sizeof *l);
    if (!l) return NULL;
    l->base.name      = "tcp";
    l->base.start     = tcp_listener_start;
    l->base.stop      = tcp_listener_stop;
    l->base.accept_fd = tcp_listener_accept_fd;
    l->base.accept    = tcp_listener_accept;
    l->base.destroy   = tcp_listener_destroy;
    l->server_fd      = -1;
    l->port           = port ? port : UMM_DEFAULT_PORT;
    if (host) snprintf(l->host, sizeof l->host, "%s", host);
    return &l->base;
}

void umm_listener_destroy(UMMListener *l) {
    if (l && l->destroy) l->destroy(l);
}

/* ── listener: UNIX domain socket ────────────────────────────────────────── */

typedef struct {
    UMMListener base;
    int         server_fd;
    char        path[108];
    UMMRouter  *router;
} UnixListener;

static bool unix_listener_start(UMMListener *l, UMMRouter *r) {
    UnixListener *ul = (UnixListener *)l;
    ul->router = r;

    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return false;

    unlink(ul->path);   /* remove stale socket */

    struct sockaddr_un sa = {0};
    sa.sun_family = AF_UNIX;
    snprintf(sa.sun_path, sizeof sa.sun_path, "%s", ul->path);

    if (bind(fd, (struct sockaddr *)&sa, sizeof sa) != 0) { close(fd); return false; }
    if (listen(fd, 16) != 0) { close(fd); return false; }

    ul->server_fd = fd;
    fprintf(stderr, "[UMMRouter] UNIX listener on %s\n", ul->path);
    return true;
}

static void unix_listener_stop(UMMListener *l) {
    UnixListener *ul = (UnixListener *)l;
    if (ul->server_fd >= 0) { close(ul->server_fd); ul->server_fd = -1; }
}

static int unix_listener_accept_fd(UMMListener *l) {
    return ((UnixListener *)l)->server_fd;
}

typedef struct {
    UMMClient base;
    int       fd;
} UnixClientConn;

static int    ucc_fd(UMMClient *c) { return ((UnixClientConn *)c)->fd; }
static bool   ucc_recv(UMMClient *c, uint8_t *b, size_t n) { return fd_recv_exact(((UnixClientConn *)c)->fd, b, n); }
static bool   ucc_send(UMMClient *c, const uint8_t *b, size_t n) { return fd_send_exact(((UnixClientConn *)c)->fd, b, n); }
static const char *ucc_peer(UMMClient *c) { (void)c; return "unix"; }
static void   ucc_destroy(UMMClient *c) { UnixClientConn *u = (UnixClientConn *)c; if (u->fd>=0) close(u->fd); free(u); }

static UMMClient *unix_listener_accept(UMMListener *l, UMMRouter *router) {
    UnixListener *ul = (UnixListener *)l;
    int fd = accept(ul->server_fd, NULL, NULL);
    if (fd < 0) return NULL;
    UnixClientConn *c = calloc(1, sizeof *c);
    if (!c) { close(fd); return NULL; }
    c->base.fd        = ucc_fd;
    c->base.recv      = ucc_recv;
    c->base.send      = ucc_send;
    c->base.peer_addr = ucc_peer;
    c->base.destroy   = ucc_destroy;
    c->fd             = fd;
    (void)router;
    return &c->base;
}

static void unix_listener_destroy(UMMListener *l) {
    UnixListener *ul = (UnixListener *)l;
    if (ul->server_fd >= 0) { close(ul->server_fd); unlink(ul->path); }
    free(ul);
}

UMMListener *umm_listener_unix(const char *path) {
    UnixListener *l = calloc(1, sizeof *l);
    if (!l) return NULL;
    l->base.name      = "unix";
    l->base.start     = unix_listener_start;
    l->base.stop      = unix_listener_stop;
    l->base.accept_fd = unix_listener_accept_fd;
    l->base.accept    = unix_listener_accept;
    l->base.destroy   = unix_listener_destroy;
    l->server_fd      = -1;
    if (path) snprintf(l->path, sizeof l->path, "%s", path);
    return &l->base;
}

/* ── router ───────────────────────────────────────────────────────────────── */

#define MAX_LISTENERS   8
#define MAX_CLIENTS     UMM_MAX_ATTACHES
#define MAX_POLL_FDS    (MAX_LISTENERS + MAX_CLIENTS + 4)

struct UMMRouter {
    uint32_t   router_id;
    char       name[UMM_MAX_NAME_LEN];
    int32_t    msg_id;      /* router-originated message sequence */
    int        next_attach_id;

    SubTable   subs;
    AttachInfo attaches[MAX_CLIENTS];

    UMMListener *listeners[MAX_LISTENERS];
    int          listener_count;

    volatile bool stopping;

    /* scratch buffers */
    uint8_t send_buf[UMM_MAX_BUFF_SIZE];
};

UMMRouter *umm_router_create(uint32_t router_id, const char *name) {
    UMMRouter *r = calloc(1, sizeof *r);
    if (!r) return NULL;
    r->router_id    = router_id ? router_id : 1;
    r->msg_id       = 1;
    r->next_attach_id = 1;
    snprintf(r->name, sizeof r->name, "%s", name ? name : "UMMRouter");
    sub_table_init(&r->subs);
    return r;
}

void umm_router_destroy(UMMRouter *r) {
    if (!r) return;
    for (int i = 0; i < r->listener_count; i++) {
        r->listeners[i]->stop(r->listeners[i]);
        umm_listener_destroy(r->listeners[i]);
    }
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (r->attaches[i].active) {
            if (r->attaches[i].client)
                r->attaches[i].client->destroy(r->attaches[i].client);
            attach_free_queue(&r->attaches[i]);
        }
    }
    sub_table_free(&r->subs);
    free(r);
}

bool umm_router_add_listener(UMMRouter *r, UMMListener *l) {
    if (r->listener_count >= MAX_LISTENERS) return false;
    r->listeners[r->listener_count++] = l;
    return true;
}

uint32_t umm_router_id(const UMMRouter *r)         { return r->router_id; }
int      umm_router_client_count(const UMMRouter *r) {
    int n = 0;
    for (int i = 0; i < MAX_CLIENTS; i++)
        if (r->attaches[i].active) n++;
    return n;
}

/* ── internal helpers ─────────────────────────────────────────────────────── */

static int alloc_attach(UMMRouter *r, UMMClient *client) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (!r->attaches[i].active) {
            AttachInfo *a = &r->attaches[i];
            memset(a, 0, sizeof *a);
            a->active    = true;
            a->status    = EAS_INUSE;
            a->attach_id = r->next_attach_id++;
            a->client    = client;
            return i;
        }
    }
    return -1;
}

static void router_deliver(UMMRouter *r, int attach_idx,
                            const uint8_t *wire, size_t wlen)
{
    AttachInfo *a = &r->attaches[attach_idx];
    if (!a->active) return;

    bool online = (a->status & EAS_INUSE) && !(a->status & EAS_OFFLINE);
    if (online && a->client) {
        if (!a->client->send(a->client, wire, wlen)) {
            a->status |= EAS_OFFLINE;
            if (a->attach_flags & ATTACH_PERM_KEEP)
                attach_enqueue(a, wire, wlen);
        }
    } else if ((a->attach_flags & ATTACH_PERM_KEEP) && (a->status & EAS_OFFLINE)) {
        attach_enqueue(a, wire, wlen);
    }
}

/* Encode a router-originated message and deliver it to the subscription table. */
static void router_publish(UMMRouter *r,
                            int32_t mtype, int32_t subtype,
                            uint8_t channel, int32_t reg_id,
                            const uint8_t *payload, size_t pay_len)
{
    UMMHeader h;
    umm_header_init(&h, r->router_id, mtype, subtype,
                    0, reg_id, r->msg_id++, channel);

    size_t wlen = umm_msg_encode(r->send_buf, sizeof r->send_buf,
                                 &h, payload, pay_len);
    if (!wlen) return;

    /* route through subscription table */
    /* collect candidates (channel=0 wildcard + exact channel) */
    for (int pass = 0; pass < 2; pass++) {
        int ch = (pass == 0) ? 0 : channel;
        unsigned cb = CHAN_BUCKET(ch);

        /* exact mtype + exact subtype */
        for (int mb_pass = 0; mb_pass < 3; mb_pass++) {
            int32_t mt = (mb_pass == 0) ? mtype : 0;
            int32_t st = (mb_pass == 1) ? subtype : (mb_pass == 0) ? subtype : 0;
            if (mb_pass == 2) { mt = 0; st = 0; }

            unsigned mb = MTYPE_BUCKET(mt);
            unsigned sb = SUB_BUCKET(st);

            for (RegEntry *e = r->subs.head[cb][mb][sb]; e; e = e->next) {
                if (e->mtype != mt || e->subtype != st) continue;
                if (e->channel != ch) continue;

                AttachInfo *a = &r->attaches[e->attach_idx];
                if (!a->active) continue;

                /* content match */
                if (!tlv_content_match(payload, pay_len,
                                        e->match_tlvs, e->match_len))
                    continue;

                /* stamp reg_id and deliver */
                h.reg_id = e->reg_id;
                wlen = umm_msg_encode(r->send_buf, sizeof r->send_buf,
                                      &h, payload, pay_len);
                if (wlen) router_deliver(r, e->attach_idx, r->send_buf, wlen);
            }
        }
    }
}

/* Send directly to one client (bypasses subscription lookup). */
static void router_send_to(UMMRouter *r, int attach_idx,
                            int32_t mtype, int32_t subtype, uint8_t channel,
                            int32_t flags, int32_t reg_id,
                            const uint8_t *payload, size_t pay_len)
{
    AttachInfo *a = &r->attaches[attach_idx];
    if (!a->active || !a->client) return;

    UMMHeader h;
    umm_header_init(&h, r->router_id, mtype, subtype,
                    flags, reg_id, r->msg_id++, channel);
    h.attach_router = r->router_id;
    h.attach_id     = a->attach_id;

    size_t wlen = umm_msg_encode(r->send_buf, sizeof r->send_buf,
                                 &h, payload, pay_len);
    if (wlen) router_deliver(r, attach_idx, r->send_buf, wlen);
}

/* ── lifecycle events ─────────────────────────────────────────────────────── */

static void publish_lifecycle(UMMRouter *r, int32_t subtype, int attach_idx) {
    AttachInfo *a = &r->attaches[attach_idx];
    uint8_t pay[128]; size_t plen = 0;
    /* Wire format matches Python router _publish_lifecycle exactly:
     *   TLV_ATTID  (type 12)  router_id(4,NBO) + attach_id(4,NBO)
     *   TLV_INT    (type  2)  agent_mtype
     *   TLV_STRING (type  8)  process_name (null-terminated)
     */
    tlv_encode_attid(pay, sizeof pay, &plen,
                     r->router_id, a->attach_id);
    tlv_encode_int(pay, sizeof pay, &plen, a->agent_mtype, MWORD_NONE, META_NONE);
    tlv_encode_string(pay, sizeof pay, &plen, a->process_name, MWORD_NONE, META_NONE);
    router_publish(r, MTYPE_UMM, subtype, CHAN_APP, 0, pay, plen);
}

/* ── INIT ─────────────────────────────────────────────────────────────────── */

static void send_init(UMMRouter *r, int attach_idx) {
    uint8_t pay[32]; size_t plen = 0;
    tlv_encode_attid(pay, sizeof pay, &plen,
                     r->router_id, r->attaches[attach_idx].attach_id);
    router_send_to(r, attach_idx, MTYPE_UMM, ST_INIT,
                   CHAN_APP, 0, 0, pay, plen);
}

/* ── message dispatch ─────────────────────────────────────────────────────── */

static void handle_attach(UMMRouter *r, int attach_idx, const UMMHeader *hdr,
                           const uint8_t *payload, size_t pay_len)
{
    AttachInfo *a = &r->attaches[attach_idx];
    a->attach_flags = (uint32_t)hdr->flags;

    /* decode LogId TLV and optional Int(agent_mtype) */
    UMMTLV tlvs[8];
    int n = tlv_decode_all(payload, pay_len, tlvs, 8);
    for (int i = 0; i < n; i++) {
        if (tlvs[i].type_id == TLV_LOGID && tlvs[i].length > 0) {
            /* first null-terminated string is process_name */
            size_t copy = tlvs[i].length < UMM_MAX_NAME_LEN - 1
                         ? tlvs[i].length : UMM_MAX_NAME_LEN - 1;
            memcpy(a->process_name, tlvs[i].value, copy);
            a->process_name[copy] = '\0';
            /* strip at first null terminator */
            char *nul = memchr(a->process_name, '\0', copy);
            if (nul) *nul = '\0';
        } else if (tlvs[i].type_id == TLV_INT) {
            int32_t v;
            if (tlv_get_int(&tlvs[i], &v)) a->agent_mtype = v;
        }
    }

    /* check for permanent re-attach */
    uint32_t conf_flag = ATTACH_CONF_NORMAL;
    bool is_reattach   = false;

    if (a->attach_flags & ATTACH_PERM_KEEP) {
        /* search for an offline permanent agent with the same process name */
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (i == attach_idx) continue;
            AttachInfo *old = &r->attaches[i];
            if (!old->active) continue;
            if (!(old->attach_flags & ATTACH_PERM_KEEP)) continue;
            if (!(old->status & EAS_OFFLINE)) continue;
            if (strcmp(old->process_name, a->process_name) != 0) continue;

            /* migrate: transfer client from temp slot to old slot */
            if (old->client) old->client->destroy(old->client);
            old->client       = a->client;
            old->attach_flags = a->attach_flags;
            old->agent_mtype  = a->agent_mtype;
            memcpy(old->process_name, a->process_name, UMM_MAX_NAME_LEN);
            old->status       = EAS_INUSE | EAS_RUNNING | EAS_REATTACH;

            /* free the temp slot */
            a->active    = false;
            a->client    = NULL;
            attach_idx   = i;
            a            = &r->attaches[i];
            conf_flag    = ATTACH_CONF_PERM_REATT;
            is_reattach  = true;
            break;
        }
        if (!is_reattach) {
            conf_flag = ATTACH_CONF_PERM_NEW;
            a->status = EAS_INUSE | EAS_RUNNING;
        }
    }

    /* send ATTACH_CONFIRM */
    uint8_t pay[32]; size_t plen = 0;
    tlv_encode_attid(pay, sizeof pay, &plen,
                     r->router_id, a->attach_id);
    tlv_encode_int(pay, sizeof pay, &plen, (int32_t)conf_flag, MWORD_NONE, META_NONE);
    router_send_to(r, attach_idx, MTYPE_UMM, ST_ATTACH_CONFIRM,
                   CHAN_APP, (int32_t)conf_flag, 0, pay, plen);

    if (is_reattach)
        attach_flush_queue(a);

    int32_t lifecycle = is_reattach ? ST_AGENT_REATTACHED : ST_AGENT_ATTACHED;
    publish_lifecycle(r, lifecycle, attach_idx);

    fprintf(stderr, "[UMMRouter] Attach confirmed: id=%u name='%s' flags=0x%x\n",
            a->attach_id, a->process_name, a->attach_flags);
}

static void handle_register(UMMRouter *r, int attach_idx, const UMMHeader *hdr,
                             const uint8_t *payload, size_t pay_len)
{
    AttachInfo *a = &r->attaches[attach_idx];
    if (!a->active) return;

    /* skip re-registrations on re-attach */
    if (a->status & EAS_REATTACH) {
        if (hdr->flags & REQ_LAST_REQUEST)
            attach_flush_queue(a);
        return;
    }

    int reg_id = hdr->reg_id;
    if (reg_id <= 0 || reg_id >= UMM_MAX_REGISTRATIONS) return;

    /* decode subscription spec from TLV_SUBSPEC in payload */
    int32_t  sub_mtype = 0, sub_subtype = 0;
    const uint8_t *match_bytes = NULL;
    size_t   match_len  = 0;

    UMMTLV tlvs[8];
    int n = tlv_decode_all(payload, pay_len, tlvs, 8);
    for (int i = 0; i < n; i++) {
        if (tlvs[i].type_id == TLV_SUBSPEC && tlvs[i].length >= 8) {
            int32_t t;
            memcpy(&t, tlvs[i].value,     4); sub_mtype   = (int32_t)ntohl((uint32_t)t);
            memcpy(&t, tlvs[i].value + 4, 4); sub_subtype = (int32_t)ntohl((uint32_t)t);
            match_bytes = tlvs[i].value + 8;
            match_len   = tlvs[i].length - 8;
            break;
        }
    }

    /* build and store the reg entry */
    RegEntry *e = calloc(1, sizeof *e);
    if (!e) return;
    e->reg_id     = reg_id;
    e->attach_idx = attach_idx;
    e->mtype      = sub_mtype;
    e->subtype    = sub_subtype;
    e->channel    = hdr->channel;
    e->flags      = (uint32_t)hdr->flags;
    if (match_len && match_bytes) {
        size_t copy = match_len < sizeof e->match_tlvs ? match_len : sizeof e->match_tlvs;
        memcpy(e->match_tlvs, match_bytes, copy);
        e->match_len = copy;
    }

    sub_table_add(&r->subs, e);

    if (a->reg_count < UMM_MAX_REGISTRATIONS)
        a->reg_ids[a->reg_count++] = reg_id;

    if (hdr->flags & REQ_LAST_REQUEST)
        attach_flush_queue(a);
}

static void handle_unregister(UMMRouter *r, int attach_idx, const UMMHeader *hdr)
{
    sub_table_remove(&r->subs, attach_idx, hdr->reg_id);
    /* remove from attach's reg_id list */
    AttachInfo *a = &r->attaches[attach_idx];
    for (int i = 0; i < a->reg_count; i++) {
        if (a->reg_ids[i] == hdr->reg_id) {
            a->reg_ids[i] = a->reg_ids[--a->reg_count];
            break;
        }
    }
}

static void handle_detach(UMMRouter *r, int attach_idx) {
    AttachInfo *a = &r->attaches[attach_idx];
    if (!a->active) return;
    a->status |= EAS_DETACHED;
    publish_lifecycle(r, ST_AGENT_DETACHED, attach_idx);
    sub_table_remove_all(&r->subs, attach_idx);
    if (a->client) { a->client->destroy(a->client); a->client = NULL; }
    attach_free_queue(a);
    a->active = false;
    fprintf(stderr, "[UMMRouter] Detached: id=%u name='%s'\n",
            a->attach_id, a->process_name);
}

static void handle_list_agents(UMMRouter *r, int attach_idx) {
    (void)attach_idx;
    /* Build a simple JSON response.
       For brevity we use a fixed-size buffer — sufficient for UMM_MAX_ATTACHES. */
    char     json[8192];
    int      pos = 0;

    pos += snprintf(json + pos, sizeof json - pos,
                    "{\"router_id\":%u,\"router_name\":\"%s\",\"agents\":[",
                    r->router_id, r->name);

    /* router itself as entry 0 */
    pos += snprintf(json + pos, sizeof json - pos,
                    "{\"attach_id\":0,\"name\":\"%s\",\"mtype\":1,\"online\":true}",
                    r->name);

    for (int i = 0; i < MAX_CLIENTS; i++) {
        AttachInfo *a = &r->attaches[i];
        if (!a->active) continue;
        bool online = (a->status & EAS_INUSE) && !(a->status & EAS_OFFLINE);
        if (!online) continue;
        pos += snprintf(json + pos, sizeof json - pos,
                        ",{\"attach_id\":%u,\"name\":\"%s\",\"mtype\":%d,\"online\":true}",
                        a->attach_id, a->process_name, a->agent_mtype);
    }
    pos += snprintf(json + pos, sizeof json - pos, "]}");

    uint8_t pay[8256]; size_t plen = 0;
    tlv_encode_string(pay, sizeof pay, &plen, json, MWORD_NONE, META_NONE);
    router_publish(r, MTYPE_UMM, ST_LIST_AGENTS_RESPONSE, CHAN_APP, 0, pay, plen);
}

/* Route an application message to all matching subscribers.
 * Returns the number of agents the message was delivered to (the
 * receiver_count reported by a ROUTER_CONFIRM). */
static int route_message(UMMRouter *r, int from_attach,
                          const UMMHeader *hdr,
                          const uint8_t *payload, size_t pay_len)
{
    int delivered = 0;

    /* iterate channel=0 (wildcard) AND exact channel */
    for (int pass = 0; pass < 2; pass++) {
        int ch = (pass == 0) ? 0 : (int)hdr->channel;
        unsigned cb = CHAN_BUCKET(ch);

        /* three mtype/subtype combinations:
           (exact, exact)  (exact, 0)  (0, 0) */
        for (int mp = 0; mp < 3; mp++) {
            int32_t mt = (mp < 2) ? hdr->mtype : 0;
            int32_t st = (mp == 0) ? hdr->subtype : 0;
            unsigned mb = MTYPE_BUCKET(mt);
            unsigned sb = SUB_BUCKET(st);

            for (RegEntry *e = r->subs.head[cb][mb][sb]; e; e = e->next) {
                if (e->mtype != mt || e->subtype != st) continue;
                if (e->channel != ch) continue;

                /* DONT_SEND_SELF */
                if (e->attach_idx == from_attach && (e->flags & REQ_DONT_SEND_SELF))
                    continue;

                /* content match */
                if (!tlv_content_match(payload, pay_len,
                                        e->match_tlvs, e->match_len))
                    continue;

                /* stamp and deliver */
                UMMHeader dh = *hdr;
                dh.reg_id       = e->reg_id;
                dh.attach_router = r->router_id;
                dh.attach_id     = r->attaches[e->attach_idx].attach_id;
                size_t wlen = umm_msg_encode(r->send_buf, sizeof r->send_buf,
                                              &dh, payload, pay_len);
                if (wlen) router_deliver(r, e->attach_idx, r->send_buf, wlen);
                delivered++;
            }
        }
    }
    return delivered;
}

/* ── delivery confirmations ───────────────────────────────────────────────
 * MsgFlag CONFIRM_RTR / CONFIRM_RCV: after routing, the router reports back
 * to the originator on MTYPE_CONFIRM (-1), channel CHAN_CONFIRM.
 *
 * Payload — wire-compatible with the Python router (_send_confirm):
 *     ROUTER_CONFIRM (2): Int(source_mtype)  MsgRef  Int(receiver_count)
 *     RECEIVER_ACK   (3): Int(source_mtype)  MsgRef
 * MsgRef = origin_router(4) origin_id(4) msg_id(4), all NBO, of the
 * original message, so the sender can correlate confirm to send.
 *
 * reg_id stamping (the Session 34 fix, ported from the Python router):
 * confirms are delivered directly, bypassing normal routing, but the agent
 * library dispatches incoming messages by reg_id — a confirm carrying
 * reg_id=0 is silently dropped on the client.  So the confirm is matched
 * against the ORIGINATOR's own subscriptions — including content criteria;
 * send_confirmed() subscribes with Int == source_mtype — and the matching
 * reg_id is stamped, preserving the invariant that reg_id > 0 ⇔ the router
 * matched a subscription.  reg_id stays 0 if the originator holds no
 * matching subscription. */

static int32_t find_origin_reg_id(UMMRouter *r, int origin_idx,
                                  int32_t mtype, int32_t subtype,
                                  uint8_t channel,
                                  const uint8_t *payload, size_t pay_len)
{
    for (int pass = 0; pass < 2; pass++) {
        int ch = (pass == 0) ? 0 : (int)channel;
        if (pass == 1 && ch == 0) break;   /* don't rescan the wildcard bucket */
        unsigned cb = CHAN_BUCKET(ch);

        for (int mp = 0; mp < 3; mp++) {
            int32_t mt = (mp < 2) ? mtype : 0;
            int32_t st = (mp == 0) ? subtype : 0;
            unsigned mb = MTYPE_BUCKET(mt);
            unsigned sb = SUB_BUCKET(st);

            for (RegEntry *e = r->subs.head[cb][mb][sb]; e; e = e->next) {
                if (e->mtype != mt || e->subtype != st) continue;
                if (e->channel != ch) continue;
                if (e->attach_idx != origin_idx) continue;
                if (!tlv_content_match(payload, pay_len,
                                        e->match_tlvs, e->match_len))
                    continue;
                return e->reg_id;
            }
        }
    }
    return 0;
}

static void router_send_confirm(UMMRouter *r, int origin_idx,
                                const UMMHeader *orig, int receiver_count)
{
    /* MsgRef of the original message */
    uint8_t msgref[12];
    uint32_t v;
    v = htonl(orig->origin_router);        memcpy(msgref,     &v, 4);
    v = htonl(orig->origin_id);            memcpy(msgref + 4, &v, 4);
    v = htonl((uint32_t)orig->msg_id);     memcpy(msgref + 8, &v, 4);

    if (orig->flags & MSG_CONFIRM_RTR) {
        uint8_t pay[128]; size_t plen = 0;
        tlv_encode_int(pay, sizeof pay, &plen, orig->mtype,
                       MWORD_NONE, META_NONE);
        tlv_encode(pay, sizeof pay, &plen, TLV_MSGREF,
                   MWORD_NONE, META_NONE, msgref, sizeof msgref);
        tlv_encode_int(pay, sizeof pay, &plen, receiver_count,
                       MWORD_NONE, META_NONE);
        int32_t reg_id = find_origin_reg_id(r, origin_idx, MTYPE_CONFIRM,
                                            CST_ROUTER_CONFIRM, CHAN_CONFIRM,
                                            pay, plen);
        router_send_to(r, origin_idx, MTYPE_CONFIRM, CST_ROUTER_CONFIRM,
                       CHAN_CONFIRM, 0, reg_id, pay, plen);
    }

    if (orig->flags & MSG_CONFIRM_RCV) {
        /* The router acks on behalf of receivers (as the Python router
         * does); true application-level acks are CONFIRM_APP and require
         * explicit agent support. */
        uint8_t pay[128]; size_t plen = 0;
        tlv_encode_int(pay, sizeof pay, &plen, orig->mtype,
                       MWORD_NONE, META_NONE);
        tlv_encode(pay, sizeof pay, &plen, TLV_MSGREF,
                   MWORD_NONE, META_NONE, msgref, sizeof msgref);
        int32_t reg_id = find_origin_reg_id(r, origin_idx, MTYPE_CONFIRM,
                                            CST_RECEIVER_ACK, CHAN_CONFIRM,
                                            pay, plen);
        router_send_to(r, origin_idx, MTYPE_CONFIRM, CST_RECEIVER_ACK,
                       CHAN_CONFIRM, 0, reg_id, pay, plen);
    }
}

/* ── read one complete message from a client ──────────────────────────────── */

static bool read_message(UMMClient *client,
                          UMMHeader *hdr_out,
                          uint8_t *payload_buf, size_t payload_buf_size,
                          size_t *pay_len_out)
{
    uint8_t hdr_bytes[UMM_FIXED_HEADER_SIZE];
    if (!client->recv(client, hdr_bytes, UMM_FIXED_HEADER_SIZE))
        return false;
    if (!umm_msg_decode_header(hdr_bytes, UMM_FIXED_HEADER_SIZE, hdr_out))
        return false;

    /* read TLV header */
    uint8_t tlv_hdr[TLV_HEADER_SIZE];
    if (!client->recv(client, tlv_hdr, TLV_HEADER_SIZE))
        return false;

    uint32_t tlv_len;
    memcpy(&tlv_len, tlv_hdr + 12, 4); tlv_len = ntohl(tlv_len);
    uint32_t padded = tlv_padded_len(tlv_len);

    if (padded > payload_buf_size) {
        /* drain and discard */
        uint8_t discard[256];
        size_t rem = padded;
        while (rem > 0) {
            size_t chunk = rem < sizeof discard ? rem : sizeof discard;
            client->recv(client, discard, chunk);
            rem -= chunk;
        }
        *pay_len_out = 0;
        return true;
    }

    if (padded > 0) {
        if (!client->recv(client, payload_buf, padded))
            return false;
    }
    *pay_len_out = tlv_len;
    return true;
}

/* ── dispatch one message from a client ──────────────────────────────────── */

static void dispatch(UMMRouter *r, int attach_idx,
                     const UMMHeader *hdr,
                     const uint8_t *payload, size_t pay_len)
{
    AttachInfo *a = &r->attaches[attach_idx];
    int delivered = 0;

    /* stamp the sender */
    UMMHeader stamped = *hdr;
    if (stamped.attach_id == 0) {
        stamped.attach_router = r->router_id;
        stamped.attach_id     = a->attach_id;
    }
    if (stamped.origin_id == 0) {
        stamped.origin_router = r->router_id;
        stamped.origin_id     = a->attach_id;
    }

    if (stamped.mtype == MTYPE_UMM) {
        /* intercept control subtypes */
        switch (stamped.subtype) {
        case ST_ATTACH:
            handle_attach(r, attach_idx, &stamped, payload, pay_len);
            break;
        case ST_DETACH:
            handle_detach(r, attach_idx);
            break;
        case ST_REGISTER:
            handle_register(r, attach_idx, &stamped, payload, pay_len);
            break;
        case ST_UNREGISTER:
            handle_unregister(r, attach_idx, &stamped);
            break;
        case ST_LIST_AGENTS:
            handle_list_agents(r, attach_idx);
            break;
        case ST_VERSION_REQUEST:
        case ST_VERSION: {
            /* reply with simple version string */
            uint8_t pay[128]; size_t plen = 0;
            char vstr[64];
            snprintf(vstr, sizeof vstr,
                     "{\"system\":\"%s\",\"build\":\"c\"}",
                     UMM_VERSION_STR);
            tlv_encode_int(pay, sizeof pay, &plen, MTYPE_UMM, MWORD_NONE, META_NONE);
            tlv_encode_string(pay, sizeof pay, &plen, vstr, MWORD_NONE, META_NONE);
            router_send_to(r, attach_idx, MTYPE_UMM, ST_VERSION_RESPONSE,
                           CHAN_APP, 0, hdr->reg_id, pay, plen);
            break;
        }
        default:
            break;
        }
        /* Also dispatch through subscription system so monitors see it */
        delivered = route_message(r, attach_idx, &stamped, payload, pay_len);
    } else {
        delivered = route_message(r, attach_idx, &stamped, payload, pay_len);
    }

    /* Delivery confirmations, if the sender requested them */
    if (stamped.flags & (MSG_CONFIRM_RTR | MSG_CONFIRM_RCV))
        router_send_confirm(r, attach_idx, &stamped, delivered);
}

/* ── main event loop ──────────────────────────────────────────────────────── */

void umm_router_accept_client(UMMRouter *r, UMMClient *client) {
    int idx = alloc_attach(r, client);
    if (idx < 0) {
        fprintf(stderr, "[UMMRouter] Too many clients — rejecting %s\n",
                client->peer_addr ? client->peer_addr(client) : "?");
        client->destroy(client);
        return;
    }
    fprintf(stderr, "[UMMRouter] Client connected from %s → attach_id=%u\n",
            client->peer_addr ? client->peer_addr(client) : "?",
            r->attaches[idx].attach_id);
    send_init(r, idx);
}

void umm_router_step(UMMRouter *r, int timeout_ms) {
    struct pollfd fds[MAX_POLL_FDS];
    int          idx_map[MAX_POLL_FDS]; /* fds[i] → attach index (-1 = listener) */
    int          nfds = 0;

    /* add listener fds */
    for (int i = 0; i < r->listener_count; i++) {
        int fd = r->listeners[i]->accept_fd(r->listeners[i]);
        if (fd < 0) continue;
        fds[nfds].fd      = fd;
        fds[nfds].events  = POLLIN;
        idx_map[nfds]     = -(i + 1);   /* negative → listener index */
        nfds++;
    }

    /* add client fds */
    for (int i = 0; i < MAX_CLIENTS; i++) {
        AttachInfo *a = &r->attaches[i];
        if (!a->active || !a->client) continue;
        if (a->status & EAS_OFFLINE)   continue;  /* don't poll offline */
        int fd = a->client->fd(a->client);
        if (fd < 0) continue;
        fds[nfds].fd      = fd;
        fds[nfds].events  = POLLIN;
        idx_map[nfds]     = i;
        nfds++;
    }

    if (nfds == 0) return;

    int ret = poll(fds, nfds, timeout_ms);
    if (ret <= 0) return;

    static uint8_t payload_buf[UMM_MAX_BUFF_SIZE];

    for (int i = 0; i < nfds; i++) {
        if (!(fds[i].revents & POLLIN)) continue;

        int map = idx_map[i];

        if (map < 0) {
            /* listener — accept new connection */
            int li = -(map + 1);
            UMMClient *c = r->listeners[li]->accept(r->listeners[li], r);
            if (c) umm_router_accept_client(r, c);
            continue;
        }

        /* existing client — read one message */
        AttachInfo *a = &r->attaches[map];
        if (!a->active || !a->client) continue;

        UMMHeader hdr;
        size_t    pay_len = 0;

        bool ok = read_message(a->client, &hdr, payload_buf, sizeof payload_buf, &pay_len);
        if (!ok) {
            /* connection lost */
            fprintf(stderr, "[UMMRouter] Client %u disconnected\n", a->attach_id);
            if (!(a->status & EAS_DETACHED))
                publish_lifecycle(r, ST_AGENT_DETACHED, map);
            sub_table_remove_all(&r->subs, map);

            if ((a->attach_flags & ATTACH_PERM_KEEP) && !(a->status & EAS_DETACHED)) {
                /* keep the slot alive for re-attach */
                a->client->destroy(a->client);
                a->client = NULL;
                a->status |= EAS_OFFLINE;
                a->status &= ~EAS_INUSE;
            } else {
                a->client->destroy(a->client);
                a->client = NULL;
                attach_free_queue(a);
                a->active = false;
            }
            continue;
        }

        dispatch(r, map, &hdr, payload_buf, pay_len);
    }
}

void umm_router_run(UMMRouter *r) {
    /* start all listeners */
    for (int i = 0; i < r->listener_count; i++) {
        if (!r->listeners[i]->start(r->listeners[i], r)) {
            fprintf(stderr, "[UMMRouter] Failed to start listener '%s'\n",
                    r->listeners[i]->name);
        }
    }

    r->stopping = false;
    while (!r->stopping)
        umm_router_step(r, 100);   /* 100ms poll timeout */

    /* stop all listeners */
    for (int i = 0; i < r->listener_count; i++)
        r->listeners[i]->stop(r->listeners[i]);
}

void umm_router_stop(UMMRouter *r) {
    r->stopping = true;
}
