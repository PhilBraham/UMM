/**
 * router_main.c  —  UMM Router standalone process entry point.
 *
 * Usage:
 *   umm_router [--port N] [--host ADDR] [--id SITE.NODE] [--name NAME]
 *              [--unix PATH] [--bluetooth CHANNEL]
 *
 * © Realtime Software Pty Ltd.  MIT licence.
 */

#include "umm_router.h"
#include "umm_types.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <ifaddrs.h>

static UMMRouter *g_router = NULL;

static void on_signal(int sig) {
    (void)sig;
    if (g_router) umm_router_stop(g_router);
}

/**
 * Auto-detect the router_id from the primary non-loopback IPv4 address.
 * Uses the last two octets: 192.168.1.31 → 0x0001001F = 65567.
 */
static uint32_t detect_router_id(void) {
    struct ifaddrs *ifap = NULL;
    if (getifaddrs(&ifap) != 0) return 1;

    uint32_t id = 1;
    for (struct ifaddrs *ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr || ifa->ifa_addr->sa_family != AF_INET) continue;
        if (strcmp(ifa->ifa_name, "lo") == 0) continue;
        struct sockaddr_in *sa = (struct sockaddr_in *)ifa->ifa_addr;
        uint32_t ip = ntohl(sa->sin_addr.s_addr);
        uint16_t site = (uint16_t)((ip >> 8) & 0xFF);
        uint16_t node = (uint16_t)(ip & 0xFF);
        id = ((uint32_t)site << 16) | node;
        break;
    }
    freeifaddrs(ifap);
    return id;
}

static void print_usage(const char *prog) {
    fprintf(stderr,
        "Usage: %s [options]\n"
        "\n"
        "Options:\n"
        "  --port N          TCP port to listen on (default %d)\n"
        "  --host ADDR       Bind address (default: all interfaces)\n"
        "  --router ADDR     Alias for --host (accepted for compatibility)\n"
        "  --id SITE.NODE    Router ID in site.node format (default: auto)\n"
        "  --name NAME       Router name (default: UMMRouter)\n"
        "  --unix PATH       Also listen on a UNIX domain socket\n"
        "  --debug           Enable verbose logging\n"
        "  --version         Print version and exit\n"
        "\n"
        "Environment:\n"
        "  UMM_ROUTER        Override bind address (host:port or host)\n"
        "\n",
        prog, UMM_DEFAULT_PORT);
}

int main(int argc, char *argv[]) {
    uint16_t    port      = UMM_DEFAULT_PORT;
    const char *host      = "";
    uint32_t    router_id = 0;      /* 0 = auto-detect */
    const char *name      = "UMMRouter";
    const char *unix_path = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            port = (uint16_t)atoi(argv[++i]);
        } else if ((strcmp(argv[i], "--host")   == 0 ||
                    strcmp(argv[i], "--router") == 0) && i + 1 < argc) {
            host = argv[++i];
        } else if (strcmp(argv[i], "--id") == 0 && i + 1 < argc) {
            /* accept "site.node" format */
            unsigned site = 0, node = 0;
            if (sscanf(argv[++i], "%u.%u", &site, &node) == 2)
                router_id = (site << 16) | (node & 0xFFFF);
            else
                router_id = (uint32_t)atoi(argv[i]);
        } else if (strcmp(argv[i], "--name") == 0 && i + 1 < argc) {
            name = argv[++i];
        } else if (strcmp(argv[i], "--unix") == 0 && i + 1 < argc) {
            unix_path = argv[++i];
        } else if (strcmp(argv[i], "--debug") == 0) {
            /* future: set debug flag */
        } else if (strcmp(argv[i], "--version") == 0) {
            printf("UMM Router C v%s\n", UMM_VERSION_STR);
            return 0;
        } else if (strcmp(argv[i], "--help") == 0 ||
                   strcmp(argv[i], "-h") == 0) {
            print_usage(argv[0]);
            return 0;
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            print_usage(argv[0]);
            return 1;
        }
    }

    /* override from environment */
    const char *env = getenv("UMM_ROUTER");
    if (env && strchr(env, ':')) {
        port = (uint16_t)atoi(strrchr(env, ':') + 1);
    }

    if (router_id == 0)
        router_id = detect_router_id();

    g_router = umm_router_create(router_id, name);
    if (!g_router) {
        fprintf(stderr, "Failed to create router\n");
        return 1;
    }

    /* TCP listener (always) */
    UMMListener *tcp_l = umm_listener_tcp(host, port);
    if (!tcp_l || !umm_router_add_listener(g_router, tcp_l)) {
        fprintf(stderr, "Failed to add TCP listener\n");
        umm_router_destroy(g_router);
        return 1;
    }

    /* Optional UNIX socket listener */
    if (unix_path) {
        UMMListener *unix_l = umm_listener_unix(unix_path);
        if (unix_l) umm_router_add_listener(g_router, unix_l);
    }

    /* Signal handlers */
    signal(SIGINT,  on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGPIPE, SIG_IGN);

    uint16_t site = (uint16_t)(router_id >> 16);
    uint16_t node = (uint16_t)(router_id & 0xFFFF);
    fprintf(stderr, "[UMMRouter] '%s' id=%u.%u starting on port %u\n",
            name, site, node, port);

    umm_router_run(g_router);

    fprintf(stderr, "[UMMRouter] Stopped\n");
    umm_router_destroy(g_router);
    return 0;
}
