@echo off
setlocal EnableExtensions

rem ===========================================================================
rem  runumm.cmd  --  UMM system manager (Windows)
rem
rem  Thin wrapper around umm_ctl.py, kept in parity with the Unix `runumm`
rem  script so the same commands work on every platform, e.g.:
rem
rem      runumm start              start the core stack
rem      runumm start parser       run the bus monitor
rem      runumm stop               stop everything
rem      runumm status             show what is running
rem
rem  Works no matter which directory you call it from.
rem ===========================================================================

rem -- Directory this script lives in (includes a trailing backslash) ---------
set "UMM_DIR=%~dp0"

rem -- Make sure the launcher is sitting next to umm_ctl.py -------------------
if not exist "%UMM_DIR%umm_ctl.py" (
    echo runumm: error: umm_ctl.py was not found next to runumm.cmd.
    echo   Expected at: %UMM_DIR%umm_ctl.py
    exit /b 1
)

rem -- Choose a Python 3 interpreter -----------------------------------------
rem  Prefer the official Windows launcher "py -3": it always picks a real
rem  Python 3 and avoids the Microsoft Store "python" alias stub.
set "PYEXE="
py -3 --version >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE (
    python --version >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
    python3 --version >nul 2>&1 && set "PYEXE=python3"
)
if not defined PYEXE (
    echo runumm: error: Python 3 was not found on your PATH.
    echo   Install Python 3.11 or later from https://www.python.org/downloads/
    echo   and tick "Add python.exe to PATH" in the installer.
    exit /b 9009
)

rem -- Hand off to umm_ctl.py, forwarding every argument ----------------------
%PYEXE% "%UMM_DIR%umm_ctl.py" %*
set "RC=%ERRORLEVEL%"

endlocal & exit /b %RC%
