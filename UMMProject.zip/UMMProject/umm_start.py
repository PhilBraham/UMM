#!/usr/bin/env python3
"""
umm_start.py
============
UMM canonical startup script.

Starts the router then the supervisor.  The supervisor reads
``supervisor.conf`` and starts everything else.

Configuration is taken from environment variables, falling back to
``umm.conf`` (same directory as this script), falling back to built-in
defaults.

Environment variables
---------------------
UMM_ROUTER      Router host:port  e.g. ``localhost:5100``
                (host only → port defaults to 5100)
UMM_ROUTER_ID   Router ID as site.node  e.g. ``1.3``
                (overrides umm.conf ``router_id``)

Usage
-----
    python3 umm_start.py                    # use defaults / env vars
    python3 umm_start.py --config my.conf   # use alternate umm.conf
    python3 umm_start.py --supervisor-config supervisor.conf
    python3 umm_start.py --stop             # stop everything

The script does not daemonise.  Run it in a terminal or under a process
manager such as systemd.  Ctrl-C stops both the router and supervisor
cleanly.
"""

from __future__ import annotations

import argparse
import configparser
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).parent.resolve()

# ── defaults ──────────────────────────────────────────────────────────────────

DEFAULT_HOST      = 'localhost'
DEFAULT_PORT      = 5100
DEFAULT_ROUTER_ID = '1.1'
DEFAULT_PYTHON    = 'python3'
DEFAULT_SUP_CONF  = str(HERE / 'supervisor.conf')


# ── config loading ────────────────────────────────────────────────────────────

def load_config(conf_path: Path) -> dict:
    """
    Load settings from ``umm.conf``, then override with environment variables.

    Priority (highest first):
      1. Environment variables (UMM_ROUTER, UMM_ROUTER_ID)
      2. umm.conf [settings] section
      3. Built-in defaults
    """
    cfg = {
        'host':      DEFAULT_HOST,
        'port':      DEFAULT_PORT,
        'router_id': DEFAULT_ROUTER_ID,
        'python':    DEFAULT_PYTHON,
    }

    if conf_path.exists():
        parser = configparser.ConfigParser()
        parser.read(str(conf_path))
        if parser.has_section('settings'):
            s = parser['settings']
            cfg['host']      = s.get('router',    cfg['host'])
            cfg['port']      = int(s.get('port',   str(cfg['port'])))
            cfg['router_id'] = s.get('router_id', cfg['router_id'])
            cfg['python']    = s.get('python',     cfg['python'])
    else:
        print(f"[umm_start] Note: {conf_path} not found — using defaults")

    # UMM_ROUTER overrides host and port
    env_router = os.environ.get('UMM_ROUTER', '').strip()
    if env_router:
        if ':' in env_router:
            env_host, _, env_port_str = env_router.rpartition(':')
            try:
                cfg['host'] = env_host.strip()
                cfg['port'] = int(env_port_str.strip())
            except ValueError:
                print(f"[umm_start] WARN: UMM_ROUTER={env_router!r} — "
                      f"port is not an integer, ignoring")
        else:
            cfg['host'] = env_router

    # UMM_ROUTER_ID overrides router_id
    env_id = os.environ.get('UMM_ROUTER_ID', '').strip()
    if env_id:
        cfg['router_id'] = env_id

    return cfg


# ── process management ────────────────────────────────────────────────────────

class ManagedProcess:
    """A subprocess we own and will stop on exit."""

    def __init__(self, name: str, cmd: list[str]) -> None:
        self.name = name
        self.cmd  = cmd
        self.proc: subprocess.Popen | None = None

    def start(self) -> bool:
        print(f"[umm_start] Starting {self.name}")
        print(f"[umm_start]   {' '.join(self.cmd)}")
        try:
            self.proc = subprocess.Popen(self.cmd)
            return True
        except FileNotFoundError as exc:
            print(f"[umm_start] ERROR: Could not start {self.name}: {exc}")
            return False

    def stop(self) -> None:
        if not self.proc:
            return
        if self.proc.poll() is not None:
            return   # already exited
        print(f"[umm_start] Stopping {self.name} (pid={self.proc.pid})")
        try:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                print(f"[umm_start] {self.name} did not stop — sending SIGKILL")
                self.proc.kill()
        except Exception as exc:
            print(f"[umm_start] Warning: error stopping {self.name}: {exc}")

    def is_running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None


# ── router readiness check ────────────────────────────────────────────────────

def wait_for_router(host: str, port: int,
                    timeout: float = 10.0) -> bool:
    """Poll until the router is accepting connections."""
    import socket
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            s = socket.create_connection((host, port), timeout=0.5)
            s.close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


# ── main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(
        description='UMM start — launch router then supervisor')
    p.add_argument('--config', default=str(HERE / 'umm.conf'),
                   help='Path to umm.conf (default: umm.conf)')
    p.add_argument('--supervisor-config', default=DEFAULT_SUP_CONF,
                   dest='sup_conf',
                   help='Path to supervisor.conf '
                        '(default: supervisor.conf)')
    p.add_argument('--router-wait', type=float, default=10.0,
                   dest='router_wait',
                   help='Seconds to wait for router to be ready (default: 10)')
    args = p.parse_args()

    cfg = load_config(Path(args.config))
    host      = cfg['host']
    port      = cfg['port']
    router_id = cfg['router_id']
    python    = cfg['python']

    print(f"[umm_start] Router:    {host}:{port}  id={router_id}")
    print(f"[umm_start] Supervisor config: {args.sup_conf}")

    processes: list[ManagedProcess] = []

    def stop_all(signum=None, frame=None) -> None:
        print("\n[umm_start] Shutting down...")
        for proc in reversed(processes):
            proc.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT,  stop_all)
    signal.signal(signal.SIGTERM, stop_all)

    # ── 1. Start router ───────────────────────────────────────────────────────
    router = ManagedProcess('router', [
        python, '-m', 'umm.router',
        '--port', str(port),
        '--id',   router_id,
        '--name', f'router-{router_id}',
    ])
    if not router.start():
        sys.exit(1)
    processes.append(router)

    # Wait for router to be ready
    # Brief pause so router log output appears before "Waiting..." message
    time.sleep(0.3)
    print(f"[umm_start] Waiting for router on {host}:{port}...")
    if not wait_for_router(host, port, timeout=args.router_wait):
        print(f"[umm_start] ERROR: Router did not start within "
              f"{args.router_wait:.0f}s")
        stop_all()
        sys.exit(1)
    print(f"[umm_start] Router ready")

    # ── 2. Start supervisor ───────────────────────────────────────────────────
    supervisor = ManagedProcess('supervisor', [
        python, '-m', 'umm.modules.supervisor',
        '--router', host,
        '--port',   str(port),
        '--config', args.sup_conf,
        '--name',   'supervisor',
    ])
    if not supervisor.start():
        stop_all()
        sys.exit(1)
    processes.append(supervisor)

    # ── 3. Monitor ────────────────────────────────────────────────────────────
    print(f"[umm_start] System running.  Ctrl-C to stop.")
    try:
        while True:
            time.sleep(1.0)
            # If router dies, stop everything
            if not router.is_running():
                print("[umm_start] Router exited unexpectedly — stopping")
                stop_all()
    except KeyboardInterrupt:
        stop_all()


if __name__ == '__main__':
    main()
