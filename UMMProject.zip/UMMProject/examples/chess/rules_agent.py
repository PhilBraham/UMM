"""
examples/chess/rules_agent.py
=============================
The single authority on chess legality and game state.

Wraps python-chess.  Receives proposed moves on the game channel
(MT_CHESS_GAME, 2000), validates them, and publishes MoveConfirmed /
MoveRejected.  Everything downstream (boards, engines, recorders)
subscribes only to confirmed moves — single source of truth.

Legal-move queries travel on the service channel (11) under
MT_CHESS_RULES (2001) so `parser --channel 1` shows exactly the story
of the game with no UI plumbing.

Run:
    python3 -m examples.chess.rules_agent [--router HOST] [--port N]

Requires:  python-chess (a PyPI package, not a Homebrew formula):
               python3 -m pip install python-chess
           On externally-managed Pythons (recent Homebrew/Debian) add
           --break-system-packages, or use a project venv.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import traceback

if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

try:
    import chess
except ImportError:
    print("ERROR: python-chess not found.")
    print("       python-chess is a PyPI package, NOT a Homebrew formula —")
    print("       install it with pip using the same Python that runs this agent:")
    print(f"       {sys.executable} -m pip install python-chess")
    print("       If pip reports 'externally-managed-environment' (recent")
    print("       Homebrew/Debian Pythons), either add --break-system-packages")
    print("       or use a project venv:")
    print("       python3 -m venv .venv && source .venv/bin/activate")
    print("       python3 -m pip install python-chess websockets")
    sys.exit(1)

from umm.agent import UMMAgent
from umm.core.registry import registry
from umm.core.messages import DEFAULT_PORT, Channel
from umm.core.meta import CHAR_META_JSON
from umm.types.builtin import BUILTIN_TYPES
from umm.capability import register_capability_handler

for _cls in BUILTIN_TYPES:
    registry.register_class(_cls)

from examples.chess.capabilities import (
    MT_CHESS_GAME, MT_CHESS_RULES, CHESS_SVC_CHANNEL,
    ST_BOARD_STATE, ST_STATE_REQ, ST_MOVE_PROPOSED, ST_MOVE_CONFIRMED,
    ST_MOVE_REJECTED, ST_NEW_GAME, ST_RESIGN, ST_DRAW_ACCEPT,
    ST_GAME_OVER, ST_SETUP_REJECTED, ST_LEGAL_REQ, ST_LEGAL_RESP,
    META_FEN, META_UCI, META_SAN, META_RESULT, META_REASON,
    META_GAME_ID, META_COLOUR, META_GSTATUS, META_SQUARE, META_MOVE_NO,
    GS_IN_PROGRESS, GS_CHECK, GS_CHECKMATE, GS_STALEMATE,
    GS_DRAW_AUTO, GS_DRAW_AGREED, GS_RESIGNATION,
    WHITE, BLACK,
    RULES_CAPABILITY, register_chess_metas,
)

log = logging.getLogger('chess.rules')

_char  = registry.get_by_name('Char')
_int   = registry.get_by_name('Int')

STANDARD_START = chess.STARTING_FEN


from examples.chess.tlvutil import tlv_fields as _tlv_fields, \
    get_char as _get_char, get_int as _get_int


# ── game state ─────────────────────────────────────────────────────────────────

class Game:
    """One chess game: a python-chess Board plus its result once finished."""

    def __init__(self, game_id: int, fen: str = STANDARD_START) -> None:
        self.game_id = game_id
        self.board   = chess.Board(fen)
        self.over    = False
        self.result  = None    # '1-0' / '0-1' / '1/2-1/2'
        self.reason  = None

    # -- status -----------------------------------------------------------
    def status(self) -> int:
        b = self.board
        if self.over:
            if self.reason == 'resignation':
                return GS_RESIGNATION
            if self.reason == 'draw agreed':
                return GS_DRAW_AGREED
        if b.is_checkmate():
            return GS_CHECKMATE
        if b.is_stalemate():
            return GS_STALEMATE
        if (b.is_insufficient_material() or b.is_seventyfive_moves()
                or b.is_fivefold_repetition()):
            return GS_DRAW_AUTO
        if b.is_check():
            return GS_CHECK
        return GS_IN_PROGRESS

    def finish_if_terminal(self) -> bool:
        """After a move: set over/result/reason if the position is terminal."""
        b = self.board
        if b.is_checkmate():
            self.over   = True
            self.result = '0-1' if b.turn == chess.WHITE else '1-0'
            self.reason = 'checkmate'
        elif b.is_stalemate():
            self.over, self.result, self.reason = True, '1/2-1/2', 'stalemate'
        elif b.is_insufficient_material():
            self.over, self.result, self.reason = True, '1/2-1/2', 'insufficient material'
        elif b.is_seventyfive_moves():
            self.over, self.result, self.reason = True, '1/2-1/2', '75-move rule'
        elif b.is_fivefold_repetition():
            self.over, self.result, self.reason = True, '1/2-1/2', 'fivefold repetition'
        return self.over


# ── the agent ──────────────────────────────────────────────────────────────────

class RulesAgent:

    def __init__(self, agent: UMMAgent) -> None:
        self.agent = agent
        self.games: dict[int, Game] = {}

    def game(self, game_id: int) -> Game:
        if game_id not in self.games:
            self.games[game_id] = Game(game_id)
            log.info('game %d created (standard start)', game_id)
        return self.games[game_id]

    # ── publishers ─────────────────────────────────────────────────────────

    def publish_state(self, g: Game) -> None:
        self.agent.send(
            mtype=MT_CHESS_GAME, subtype=ST_BOARD_STATE, channel=int(Channel.APP),
            tlvs=[_char.make_tlv(g.board.fen(), meta=META_FEN),
                  _int.make_tlv(g.game_id, meta=META_GAME_ID),
                  _int.make_tlv(g.status(), meta=META_GSTATUS)])

    def publish_game_over(self, g: Game) -> None:
        self.agent.send(
            mtype=MT_CHESS_GAME, subtype=ST_GAME_OVER, channel=int(Channel.APP),
            tlvs=[_char.make_tlv(g.result, meta=META_RESULT),
                  _char.make_tlv(g.reason, meta=META_REASON),
                  _char.make_tlv(g.board.fen(), meta=META_FEN),
                  _int.make_tlv(g.game_id, meta=META_GAME_ID)])
        log.info('game %d over: %s (%s)', g.game_id, g.result, g.reason)

    def reject_move(self, uci: str, reason: str, colour: int, game_id: int) -> None:
        self.agent.send(
            mtype=MT_CHESS_GAME, subtype=ST_MOVE_REJECTED, channel=int(Channel.APP),
            tlvs=[_char.make_tlv(uci or '?', meta=META_UCI),
                  _char.make_tlv(reason, meta=META_REASON),
                  _int.make_tlv(colour, meta=META_COLOUR),
                  _int.make_tlv(game_id, meta=META_GAME_ID)])
        log.info('game %d: rejected %s — %s', game_id, uci, reason)

    # ── handlers ───────────────────────────────────────────────────────────

    def on_new_game(self, msg) -> None:
        keyed, ordered = _tlv_fields(msg)
        game_id = _get_int(keyed, ordered, META_GAME_ID, 1)
        fen     = _get_char(keyed, ordered, META_FEN)
        if fen:
            fen = fen.strip()
            # Validate before accepting: structure, then position legality.
            try:
                board = chess.Board(fen)
            except ValueError as e:
                self._setup_reject(fen, f'invalid FEN: {e}', game_id)
                return
            st = board.status()
            if st != chess.STATUS_VALID:
                self._setup_reject(fen, self._status_text(st), game_id)
                return
        else:
            board = chess.Board(STANDARD_START)
        g = Game(game_id, board.fen())
        self.games[game_id] = g
        log.info('game %d: new game, fen=%s', game_id, g.board.fen())
        self.publish_state(g)

    def _setup_reject(self, fen: str, reason: str, game_id: int) -> None:
        self.agent.send(
            mtype=MT_CHESS_GAME, subtype=ST_SETUP_REJECTED, channel=int(Channel.APP),
            tlvs=[_char.make_tlv(fen, meta=META_FEN),
                  _char.make_tlv(reason, meta=META_REASON),
                  _int.make_tlv(game_id, meta=META_GAME_ID)])
        log.info('game %d: setup rejected — %s', game_id, reason)

    @staticmethod
    def _status_text(st) -> str:
        names = {
            chess.STATUS_NO_WHITE_KING:  'no white king',
            chess.STATUS_NO_BLACK_KING:  'no black king',
            chess.STATUS_TOO_MANY_KINGS: 'more than one king per side',
            chess.STATUS_PAWNS_ON_BACKRANK: 'pawn on rank 1 or 8',
            chess.STATUS_OPPOSITE_CHECK: 'side not to move is in check',
            chess.STATUS_TOO_MANY_WHITE_PIECES: 'too many white pieces',
            chess.STATUS_TOO_MANY_BLACK_PIECES: 'too many black pieces',
            chess.STATUS_TOO_MANY_WHITE_PAWNS:  'too many white pawns',
            chess.STATUS_TOO_MANY_BLACK_PAWNS:  'too many black pawns',
            chess.STATUS_BAD_CASTLING_RIGHTS:   'castling rights inconsistent with placement',
            chess.STATUS_INVALID_EP_SQUARE:     'invalid en passant square',
        }
        parts = [txt for flag, txt in names.items() if st & flag]
        return '; '.join(parts) if parts else f'invalid position (status {int(st)})'

    def on_state_req(self, msg) -> None:
        keyed, ordered = _tlv_fields(msg)
        game_id = _get_int(keyed, ordered, META_GAME_ID, 1)
        self.publish_state(self.game(game_id))

    def on_move_proposed(self, msg) -> None:
        keyed, ordered = _tlv_fields(msg)
        game_id = _get_int(keyed, ordered, META_GAME_ID, 1)
        colour  = _get_int(keyed, ordered, META_COLOUR, -1)
        uci     = _get_char(keyed, ordered, META_UCI)
        g = self.game(game_id)

        if g.over:
            self.reject_move(uci, 'game over', colour, game_id)
            return
        if uci is None:
            self.reject_move(None, 'no move supplied', colour, game_id)
            return
        side_to_move = WHITE if g.board.turn == chess.WHITE else BLACK
        if colour != side_to_move:
            self.reject_move(uci, 'not your turn', colour, game_id)
            return
        try:
            move = chess.Move.from_uci(uci.strip())
        except ValueError:
            self.reject_move(uci, 'malformed UCI move', colour, game_id)
            return
        if move not in g.board.legal_moves:
            self.reject_move(uci, 'illegal move', colour, game_id)
            return

        san     = g.board.san(move)
        move_no = g.board.fullmove_number
        g.board.push(move)
        terminal = g.finish_if_terminal()

        self.agent.send(
            mtype=MT_CHESS_GAME, subtype=ST_MOVE_CONFIRMED, channel=int(Channel.APP),
            tlvs=[_char.make_tlv(uci, meta=META_UCI),
                  _char.make_tlv(san, meta=META_SAN),
                  _char.make_tlv(g.board.fen(), meta=META_FEN),
                  _int.make_tlv(colour, meta=META_COLOUR),
                  _int.make_tlv(g.status(), meta=META_GSTATUS),
                  _int.make_tlv(move_no, meta=META_MOVE_NO),
                  _int.make_tlv(game_id, meta=META_GAME_ID)])
        log.info('game %d: %d%s %s (%s)', game_id, move_no,
                 '.' if colour == WHITE else '...', san, uci)
        if terminal:
            self.publish_game_over(g)

    def on_resign(self, msg) -> None:
        keyed, ordered = _tlv_fields(msg)
        game_id = _get_int(keyed, ordered, META_GAME_ID, 1)
        colour  = _get_int(keyed, ordered, META_COLOUR, -1)
        g = self.game(game_id)
        if g.over or colour not in (WHITE, BLACK):
            return
        g.over   = True
        g.result = '0-1' if colour == WHITE else '1-0'
        g.reason = 'resignation'
        self.publish_game_over(g)

    def on_draw_accept(self, msg) -> None:
        keyed, ordered = _tlv_fields(msg)
        game_id = _get_int(keyed, ordered, META_GAME_ID, 1)
        g = self.game(game_id)
        if g.over:
            return
        g.over, g.result, g.reason = True, '1/2-1/2', 'draw agreed'
        self.publish_game_over(g)

    def on_legal_req(self, msg) -> None:
        keyed, ordered = _tlv_fields(msg)
        game_id = _get_int(keyed, ordered, META_GAME_ID, 1)
        square  = _get_int(keyed, ordered, META_SQUARE)
        log.debug('game %d: legal_req square=%s', game_id, square)
        g = self.game(game_id)
        if g.over:
            moves = []
        elif square is not None:
            moves = [m.uci() for m in g.board.legal_moves
                     if m.from_square == square]
        else:
            moves = [m.uci() for m in g.board.legal_moves]
        tlvs = [_char.make_tlv(json.dumps(moves), meta=CHAR_META_JSON),
                _int.make_tlv(game_id, meta=META_GAME_ID),
                # The authority's position rides on every response so clients
                # can DETECT divergence (e.g. this agent restarted and lost
                # its in-memory games): a board whose FEN differs knows its
                # highlights would be wrong and can resync via StateReq.
                _char.make_tlv(g.board.fen(), meta=META_FEN)]
        if square is not None:
            tlvs.insert(1, _int.make_tlv(square, meta=META_SQUARE))
        self.agent.send(mtype=MT_CHESS_RULES, subtype=ST_LEGAL_RESP,
                        channel=CHESS_SVC_CHANNEL, tlvs=tlvs)


# ── wiring ─────────────────────────────────────────────────────────────────────

def _guard(fn):
    """Log-and-continue wrapper so a handler exception never kills the agent
    (the tank-agent lesson: unlogged callback exceptions hide root causes)."""
    def wrapped(msg):
        try:
            fn(msg)
        except Exception:
            log.error('handler %s failed:\n%s', fn.__name__, traceback.format_exc())
    return wrapped


def main() -> None:
    p = argparse.ArgumentParser(description='UMM Chess Rules Agent')
    p.add_argument('--router', default='localhost')
    p.add_argument('--port',   type=int, default=DEFAULT_PORT)
    p.add_argument('--name',   default='ChessRules',
                   help='Agent name shown in GUI and parser (passed by umm_ctl)')
    p.add_argument('--type',   type=int, default=MT_CHESS_GAME,
                   help='Agent mtype override (passed by umm_ctl)')
    p.add_argument('--debug',  action='store_true')
    args = p.parse_args()

    # Log to stdout so the runumm per-agent log wrapper captures everything
    # (the Session-33 tank lesson: stderr output is lost under supervision).
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        stream=sys.stdout,
                        format='%(asctime)s %(name)s %(levelname)s %(message)s')
    register_chess_metas()

    agent = UMMAgent(host=args.router, port=args.port,
                     process_name=args.name, agent_mtype=args.type)
    agent.connect()
    register_capability_handler(agent, RULES_CAPABILITY)

    rules = RulesAgent(agent)

    ch_app = int(Channel.APP)
    agent.register(mtype=MT_CHESS_GAME,  subtype=ST_NEW_GAME,
                   callback=_guard(rules.on_new_game),      channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,  subtype=ST_STATE_REQ,
                   callback=_guard(rules.on_state_req),     channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,  subtype=ST_MOVE_PROPOSED,
                   callback=_guard(rules.on_move_proposed), channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,  subtype=ST_RESIGN,
                   callback=_guard(rules.on_resign),        channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,  subtype=ST_DRAW_ACCEPT,
                   callback=_guard(rules.on_draw_accept),   channel=ch_app)
    agent.register(mtype=MT_CHESS_RULES, subtype=ST_LEGAL_REQ,
                   callback=_guard(rules.on_legal_req),     channel=CHESS_SVC_CHANNEL)

    log.info('ChessRules agent running (game channel %d on APP, '
             'legal-move service %d on channel %d)',
             MT_CHESS_GAME, MT_CHESS_RULES, CHESS_SVC_CHANNEL)
    try:
        agent.run()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
