"""
examples/chess/playback.py
================================
Replays a recorded chess game onto the bus so every board and observer
GUI animates exactly as it did live.

Input is a parser recording — the JSON-lines file written by
`python3 -m umm.modules.parser --record game.json` while a game was
played.  The agent extracts the game's *story* from the recording (the
starting position, the MoveConfirmed sequence with its timestamps, and
any resignation / agreed-draw ending) and replays it at the game level:
NewGame, then paced MoveProposed messages through the rules agent,
waiting for each MoveConfirmed before scheduling the next.

Design (spec §8): the rules agent remains the single source of truth —
playback is just another proposer, indistinguishable from a board.  The
GUI needs no changes; it observes confirmed moves as always.  Raw
verbatim bus replay is a different job and already exists as
`python3 -m umm.tools.send --replay`.  Because playback only reads the
records, it needs no python-chess.

Run:
    python3 -m examples.chess.playback --file game.json
        [--speed N] [--interval SECS] [--max-gap SECS]
        [--game N] [--loop] [--hold] [--router HOST] [--port N]

Pacing (per move, in this precedence):
    --interval S   fixed S seconds between moves (ignores recorded gaps)
    --speed N      recorded gap ÷ N (default 1.0 = the pace it was played)
    --max-gap S    cap on the resulting wait — tames long thinking pauses
Speed and interval are also changeable at runtime (PlaybackSpeed).

Runtime control (MT_CHESS_PLAYBACK = 2003):
    (2003,100) PlaybackLoad     Char(path, meta=recording-path) [Int(game)]
    (2003,101) PlaybackPlay     start / resume; from DONE restarts
    (2003,102) PlaybackPause
    (2003,103) PlaybackStep     one move while paused / ready
    (2003,104) PlaybackSpeed    Float(meta=speed) and/or Float(meta=seconds)
                                (seconds = fixed interval; 0 clears it)
    (2003,105) PlaybackRestart  rewind to move 0
    (2003,106) PlaybackStatus   Char(json) announcement (out)

Threading: message callbacks run on the agent's event loop and must stay
fast, so they only flip flags and poke the worker (the engine-agent
pattern).  The worker thread does all waiting and sending.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Optional

if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

from umm.agent import UMMAgent
from umm.core.registry import registry
from umm.core.messages import DEFAULT_PORT, Channel
from umm.core.meta import CHAR_META_JSON
from umm.core.tlv import decode_all
from umm.types.builtin import BUILTIN_TYPES
from umm.capability import register_capability_handler

for _cls in BUILTIN_TYPES:
    registry.register_class(_cls)

from examples.chess.capabilities import (
    MT_CHESS_GAME, MT_CHESS_PLAYBACK,
    ST_BOARD_STATE, ST_MOVE_PROPOSED, ST_MOVE_CONFIRMED, ST_MOVE_REJECTED,
    ST_NEW_GAME, ST_RESIGN, ST_DRAW_ACCEPT, ST_GAME_OVER, ST_SETUP_REJECTED,
    ST_PB_LOAD, ST_PB_PLAY, ST_PB_PAUSE, ST_PB_STEP, ST_PB_SPEED,
    ST_PB_RESTART, ST_PB_STATUS,
    META_FEN, META_UCI, META_SAN, META_RESULT, META_REASON,
    META_GAME_ID, META_COLOUR, META_MOVE_NO,
    META_SECONDS, META_SPEED, META_REC_PATH,
    WHITE, BLACK,
    PLAYBACK_CAPABILITY, register_chess_metas,
)
from examples.chess.tlvutil import tlv_fields, get_char, get_int, get_float

log = logging.getLogger('chess.playback')

_char  = registry.get_by_name('Char')
_int   = registry.get_by_name('Int')

STANDARD_START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'


# ── recording model ────────────────────────────────────────────────────────────

class Move:
    __slots__ = ('ts', 'uci', 'colour', 'san', 'move_no')

    def __init__(self, ts, uci, colour, san, move_no):
        self.ts, self.uci, self.colour = ts, uci, colour
        self.san, self.move_no = san, move_no


class Ending:
    """A game end that is an *input* event, so must itself be replayed
    (moves end the game by themselves; resignation and agreed draws don't)."""
    __slots__ = ('ts', 'kind', 'colour')      # kind: 'resign' | 'draw'

    def __init__(self, ts, kind, colour):
        self.ts, self.kind, self.colour = ts, kind, colour


def _decode_record_tlvs(tlvs_hex: str):
    """hex payload → the (keyed, ordered) shape tlvutil's getters expect."""
    keyed, ordered = {}, []
    if not tlvs_hex:
        return keyed, ordered
    for t in decode_all(bytes.fromhex(tlvs_hex)):
        h = registry.get_by_id(t.type_id)
        if not h:
            continue
        try:
            v = h.unpack(t.value)
        except Exception:
            continue
        ordered.append((t.type_id, t.meta, v))
        if t.meta:
            keyed[(t.type_id, t.meta)] = v
    return keyed, ordered


class GameRecording:
    """
    The story of one game, extracted from a parser --record file.

    start_fen  : str | None      None = standard start
    moves      : list[Move]      the MoveConfirmed sequence, recording order
    ending     : Ending | None   resignation / agreed draw to replay
    result     : (result, reason) from GameOver, informational
    games_seen : sorted list of every game_id in the file
    """

    def __init__(self, path: str, game_id: int):
        self.path       = path
        self.game_id    = game_id
        self.start_fen: Optional[str] = None
        self.moves:     list[Move]    = []
        self.ending:    Optional[Ending] = None
        self.result:    Optional[tuple]  = None
        self.games_seen: list[int]    = []

    @classmethod
    def load(cls, path: str, game_id: Optional[int] = None) -> 'GameRecording':
        """Parse the file; raises ValueError with a human message on trouble."""
        p = Path(path)
        if not p.exists():
            raise ValueError(f'recording not found: {path}')

        records = []
        for line in p.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if '_umm_recording' in rec or 'mtype' not in rec:
                continue                     # header / non-message line
            if rec['mtype'] != MT_CHESS_GAME:
                continue                     # rules-svc chatter, system, ...
            records.append(rec)
        if not records:
            raise ValueError(f'no chess-game messages (mtype {MT_CHESS_GAME}) '
                             f'in {path} — was the parser recording channel 1?')

        # Which game ids exist?  (default game_id when the TLV is absent is 1,
        # matching the rules agent's convention.)
        seen: dict[int, int] = {}            # game_id → confirmed-move count
        parsed = []
        for rec in records:
            keyed, ordered = _decode_record_tlvs(rec.get('tlvs_hex', ''))
            gid = get_int(keyed, ordered, META_GAME_ID, 1)
            parsed.append((rec, keyed, ordered, gid))
            seen.setdefault(gid, 0)
            if rec['subtype'] == ST_MOVE_CONFIRMED:
                seen[gid] += 1

        if game_id is None:
            # Default: the game with moves; ambiguity is an error, not a guess.
            with_moves = [g for g, n in seen.items() if n > 0]
            if len(with_moves) == 1:
                game_id = with_moves[0]
            elif not with_moves:
                raise ValueError(f'no confirmed moves in {path}')
            else:
                raise ValueError(f'{path} contains several games with moves '
                                 f'({sorted(with_moves)}) — choose one with --game')

        out = cls(path, game_id)
        out.games_seen = sorted(seen)

        for rec, keyed, ordered, gid in parsed:
            if gid != game_id:
                continue
            st = rec['subtype']
            ts = rec.get('ts_secs', 0) + rec.get('ts_ms', 0) / 1000.0

            if st == ST_NEW_GAME:
                # A NewGame restarts the story: drop anything before it.
                out.moves.clear()
                out.ending = None
                out.result = None
                out.start_fen = get_char(keyed, ordered, META_FEN)
            elif st == ST_BOARD_STATE and not out.moves:
                # Pre-move authoritative state pins the starting position
                # even when the NewGame itself wasn't captured.
                out.start_fen = get_char(keyed, ordered, META_FEN)
            elif st == ST_MOVE_CONFIRMED:
                uci     = get_char(keyed, ordered, META_UCI)
                san     = keyed.get((8, META_SAN))
                colour  = get_int(keyed, ordered, META_COLOUR, -1)
                move_no = get_int(keyed, ordered, META_MOVE_NO, 0)
                if uci and colour in (WHITE, BLACK):
                    out.moves.append(Move(ts, uci, colour, san, move_no))
            elif st == ST_RESIGN:
                colour = get_int(keyed, ordered, META_COLOUR, -1)
                if colour in (WHITE, BLACK):
                    out.ending = Ending(ts, 'resign', colour)
            elif st == ST_DRAW_ACCEPT:
                colour = get_int(keyed, ordered, META_COLOUR, -1)
                if colour in (WHITE, BLACK):
                    out.ending = Ending(ts, 'draw', colour)
            elif st == ST_GAME_OVER:
                out.result = (keyed.get((8, META_RESULT)),
                              keyed.get((8, META_REASON)))

        if out.start_fen:
            out.start_fen = out.start_fen.strip()
            if out.start_fen == STANDARD_START:
                out.start_fen = None          # standard start needs no FEN TLV
        if not out.moves:
            raise ValueError(f'game {game_id} in {path} has no confirmed moves')
        return out


# ── the agent ──────────────────────────────────────────────────────────────────

# Playback states
NO_FILE, READY, PLAYING, PAUSED, DONE, ERROR = \
    'no-file', 'ready', 'playing', 'paused', 'done', 'error'

FIRST_MOVE_SETTLE = 0.5      # pause between NewGame and the first proposal
CONFIRM_TIMEOUT   = 10.0     # seconds to wait for MoveConfirmed / BoardState


class PlaybackAgent:

    def __init__(self, agent: UMMAgent, game_id_override: Optional[int],
                 speed: float, interval: Optional[float],
                 max_gap: Optional[float], loop: bool) -> None:
        self.agent    = agent
        self.game_arg = game_id_override
        self.speed    = max(speed, 0.01)
        self.interval = interval            # None = use recorded gaps
        self.max_gap  = max_gap             # None = uncapped
        self.loop     = loop

        self.rec: Optional[GameRecording] = None
        self.state    = NO_FILE
        self.error    = None                # human reason when state == ERROR
        self.idx      = 0                   # next move to propose
        self.new_game_sent = False

        self._lock  = threading.RLock()
        self._wake  = threading.Condition(self._lock)
        self._step_pending = False
        self._load_pending: Optional[tuple] = None   # (path, game_id|None)
        self._shutdown = False

        # Set by callbacks; read by the worker between sends.
        self._confirm_evt = threading.Event()
        self._confirm_info = None           # ('confirmed', uci) | ('rejected', reason) | ('state',)

        self._worker = threading.Thread(target=self._run, name='playback',
                                        daemon=True)

    # ── loading ───────────────────────────────────────────────────────────

    def load(self, path: str, game_id: Optional[int]) -> None:
        """Worker-thread context only."""
        try:
            rec = GameRecording.load(path, game_id)
        except ValueError as e:
            with self._lock:
                self.rec, self.state, self.error = None, ERROR, str(e)
            log.error('%s', e)
            self.publish_status()
            return
        with self._lock:
            self.rec   = rec
            self.state = READY
            self.error = None
            self.idx   = 0
            self.new_game_sent = False
        log.info('loaded %s: game %d, %d moves, start=%s, ending=%s '
                 '(games in file: %s)',
                 rec.path, rec.game_id, len(rec.moves),
                 'custom FEN' if rec.start_fen else 'standard',
                 rec.ending.kind if rec.ending else
                 (rec.result[1] if rec.result else 'by move'),
                 rec.games_seen)
        self.publish_status()

    # ── control handlers (event-loop thread: flip flags, poke worker) ─────

    def on_load(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        path = keyed.get((8, META_REC_PATH)) or get_char(keyed, ordered, META_REC_PATH)
        game = get_int(keyed, ordered, META_GAME_ID)
        if not path:
            log.warning('PlaybackLoad without a recording-path Char — ignored')
            return
        with self._wake:
            self._load_pending = (path, game)
            self.state = NO_FILE            # worker reloads before anything else
            self._wake.notify()

    def on_play(self, msg) -> None:
        with self._wake:
            if self.state == DONE:          # Play after the end = watch again
                self.idx, self.new_game_sent = 0, False
            if self.state in (READY, PAUSED, DONE):
                self.state = PLAYING
                self._wake.notify()

    def on_pause(self, msg) -> None:
        with self._wake:
            if self.state == PLAYING:
                self.state = PAUSED
                self._wake.notify()
        self.publish_status()

    def on_step(self, msg) -> None:
        with self._wake:
            if self.state in (READY, PAUSED):
                self.state = PAUSED         # READY + step behaves like paused
                self._step_pending = True
                self._wake.notify()

    def on_speed(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        mult = keyed.get((6, META_SPEED))
        secs = keyed.get((6, META_SECONDS))
        with self._wake:
            if mult is not None and mult > 0:
                self.speed = mult
            if secs is not None:
                self.interval = secs if secs > 0 else None
            self._wake.notify()             # re-time any wait in progress
        log.info('pacing: speed=%.2fx interval=%s', self.speed, self.interval)
        self.publish_status()

    def on_restart(self, msg) -> None:
        with self._wake:
            if self.rec:
                self.idx, self.new_game_sent = 0, False
                self.state = READY
                self._step_pending = False
                self._wake.notify()
        self.publish_status()

    # ── game-channel handlers ─────────────────────────────────────────────

    def on_move_confirmed(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        if self.rec and get_int(keyed, ordered, META_GAME_ID, 1) != self.rec.game_id:
            return
        self._confirm_info = ('confirmed', get_char(keyed, ordered, META_UCI))
        self._confirm_evt.set()

    def on_move_rejected(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        if self.rec and get_int(keyed, ordered, META_GAME_ID, 1) != self.rec.game_id:
            return
        self._confirm_info = ('rejected',
                              get_char(keyed, ordered, META_REASON) or 'rejected')
        self._confirm_evt.set()

    def on_board_state(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        if self.rec and get_int(keyed, ordered, META_GAME_ID, 1) != self.rec.game_id:
            return
        self._confirm_info = ('state',)
        self._confirm_evt.set()

    def on_setup_rejected(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        if self.rec and get_int(keyed, ordered, META_GAME_ID, 1) != self.rec.game_id:
            return
        self._confirm_info = ('rejected',
                              get_char(keyed, ordered, META_REASON) or 'setup rejected')
        self._confirm_evt.set()

    # ── status ────────────────────────────────────────────────────────────

    def publish_status(self) -> None:
        with self._lock:
            info = {'state': self.state,
                    'file':  self.rec.path if self.rec else None,
                    'game':  self.rec.game_id if self.rec else None,
                    'move':  self.idx,
                    'total': len(self.rec.moves) if self.rec else 0,
                    'speed': self.speed,
                    'interval': self.interval,
                    'loop':  self.loop}
            if self.rec and 0 < self.idx <= len(self.rec.moves):
                info['last'] = self.rec.moves[self.idx - 1].san
            if self.error:
                info['error'] = self.error
            if self.state == DONE and self.rec and self.rec.result:
                info['result'], info['reason'] = self.rec.result
        try:
            self.agent.send(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_STATUS,
                            channel=int(Channel.APP),
                            tlvs=[_char.make_tlv(json.dumps(info),
                                                 meta=CHAR_META_JSON)])
        except Exception:
            log.error('status publish failed:\n%s', traceback.format_exc())

    # ── pacing ────────────────────────────────────────────────────────────

    def _gap_before(self, idx: int) -> float:
        """Seconds to wait before proposing move idx, at current settings.
        Reads self.speed/self.interval live so runtime changes re-time an
        in-progress wait (the worker recomputes every poll tick)."""
        if self.interval is not None:
            gap = self.interval
        elif idx == 0:
            gap = FIRST_MOVE_SETTLE
        else:
            recorded = self.rec.moves[idx].ts - self.rec.moves[idx - 1].ts
            gap = max(recorded, 0.0) / self.speed
        if self.max_gap is not None:
            gap = min(gap, self.max_gap)
        return gap

    def _ending_gap(self) -> float:
        if self.interval is not None:
            gap = self.interval
        else:
            e, last = self.rec.ending, self.rec.moves[-1]
            gap = max(e.ts - last.ts, 0.0) / self.speed
        if self.max_gap is not None:
            gap = min(gap, self.max_gap)
        return gap

    def _wait_gap(self, gap_fn) -> str:
        """Wait out a pacing gap; responsive to pause/speed/step/shutdown.
        Returns 'go' | 'interrupted' (state changed away from PLAYING/step)."""
        elapsed = 0.0
        mark = time.monotonic()
        while True:
            with self._wake:
                if self._shutdown or self._load_pending:
                    return 'interrupted'
                if self._step_pending:      # step fires immediately
                    return 'go'
                if self.state != PLAYING:
                    return 'interrupted'
                remaining = gap_fn() - elapsed
                if remaining <= 0:
                    return 'go'
                self._wake.wait(min(remaining, 0.25))
            now = time.monotonic()
            elapsed += now - mark           # only accumulates while PLAYING
            mark = now

    # ── the worker ────────────────────────────────────────────────────────

    def start(self, initial: Optional[tuple], autoplay: bool) -> None:
        self._initial  = initial            # (path, game) from the CLI
        self._autoplay = autoplay
        self._worker.start()

    def _run(self) -> None:
        if self._initial:
            self.load(*self._initial)
            if self._autoplay and self.state == READY:
                with self._wake:
                    self.state = PLAYING
        try:
            self._loop_forever()
        except Exception:
            log.error('playback worker died:\n%s', traceback.format_exc())
            with self._lock:
                self.state, self.error = ERROR, 'internal error (see log)'
            self.publish_status()

    def _loop_forever(self) -> None:
        while not self._shutdown:
            # Pending runtime load?
            with self._wake:
                pending, self._load_pending = self._load_pending, None
            if pending:
                self.load(*pending)
                continue

            # Wait for something to do.
            with self._wake:
                if not (self.state == PLAYING or self._step_pending):
                    self._wake.wait(0.25)
                    continue
                stepping = self._step_pending

            # NewGame first (also on replay-after-done / restart).
            if not self.new_game_sent:
                if not self._send_new_game():
                    continue                # went to ERROR

            if self.idx >= len(self.rec.moves):
                self._finish(stepping)
                continue

            if not stepping:
                if self._wait_gap(lambda: self._gap_before(self.idx)) != 'go':
                    continue                # paused / re-load / shutdown
            with self._wake:
                stepping = self._step_pending
                self._step_pending = False

            if not self._propose(self.rec.moves[self.idx]):
                continue                    # rejected / timed out → ERROR
            with self._lock:
                self.idx += 1
            self.publish_status()

            if self.idx >= len(self.rec.moves):
                self._finish(stepping)

    def _send_new_game(self) -> bool:
        tlvs = [_int.make_tlv(self.rec.game_id, meta=META_GAME_ID)]
        if self.rec.start_fen:
            tlvs.append(_char.make_tlv(self.rec.start_fen, meta=META_FEN))
        self._confirm_evt.clear()
        self._confirm_info = None
        self.agent.send(mtype=MT_CHESS_GAME, subtype=ST_NEW_GAME,
                        channel=int(Channel.APP), tlvs=tlvs)
        log.info('game %d: NewGame sent (%s)', self.rec.game_id,
                 self.rec.start_fen or 'standard start')
        # The rules agent answers with BoardState (or SetupRejected).
        if not self._confirm_evt.wait(CONFIRM_TIMEOUT):
            return self._fail('no BoardState after NewGame — '
                              'is the rules agent running?')
        if self._confirm_info and self._confirm_info[0] == 'rejected':
            return self._fail(f'NewGame rejected: {self._confirm_info[1]}')
        with self._lock:
            self.new_game_sent = True
        self.publish_status()
        return True

    def _propose(self, mv: Move) -> bool:
        self._confirm_evt.clear()
        self._confirm_info = None
        self.agent.send(mtype=MT_CHESS_GAME, subtype=ST_MOVE_PROPOSED,
                        channel=int(Channel.APP),
                        tlvs=[_char.make_tlv(mv.uci, meta=META_UCI),
                              _int.make_tlv(mv.colour, meta=META_COLOUR),
                              _int.make_tlv(self.rec.game_id, meta=META_GAME_ID)])
        deadline = time.monotonic() + CONFIRM_TIMEOUT
        while time.monotonic() < deadline:
            if not self._confirm_evt.wait(0.25):
                continue
            info = self._confirm_info
            self._confirm_evt.clear()
            if info is None:
                continue
            if info[0] == 'confirmed':
                if info[1] == mv.uci:
                    log.info('game %d: %d%s %s',
                             self.rec.game_id, mv.move_no,
                             '.' if mv.colour == WHITE else '...',
                             mv.san or mv.uci)
                    return True
                continue                    # someone else's move — keep waiting
            if info[0] == 'rejected':
                return self._fail(f'move {mv.uci} rejected: {info[1]} — '
                                  'recording out of sync with the game')
            # ('state',) — a BoardState mid-game; ignore and keep waiting
        return self._fail(f'no confirmation for {mv.uci} — '
                          'is the rules agent running?')

    def _finish(self, stepping: bool) -> None:
        rec = self.rec
        if rec.ending:
            if not stepping:
                if self._wait_gap(self._ending_gap) != 'go':
                    return
            with self._wake:
                self._step_pending = False
            if rec.ending.kind == 'resign':
                st, what = ST_RESIGN, 'resignation'
            else:
                st, what = ST_DRAW_ACCEPT, 'agreed draw'
            self.agent.send(mtype=MT_CHESS_GAME, subtype=st,
                            channel=int(Channel.APP),
                            tlvs=[_int.make_tlv(rec.ending.colour, meta=META_COLOUR),
                                  _int.make_tlv(rec.game_id, meta=META_GAME_ID)])
            log.info('game %d: replayed %s', rec.game_id, what)
        with self._wake:
            if self.loop:
                self.idx, self.new_game_sent = 0, False
                self.state = PLAYING        # straight around again
            else:
                self.state = DONE
                self._step_pending = False
        log.info('game %d: playback %s', rec.game_id,
                 'looping' if self.loop else 'done')
        self.publish_status()

    def _fail(self, reason: str) -> bool:
        log.error('%s', reason)
        with self._wake:
            self.state, self.error = ERROR, reason
            self._step_pending = False
        self.publish_status()
        return False


# ── guard (rules-agent convention) ─────────────────────────────────────────────

def _guard(fn):
    def wrapped(msg):
        try:
            fn(msg)
        except Exception:
            log.error('handler %s failed:\n%s', fn.__name__, traceback.format_exc())
    return wrapped


# ── wiring ─────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description='UMM Chess Playback Agent')
    p.add_argument('--file',     default=None, metavar='REC',
                   help='parser --record JSON-lines file to play')
    p.add_argument('--game',     type=int, default=None,
                   help='game_id within the recording (needed only when '
                        'the file contains several games)')
    p.add_argument('--speed',    type=float, default=1.0, metavar='N',
                   help='speed multiplier on recorded gaps '
                        '(1.0 = as played, 2.0 = twice as fast; default 1.0)')
    p.add_argument('--interval', type=float, default=None, metavar='SECS',
                   help='fixed seconds between moves — overrides recorded gaps')
    p.add_argument('--max-gap',  type=float, default=None, metavar='SECS',
                   help='cap any single wait at SECS (tames thinking pauses)')
    p.add_argument('--loop',     action='store_true',
                   help='restart from move 0 when the game ends')
    p.add_argument('--hold',     action='store_true',
                   help='load but wait for a PlaybackPlay message '
                        '(default: start playing immediately)')
    p.add_argument('--router',   default='localhost')
    p.add_argument('--port',     type=int, default=DEFAULT_PORT)
    p.add_argument('--name',     default='ChessPlayback',
                   help='Agent name shown in GUI and parser (passed by umm_ctl)')
    p.add_argument('--type',     type=int, default=MT_CHESS_PLAYBACK,
                   help='Agent mtype override (passed by umm_ctl)')
    p.add_argument('--debug',    action='store_true')
    args = p.parse_args()

    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        stream=sys.stdout,
                        format='%(asctime)s %(name)s %(levelname)s %(message)s')
    register_chess_metas()

    agent = UMMAgent(host=args.router, port=args.port,
                     process_name=args.name, agent_mtype=args.type)
    agent.connect()
    register_capability_handler(agent, PLAYBACK_CAPABILITY)

    pb = PlaybackAgent(agent, args.game, speed=args.speed,
                       interval=args.interval, max_gap=args.max_gap,
                       loop=args.loop)

    ch_app = int(Channel.APP)
    agent.register(mtype=MT_CHESS_GAME, subtype=ST_MOVE_CONFIRMED,
                   callback=_guard(pb.on_move_confirmed), channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME, subtype=ST_MOVE_REJECTED,
                   callback=_guard(pb.on_move_rejected),  channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME, subtype=ST_BOARD_STATE,
                   callback=_guard(pb.on_board_state),    channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME, subtype=ST_SETUP_REJECTED,
                   callback=_guard(pb.on_setup_rejected), channel=ch_app)
    agent.register(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_LOAD,
                   callback=_guard(pb.on_load),    channel=ch_app)
    agent.register(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_PLAY,
                   callback=_guard(pb.on_play),    channel=ch_app)
    agent.register(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_PAUSE,
                   callback=_guard(pb.on_pause),   channel=ch_app)
    agent.register(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_STEP,
                   callback=_guard(pb.on_step),    channel=ch_app)
    agent.register(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_SPEED,
                   callback=_guard(pb.on_speed),   channel=ch_app)
    agent.register(mtype=MT_CHESS_PLAYBACK, subtype=ST_PB_RESTART,
                   callback=_guard(pb.on_restart), channel=ch_app)

    pb.start(initial=(args.file, args.game) if args.file else None,
             autoplay=not args.hold)
    pb.publish_status()

    log.info('ChessPlayback agent running (control mtype %d; %s)',
             MT_CHESS_PLAYBACK,
             f'file={args.file}' if args.file else 'no file — send PlaybackLoad')
    try:
        agent.run()
    except KeyboardInterrupt:
        pass
    finally:
        pb._shutdown = True


if __name__ == '__main__':
    main()
