"""
examples/chess/tlvutil.py
=========================
Shared TLV decode helpers for the chess agents (rules, engine, playback).

Meta-keyed access first, positional fallback — the same convention the
rest of the demo uses.
"""

from umm.core.registry import registry


def tlv_fields(msg):
    """Decode a message's TLVs into ({(type_id, meta): value}, [ordered])."""
    from umm.core.tlv import decode_all
    keyed, ordered = {}, []
    if msg.tdata.value:
        for t in decode_all(msg.tdata.value):
            h = registry.get_by_id(t.type_id)
            if not h:
                continue
            try:
                v = h.unpack(t.value)
            except Exception:
                continue
            ordered.append((t.type_id, t.meta, v))
            if t.meta:
                keyed[(t.type_id, t.meta)] = v
    return keyed, ordered


def get_char(keyed, ordered, meta):
    if (8, meta) in keyed:
        return keyed[(8, meta)]
    for tid, m, v in ordered:            # positional fallback: first untagged Char
        if tid == 8 and m == 0:
            return v
    return None


def get_int(keyed, ordered, meta, default=None):
    if (2, meta) in keyed:
        return keyed[(2, meta)]
    return default


def get_float(keyed, ordered, meta, default=None):
    if (6, meta) in keyed:
        return keyed[(6, meta)]
    for tid, m, v in ordered:
        if tid == 6 and m == 0:
            return v
    return default
