"""
examples/chess/capabilities.py
==============================
Constants, meta registrations, and capability declarations for the UMM
chess demo.  See chess_protocol_spec.md for the full protocol.

mtype allocation (2000 block; sorting owns 1001-1007, tank owns 5000-5001):
    2000  MT_CHESS_GAME      game channel — moves, state, results
    2001  MT_CHESS_RULES     legal-move request/response service
    2002  MT_CHESS_ENGINE    engine control
    2003  MT_CHESS_PLAYBACK  playback control

Channel assignment — the two axes are independent (mtype = addressing,
channel = traffic class):
    MT_CHESS_GAME traffic          → Channel.APP (1)
    MT_CHESS_RULES traffic         → CHESS_SVC_CHANNEL (11)
    engine / playback control      → Channel.APP (1)
"""

from umm.capability import make_capability, SubtypeSpec, TLVSpec
from umm.core.meta import meta_registry

# ── mtype constants ───────────────────────────────────────────────────────────

MT_CHESS_GAME     = 2000
MT_CHESS_RULES    = 2001
MT_CHESS_ENGINE   = 2002
MT_CHESS_PLAYBACK = 2003

# ── channel ───────────────────────────────────────────────────────────────────

# Legal-move queries are UI plumbing (a player may lift and replace several
# pieces per move); they travel on a user channel so `parser --channel 1`
# shows exactly the story of the game.  Same reasoning as the sorting demo's
# PULSE_CHANNEL = 127.
CHESS_SVC_CHANNEL = 11

# ── game channel subtypes (MT_CHESS_GAME) ─────────────────────────────────────

ST_BOARD_STATE    = 100  # R→*  authoritative position:      Char(fen) Int(game) Int(status)
ST_STATE_REQ      = 101  # *→R  request a BOARD_STATE:        Int(game)
ST_MOVE_PROPOSED  = 102  # B,E,P→R  proposed move:            Char(uci) Int(colour) Int(game)
ST_MOVE_CONFIRMED = 103  # R→*  validated move:               Char(uci) Char(san) Char(fen')
                         #                                    Int(colour) Int(status) Int(move_no) Int(game)
ST_MOVE_REJECTED  = 104  # R→*  illegal proposal:             Char(uci) Char(reason) Int(colour) Int(game)
ST_NEW_GAME       = 105  # *→R  start a game:                 Int(game) [Char(fen) — absent = standard start]
ST_RESIGN         = 106  # B→R  resignation:                  Int(colour) Int(game)
ST_DRAW_OFFER     = 107  # B→*  draw offered:                 Int(colour) Int(game)
ST_DRAW_ACCEPT    = 108  # B→R  draw accepted:                Int(colour) Int(game)
ST_GAME_OVER      = 109  # R→*  result:                       Char(result) Char(reason) Char(fen) Int(game)
ST_SETUP_REJECTED = 110  # R→*  invalid NEW_GAME position:    Char(fen) Char(reason) Int(game)

# ── rules service subtypes (MT_CHESS_RULES, channel CHESS_SVC_CHANNEL) ────────

ST_LEGAL_REQ      = 100  # B→R  legal moves [for one square]: [Int(square)] Int(game)
ST_LEGAL_RESP     = 101  # R→B  json array of UCI strings:    Char(json) [Int(square)] Int(game)

# ── playback control subtypes (MT_CHESS_PLAYBACK) ─────────────────────────────

ST_PB_LOAD    = 100  # *→P  load a parser recording:  Char(path) [Int(game)]
ST_PB_PLAY    = 101  # *→P  start / resume (from DONE: restart)
ST_PB_PAUSE   = 102  # *→P  pause between moves
ST_PB_STEP    = 103  # *→P  play exactly one move (while paused / ready)
ST_PB_SPEED   = 104  # *→P  Float(multiplier, meta=speed) | Float(secs, meta=seconds)
ST_PB_RESTART = 105  # *→P  rewind to move 0 (state → READY)
ST_PB_STATUS  = 106  # P→*  Char(json, CHAR_META_JSON): state/file/move/total/speed

# ── engine control subtypes (MT_CHESS_ENGINE) ─────────────────────────────────

ST_ENG_CONFIG     = 100  # *→E  Int(colour) [Float(seconds)] [Char(backend)]
ST_ENG_GO         = 101  # *→E  Int(game) — start participating
ST_ENG_STOP       = 102  # *→E  Int(game) — stop (abandon any search)
ST_ENG_STATUS     = 103  # E→*  Char(json, CHAR_META_JSON): backend/colour/active/state

# ── meta assignments (application range 1000+; see umm/core/meta.py) ──────────

# Char (type_id 8)
META_FEN      = 1000  # complete position, FEN string
META_UCI      = 1001  # a move in UCI notation (e2e4, e7e8q)
META_SAN      = 1002  # the same move in SAN (Nf3) — display convenience
META_RESULT   = 1003  # game result string: 1-0, 0-1, 1/2-1/2
META_REASON   = 1004  # human-readable reason (rejection / game end)
META_PGN_PATH = 1005  # filename of a PGN file (playback)
META_BACKEND  = 1006  # engine backend name (minimax, uci, ...)
META_REC_PATH = 1007  # filename of a parser --record JSON-lines file (playback)

# Int (type_id 2)
META_GAME_ID  = 1000  # game instance id (default 1)
META_COLOUR   = 1001  # 0 = white, 1 = black
META_GSTATUS  = 1002  # game status enum below
META_SQUARE   = 1003  # square index 0-63 (a1=0 ... h8=63)
META_MOVE_NO  = 1004  # full-move number

# Float (type_id 6)
META_SECONDS  = 1000  # a duration in seconds (engine time per move / playback interval)
META_SPEED    = 1001  # playback speed multiplier (1.0 = recorded pace)

# ── game status enum (META_GSTATUS values) ────────────────────────────────────

GS_IN_PROGRESS = 0
GS_CHECK       = 1   # in progress, side to move is in check
GS_CHECKMATE   = 2   # mover wins
GS_STALEMATE   = 3
GS_DRAW_AUTO   = 4   # insufficient material / 75-move / fivefold
GS_DRAW_AGREED = 5
GS_RESIGNATION = 6

WHITE = 0
BLACK = 1

_CHAR  = 8
_INT   = 2
_FLOAT = 6


def register_chess_metas() -> None:
    """Register the chess meta names so parsers/GUIs display them readably."""
    for meta, name in ((META_FEN, 'fen'), (META_UCI, 'uci-move'),
                       (META_SAN, 'san-move'), (META_RESULT, 'result'),
                       (META_REASON, 'reason'), (META_PGN_PATH, 'pgn-path'),
                       (META_BACKEND, 'backend'), (META_REC_PATH, 'recording-path')):
        meta_registry.register(_CHAR, meta, name)
    for meta, name in ((META_GAME_ID, 'game-id'), (META_COLOUR, 'colour'),
                       (META_GSTATUS, 'game-status'), (META_SQUARE, 'square'),
                       (META_MOVE_NO, 'move-number')):
        meta_registry.register(_INT, meta, name)
    meta_registry.register(_FLOAT, META_SECONDS, 'seconds')
    meta_registry.register(_FLOAT, META_SPEED, 'speed')


# ── capability declarations ───────────────────────────────────────────────────

RULES_CAPABILITY = make_capability(
    what        = 'ChessGame',      # names the protocol (mtype 2000), not the
                                    # agent — parser default display derives
                                    # from this when chess.conf is not loaded
    mtype       = MT_CHESS_GAME,
    description = 'Single authority on chess legality and game state '
                  '(python-chess).  Validates proposed moves, publishes the '
                  'authoritative board state as FEN, and answers legal-move '
                  'queries on the service channel (11).  Every message '
                  'carries Int(game_id, meta=game-id).',
    subtypes    = [
        SubtypeSpec(subtype=ST_BOARD_STATE, name='BoardState', direction='out',
                    description='Authoritative game state.',
                    output_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='FEN (meta=fen).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='game_id (meta=game-id).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='status enum (meta=game-status).'),
                    ]),
        SubtypeSpec(subtype=ST_STATE_REQ, name='StateRequest', direction='in',
                    description='Ask for a BoardState broadcast.',
                    input_tlvs=[TLVSpec(type_id=_INT, name='Int', required=False,
                                        description='game_id (meta=game-id).')]),
        SubtypeSpec(subtype=ST_MOVE_PROPOSED, name='MoveProposed', direction='in',
                    description='A player (board, engine, or playback) proposes a move.',
                    input_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='UCI move (meta=uci-move).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='colour 0=white 1=black (meta=colour).'),
                        TLVSpec(type_id=_INT, name='Int', required=False,
                                description='game_id (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_MOVE_CONFIRMED, name='MoveConfirmed', direction='out',
                    description='The single source of truth: a validated move. '
                                'Everything downstream subscribes to this.',
                    output_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='UCI move (meta=uci-move).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='SAN move (meta=san-move).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='FEN after the move (meta=fen).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='colour that moved (meta=colour).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='status enum (meta=game-status).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='full-move number (meta=move-number).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='game_id (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_MOVE_REJECTED, name='MoveRejected', direction='out',
                    description='An illegal or out-of-turn proposal.',
                    output_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='UCI move as proposed (meta=uci-move).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='reason (meta=reason).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='colour (meta=colour).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='game_id (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_NEW_GAME, name='NewGame', direction='in',
                    description='Start a game. Optional FEN for puzzles / '
                                'adjourned games / Setup-mode positions; '
                                'absent = standard start.',
                    input_tlvs=[
                        TLVSpec(type_id=_INT, name='Int', required=False,
                                description='game_id (meta=game-id).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=False,
                                description='starting FEN (meta=fen).'),
                    ]),
        SubtypeSpec(subtype=ST_RESIGN, name='Resign', direction='in',
                    description='A player resigns.',
                    input_tlvs=[
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='resigning colour (meta=colour).'),
                        TLVSpec(type_id=_INT, name='Int', required=False,
                                description='game_id (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_DRAW_ACCEPT, name='DrawAccept', direction='in',
                    description='Draw agreed (in response to a DrawOffer).',
                    input_tlvs=[
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='accepting colour (meta=colour).'),
                        TLVSpec(type_id=_INT, name='Int', required=False,
                                description='game_id (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_GAME_OVER, name='GameOver', direction='out',
                    description='Game finished.',
                    output_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='result 1-0 / 0-1 / 1/2-1/2 (meta=result).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='reason (meta=reason).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='final FEN (meta=fen).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='game_id (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_SETUP_REJECTED, name='SetupRejected', direction='out',
                    description='A NewGame position failed validation.',
                    output_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='offending FEN echoed (meta=fen).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='reason (meta=reason).'),
                        TLVSpec(type_id=_INT, name='Int', required=True,
                                description='game_id (meta=game-id).'),
                    ]),
    ])


ENGINE_CAPABILITY = make_capability(
    what        = 'ChessEngine',
    mtype       = MT_CHESS_ENGINE,
    description = 'A machine player. Subscribes to confirmed moves and board '
                  'states; when the FEN side-to-move equals its configured '
                  'colour it searches and publishes MoveProposed on the game '
                  'channel — indistinguishable from a board. Pluggable '
                  'backends (bundled minimax; UCI engines such as Stockfish).',
    subtypes    = [
        SubtypeSpec(subtype=ST_ENG_CONFIG, name='EngineConfig', direction='in',
                    description='Runtime reconfiguration.',
                    input_tlvs=[
                        TLVSpec(type_id=_INT, name='Int', required=False,
                                description='colour 0=white 1=black 2=both (meta=colour).'),
                        TLVSpec(type_id=_FLOAT, name='Float', required=False,
                                description='seconds per move (meta=seconds).'),
                        TLVSpec(type_id=_CHAR, name='Char', required=False,
                                description='backend name (meta=backend).'),
                    ]),
        SubtypeSpec(subtype=ST_ENG_GO, name='EngineGo', direction='in',
                    description='Start participating in the game.',
                    input_tlvs=[TLVSpec(type_id=_INT, name='Int', required=False,
                                        description='game_id (meta=game-id).')]),
        SubtypeSpec(subtype=ST_ENG_STOP, name='EngineStop', direction='in',
                    description='Stop participating; abandon any search.',
                    input_tlvs=[TLVSpec(type_id=_INT, name='Int', required=False,
                                        description='game_id (meta=game-id).')]),
        SubtypeSpec(subtype=ST_ENG_STATUS, name='EngineStatus', direction='out',
                    description='Engine state announcement.',
                    output_tlvs=[TLVSpec(type_id=_CHAR, name='Char', required=True,
                                         description='json: backend/colour/active/state (meta=json).')]),
    ])


PLAYBACK_CAPABILITY = make_capability(
    what        = 'ChessPlayback',
    mtype       = MT_CHESS_PLAYBACK,
    description = 'Replays a recorded game (parser --record JSON-lines file) '
                  'through the rules agent: NewGame then paced MoveProposed '
                  'messages, waiting for each MoveConfirmed — so every board '
                  'and observer animates exactly as it would live. Speed is '
                  'controllable at start-up and at runtime.',
    subtypes    = [
        SubtypeSpec(subtype=ST_PB_LOAD, name='PlaybackLoad', direction='in',
                    description='Load (or reload) a recording file.',
                    input_tlvs=[
                        TLVSpec(type_id=_CHAR, name='Char', required=True,
                                description='recording path (meta=recording-path).'),
                        TLVSpec(type_id=_INT, name='Int', required=False,
                                description='game_id within the recording (meta=game-id).'),
                    ]),
        SubtypeSpec(subtype=ST_PB_PLAY, name='PlaybackPlay', direction='in',
                    description='Start or resume playback; from DONE, restarts.'),
        SubtypeSpec(subtype=ST_PB_PAUSE, name='PlaybackPause', direction='in',
                    description='Pause between moves.'),
        SubtypeSpec(subtype=ST_PB_STEP, name='PlaybackStep', direction='in',
                    description='Play exactly one move while paused or ready.'),
        SubtypeSpec(subtype=ST_PB_SPEED, name='PlaybackSpeed', direction='in',
                    description='Change pacing at runtime.',
                    input_tlvs=[
                        TLVSpec(type_id=_FLOAT, name='Float', required=False,
                                description='speed multiplier on recorded gaps (meta=speed).'),
                        TLVSpec(type_id=_FLOAT, name='Float', required=False,
                                description='fixed seconds per move; overrides '
                                            'recorded gaps, 0 clears (meta=seconds).'),
                    ]),
        SubtypeSpec(subtype=ST_PB_RESTART, name='PlaybackRestart', direction='in',
                    description='Rewind to move 0 (state → READY; Play to run).'),
        SubtypeSpec(subtype=ST_PB_STATUS, name='PlaybackStatus', direction='out',
                    description='State announcement on every change and move.',
                    output_tlvs=[TLVSpec(type_id=_CHAR, name='Char', required=True,
                                         description='json: state/file/game/move/'
                                                     'total/speed/interval/last (meta=json).')]),
    ])
