"""
examples/chess/engines/uci_backend.py
=====================================
Backend adapter for any UCI engine (Stockfish, lc0, ...) via
python-chess's engine module. The engine binary is an external install —
nothing GPL is vendored (see spec §8 licensing note).

    choose(board, movetime) -> chess.Move

Set the binary with UCIBackend(path); engine_agent constructs this when
--backend uci --uci-path /path/to/stockfish is given.
"""

from __future__ import annotations

import atexit
import logging

import chess
import chess.engine

NAME = 'uci'
log = logging.getLogger('chess.engine.uci')


class UCIBackend:
    def __init__(self, path: str) -> None:
        self.path = path
        self._engine = chess.engine.SimpleEngine.popen_uci(path)
        atexit.register(self.close)
        log.info('UCI engine started: %s', path)

    def choose(self, board: chess.Board, movetime: float = 1.0) -> chess.Move:
        result = self._engine.play(board, chess.engine.Limit(time=movetime))
        if result.move is None:
            raise ValueError('UCI engine returned no move')
        return result.move

    def close(self) -> None:
        try:
            self._engine.quit()
        except Exception:
            pass
