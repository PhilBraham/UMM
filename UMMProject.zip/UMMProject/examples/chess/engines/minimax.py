"""
examples/chess/engines/minimax.py
=================================
Bundled fallback engine — original code, no external engine required.

Iterative-deepening alpha-beta over python-chess move generation, with a
material + small piece-square evaluation. Deliberately simple: the point
of the demo is the messaging architecture, not playing strength — but it
finds mates, takes hanging pieces, and does not hang its own queen at
depth ≥ 3.

Backend contract (see engine_agent.py):
    choose(board: chess.Board, movetime: float) -> chess.Move
"""

from __future__ import annotations

import random
import time

import chess

NAME = 'minimax'

# ── evaluation ─────────────────────────────────────────────────────────────────

PIECE_VALUE = { chess.PAWN: 100, chess.KNIGHT: 320, chess.BISHOP: 330,
                chess.ROOK: 500, chess.QUEEN: 900, chess.KING: 0 }

# Tiny piece-square nudges (white's view, a1 = index 0). Enough to prefer
# the centre and castled-ish kings without pretending to be a real engine.
_PAWN_PST = [
      0,  0,  0,  0,  0,  0,  0,  0,
      5, 10, 10,-20,-20, 10, 10,  5,
      5, -5,-10,  0,  0,-10, -5,  5,
      0,  0,  0, 20, 20,  0,  0,  0,
      5,  5, 10, 25, 25, 10,  5,  5,
     10, 10, 20, 30, 30, 20, 10, 10,
     50, 50, 50, 50, 50, 50, 50, 50,
      0,  0,  0,  0,  0,  0,  0,  0 ]
_KNIGHT_PST = [
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50 ]

MATE = 1_000_000

# A small "contempt" for repetition: a draw-by-shuffle scores slightly
# negative for the side to move, so two equal engines look for something
# better instead of dancing knights until the rules agent adjudicates
# fivefold. Stalemate and material draws keep their true score of 0 —
# steering into stalemate when losing is good play.
CONTEMPT = 25

# Root moves within this many centipawns of the best are considered
# equivalent and one is chosen at random — breaks the determinism that
# otherwise makes engine-vs-engine games repeat move for move.
RAND_WINDOW = 15


def evaluate(board: chess.Board) -> int:
    """Static evaluation in centipawns from WHITE's point of view."""
    score = 0
    for sq, piece in board.piece_map().items():
        v = PIECE_VALUE[piece.piece_type]
        if piece.piece_type == chess.PAWN:
            v += _PAWN_PST[sq if piece.color == chess.WHITE
                           else chess.square_mirror(sq)]
        elif piece.piece_type == chess.KNIGHT:
            v += _KNIGHT_PST[sq if piece.color == chess.WHITE
                             else chess.square_mirror(sq)]
        score += v if piece.color == chess.WHITE else -v
    return score


def _ordered_moves(board: chess.Board):
    """Captures first (roughly most-valuable-victim), then the rest."""
    def key(m):
        if board.is_capture(m):
            victim = board.piece_type_at(m.to_square) or chess.PAWN  # e.p.
            return -PIECE_VALUE[victim]
        return 1
    return sorted(board.legal_moves, key=key)


class _Timeout(Exception):
    pass


def _alphabeta(board, depth, alpha, beta, deadline) -> int:
    """Negamax with alpha-beta. Score from the side to move's view."""
    if time.monotonic() > deadline:
        raise _Timeout
    if board.is_checkmate():
        return -MATE - depth        # prefer faster mates
    # Repetition needs the move stack — the engine agent maintains game
    # history on the board precisely so this line can see it.  Twofold
    # within search+history is already heading for the draw: apply contempt.
    if board.is_repetition(2) or board.is_fivefold_repetition() \
            or board.is_seventyfive_moves():
        return -CONTEMPT
    if board.is_stalemate() or board.is_insufficient_material():
        return 0
    if depth == 0:
        s = evaluate(board)
        return s if board.turn == chess.WHITE else -s

    best = -MATE * 2
    for move in _ordered_moves(board):
        board.push(move)
        try:
            score = -_alphabeta(board, depth - 1, -beta, -alpha, deadline)
        finally:
            board.pop()
        if score > best:
            best = score
        if best > alpha:
            alpha = best
        if alpha >= beta:
            break
    return best


def choose(board: chess.Board, movetime: float = 1.0,
           max_depth: int = 4) -> chess.Move:
    """Pick a move: iterative deepening within *movetime* seconds, choosing
    randomly among root moves within RAND_WINDOW of the best."""
    deadline = time.monotonic() + max(0.05, movetime)
    legal = list(board.legal_moves)
    if not legal:
        raise ValueError('no legal moves')
    candidates = [legal[0]]
    try:
        for depth in range(1, max_depth + 1):
            scored = []
            # Root moves are searched with the FULL window: alpha-narrowing
            # at the root returns bounds rather than exact scores, which
            # would pollute the near-equal candidate set. The children still
            # prune normally; the cost is root-only and small.
            for move in _ordered_moves(board):
                board.push(move)
                try:
                    score = -_alphabeta(board, depth - 1,
                                        -MATE * 2, MATE * 2, deadline)
                finally:
                    board.pop()
                scored.append((score, move))
            if scored:
                best = max(s for s, _ in scored)
                # completed depth — keep its near-equal candidate set
                candidates = [m for s, m in scored if s >= best - RAND_WINDOW]
    except _Timeout:
        pass                             # keep the last completed depth's set
    return random.choice(candidates)
