"""
examples/chess/engine_agent.py
==============================
A machine player. Architecturally it is a headless playing board: it
subscribes to the authoritative game stream (BOARD_STATE and
MOVE_CONFIRMED), and when the FEN's side-to-move equals its configured
colour it searches and publishes MOVE_PROPOSED — through the rules agent
like every other proposer. No other component can tell it from a human.

Run (plays black by default so a human takes white in the GUI):
    python3 -m examples.chess.engine_agent [--colour white|black|both]
        [--backend minimax|uci] [--uci-path /path/to/stockfish]
        [--movetime SECONDS] [--depth N] [--game N] [--hold]

--colour both  → the engine answers every position: self-play demo.
--hold         → start passive; send EngineGo (2002,101) to begin.

Runtime control (MT_CHESS_ENGINE = 2002, spec §6.4): EngineConfig
changes colour/movetime/backend, EngineGo/EngineStop toggle
participation, EngineStatus announces state as JSON.

Threading: message callbacks run on the agent's event loop and must stay
fast, so they only record the latest position and poke a worker thread.
The worker searches and sends the proposal. Latest-position-wins: if a
new authoritative position arrives mid-search the result is discarded
(stale-FEN check before sending).

Requires: python-chess (see spec §8.1 for install notes).
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import threading
import traceback

if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

try:
    import chess
except ImportError:
    print("ERROR: python-chess not found.")
    print("       python-chess is a PyPI package, NOT a Homebrew formula —")
    print(f"       install with: {sys.executable} -m pip install python-chess")
    print("       (--break-system-packages on PEP 668 Pythons, or use a venv)")
    sys.exit(1)

from umm.agent import UMMAgent
from umm.core.registry import registry
from umm.core.messages import DEFAULT_PORT, Channel
from umm.core.meta import CHAR_META_JSON
from umm.types.builtin import BUILTIN_TYPES
from umm.capability import register_capability_handler

for _cls in BUILTIN_TYPES:
    registry.register_class(_cls)

from examples.chess.capabilities import (
    MT_CHESS_GAME, MT_CHESS_ENGINE,
    ST_BOARD_STATE, ST_STATE_REQ, ST_MOVE_PROPOSED, ST_MOVE_CONFIRMED,
    ST_MOVE_REJECTED, ST_GAME_OVER,
    ST_ENG_CONFIG, ST_ENG_GO, ST_ENG_STOP, ST_ENG_STATUS,
    META_FEN, META_UCI, META_REASON, META_GAME_ID, META_COLOUR,
    META_GSTATUS, META_BACKEND, META_SECONDS,
    GS_IN_PROGRESS, GS_CHECK, WHITE, BLACK,
    ENGINE_CAPABILITY, register_chess_metas,
)
from examples.chess.tlvutil import tlv_fields, get_char, get_int, get_float
from examples.chess.engines import minimax

BOTH = 2                     # --colour both: answer every position (self-play)
COLOUR_NAME = {WHITE: 'white', BLACK: 'black', BOTH: 'both'}

log = logging.getLogger('chess.engine')

_char = registry.get_by_name('Char')
_int  = registry.get_by_name('Int')


class EngineAgent:

    def __init__(self, agent: UMMAgent, colour: int, backend_name: str,
                 movetime: float, depth: int, game_id: int,
                 uci_path: str | None, active: bool) -> None:
        self.agent    = agent
        self.colour   = colour
        self.movetime = movetime
        self.depth    = depth
        self.game_id  = game_id
        self.uci_path = uci_path
        self.active   = active
        self.backend_name = None
        self._backend_choose = None
        self._set_backend(backend_name)     # sets both fields or raises

        self._lock    = threading.Lock()
        self._wake    = threading.Event()
        self._fen     = None                # latest authoritative position
        self._board   = None                # same position WITH move history
        self._last_proposed = None          # uci of our in-flight proposal
        self._thinking = False
        self._stop    = False
        self._worker  = threading.Thread(target=self._think_loop,
                                         name='engine-search', daemon=True)
        self._worker.start()

    # ── backend selection ──────────────────────────────────────────────────

    def _set_backend(self, name: str) -> None:
        name = (name or '').strip().lower()
        if name == 'minimax':
            depth = self.depth
            self._backend_choose = (
                lambda b, t: minimax.choose(b, movetime=t, max_depth=depth))
        elif name == 'uci':
            if not self.uci_path:
                raise ValueError('backend "uci" needs --uci-path (or a prior '
                                 'config that set it)')
            from examples.chess.engines.uci_backend import UCIBackend
            self._backend_choose = UCIBackend(self.uci_path).choose
        else:
            raise ValueError(f'unknown backend "{name}" (minimax|uci)')
        self.backend_name = name
        log.info('backend: %s', name)

    # ── message handlers (loop thread — record and poke, nothing slow) ──────

    def on_position(self, msg) -> None:
        """BOARD_STATE or MOVE_CONFIRMED: latest position wins."""
        keyed, ordered = tlv_fields(msg)
        if get_int(keyed, ordered, META_GAME_ID, 1) != self.game_id:
            return
        fen    = get_char(keyed, ordered, META_FEN)
        status = get_int(keyed, ordered, META_GSTATUS, GS_IN_PROGRESS)
        uci    = (get_char(keyed, ordered, META_UCI)
                  if msg.subtype == ST_MOVE_CONFIRMED else None)
        if not fen:
            return
        with self._lock:
            self._last_proposed = None       # position advanced; nothing in flight
            if status in (GS_IN_PROGRESS, GS_CHECK):
                self._sync_board(fen, uci)
                self._fen = fen
            else:
                self._fen = None             # terminal — nothing to do
                self._board = None
        self._wake.set()

    def _sync_board(self, fen: str, uci: str | None) -> None:
        """Keep a board WITH MOVE HISTORY (lock held by caller).

        FEN carries no history (spec Appendix A), so a board rebuilt from
        FEN alone cannot see repetitions — which is exactly how two
        deterministic engines dance into a fivefold draw. Each confirmed
        move is pushed onto the running board instead; only a reset (or a
        desync) rebuilds from the FEN.
        """
        if self._board is not None and uci:
            try:
                self._board.push(chess.Move.from_uci(uci))
                if self._board.fen() == fen:
                    return                   # history preserved
            except (ValueError, AssertionError):
                pass
            log.warning('board desync after %s — rebuilding from FEN '
                        '(repetition history lost)', uci)
        try:
            self._board = chess.Board(fen)   # reset / join: fresh history
        except ValueError:
            log.error('unparseable FEN from rules agent: %s', fen)
            self._board = None

    def on_game_over(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        if get_int(keyed, ordered, META_GAME_ID, 1) != self.game_id:
            return
        with self._lock:
            self._fen = None
            self._last_proposed = None
        log.info('game over — idle until next NEW_GAME/BOARD_STATE')

    def on_rejected(self, msg) -> None:
        """Our proposal bounced. With python-chess movegen this should never
        happen; if it does, log loudly and do NOT retry — a retry loop
        against a disagreeing rules agent would flood the bus."""
        keyed, ordered = tlv_fields(msg)
        if get_int(keyed, ordered, META_GAME_ID, 1) != self.game_id:
            return
        uci = get_char(keyed, ordered, META_UCI)
        with self._lock:
            mine = (uci == self._last_proposed)
            if mine:
                self._last_proposed = None
        if mine:
            log.error('proposal %s REJECTED by rules agent (%s) — engine and '
                      'rules disagree on legality; not retrying',
                      uci, get_char(keyed, ordered, META_REASON))

    def on_config(self, msg) -> None:
        keyed, ordered = tlv_fields(msg)
        colour  = get_int(keyed, ordered, META_COLOUR)
        seconds = get_float(keyed, ordered, META_SECONDS)
        backend = get_char(keyed, ordered, META_BACKEND)
        if colour in (WHITE, BLACK, BOTH):
            self.colour = colour
            log.info('config: colour → %s', COLOUR_NAME[colour])
        if seconds and seconds > 0:
            self.movetime = float(seconds)
            log.info('config: movetime → %.2fs', self.movetime)
        if backend:
            try:
                self._set_backend(backend)
            except Exception as e:
                log.error('config: backend change failed: %s', e)
        self.publish_status()
        self._wake.set()                    # colour change may make it our turn

    def on_go(self, msg) -> None:
        self.active = True
        log.info('EngineGo — participating')
        self.publish_status()
        self.request_state()                # re-sync and move if it is our turn

    def on_stop(self, msg) -> None:
        self.active = False
        with self._lock:
            self._fen = None                # abandon any queued position
        log.info('EngineStop — passive')
        self.publish_status()

    # ── outgoing ───────────────────────────────────────────────────────────

    def publish_status(self) -> None:
        payload = json.dumps({'backend': self.backend_name,
                              'colour': COLOUR_NAME[self.colour],
                              'active': self.active,
                              'game': self.game_id,
                              'state': 'thinking' if self._thinking else 'idle'})
        self.agent.send(mtype=MT_CHESS_ENGINE, subtype=ST_ENG_STATUS,
                        channel=int(Channel.APP),
                        tlvs=[_char.make_tlv(payload, meta=CHAR_META_JSON)])

    def request_state(self) -> None:
        self.agent.send(mtype=MT_CHESS_GAME, subtype=ST_STATE_REQ,
                        channel=int(Channel.APP),
                        tlvs=[_int.make_tlv(self.game_id, meta=META_GAME_ID)])

    # ── search worker (own thread — free to block and to call send()) ───────

    def _my_move(self, board: chess.Board) -> bool:
        if self.colour == BOTH:
            return True
        stm = WHITE if board.turn == chess.WHITE else BLACK
        return stm == self.colour

    def _think_loop(self) -> None:
        while not self._stop:
            self._wake.wait()
            self._wake.clear()
            while True:
                with self._lock:
                    fen = self._fen
                    in_flight = self._last_proposed is not None
                    # Copy WITH move history (python-chess copies the move
                    # stack by default) so the search can see repetitions.
                    board = self._board.copy() if self._board is not None else None
                if fen is None or board is None or not self.active or in_flight:
                    break
                if not self._my_move(board):
                    break
                colour_to_move = WHITE if board.turn == chess.WHITE else BLACK
                self._thinking = True
                try:
                    move = self._backend_choose(board, self.movetime)
                except Exception:
                    log.error('search failed:\n%s', traceback.format_exc())
                    self._thinking = False
                    break
                self._thinking = False
                # Stale check: a new position may have arrived mid-search.
                with self._lock:
                    if self._fen != fen:
                        continue            # think again on the fresh position
                    self._last_proposed = move.uci()
                log.info('proposing %s (%s to move, backend %s)',
                         move.uci(), COLOUR_NAME[colour_to_move],
                         self.backend_name)
                self.agent.send(
                    mtype=MT_CHESS_GAME, subtype=ST_MOVE_PROPOSED,
                    channel=int(Channel.APP),
                    tlvs=[_char.make_tlv(move.uci(), meta=META_UCI),
                          _int.make_tlv(colour_to_move, meta=META_COLOUR),
                          _int.make_tlv(self.game_id, meta=META_GAME_ID)])
                break                       # wait for the confirmation


# ── wiring ─────────────────────────────────────────────────────────────────────

def _guard(fn):
    def wrapped(msg):
        try:
            fn(msg)
        except Exception:
            log.error('handler %s failed:\n%s', fn.__name__,
                      traceback.format_exc())
    return wrapped


def main() -> None:
    p = argparse.ArgumentParser(description='UMM Chess Engine Agent')
    p.add_argument('--router',   default='localhost')
    p.add_argument('--port',     type=int, default=DEFAULT_PORT)
    p.add_argument('--name',     default='ChessEngine',
                   help='Agent name shown in GUI and parser (passed by umm_ctl)')
    p.add_argument('--type',     type=int, default=MT_CHESS_ENGINE,
                   help='Agent mtype override (passed by umm_ctl)')
    p.add_argument('--colour',   default='black',
                   choices=['white', 'black', 'both'],
                   help='side to play (default black; both = self-play)')
    p.add_argument('--backend',  default='minimax', choices=['minimax', 'uci'])
    p.add_argument('--uci-path', default=None,
                   help='path to a UCI engine binary (for --backend uci)')
    p.add_argument('--movetime', type=float, default=1.0,
                   help='seconds per move (default 1.0)')
    p.add_argument('--depth',    type=int, default=4,
                   help='minimax max depth (default 4)')
    p.add_argument('--game',     type=int, default=1, help='game id (default 1)')
    p.add_argument('--hold',     action='store_true',
                   help='start passive; send EngineGo (2002,101) to begin')
    p.add_argument('--debug',    action='store_true')
    args = p.parse_args()

    # Log to stdout so the runumm per-agent log wrapper captures everything.
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        stream=sys.stdout,
                        format='%(asctime)s %(name)s %(levelname)s %(message)s')
    register_chess_metas()

    colour = {'white': WHITE, 'black': BLACK, 'both': BOTH}[args.colour]

    agent = UMMAgent(host=args.router, port=args.port,
                     process_name=args.name, agent_mtype=args.type)
    agent.connect()
    register_capability_handler(agent, ENGINE_CAPABILITY)

    eng = EngineAgent(agent, colour=colour, backend_name=args.backend,
                      movetime=args.movetime, depth=args.depth,
                      game_id=args.game, uci_path=args.uci_path,
                      active=not args.hold)

    ch_app = int(Channel.APP)
    agent.register(mtype=MT_CHESS_GAME,   subtype=ST_BOARD_STATE,
                   callback=_guard(eng.on_position),  channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,   subtype=ST_MOVE_CONFIRMED,
                   callback=_guard(eng.on_position),  channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,   subtype=ST_MOVE_REJECTED,
                   callback=_guard(eng.on_rejected),  channel=ch_app)
    agent.register(mtype=MT_CHESS_GAME,   subtype=ST_GAME_OVER,
                   callback=_guard(eng.on_game_over), channel=ch_app)
    agent.register(mtype=MT_CHESS_ENGINE, subtype=ST_ENG_CONFIG,
                   callback=_guard(eng.on_config),    channel=ch_app)
    agent.register(mtype=MT_CHESS_ENGINE, subtype=ST_ENG_GO,
                   callback=_guard(eng.on_go),        channel=ch_app)
    agent.register(mtype=MT_CHESS_ENGINE, subtype=ST_ENG_STOP,
                   callback=_guard(eng.on_stop),      channel=ch_app)

    log.info('ChessEngine running: colour=%s backend=%s movetime=%.2fs '
             'depth=%d game=%d active=%s',
             COLOUR_NAME[colour], eng.backend_name, args.movetime,
             args.depth, args.game, eng.active)
    eng.publish_status()
    eng.request_state()          # join a game already in progress
    try:
        agent.run()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
