"""
examples/tankLevel/tankLevel.py
================================
Tank Level Agent — simulates one or more process tanks filling and emptying.

Usage:
    python3 examples/tankLevel/tankLevel.py            # single tank (tank 0)
    python3 examples/tankLevel/tankLevel.py --tanks 3  # tanks 0, 1, 2

mtype = 5000  (TankLevel)

Every message carries an Int TLV as the FIRST payload field identifying
the tank number.  This allows a single agent to manage multiple tanks and
allows FSMs and subscribers to filter by tank using a positional Int match.

    RCV_MSG  5000,102 Int = 1 Float <= 20   # level update for tank 1, low

Subtypes published (mtype 5000):
    102  LevelUpdate    Int(tank), Float(%)  — published each tick
    103  LevelLow       Int(tank), Float(%)  — level below LOW_THRESHOLD
    104  LevelHigh      Int(tank), Float(%)  — level above HIGH_THRESHOLD
    105  PumpStarted    Int(tank), Bool true  — pump turned on
    106  PumpStopped    Int(tank), Bool false — pump turned off

Subtypes received (mtype 5000):
    101  LevelRequest   Int(tank) or no TLV  — timer tick (drives simulation)
    201  ForceFill      Int(tank), Float(%)  — GUI override: jump to high level
    202  ForceEmpty     Int(tank), Float(%)  — GUI override: jump to low level

Subtypes received (mtype 5001, from pump agent):
    102  PumpEcho       Int(tank), Bool      — pump state echo
"""

from __future__ import annotations   # PEP 563 — allow "int | None" style hints on Python 3.7+

import sys
import math
import time
import argparse
import logging
import traceback
import functools
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

# Route logging to stdout so the per-agent log capture (the runumm launcher
# pipes stdout) records it.  Crashes used to leave no cause in the log because
# unhandled exceptions and asyncio task errors went to stderr, which isn't
# captured.  asyncio logs unretrieved task exceptions through this logger, so
# sending it to stdout means the next crash will be recorded.
logging.basicConfig(level=logging.WARNING, stream=sys.stdout,
                    format='%(asctime)s %(levelname)s %(name)s: %(message)s')
_log = logging.getLogger('tankLevel')


def _guard(coro_fn):
    """Wrap an async message callback so any exception is logged with a full
    traceback (to the captured stdout) instead of silently killing the agent
    or vanishing into asyncio's default handler.  The agent keeps running."""
    @functools.wraps(coro_fn)
    async def wrapper(msg):
        try:
            return await coro_fn(msg)
        except Exception:
            _log.error("[TANK] exception in %s:\n%s",
                       coro_fn.__name__, traceback.format_exc())
    return wrapper

from umm.agent import UMMAgent
from umm.core.tlv import TLV, decode_all
from umm.core.messages import DEFAULT_PORT
from umm.core.registry import registry
from umm.types.builtin import FloatType, BoolType, IntType

from umm.capability import make_capability, SubtypeSpec, TLVSpec, register_capability_handler

# ── mtype / subtype constants ─────────────────────────────────────────────────
MT_TANK          = 5000
MT_PUMP          = 5001

REC_LEVEL_REQ    = 101
SND_LEVEL_VAL    = 102
SND_LEVEL_LOW    = 103
SND_LEVEL_HIGH   = 104
SND_PUMP_STARTED = 105
SND_PUMP_STOPPED = 106
REC_FORCE_FILL   = 201
REC_FORCE_EMPTY  = 202

REC_PUMP_ECHO    = 102   # from pump agent

# ── thresholds ────────────────────────────────────────────────────────────────
LOW_THRESHOLD  = 10.0    # error below this
HIGH_THRESHOLD = 90.0    # error above this

# ── simulation parameters ─────────────────────────────────────────────────────
FILL_RATE   = 8.0    # % per tick when pump is on
DRAIN_RATE  = 5.0    # % per tick when pump is off
WOBBLE_AMP  = 1.5    # ± amplitude of sine noise

# ── per-tank state ────────────────────────────────────────────────────────────
class TankState:
    def __init__(self, tank_num: int):
        self.tank_num  = tank_num
        self.level     = 50.0
        self.filling   = False
        self.tick      = 0
        self.low_sent  = False
        self.high_sent = False

# ── TLV helpers ───────────────────────────────────────────────────────────────
_int_type   = IntType()
_float_type = FloatType()
_bool_type  = BoolType()

# Meta labels so tank messages are self-describing on the GUI and parser:
#   Int(tank)  → index,  Float(level) → level,  Bool(pump) → running
from umm.core.meta import INT_META_INDEX, FLOAT_META_LEVEL, BOOL_META_RUNNING

def _tank_tlv(tank_num: int) -> bytes:
    """First TLV in every message: Int carrying the tank number."""
    return _int_type.make_tlv(tank_num, meta=INT_META_INDEX)

def _float_tlv(value: float) -> bytes:
    return _float_type.make_tlv(value, meta=FLOAT_META_LEVEL)

def _bool_tlv(value: bool) -> bytes:
    return _bool_type.make_tlv(value, meta=BOOL_META_RUNNING)

def _parse_tank_num(msg) -> int | None:
    """Extract tank number from first Int TLV.  Returns None if absent."""
    if not msg.tdata.value:
        return None
    for tlv in decode_all(msg.tdata.value):
        h = registry.get_by_id(tlv.type_id)
        if h and h.TYPE_NAME == 'Int':
            return int(h.unpack(tlv.value))
    return None

def _parse_float(msg) -> float | None:
    """Extract first Float TLV value (second TLV in most messages)."""
    if not msg.tdata.value:
        return None
    found_int = False
    for tlv in decode_all(msg.tdata.value):
        h = registry.get_by_id(tlv.type_id)
        if h and h.TYPE_NAME == 'Int':
            found_int = True
            continue
        if h and h.TYPE_NAME == 'Float':
            return float(h.unpack(tlv.value))
    return None

def _parse_bool(msg) -> bool | None:
    """Extract first Bool TLV value."""
    if not msg.tdata.value:
        return None
    for tlv in decode_all(msg.tdata.value):
        h = registry.get_by_id(tlv.type_id)
        if h and h.TYPE_NAME == 'Bool':
            return bool(h.unpack(tlv.value))
    return None

# ── capability ────────────────────────────────────────────────────────────────
TANK_CAPABILITY = make_capability(
    what        = 'TankLevel',
    mtype       = MT_TANK,
    description = 'Simulates one or more process tanks. Each message carries an '
                  'Int(tank_number) as the first TLV so FSMs and subscribers can '
                  'filter by tank using a positional Int match.',
    subtypes    = [
        SubtypeSpec(subtype=REC_LEVEL_REQ,    name='LevelRequest',
                    direction='in',
                    description='Timer tick — drives one simulation step per tank.',
                    input_tlvs=[TLVSpec(type_id=2, name='Int', required=False,
                                        description='Tank number. If absent, ticks all tanks.')]),
        SubtypeSpec(subtype=SND_LEVEL_VAL,    name='LevelUpdate',
                    direction='out',
                    description='Current tank level (%)',
                    output_tlvs=[
                        TLVSpec(type_id=2, name='Int',   required=True,  description='Tank number.'),
                        TLVSpec(type_id=6, name='Float', required=True,  description='Level 0–100%.'),
                    ]),
        SubtypeSpec(subtype=SND_LEVEL_LOW,    name='LevelLow',
                    direction='out',
                    description='Level dropped below 10%.',
                    output_tlvs=[
                        TLVSpec(type_id=2, name='Int',   required=True,  description='Tank number.'),
                        TLVSpec(type_id=6, name='Float', required=True,  description='Level at alert.'),
                    ]),
        SubtypeSpec(subtype=SND_LEVEL_HIGH,   name='LevelHigh',
                    direction='out',
                    description='Level rose above 90%.',
                    output_tlvs=[
                        TLVSpec(type_id=2, name='Int',   required=True,  description='Tank number.'),
                        TLVSpec(type_id=6, name='Float', required=True,  description='Level at alert.'),
                    ]),
        SubtypeSpec(subtype=SND_PUMP_STARTED, name='PumpStarted',
                    direction='out',
                    description='Pump turned on.',
                    output_tlvs=[
                        TLVSpec(type_id=2, name='Int',  required=True, description='Tank number.'),
                        TLVSpec(type_id=7, name='Bool', required=True, description='true'),
                    ]),
        SubtypeSpec(subtype=SND_PUMP_STOPPED, name='PumpStopped',
                    direction='out',
                    description='Pump turned off.',
                    output_tlvs=[
                        TLVSpec(type_id=2, name='Int',  required=True, description='Tank number.'),
                        TLVSpec(type_id=7, name='Bool', required=True, description='false'),
                    ]),
        SubtypeSpec(subtype=REC_FORCE_FILL,   name='ForceFill',
                    direction='in',
                    description='GUI: jump level to ~95% to trigger high-level alert.',
                    input_tlvs=[
                        TLVSpec(type_id=2, name='Int',   required=True,  description='Tank number.'),
                        TLVSpec(type_id=6, name='Float', required=False, description='Target level (default 95).'),
                    ]),
        SubtypeSpec(subtype=REC_FORCE_EMPTY,  name='ForceEmpty',
                    direction='in',
                    description='GUI: jump level to ~5% to trigger low-level alert.',
                    input_tlvs=[
                        TLVSpec(type_id=2, name='Int',   required=True,  description='Tank number.'),
                        TLVSpec(type_id=6, name='Float', required=False, description='Target level (default 5).'),
                    ]),
    ],
    author = 'Phil Braham',
)

# ── simulation step ───────────────────────────────────────────────────────────
async def _tick_tank(ts: TankState):
    ts.tick += 1
    wobble = WOBBLE_AMP * math.sin(ts.tick * 0.7 + ts.tank_num * 1.3)
    if ts.filling:
        ts.level = min(100.0, ts.level + FILL_RATE + wobble)
    else:
        ts.level = max(0.0, ts.level - DRAIN_RATE + wobble)

    print(f'[TANK {ts.tank_num}] tick={ts.tick}  level={ts.level:.1f}%  '
          f'pump={"ON" if ts.filling else "OFF"}')

    await agent.asend(mtype=MT_TANK, subtype=SND_LEVEL_VAL,
                      tlvs=[_tank_tlv(ts.tank_num), _float_tlv(ts.level)])
    await _check_errors(ts)


async def _check_errors(ts: TankState):
    if ts.level < LOW_THRESHOLD and not ts.low_sent:
        print(f'[TANK {ts.tank_num}] ERROR: level LOW {ts.level:.1f}%')
        await agent.asend(mtype=MT_TANK, subtype=SND_LEVEL_LOW,
                          tlvs=[_tank_tlv(ts.tank_num), _float_tlv(ts.level)])
        ts.low_sent  = True
        ts.high_sent = False
    elif ts.level > HIGH_THRESHOLD and not ts.high_sent:
        print(f'[TANK {ts.tank_num}] ERROR: level HIGH {ts.level:.1f}%')
        await agent.asend(mtype=MT_TANK, subtype=SND_LEVEL_HIGH,
                          tlvs=[_tank_tlv(ts.tank_num), _float_tlv(ts.level)])
        ts.high_sent = True
        ts.low_sent  = False
    elif LOW_THRESHOLD <= ts.level <= HIGH_THRESHOLD:
        ts.low_sent  = False
        ts.high_sent = False

# ── callbacks ─────────────────────────────────────────────────────────────────
async def req_level(msg):
    """Timer tick — advance simulation for addressed tank(s)."""
    tank_num = _parse_tank_num(msg)
    if tank_num is None:
        # No tank number: tick all tanks
        for ts in tanks.values():
            await _tick_tank(ts)
    elif tank_num in tanks:
        await _tick_tank(tanks[tank_num])

async def pump_echo(msg):
    """Pump agent echo — update fill direction for the addressed tank."""
    tank_num = _parse_tank_num(msg)
    if tank_num is None or tank_num not in tanks:
        return
    state = _parse_bool(msg)
    if state is None:
        return
    ts = tanks[tank_num]
    ts.filling = state
    print(f'[TANK {tank_num}] pump {"ON  → filling" if ts.filling else "OFF → draining"}')
    subtype = SND_PUMP_STARTED if ts.filling else SND_PUMP_STOPPED
    await agent.asend(mtype=MT_TANK, subtype=subtype,
                      tlvs=[_tank_tlv(tank_num), _bool_tlv(ts.filling)])

async def force_fill(msg):
    """GUI: jump level high."""
    tank_num = _parse_tank_num(msg)
    if tank_num is None:
        tank_num = 0   # default to tank 0 (e.g. when GUI sends Float only)
    if tank_num not in tanks:
        return
    ts = tanks[tank_num]
    target = _parse_float(msg) or 95.0
    ts.level = min(100.0, target)
    ts.high_sent = False
    ts.low_sent  = False
    print(f'[TANK {tank_num}] force-fill → level={ts.level:.1f}%')
    await agent.asend(mtype=MT_TANK, subtype=SND_LEVEL_VAL,
                      tlvs=[_tank_tlv(tank_num), _float_tlv(ts.level)])
    await _check_errors(ts)

async def force_empty(msg):
    """GUI: jump level low."""
    tank_num = _parse_tank_num(msg)
    if tank_num is None:
        tank_num = 0   # default to tank 0 (e.g. when GUI sends Float only)
    if tank_num not in tanks:
        return
    ts = tanks[tank_num]
    target = _parse_float(msg) or 5.0
    ts.level = max(0.0, target)
    ts.high_sent = False
    ts.low_sent  = False
    print(f'[TANK {tank_num}] force-empty → level={ts.level:.1f}%')
    await agent.asend(mtype=MT_TANK, subtype=SND_LEVEL_VAL,
                      tlvs=[_tank_tlv(tank_num), _float_tlv(ts.level)])
    await _check_errors(ts)

# ── main ──────────────────────────────────────────────────────────────────────
parser_args = argparse.ArgumentParser(description='UMM Tank Level Agent')
parser_args.add_argument('--tanks',  type=int, default=1,
                         help='Number of tanks to simulate (default 1, numbered 0..N-1)')
parser_args.add_argument('--router', default='localhost')
parser_args.add_argument('--port',   type=int, default=DEFAULT_PORT)
parser_args.add_argument('--name',   default='TankLevelAgent',
                         help='Agent name shown in GUI and parser (passed by umm_ctl)')
parser_args.add_argument('--type',   type=int, default=MT_TANK,
                         help='Agent mtype override (passed by umm_ctl)')
args = parser_args.parse_args()

tanks: dict[int, TankState] = {n: TankState(n) for n in range(args.tanks)}
print(f'[TANK] Starting with {args.tanks} tank(s): {list(tanks.keys())}')

agent = UMMAgent(host=args.router, port=args.port,
                 process_name=args.name, agent_mtype=args.type)
agent.connect()
register_capability_handler(agent, TANK_CAPABILITY)
agent.register(mtype=MT_TANK, subtype=REC_LEVEL_REQ,  callback=_guard(req_level))
agent.register(mtype=MT_PUMP, subtype=REC_PUMP_ECHO,  callback=_guard(pump_echo))
agent.register(mtype=MT_TANK, subtype=REC_FORCE_FILL,  callback=_guard(force_fill))
agent.register(mtype=MT_TANK, subtype=REC_FORCE_EMPTY, callback=_guard(force_empty))

# Surface the loop's own unhandled exceptions to the captured log too.
try:
    agent._loop.set_exception_handler(
        lambda loop, ctx: _log.error("[TANK] async loop error: %s\n%s",
                                     ctx.get('message'),
                                     ''.join(traceback.format_exception(
                                         type(ctx['exception']), ctx['exception'],
                                         ctx['exception'].__traceback__))
                                     if ctx.get('exception') else ctx.get('message')))
except Exception:
    pass

try:
    agent.run()
except KeyboardInterrupt:
    pass
except Exception:
    # Log the cause before the process exits (and is restarted by runumm),
    # so the reason for the crash is in the log next time.
    _log.error("[TANK] agent.run() terminated with an exception:\n%s",
               traceback.format_exc())
    sys.stdout.flush()
    raise
