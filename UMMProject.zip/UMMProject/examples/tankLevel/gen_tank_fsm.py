"""
examples/tankLevel/gen_tank_fsm.py
====================================
Generates one FSM config file per tank from tankLevel.fsm.template.

Usage:
    python3 examples/tankLevel/gen_tank_fsm.py --tanks 3
        → writes tankLevel_tank0.fsm, tankLevel_tank1.fsm, tankLevel_tank2.fsm

    python3 examples/tankLevel/gen_tank_fsm.py --tanks 1
        → writes tankLevel_tank0.fsm

The generated files are consumed by umm_ctl / umm.conf agent entries.
runumm start tank  calls this script automatically before starting agents,
so there is no need to run it manually.

Each generated file is identical except the tank number {N} is substituted
throughout — in both RCV_MSG match values and SND_MSG TLV payloads.
"""

from __future__ import annotations   # PEP 563 — allow "list[Path]" style hints on Python 3.7+

import sys
import argparse
from pathlib import Path

HERE     = Path(__file__).parent
TEMPLATE = HERE / 'tankLevel.fsm.template'

def generate(num_tanks: int) -> list[Path]:
    template = TEMPLATE.read_text()
    generated = []
    for n in range(num_tanks):
        out_path = HERE / f'tankLevel_tank{n}.fsm'
        content  = template.replace('{N}', str(n))
        out_path.write_text(content)
        generated.append(out_path)
        print(f'  Generated {out_path.name}')
    return generated

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Generate per-tank FSM config files')
    p.add_argument('--tanks', type=int, default=1,
                   help='Number of tanks (default 1)')
    args = p.parse_args()
    print(f'Generating FSM files for {args.tanks} tank(s)...')
    paths = generate(args.tanks)
    print(f'Done — {len(paths)} file(s) written.')
