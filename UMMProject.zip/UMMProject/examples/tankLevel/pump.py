"""
examples/tankLevel/pump.py
===========================
Pump Agent — controls pump start/stop for one or more tanks.

A single pump agent handles all tanks.  Every command and echo message
carries an Int TLV as the FIRST field identifying which tank's pump is
being controlled.

mtype = 5001  (Pump)

Receives (mtype 5001):
    101  PumpCommand    Int(tank), Bool  — command from FSM: True=on, False=off

Sends (mtype 5001):
    102  PumpEcho       Int(tank), Bool  — current pump state (to tank agent)
"""

from __future__ import annotations   # PEP 563 — allow "int | None" style hints on Python 3.7+

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from umm.agent import UMMAgent
from umm.core.tlv import decode_all
from umm.core.messages import DEFAULT_PORT
from umm.core.registry import registry
from umm.types.builtin import IntType, BoolType

from umm.capability import make_capability, SubtypeSpec, TLVSpec, register_capability_handler

import argparse

# ── mtype / subtype constants ─────────────────────────────────────────────────
MT_PUMP        = 5001
REC_CMD        = 101   # command from FSM
SND_ECHO       = 102   # echo to tank agent

# ── TLV helpers ───────────────────────────────────────────────────────────────
_int_type  = IntType()
_bool_type = BoolType()
from umm.core.meta import INT_META_INDEX, BOOL_META_RUNNING

def _parse_tank_num(msg) -> int | None:
    if not msg.tdata.value:
        return None
    for tlv in decode_all(msg.tdata.value):
        h = registry.get_by_id(tlv.type_id)
        if h and h.TYPE_NAME == 'Int':
            return int(h.unpack(tlv.value))
    return None

def _parse_bool(msg) -> bool | None:
    if not msg.tdata.value:
        return None
    for tlv in decode_all(msg.tdata.value):
        h = registry.get_by_id(tlv.type_id)
        if h and h.TYPE_NAME == 'Bool':
            return bool(h.unpack(tlv.value))
    return None

# ── per-tank pump state ───────────────────────────────────────────────────────
pump_states: dict[int, bool] = {}   # tank_num -> running

# ── capability ────────────────────────────────────────────────────────────────
PUMP_CAPABILITY = make_capability(
    what        = 'Pump',
    mtype       = MT_PUMP,
    description = 'Controls pump start/stop for one or more tanks. '
                  'Every message carries Int(tank_number) as the first TLV.',
    subtypes    = [
        SubtypeSpec(
            subtype     = REC_CMD,
            name        = 'PumpCommand',
            direction   = 'in',
            description = 'FSM command: start or stop the pump for a specific tank.',
            input_tlvs  = [
                TLVSpec(type_id=2, name='Int',  required=True,
                        description='Tank number.'),
                TLVSpec(type_id=7, name='Bool', required=True,
                        description='true = start pump, false = stop pump.'),
            ],
        ),
        SubtypeSpec(
            subtype     = SND_ECHO,
            name        = 'PumpEcho',
            direction   = 'out',
            description = 'Current pump state echo, published after each command.',
            output_tlvs = [
                TLVSpec(type_id=2, name='Int',  required=True,
                        description='Tank number.'),
                TLVSpec(type_id=7, name='Bool', required=True,
                        description='true = running, false = stopped.'),
            ],
        ),
    ],
    author = 'Phil Braham',
)

# ── callback ──────────────────────────────────────────────────────────────────
async def on_command(msg):
    tank_num = _parse_tank_num(msg)
    state    = _parse_bool(msg)
    if tank_num is None or state is None:
        print(f'[PUMP] Bad command message — missing tank number or Bool TLV')
        return

    prev = pump_states.get(tank_num)
    if state == prev:
        print(f'[PUMP {tank_num}] Ignoring duplicate command (already {"ON" if state else "OFF"})')
        return

    pump_states[tank_num] = state
    print(f'[PUMP {tank_num}] {"START" if state else "STOP"} — echoing state')

    await agent.asend(
        mtype   = MT_PUMP,
        subtype = SND_ECHO,
        tlvs    = [
            _int_type.make_tlv(tank_num, meta=INT_META_INDEX),
            _bool_type.make_tlv(state, meta=BOOL_META_RUNNING),
        ],
    )

# ── main ──────────────────────────────────────────────────────────────────────
p = argparse.ArgumentParser(description='UMM Pump Agent')
p.add_argument('--router', default='localhost')
p.add_argument('--port',   type=int, default=DEFAULT_PORT)
p.add_argument('--name',   default='PumpAgent',
               help='Agent name shown in GUI and parser (passed by umm_ctl)')
p.add_argument('--type',   type=int, default=MT_PUMP,
               help='Agent mtype override (passed by umm_ctl)')
args = p.parse_args()

agent = UMMAgent(host=args.router, port=args.port,
                 process_name=args.name, agent_mtype=args.type)
agent.connect()
register_capability_handler(agent, PUMP_CAPABILITY)
agent.register(mtype=MT_PUMP, subtype=REC_CMD, callback=on_command)
agent.run()
