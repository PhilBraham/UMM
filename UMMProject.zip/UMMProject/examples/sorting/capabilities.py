"""
examples/sorting/capabilities.py
=================================
Capability descriptors for the parcel sorting machine demo.

Mtype allocation (user range 1000+):
    1001   ControlAgent    — operator buttons (start, e-stop, restart, bin clear)
    1002   ConveyorAgent   — belt motor control
    1003   PhotocellAgent  — parcel presence detection
    1004   BarcodeAgent    — postcode reading
    1005   DiverterAgent   — bin routing arms
    1006   BinAgent        — bin fullness monitoring

All subtypes are positive (published messages).
Negative subtypes only used where agent explicitly sends a response.

In this system:
  - ConveyorAgent acknowledges start/stop commands (response_subtype set)
  - All other agents are fire-and-forget publishers

Simulation channel
------------------
Simulation-only traffic (belt encoder timer requests, internal tick messages,
timer confirmations) travels on SIM_CHANNEL rather than channel 1 (APP).  This keeps
the application bus clean: a subscriber watching channel 1 sees exactly the
messages that would be present on a real machine (state changes, photocell
events, diverter activations etc.) with no simulator scaffolding visible.

To observe simulation traffic, subscribe on SIM_CHANNEL (128 by default).
The parser supports: python3 -m umm.modules.parser --channel 1 --channel 128
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from umm.capability import (
    make_capability, SubtypeSpec, TLVSpec, AgentCapability,
    BUILTIN_CAPABILITIES
)

# ── mtype constants ───────────────────────────────────────────────────────────

MT_CONTROL   = 1001
MT_CONVEYOR  = 1002
MT_PHOTOCELL = 1003
MT_BARCODE   = 1004
MT_DIVERTER  = 1005
MT_BIN       = 1006
MT_FEEDER    = 1007   # infeed feeder belt — demand-feeds one parcel at a time

# ── subtype constants ─────────────────────────────────────────────────────────

# ControlAgent subtypes (operator inputs)
ST_CTRL_START        = 101  # Start button pressed
ST_CTRL_ESTOP        = 102  # Emergency stop pressed
ST_CTRL_RESTART      = 103  # Restart after e-stop
ST_CTRL_CLEAR_BIN    = 104  # Bin cleared by operator (Int TLV = bin number)
ST_CTRL_OPERATOR_MSG = 199  # Operator message (Char)

# ConveyorAgent subtypes
ST_CONV_CMD_C1       = 101  # Command C1 (feed belt):  Bool true=start false=stop
ST_CONV_CMD_C2       = 102  # Command C2 (read belt):  Bool true=start false=stop
ST_CONV_STATE_C1     = 103  # C1 state changed (published): Bool running/stopped
ST_CONV_STATE_C2     = 104  # C2 state changed (published): Bool running/stopped
ST_CONV_PULSE_C1     = 105  # Belt encoder pulse C1: Int(cumulative_count) — fired by timer
ST_CONV_PULSE_C2     = 106  # Belt encoder pulse C2: Int(cumulative_count) — fired by timer
ST_CONV_STALL_C1     = 107  # C1 stall detected: commanded ON but no pulses received
ST_CONV_STALL_C2     = 108  # C2 stall detected: commanded ON but no pulses received
ST_CONV_ACK_C1       = -101 # Response to C1 command (if agent acks)
ST_CONV_ACK_C2       = -102 # Response to C2 command (if agent acks)

# FeederAgent subtypes (mtype 1007 — the infeed feeder belt)
ST_FEED_CMD          = 101  # Command feeder belt: Bool true=run, false=stop
ST_FEED_STATE        = 102  # Feeder state changed (published): Bool running/stopped
ST_FEED_ACK          = -101 # Response to feeder command (if agent acks)

# Belt encoder constants
PULSE_INTERVAL_MS    = 120  # ms between encoder pulses at normal belt speed
MM_PER_PULSE         = 25   # belt moves 25mm per pulse
BELT_LENGTH_MM       = 2400 # total belt length in mm (96 pulses end-to-end)
STALL_TIMEOUT_MS     = 500  # ms without pulse before stall alarm

# Simulation channel — all timer requests and internal tick messages travel
# on this channel so they are invisible on the channel-0 application bus.
# Change to 0 to put simulation traffic back on the application bus (e.g. for
# debugging the simulation itself).
SIM_CHANNEL          = 128  # Channel.SIM from umm.core.messages

# Belt-encoder pulse channel — the high-frequency PulseC1/PulseC2 telemetry is
# published here instead of the channel-1 application bus, so a parser watching
# channel 1 sees only the parcel-level events (scans, routes, photocells, state
# changes) and isn't flooded by pulses.  Consumers that want pulses subscribe on
# this channel (or on channel 0 = ALL, as the GUI does).
#   Watch parcels only:  python3 -m umm.modules.parser --channel 1
#   Watch pulses too:    python3 -m umm.modules.parser --channel 1 --channel 127
PULSE_CHANNEL        = 127

# Meta key for the barcode sort code.  The barcode reader tags the sort-code
# Int with this (non-zero) meta; the FSM's bin/reject rules carry the same meta
# on their conditions, so the router keys onto that one field and ANDs the two
# range conditions (>= lo, <= hi) against it.  (meta=0 fields stay positional.)
# Chosen well clear of the built-in Int meta values (1-7 in umm.core.meta).
META_SORTCODE        = 100

# PhotocellAgent subtypes (all published events, all positive)
ST_PC_C1_DETECTED    = 101  # Parcel detected at feed belt entry
ST_PC_C2_DETECTED    = 102  # Parcel detected at barcode reader
ST_PC_BIN1_DETECTED  = 103  # Parcel detected at bin 1
ST_PC_BIN2_DETECTED  = 104  # Parcel detected at bin 2
ST_PC_BIN3_DETECTED  = 105  # Parcel detected at bin 3
ST_PC_BIN4_DETECTED  = 106  # Parcel detected at bin 4
ST_PC_REJECT_DETECTED= 107  # Parcel detected at reject bin
ST_PC_C1_CLEARED     = 111  # Parcel cleared from feed belt entry
ST_PC_C2_CLEARED     = 112  # Parcel cleared from barcode reader
ST_PC_INFEED_DETECTED= 108  # Parcel present at the infeed drop point (in front of the reader belt)
ST_PC_INFEED_CLEARED = 118  # Infeed drop point cleared (parcel carried onto the main belt)

# BarcodeAgent subtypes (published events)
ST_BC_REQUEST        = 101  # Scan request (sent by FSM to barcode reader)
ST_BC_SUCCESS        = 102  # Scan successful: Int(sort_code, meta=META_SORTCODE)
ST_BC_FAILED         = 103  # Scan failed:     Int(parcel_id) Int(tracking_num)
ST_BC_RECORD         = 104  # Audit record: Int(sort_code, meta=META_SORTCODE)
                            #               Int(bin,       meta=META_BC_BIN_NUMBER)
                            #               Int(track,     meta=META_BC_TRACKING_NUM)

# Meta field identifiers for ST_BC_RECORD (mtype=1004, subtype=104).  A non-zero
# meta lets a subscriber select a field by key instead of position (e.g. a
# database writer can pick the bin field without relying on TLV order).  The
# sort_code field reuses META_SORTCODE — same meaning as in ScanSuccess.
META_BC_BIN_NUMBER   = 101  # Int TLV: destination bin number (0 = reject lane)
META_BC_TRACKING_NUM = 102  # Int TLV: parcel tracking number

# DiverterAgent subtypes
ST_DIV_CMD           = 101  # Activate diverter: Int(bin_number 1-4, 0=reject)
ST_DIV_ACTIVATED     = 102  # Diverter fired (published): Int(bin_number)

# BinAgent subtypes (published events)
ST_BIN_FULL          = 101  # Bin N is full:    Int(bin_number)
ST_BIN_CLEARED       = 102  # Bin N is cleared: Int(bin_number)
ST_BIN_LEVEL         = 103  # Bin level update: Int(bin_number) Int(count)
ST_BIN_SET_CAP       = 104  # Set bin capacity: Int(count)


# ── capability descriptors ────────────────────────────────────────────────────

CONTROL_CAPABILITY = make_capability(
    what        = "ControlAgent",
    mtype       = MT_CONTROL,
    description = "Operator control panel. Publishes button press events.",
    subtypes    = [
        SubtypeSpec(subtype=ST_CTRL_START,     name="Start",
                    direction="out",
                    description="Start button pressed. Starts the sorting line if safe."),
        SubtypeSpec(subtype=ST_CTRL_ESTOP,     name="EStop",
                    direction="out",
                    description="Emergency stop pressed. Stops all belts immediately."),
        SubtypeSpec(subtype=ST_CTRL_RESTART,   name="Restart",
                    direction="out",
                    description="Restart after e-stop. FSM checks all-clear first."),
        SubtypeSpec(subtype=ST_CTRL_CLEAR_BIN, name="BinCleared",
                    direction="out",
                    description="Operator has emptied a bin.",
                    output_tlvs=[
                        TLVSpec(type_id=2, name="Int", required=True,
                                description="Bin number (1-4, 0=reject bin).")]),
    ],
    author="Realtime Software Pty Ltd",
)

CONVEYOR_CAPABILITY = make_capability(
    what        = "ConveyorAgent",
    mtype       = MT_CONVEYOR,
    description = (
        "Controls belt motors. Receives start/stop commands and publishes "
        "state change events. Sends an acknowledgement response for each command."
    ),
    subtypes    = [
        SubtypeSpec(
            subtype          = ST_CONV_CMD_C1,
            name             = "CommandC1",
            direction        = "in",
            description      = "Start or stop the feed belt (C1).",
            response_subtype = ST_CONV_ACK_C1,   # agent sends ack
            input_tlvs       = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = start, false = stop."),
            ],
        ),
        SubtypeSpec(
            subtype          = ST_CONV_CMD_C2,
            name             = "CommandC2",
            direction        = "in",
            description      = "Start or stop the read belt (C2).",
            response_subtype = ST_CONV_ACK_C2,
            input_tlvs       = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = start, false = stop."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_CONV_STATE_C1,
            name         = "C1StateChanged",
            direction    = "out",
            description  = "Published when C1 (feed belt) changes state.",
            output_tlvs  = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = running, false = stopped."),
                TLVSpec(type_id=8, name="Char", required=False,
                        description="Reason: 'start_cmd','stop_cmd','estop','bin_full'."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_CONV_STATE_C2,
            name         = "C2StateChanged",
            direction    = "out",
            description  = "Published when C2 (read belt) changes state.",
            output_tlvs  = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = running, false = stopped."),
                TLVSpec(type_id=8, name="Char", required=False,
                        description="Reason for state change."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_CONV_ACK_C1,
            name         = "C1Acknowledged",
            direction    = "out",
            responds_to  = ST_CONV_CMD_C1,
            description  = "Response to C1 command.",
            output_tlvs  = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = command executed, false = rejected (e.g. e-stop active)."),
                TLVSpec(type_id=8, name="Char", required=False,
                        description="Rejection reason if false."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_CONV_ACK_C2,
            name         = "C2Acknowledged",
            direction    = "out",
            responds_to  = ST_CONV_CMD_C2,
            description  = "Response to C2 command.",
            output_tlvs  = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = executed, false = rejected."),
                TLVSpec(type_id=8, name="Char", required=False,
                        description="Rejection reason if false."),
            ],
        ),
    ],
    author="Realtime Software Pty Ltd",
)

PHOTOCELL_CAPABILITY = make_capability(
    what        = "PhotocellAgent",
    mtype       = MT_PHOTOCELL,
    description = (
        "Parcel presence detectors. Publishes events when a parcel "
        "breaks or clears each beam. Pure publisher — no commands accepted."
    ),
    subtypes    = [
        SubtypeSpec(subtype=ST_PC_C1_DETECTED,    name="FeedEntryDetected",
                    direction="out",
                    description="Parcel detected at feed belt entry (PC1)."),
        SubtypeSpec(subtype=ST_PC_C2_DETECTED,    name="ReaderDetected",
                    direction="out",
                    description="Parcel detected at barcode reader position (PC2)."),
        SubtypeSpec(subtype=ST_PC_BIN1_DETECTED,  name="Bin1Detected",
                    direction="out",
                    description="Parcel detected entering bin 1."),
        SubtypeSpec(subtype=ST_PC_BIN2_DETECTED,  name="Bin2Detected",
                    direction="out",
                    description="Parcel detected entering bin 2."),
        SubtypeSpec(subtype=ST_PC_BIN3_DETECTED,  name="Bin3Detected",
                    direction="out",
                    description="Parcel detected entering bin 3."),
        SubtypeSpec(subtype=ST_PC_BIN4_DETECTED,  name="Bin4Detected",
                    direction="out",
                    description="Parcel detected entering bin 4."),
        SubtypeSpec(subtype=ST_PC_REJECT_DETECTED,name="RejectDetected",
                    direction="out",
                    description="Parcel detected entering reject bin."),
        SubtypeSpec(subtype=ST_PC_C1_CLEARED,     name="FeedEntryCleared",
                    direction="out",
                    description="Feed belt entry beam cleared (parcel passed)."),
        SubtypeSpec(subtype=ST_PC_C2_CLEARED,     name="ReaderCleared",
                    direction="out",
                    description="Reader position beam cleared."),
        SubtypeSpec(subtype=ST_PC_INFEED_DETECTED, name="InfeedDetected",
                    direction="out",
                    description="Parcel present at the infeed drop point, just "
                                "ahead of the reader belt — gates the feeder."),
        SubtypeSpec(subtype=ST_PC_INFEED_CLEARED,  name="InfeedCleared",
                    direction="out",
                    description="Infeed drop point cleared: the main belt has "
                                "carried the parcel on, so the feeder may "
                                "release the next one."),
    ],
    author="Realtime Software Pty Ltd",
)

BARCODE_CAPABILITY = make_capability(
    what        = "BarcodeAgent",
    mtype       = MT_BARCODE,
    description = (
        "Barcode/postcode reader. Triggered by FSM when C2 is stopped "
        "with a parcel in position. Publishes scan result. Pure publisher."
    ),
    subtypes    = [
        SubtypeSpec(
            subtype     = 1,
            name        = "ScanRequest",
            direction   = "in",
            description = "FSM asks barcode agent to scan the parcel now in position.",
            response_subtype = None,  # response comes as ST_BC_SUCCESS or ST_BC_FAILED
            notes       = "Response arrives as subtype 2 (success) or 3 (failed).",
        ),
        SubtypeSpec(
            subtype      = ST_BC_SUCCESS,
            name         = "ScanSuccess",
            direction    = "out",
            description  = "Sort code read successfully.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Sort code (0000-9999)."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Parcel ID (sequential integer)."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Tracking number (6-digit integer, 100000-999999)."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_BC_FAILED,
            name         = "ScanFailed",
            direction    = "out",
            description  = "Sort code could not be read — parcel goes to reject bin.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Parcel ID."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Tracking number (6-digit integer)."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_BC_RECORD,
            name         = "ParcelRecord",
            direction    = "out",
            description  = "Audit record published after every scan (success or fail). "
                           "Carries the sort code, destination bin, and tracking number.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Sort code (0000-9999; 0 if scan failed)."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Destination bin (1-4, or 0 = reject)."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Tracking number (6-digit integer)."),
            ],
        ),
    ],
    author="Realtime Software Pty Ltd",
)

DIVERTER_CAPABILITY = make_capability(
    what        = "DiverterAgent",
    mtype       = MT_DIVERTER,
    description = "Routing arms that push parcels from the main belt into bins.",
    subtypes    = [
        SubtypeSpec(
            subtype          = ST_DIV_CMD,
            name             = "Route",
            direction        = "in",
            description      = "Route the next parcel to a bin.",
            response_subtype = None,  # fire-and-forget, watch ST_DIV_ACTIVATED
            input_tlvs       = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Bin number 1–4. 0 = reject bin."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_DIV_ACTIVATED,
            name         = "Activated",
            direction    = "out",
            description  = "Published when diverter arm fires.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Bin number that was activated."),
            ],
        ),
    ],
    author="Realtime Software Pty Ltd",
)

BIN_CAPABILITY = make_capability(
    what        = "BinAgent",
    mtype       = MT_BIN,
    description = (
        "Monitors bin fullness via photocell and parcel count. "
        "Publishes full/cleared events that cause upstream belts to stop/start."
    ),
    subtypes    = [
        SubtypeSpec(
            subtype      = ST_BIN_FULL,
            name         = "BinFull",
            direction    = "out",
            description  = "A bin has reached capacity. Upstream belts must stop.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Bin number (1–4, 0=reject)."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_BIN_CLEARED,
            name         = "BinCleared",
            direction    = "out",
            description  = "Bin has been emptied. Upstream belts may restart.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Bin number."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_BIN_LEVEL,
            name         = "BinLevel",
            direction    = "out",
            description  = "Current parcel count in a bin.",
            output_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Bin number."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Current parcel count."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Maximum capacity."),
            ],
        ),
    ],
    author="Realtime Software Pty Ltd",
)

# ── full capability registry for this application ─────────────────────────────

FEEDER_CAPABILITY = make_capability(
    what        = "FeederAgent",
    mtype       = MT_FEEDER,
    description = (
        "Infeed feeder belt — a separate down-slope conveyor packed with "
        "parcels that delivers ONE parcel at a time onto the start of the main "
        "feed belt. Driven by the feeder FSM: it runs until a parcel reaches "
        "the infeed detector, then stops until that parcel is carried on (the "
        "detector clears). Accepts run/stop commands and publishes its state."
    ),
    subtypes    = [
        SubtypeSpec(
            subtype          = ST_FEED_CMD,
            name             = "CommandFeeder",
            direction        = "in",
            description      = "Run or stop the infeed feeder belt.",
            response_subtype = ST_FEED_ACK,
            input_tlvs       = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = run, false = stop."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_FEED_STATE,
            name         = "FeederStateChanged",
            direction    = "out",
            description  = "Published when the feeder belt changes state.",
            output_tlvs  = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = running, false = stopped."),
                TLVSpec(type_id=8, name="Char", required=False,
                        description="Reason: 'start_cmd','parcel_delivered','estop'."),
            ],
        ),
        SubtypeSpec(
            subtype      = ST_FEED_ACK,
            name         = "FeederAcknowledged",
            direction    = "out",
            responds_to  = ST_FEED_CMD,
            description  = "Response to a feeder command.",
            output_tlvs  = [
                TLVSpec(type_id=7, name="Bool", required=True,
                        description="true = executed, false = rejected."),
            ],
        ),
    ],
    author="Realtime Software Pty Ltd",
)

SORTING_CAPABILITIES = {
    cap.mtype: cap for cap in [
        CONTROL_CAPABILITY,
        CONVEYOR_CAPABILITY,
        PHOTOCELL_CAPABILITY,
        BARCODE_CAPABILITY,
        DIVERTER_CAPABILITY,
        BIN_CAPABILITY,
        FEEDER_CAPABILITY,
    ]
}

# Also register with built-ins so capability viewer can find them
BUILTIN_CAPABILITIES.update(SORTING_CAPABILITIES)

# Give the sort-code meta a readable label so tools (e.g. the parser) can show
# it as "sort-code" rather than a bare number.
try:
    from umm.core.meta import meta_registry as _meta_registry
    from umm.core.tlv import TLV_INT as _TLV_INT
    _meta_registry.register(_TLV_INT, META_SORTCODE, "sort-code")
    _meta_registry.register(_TLV_INT, META_BC_BIN_NUMBER,   "bin-number")
    _meta_registry.register(_TLV_INT, META_BC_TRACKING_NUM, "tracking-num")
except Exception:
    pass


if __name__ == '__main__':
    for cap in SORTING_CAPABILITIES.values():
        print(f"\nmtype={cap.mtype:5d}  {cap.what}")
        print(f"  {cap.description[:70]}")
        for s in cap.subtypes:
            if s.subtype in ():
                continue   # skip standard capability subtypes
            arrow = '←' if s.direction == 'out' else '→'
            resp  = f"  (ack: {s.response_subtype})" if s.response_subtype else ""
            paired = f"  (response to {s.responds_to})" if s.responds_to else ""
            print(f"  {arrow} subtype={s.subtype:4d}  {s.name}{resp}{paired}")
