"""
examples/sorting/sorting_demo.py
=================================
Parcel sorting machine simulation.

Runs the simulated agents that drive the FSM:
  - ConveyorSim        — belt motor simulation; publishes encoder pulses and state changes
  - BarcodeSimulator   — waits for scan request; generates random sort code + tracking number
  - BinMonitor         — counts parcels per bin; publishes BinFull/BinCleared events
  - DiverterSim        — fires diverter arm on Route command; publishes Activated

Sort code → bin mapping:
  0000–1999  → bin 1
  2000–3999  → bin 2
  4000–5999  → bin 3
  6000–7999  → bin 4
  8000–9999  → reject (bin 0)
  Scan fail  → reject (bin 0)

Messages published after every scan:
  1004,102  ScanSuccess   Int(sort_code)                      — FSM routing trigger
  1004,104  ParcelRecord  Int(sort_code) Int(bin) Int(track)  — audit record

Tracking numbers: 6-digit integers (100000–999999), one per parcel.

Run via umm_ctl (recommended)::
    runumm start        # core stack
    runumm start demo   # sorting demo agents + FSM

Run manually::
    # Terminal 1: core stack
    python3 umm_ctl.py start

    # Terminal 2: FSM
    python3 -m umm.modules.fsm --config examples/sorting/sorting.fsm \
        --router localhost --port 5300 --name SortingFSM

    # Terminal 3: demo agents
    python3 -m examples.sorting.sorting_demo --router localhost --port 5300

    # Terminal 3: simulation agents
    python3 examples/sorting/sorting_demo.py --router localhost --port 5100

    # Terminal 4: parser (watch all messages)
    python3 -m umm.modules.parser --router localhost --port 5100

    # Terminal 5: send messages to drive the simulation
    python3 -m umm.tools.send --port 5100 --interactive
"""

from __future__ import annotations

import random
import sys
import threading
import time
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from umm.agent import UMMAgent
from umm.core.tlv import TLV, TLVBuffer
from umm.capability import CapabilityMixin
from umm.mixins import DebugMixin, VersionMixin
from umm.modules.timer import (ST_CONFIRMED as _ST_TIMER_CONFIRMED,
                               ST_REQUEST   as _ST_TIMER_REQUEST,
                               ST_CANCEL    as _ST_TIMER_CANCEL)

from examples.sorting.capabilities import (
    MT_CONTROL, MT_CONVEYOR, MT_PHOTOCELL, MT_BARCODE,
    MT_DIVERTER, MT_BIN,
    ST_CTRL_START, ST_CTRL_ESTOP, ST_CTRL_RESTART, ST_CTRL_CLEAR_BIN,
    ST_CONV_CMD_C1, ST_CONV_CMD_C2, ST_CONV_STATE_C1, ST_CONV_STATE_C2,
    ST_CONV_PULSE_C1, ST_CONV_PULSE_C2,
    ST_CONV_STALL_C1, ST_CONV_STALL_C2,
    ST_CONV_ACK_C1, ST_CONV_ACK_C2,
    PULSE_INTERVAL_MS, MM_PER_PULSE, BELT_LENGTH_MM, STALL_TIMEOUT_MS,
    SIM_CHANNEL,
    PULSE_CHANNEL,
    META_SORTCODE,
    ST_PC_C1_DETECTED, ST_PC_C2_DETECTED,
    ST_PC_BIN1_DETECTED, ST_PC_BIN2_DETECTED,
    ST_PC_BIN3_DETECTED, ST_PC_BIN4_DETECTED,
    ST_PC_REJECT_DETECTED,
    ST_PC_C1_CLEARED, ST_PC_C2_CLEARED,
    ST_BC_REQUEST, ST_BC_SUCCESS, ST_BC_FAILED, ST_BC_RECORD,
    META_BC_BIN_NUMBER, META_BC_TRACKING_NUM,
    ST_DIV_CMD, ST_DIV_ACTIVATED,
    ST_BIN_FULL, ST_BIN_CLEARED, ST_BIN_LEVEL, ST_BIN_SET_CAP,
    CONVEYOR_CAPABILITY, BARCODE_CAPABILITY,
    BIN_CAPABILITY, DIVERTER_CAPABILITY,
)

logger = logging.getLogger(__name__)

# ── postcode → bin mapping ────────────────────────────────────────────────────

BIN_CAPACITY = 50   # parcels per bin before FULL

# Sort code → bin mapping
# 0000-1999 → bin 1,  2000-3999 → bin 2
# 4000-5999 → bin 3,  6000-7999 → bin 4,  8000-9999 → reject
SORT_CODE_RANGES = {
    1: (0,    1999),
    2: (2000, 3999),
    3: (4000, 5999),
    4: (6000, 7999),
    # 8000-9999 → reject (bin 0)
}
SCAN_FAIL_RATE = 0.02   # 2% chance of read failure (realistic for a barcode reader)


def sort_code_to_bin(sort_code: int) -> int:
    """Map a 4-digit sort code to bin 1-4, or 0 for reject."""
    for bin_num, (lo, hi) in SORT_CODE_RANGES.items():
        if lo <= sort_code <= hi:
            return bin_num
    return 0   # reject


def random_sort_code() -> int:
    """Return a random 4-digit sort code, biased to reduce reject frequency.

    Bins 1-4 cover 0000-7999 (8000 values, 80% of range).
    Reject covers 8000-9999 (2000 values, 20% of range).
    To send only 1/3 as many to reject, we pick a bin code 2 times out of 3
    when we would otherwise land in the reject range.
    Net result: ~7% reject rate instead of ~20%.
    """
    code = random.randint(0, 9999)
    if code >= 8000 and random.random() < 2/3:
        # Redirect to a random bin range instead
        code = random.randint(0, 7999)
    return code


def random_tracking_number() -> int:
    """Return a random 6-digit tracking number (100000-999999)."""
    return random.randint(100000, 999999)


# ── conveyor simulator ────────────────────────────────────────────────────────

class ConveyorSim(CapabilityMixin, DebugMixin, VersionMixin):
    """
    Simulates both belt motors with belt encoder pulses.

    When a belt is running, publishes BeltPulse messages at PULSE_INTERVAL_MS
    intervals using the ConveyorTimer (mtype=1050). Each pulse increments a
    cumulative counter and represents MM_PER_PULSE mm of belt travel.

    If the belt is commanded ON but no pulse has been published for
    STALL_TIMEOUT_MS, a stall alarm is raised.

    Pulse consumers (visualisation, position tracking) use:
        parcel_x_mm = entry_pulse * MM_PER_PULSE
        current_x_mm = current_pulse * MM_PER_PULSE
        parcel_offset_mm = (current_pulse - entry_pulse) * MM_PER_PULSE

    Internal design — two-stage pulse pipeline
    ------------------------------------------
    The ConveyorTimer fires a raw tick on the INTERNAL subtypes below.
    Only ConveyorSim subscribes to those.  ConveyorSim increments its
    counter and re-publishes the *public* pulse (ST_CONV_PULSE_C1/C2)
    with the cumulative Int counter attached.  This keeps the public event
    clean (always carries count) and avoids the GUI or FSM seeing a
    counter-less raw tick from the timer.
    """
    CAPABILITY    = CONVEYOR_CAPABILITY
    AGENT_VERSION = "1.0.1"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    # Timer mtype for conveyor encoder pulses (from umm.conf: type=1050)
    PULSE_TIMER_MTYPE = 1050

    # Private subtypes used only as timer-tick targets — never subscribed
    # to by any external agent.  Negative to signal "internal only" by convention.
    _ST_TICK_C1 = -105  # timer fires here → ConveyorSim re-publishes as ST_CONV_PULSE_C1
    _ST_TICK_C2 = -106  # timer fires here → ConveyorSim re-publishes as ST_CONV_PULSE_C2

    def __init__(self, host: str, port: int, sim_channel: int = SIM_CHANNEL) -> None:
        self._agent      = UMMAgent(host=host, port=port,
                                    process_name='ConveyorSim',
                                    agent_mtype=MT_CONVEYOR)
        # sim_channel is used explicitly on scaffolding sends (timer requests,
        # cancels, confirmations, internal ticks).  The agent itself stays on
        # channel 0 — real-world events (state changes, pulses, acks) go to
        # the application bus.  We do NOT pass sim_channel to UMMAgent because
        # this agent has mixed traffic; the channel is chosen per-send.
        self._sim_channel = sim_channel
        self.c1_running  = False
        self.c2_running  = False
        # Cumulative pulse counters (wrap at 65535)
        self.c1_pulses   = 0
        self.c2_pulses   = 0
        # Timer ref_ids for cancellation
        self._c1_timer        = None
        self._c2_timer        = None
        self._c1_timer_msg_id = None
        self._c2_timer_msg_id = None
        # MsgRef correlation: msg_id → belt (1 or 2), cleared when response arrives
        self._pending_timer_reqs: dict = {}

    def _send(self, mtype: int, subtype: int, tlvs=None, belt: int = None,
              channel: int = 1) -> None:
        """Non-blocking send from callback thread — avoids deadlocking the event loop.

        If belt is provided, pre-consumes the next msg_id and records
        msg_id → belt in _pending_timer_reqs for correlation in _on_timer_resp.
        The msg_id is passed explicitly into _async_send so the send uses
        exactly the id we recorded — no race between peek and consume.

        channel : int
            Default 1 = application bus / Channel.APP (real-world events: state changes,
            pulses, acks).  Pass self._sim_channel only for simulation
            scaffolding (timer requests, timer cancels, tick confirmations).
        """
        loop = self._agent._loop
        if loop is None:
            return
        # Pre-consume the msg_id now (on whatever thread we're on) and pass it
        # to the coroutine so _make_msg uses the same id we recorded.
        if belt is not None:
            msg_id = self._agent._next_msg_id()
            self._pending_timer_reqs[msg_id] = belt
        else:
            msg_id = None
        async def _coro():
            try:
                await self._agent._async_send(mtype, subtype, tlvs or [], 0,
                                              msg_id=msg_id, channel=channel)
            except Exception as exc:
                self.log_error("%s._send failed mtype=%d sub=%d: %s",
                             type(self).__name__, mtype, subtype, exc)
        loop.call_soon_threadsafe(lambda: loop.create_task(_coro()))

    def run(self) -> None:
        self._agent.connect()
        self.register_capability_handler(self._agent, instance='ConveyorSim-1')
        self.register_debug_handler(self._agent, MT_CONVEYOR)
        self.register_version_handler(self._agent, MT_CONVEYOR)

        self._agent.register(MT_CONVEYOR, ST_CONV_CMD_C1, self._on_c1_cmd)
        self._agent.register(MT_CONVEYOR, ST_CONV_CMD_C2, self._on_c2_cmd)

        # Subscribe to timer confirmations (ST_CONFIRMED=103) on ch2 (CONFIRM channel).
        self._agent.register(self.PULSE_TIMER_MTYPE, _ST_TIMER_CONFIRMED,
                             self._on_timer_resp,
                             channel=2)

        # Subscribe to the INTERNAL tick subtypes the timer fires.
        # These are private to ConveyorSim — no other agent subscribes here.
        # ConveyorSim enriches each tick with a cumulative counter and
        # re-publishes it as the public ST_CONV_PULSE_C1/C2 event.
        # Subscribed on sim_channel — the ticks are simulation scaffolding.
        self._agent.register(MT_CONVEYOR, self._ST_TICK_C1, self._on_c1_tick,
                             channel=self._sim_channel)
        self._agent.register(MT_CONVEYOR, self._ST_TICK_C2, self._on_c2_tick,
                             channel=self._sim_channel)

        self.log_info("ConveyorSim running — pulse interval=%dms, %dmm/pulse",
                      PULSE_INTERVAL_MS, MM_PER_PULSE)
        self._agent.run()

    def _on_c1_cmd(self, msg) -> None:
        running = self._extract_bool(msg)
        self.c1_running = running
        self.log_info("C1 → %s", "RUNNING" if running else "STOPPED")
        self._send_state(ST_CONV_STATE_C1, running, "cmd")
        self._send_ack(ST_CONV_ACK_C1, True, "")
        if running:
            # Start the pulse timer only if one isn't already running or pending.
            # A "start" to an already-running belt is a no-op — re-issuing it must
            # not cancel and re-request the timer.  (Read-on-the-fly: the belt
            # runs continuously, so it is started once and left alone.)  This also
            # stops a second continuous timer from stacking — running at double
            # speed — if start/start arrives before the first confirmation returns.
            if self._c1_timer is None and self._c1_timer_msg_id is None:
                self._start_pulse_timer(belt=1)
        else:
            self._stop_pulse_timer(belt=1)

    def _on_c2_cmd(self, msg) -> None:
        running = self._extract_bool(msg)
        self.c2_running = running
        self.log_info("C2 → %s", "RUNNING" if running else "STOPPED")
        self._send_state(ST_CONV_STATE_C2, running, "cmd")
        self._send_ack(ST_CONV_ACK_C2, True, "")
        if running:
            # See _on_c1_cmd: a start to an already-running belt is a no-op.
            if self._c2_timer is None and self._c2_timer_msg_id is None:
                self._start_pulse_timer(belt=2)
        else:
            self._stop_pulse_timer(belt=2)

    def _on_c1_tick(self, msg) -> None:
        """Internal timer tick for C1 — increment counter and publish the public pulse."""
        self.c1_pulses = (self.c1_pulses + 1) % 65536
        self.log_debug("C1 tick ch=%d → pulse counter=%d", msg.channel, self.c1_pulses)
        self._publish_pulse(ST_CONV_PULSE_C1, self.c1_pulses, belt_id=1)

    def _on_c2_tick(self, msg) -> None:
        """Internal timer tick for C2 — increment counter and publish the public pulse."""
        self.c2_pulses = (self.c2_pulses + 1) % 65536
        self.log_debug("C2 tick ch=%d → pulse counter=%d", msg.channel, self.c2_pulses)
        self._publish_pulse(ST_CONV_PULSE_C2, self.c2_pulses, belt_id=2)

    def _on_timer_resp(self, msg) -> None:
        """Capture timer ref_id from confirmation so we can cancel later.

        The timer sends ST_CONFIRMED (subtype=103) containing:
          Int(ref)    — assigned timer reference
          MsgRef(corr) — (router, attach_id, msg_id) of the original request

        We recorded msg_id → belt in _pending_timer_reqs when we sent the
        request, so we can unambiguously match the confirmation to a belt.
        """
        import struct
        from umm.core.tlv import decode_all, TLV_INT, TLV_MSGREF
        if not msg.tdata.value:
            return

        ref      = None
        msg_id   = None
        for tlv in decode_all(msg.tdata.value):
            if tlv.type_id == TLV_INT and ref is None:
                ref = struct.unpack('!i', tlv.value)[0]
            elif tlv.type_id == TLV_MSGREF and len(tlv.value) >= 12:
                # MsgRef layout: router_id(4) attach_id(4) msg_id(4)
                msg_id = struct.unpack('!I', tlv.value[8:12])[0]

        if ref is None:
            self.log_warn("_on_timer_resp: no Int ref in ST_CONFIRMED message — ignoring")
            return

        belt = self._pending_timer_reqs.pop(msg_id, None)
        if belt is None and msg_id is not None:
            # Try signed/unsigned mismatch correction
            alt_id = msg_id if msg_id < 2**31 else msg_id - 2**32
            belt = self._pending_timer_reqs.pop(alt_id, None)
        if belt is None:
            # Last resort: if only one pending request, use it
            if len(self._pending_timer_reqs) == 1:
                only_key = next(iter(self._pending_timer_reqs))
                belt = self._pending_timer_reqs.pop(only_key)
                self.log_warn("Timer resp: msg_id mismatch (%s vs %s), using only pending",
                              msg_id, only_key)
            else:
                self.log_warn("Timer response msg_id=%s not in pending — ignoring ref=%d",
                              msg_id, ref)
                return

        if belt == 1:
            self._c1_timer = ref
        else:
            self._c2_timer = ref
        self.log_debug("Belt C%d timer confirmed ref=%d (corr msg_id=%s)", belt, ref, msg_id)

    def _start_pulse_timer(self, belt: int) -> None:
        """
        Request the ConveyorTimer to fire a tick every PULSE_INTERVAL_MS.

        The request travels on ch1 (APP) so the timer receives it normally.
        The desired tick channel (ch128 = SIM) is encoded inside the Msg{} TLV
        header: mtype(4) + subtype(4) + channel(2) + flags(2).  The timer fires
        the tick on that channel.  ConveyorSim subscribes to the tick on ch128.
        The confirmation goes back on ch2 (CONFIRM channel).

        If a timer is already running or pending for this belt, it is cancelled
        first.  This prevents double-speed ticks when start/stop/start arrives
        faster than the confirmation round-trip (e.g. BinFull → BinCleared).
        """
        # Cancel any existing timer before requesting a new one.
        # This handles the case where stop+start arrive before the confirmation
        # for the first start has come back — without this guard the second
        # start stacks a second continuous timer and the belt runs at 2× speed.
        ref        = self._c1_timer        if belt == 1 else self._c2_timer
        req_msg_id = self._c1_timer_msg_id if belt == 1 else self._c2_timer_msg_id
        if ref is not None or req_msg_id is not None:
            self.log_info("Belt C%d start: existing timer (ref=%s msg_id=%s) — cancelling first",
                          belt, ref, req_msg_id)
            self._stop_pulse_timer(belt)
        import struct
        from umm.core.tlv import TLV, TLVBuffer, TLV_INT, TLV_MSG
        from umm.types.builtin import UTimeType

        tick_subtype = self._ST_TICK_C1 if belt == 1 else self._ST_TICK_C2
        interval_s   = PULSE_INTERVAL_MS / 1000.0

        # Inner message: mtype(4) subtype(4) channel(2) flags(2) — tick fires on sim channel
        inner     = struct.pack('!iiHH', MT_CONVEYOR, tick_subtype, self._sim_channel, 0)
        inner_tlv = TLV(type_id=TLV_MSG, value=inner)

        # Build timer request: UTime(interval) Int(count=0=continuous) Msg{...}
        utime_t = UTimeType()
        buf     = TLVBuffer()
        buf.add(utime_t.make_tlv(interval_s))
        buf.add(TLV(type_id=TLV_INT, value=struct.pack('!i', 0)))  # 0 = continuous
        buf.add(inner_tlv)

        msg_id = self._agent._peek_msg_id()
        if belt == 1:
            self._c1_timer_msg_id = msg_id
        else:
            self._c2_timer_msg_id = msg_id
        self._send(mtype=self.PULSE_TIMER_MTYPE, subtype=_ST_TIMER_REQUEST,
                   tlvs=list(buf), belt=belt)
        self.log_info("Belt C%d tick timer requested (%.0fms, subtype=%d, tick_ch=%d)",
                      belt, PULSE_INTERVAL_MS, tick_subtype, self._sim_channel)

    def _stop_pulse_timer(self, belt: int) -> None:
        """Cancel the pulse timer for this belt.

        NOTE: we intentionally do NOT clear _c1/_c2_timer_msg_id here.
        The msg_id must stay in _pending_timer_reqs until the confirmation
        arrives (or is known not to arrive) so that _on_timer_resp can match
        it.  If we cleared it now and _start_pulse_timer were called before
        the confirmation came back, _on_timer_resp would have two pending
        entries and could assign the old confirmation's ref to the new belt
        timer — leaving both running simultaneously (double-speed).

        The IDs are cleared in _on_timer_resp when the confirmation is
        matched, or in _start_pulse_timer before issuing the new request
        (which cancels any outstanding pending first via this method).
        """
        import struct
        from umm.core.tlv import TLV, TLV_INT

        ref        = self._c1_timer        if belt == 1 else self._c2_timer
        req_msg_id = self._c1_timer_msg_id if belt == 1 else self._c2_timer_msg_id
        if ref is None and req_msg_id is None:
            self.log_warn("Belt C%d stop requested but no timer ref — timer may still be running", belt)
            return

        cancel_tlvs = []
        if ref is not None:
            cancel_tlvs.append(TLV(type_id=TLV_INT, value=struct.pack('!i', ref)))
        if req_msg_id is not None:
            from umm.types.builtin import MsgRefType as _MsgRef
            # RouterId 0,0 and attach_id 0 — timer matches on msg_id only
            cancel_tlvs.append(_MsgRef.make_tlv(0, 0, req_msg_id))
        self._send(mtype=self.PULSE_TIMER_MTYPE, subtype=_ST_TIMER_CANCEL,
                   tlvs=cancel_tlvs)

        # Clear the ref (timer is being cancelled) but leave msg_id in
        # _pending_timer_reqs so _on_timer_resp can still match and discard
        # a late-arriving confirmation rather than assigning it to the belt.
        if belt == 1:
            self._c1_timer = None
            # Remove from pending so a late confirmation is silently dropped
            if self._c1_timer_msg_id is not None:
                self._pending_timer_reqs.pop(self._c1_timer_msg_id, None)
                self._pending_timer_reqs.pop(
                    self._c1_timer_msg_id - 2**32
                    if self._c1_timer_msg_id >= 2**31 else
                    self._c1_timer_msg_id + 2**32,
                    None)
            self._c1_timer_msg_id = None
        else:
            self._c2_timer = None
            if self._c2_timer_msg_id is not None:
                self._pending_timer_reqs.pop(self._c2_timer_msg_id, None)
                self._pending_timer_reqs.pop(
                    self._c2_timer_msg_id - 2**32
                    if self._c2_timer_msg_id >= 2**31 else
                    self._c2_timer_msg_id + 2**32,
                    None)
            self._c2_timer_msg_id = None
        self.log_info("Belt C%d pulse timer cancelled (ref=%s msg_id=%s)",
                      belt, ref, req_msg_id)

    def _publish_pulse(self, subtype: int, count: int, belt_id: int) -> None:
        """Publish a belt encoder pulse event.

        Pulses go out on PULSE_CHANNEL (127), not the channel-1 application bus,
        so a parser watching channel 1 isn't flooded by them.  Subscribers that
        want pulses register on channel 127 (or channel 0 = ALL, as the GUI does).
        """
        import struct
        from umm.core.tlv import TLV, TLV_INT
        self.log_debug("Publishing pulse subtype=%d count=%d belt=%d", subtype, count, belt_id)
        self._send(
            mtype  = MT_CONVEYOR,
            subtype= subtype,
            tlvs   = [TLV(type_id=TLV_INT, value=struct.pack('!i', count)),
                      TLV(type_id=TLV_INT, value=struct.pack('!i', belt_id))],
            channel= PULSE_CHANNEL,
        )

    def _extract_bool(self, msg) -> bool:
        from umm.core.tlv import decode_all
        from umm.core.registry import registry as _reg
        if msg.tdata.value:
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == 7:
                    h = _reg.get_by_id(7)
                    if h:
                        return bool(h.unpack(tlv.value))
                    # Fallback: last byte of 4-byte NBO bool
                    return bool(tlv.value[-1]) if tlv.value else False
        return False

    def _send_state(self, subtype: int, running: bool, reason: str) -> None:
        buf = TLVBuffer()
        buf.add(TLV(type_id=7, value=bytes([1 if running else 0])))
        buf.add(TLV(type_id=8, value=reason.encode() + b'\x00'))
        self._send(mtype=MT_CONVEYOR, subtype=subtype, tlvs=list(buf))

    def _send_ack(self, subtype: int, ok: bool, reason: str) -> None:
        buf = TLVBuffer()
        buf.add(TLV(type_id=7, value=bytes([1 if ok else 0])))
        if reason:
            buf.add(TLV(type_id=8, value=reason.encode() + b'\x00'))
        self._send(mtype=MT_CONVEYOR, subtype=subtype, tlvs=list(buf))


# ── barcode simulator ─────────────────────────────────────────────────────────

class BarcodeSimulator(CapabilityMixin, DebugMixin, VersionMixin):
    """
    Simulates the barcode reader.
    When FSM sends a scan request (mtype=1004, subtype=101), waits 0.75s
    then publishes success (random postcode) or failure.
    """
    CAPABILITY    = BARCODE_CAPABILITY
    AGENT_VERSION = "1.0.1"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    def __init__(self, host: str, port: int) -> None:
        self._agent    = UMMAgent(host=host, port=port,
                                  process_name='BarcodeSimulator',
                                  agent_mtype=MT_BARCODE)
        self._parcel_id = 1
        self._scanning  = False

    def _send(self, mtype: int, subtype: int, tlvs=None) -> None:
        """Non-blocking send from callback thread — avoids deadlocking the event loop."""
        loop = self._agent._loop
        if loop is None:
            return
        async def _coro():
            try:
                await self._agent._async_send(mtype, subtype, tlvs or [], 0)
            except Exception as exc:
                self.log_error("%s._send failed mtype=%d sub=%d: %s",
                             type(self).__name__, mtype, subtype, exc)
        loop.call_soon_threadsafe(lambda: loop.create_task(_coro()))

    def run(self) -> None:
        self._agent.connect()
        self.register_capability_handler(self._agent, instance='BarcodeReader-1')
        self.register_debug_handler(self._agent, MT_BARCODE)
        self.register_version_handler(self._agent, MT_BARCODE)
        self._agent.register(MT_BARCODE, ST_BC_REQUEST, self._on_scan_request)
        self.log_info("BarcodeSimulator running (fail rate=%.0f%%)",
                      SCAN_FAIL_RATE * 100)
        self._agent.run()

    def _on_scan_request(self, msg) -> None:
        if self._scanning:
            self.log_warn("Scan already in progress — ignoring duplicate request")
            return
        self._scanning = True
        parcel_id = self._parcel_id
        self._parcel_id += 1

        def do_scan() -> None:
            import struct as _struct
            time.sleep(0.75)  # simulate scan time
            self._scanning = False
            sort_code    = random_sort_code()
            tracking_num = random_tracking_number()
            bin_num      = sort_code_to_bin(sort_code)

            if random.random() < SCAN_FAIL_RATE:
                self.log_info("Parcel %d — SCAN FAILED  tracking=%06d",
                              parcel_id, tracking_num)
                self._send(
                    mtype   = MT_BARCODE,
                    subtype = ST_BC_FAILED,
                    tlvs    = [TLV(type_id=2,
                                   value=_struct.pack('!i', parcel_id)),
                               TLV(type_id=2,
                                   value=_struct.pack('!i', tracking_num))])
                bin_num = 0  # reject
            else:
                self.log_info("Parcel %d — sort=%04d → bin %d  tracking=%06d",
                              parcel_id, sort_code, bin_num, tracking_num)
                # ST_BC_SUCCESS carries the sort code tagged with META_SORTCODE,
                # so the FSM's range rules key onto it (router meta-keyed match)
                # regardless of position — two conditions (>= lo, <= hi) on this
                # one field AND together into a range.
                self._send(mtype=MT_BARCODE, subtype=ST_BC_SUCCESS,
                           tlvs=[TLV(type_id=2,
                                     value=_struct.pack('!i', sort_code),
                                     meta=META_SORTCODE)])

            # ST_BC_RECORD: full audit record — sent after every scan.
            # Carries sort_code (0 if failed), bin (0=reject), tracking_num.
            # Each Int is meta-tagged so a subscriber can select a field by key
            # rather than by position (the GUI still reads them positionally).
            rec = TLVBuffer()
            rec.add(TLV(type_id=2, value=_struct.pack('!i', sort_code),    meta=META_SORTCODE))
            rec.add(TLV(type_id=2, value=_struct.pack('!i', bin_num),      meta=META_BC_BIN_NUMBER))
            rec.add(TLV(type_id=2, value=_struct.pack('!i', tracking_num), meta=META_BC_TRACKING_NUM))
            self._send(mtype=MT_BARCODE, subtype=ST_BC_RECORD, tlvs=list(rec))

        threading.Thread(target=do_scan, daemon=True,
                         name=f'scan-{parcel_id}').start()


# ── bin monitor ───────────────────────────────────────────────────────────────

class BinMonitor(CapabilityMixin, DebugMixin, VersionMixin):
    """
    Monitors bin levels. Counts parcels entering each bin via photocell events.
    Publishes BinFull when a bin reaches capacity.
    Publishes BinCleared when operator clears a bin.
    """
    CAPABILITY    = BIN_CAPABILITY
    AGENT_VERSION = "1.0.1"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    def __init__(self, host: str, port: int,
                 capacity: int = BIN_CAPACITY) -> None:
        self._agent    = UMMAgent(host=host, port=port,
                                  process_name='BinMonitor',
                                  agent_mtype=MT_BIN)
        self._capacity = capacity
        self._counts   = {1: 0, 2: 0, 3: 0, 4: 0, 0: 0}   # 0=reject
        self._full     = set()

    def _send(self, mtype: int, subtype: int, tlvs=None) -> None:
        """Non-blocking send from callback thread — avoids deadlocking the event loop."""
        loop = self._agent._loop
        if loop is None:
            return
        async def _coro():
            try:
                await self._agent._async_send(mtype, subtype, tlvs or [], 0)
            except Exception as exc:
                self.log_error("%s._send failed mtype=%d sub=%d: %s",
                             type(self).__name__, mtype, subtype, exc)
        loop.call_soon_threadsafe(lambda: loop.create_task(_coro()))

    def run(self) -> None:
        self._agent.connect()
        self.register_capability_handler(self._agent, instance='BinMonitor-1')

        # Watch parcels entering each bin
        pc_subs = {
            ST_PC_BIN1_DETECTED:    1,
            ST_PC_BIN2_DETECTED:    2,
            ST_PC_BIN3_DETECTED:    3,
            ST_PC_BIN4_DETECTED:    4,
            ST_PC_REJECT_DETECTED:  0,
        }
        for subtype, bin_num in pc_subs.items():
            self._agent.register(
                MT_PHOTOCELL, subtype,
                lambda msg, b=bin_num: self._parcel_entered(b))

        # Watch for operator clearing bins
        self._agent.register(MT_CONTROL, ST_CTRL_CLEAR_BIN,
                             self._on_bin_cleared)
        # Allow GUI (or any agent) to change capacity at runtime
        self._agent.register(MT_BIN, ST_BIN_SET_CAP,
                             self._on_set_capacity)
        self.register_debug_handler(self._agent, MT_BIN)
        self.register_version_handler(self._agent, MT_BIN)
        self.log_info("BinMonitor running (capacity=%d)", self._capacity)
        self._agent.run()

    def _parcel_entered(self, bin_num: int) -> None:
        self._counts[bin_num] += 1
        count = self._counts[bin_num]
        self.log_info("Bin %d: %d/%d parcels",
                    bin_num, count, self._capacity)

        # Publish level update
        self._send_level(bin_num)

        # Check if full
        if count >= self._capacity and bin_num not in self._full:
            self._full.add(bin_num)
            self.log_warn("Bin %d FULL", bin_num)
            self._send(
                mtype   = MT_BIN,
                subtype = ST_BIN_FULL,
                tlvs    = [TLV(type_id=2,
                               value=__import__('struct').pack('!i', bin_num))])

    def _on_bin_cleared(self, msg) -> None:
        import struct
        bin_num = 0
        if msg.tdata.value:
            from umm.core.tlv import decode_all
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == 2:
                    bin_num = struct.unpack('!i', tlv.value)[0]
        if bin_num not in self._counts:
            return
        self._counts[bin_num] = 0
        self._full.discard(bin_num)
        self.log_info("Bin %d cleared", bin_num)
        self._send_level(bin_num)
        self._send(
            mtype   = MT_BIN,
            subtype = ST_BIN_CLEARED,
            tlvs    = [TLV(type_id=2,
                           value=__import__('struct').pack('!i', bin_num))])

    def _on_set_capacity(self, msg) -> None:
        import struct
        if msg.tdata.value:
            from umm.core.tlv import decode_all
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == 2:
                    new_cap = struct.unpack('!i', tlv.value)[0]
                    if new_cap > 0:
                        self._capacity = new_cap
                        self.log_info("Bin capacity updated to %d", self._capacity)
                        # Re-check all bins — some may now be full or no longer full
                        for bn, count in self._counts.items():
                            if count >= self._capacity and bn not in self._full:
                                self._full.add(bn)
                                self._send(mtype=MT_BIN, subtype=ST_BIN_FULL,
                                           tlvs=[TLV(type_id=2,
                                                     value=struct.pack('!i', bn))])
                            elif count < self._capacity and bn in self._full:
                                self._full.discard(bn)
                        # Republish all levels with new capacity
                        for bn in self._counts:
                            self._send_level(bn)

    def _send_level(self, bin_num: int) -> None:
        import struct
        buf = TLVBuffer()
        buf.add(TLV(type_id=2, value=struct.pack('!i', bin_num)))
        buf.add(TLV(type_id=2, value=struct.pack('!i', self._counts[bin_num])))
        buf.add(TLV(type_id=2, value=struct.pack('!i', self._capacity)))
        self._send(mtype=MT_BIN, subtype=ST_BIN_LEVEL,
                         tlvs=list(buf))


# ── diverter simulator ────────────────────────────────────────────────────────

class DiverterSim(CapabilityMixin, DebugMixin, VersionMixin):
    """
    Simulates the diverter arms.
    Fires 0.5s after receiving a route command, then publishes Activated.
    Also simulates the photocell detecting the parcel entering the bin.
    """
    CAPABILITY    = DIVERTER_CAPABILITY
    AGENT_VERSION = "1.0.1"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    def __init__(self, host: str, port: int) -> None:
        self._agent = UMMAgent(host=host, port=port,
                               process_name='DiverterSim',
                               agent_mtype=MT_DIVERTER)

    def _send(self, mtype: int, subtype: int, tlvs=None) -> None:
        """Non-blocking send from callback thread — avoids deadlocking the event loop."""
        loop = self._agent._loop
        if loop is None:
            return
        async def _coro():
            try:
                await self._agent._async_send(mtype, subtype, tlvs or [], 0)
            except Exception as exc:
                self.log_error("%s._send failed mtype=%d sub=%d: %s",
                             type(self).__name__, mtype, subtype, exc)
        loop.call_soon_threadsafe(lambda: loop.create_task(_coro()))

    def run(self) -> None:
        self._agent.connect()
        self.register_capability_handler(self._agent, instance='Diverter-1')
        self.register_debug_handler(self._agent, MT_DIVERTER)
        self.register_version_handler(self._agent, MT_DIVERTER)
        self._agent.register(MT_DIVERTER, ST_DIV_CMD, self._on_route)
        self.log_info("DiverterSim running")
        self._agent.run()

    def _on_route(self, msg) -> None:
        import struct
        bin_num = 1
        if msg.tdata.value:
            from umm.core.tlv import decode_all
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == 2:
                    bin_num = struct.unpack('!i', tlv.value)[0]

        def fire() -> None:
            if bin_num == 0:
                # Reject bin is at the end of C2 — no diverter arm, no PC to fire.
                # PC_REJ is fired by the GUI when the parcel animation reaches
                # yC2Bot — that is the authoritative count moment (same as PC_BIN*).
                self.log_info("Reject: parcel will reach end of belt — PC fired by GUI")
            else:
                time.sleep(0.2)   # diverter arm travel time
                self.log_info("Diverter activated → bin %d", bin_num)

                # Publish diverter activated event
                self._send(
                    mtype   = MT_DIVERTER,
                    subtype = ST_DIV_ACTIVATED,
                    tlvs    = [TLV(type_id=2,
                                   value=struct.pack('!i', bin_num))])
                # Note: PC_BIN* is fired by the GUI when the parcel animation
                # reaches the arm position — that is the authoritative count moment.

        threading.Thread(target=fire, daemon=True,
                         name=f'divert-{bin_num}').start()



# ── main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    import argparse
    logging.basicConfig(
        level   = logging.INFO,
        format  = '%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    p = argparse.ArgumentParser(description='Sorting machine simulation agents')
    p.add_argument('--router', default='localhost')
    p.add_argument('--port',   type=int, default=5000)
    p.add_argument('--name',   default='SortingAgents',
                   help='Process name shown on the bus')
    p.add_argument('--debug',  action='store_true')
    args = p.parse_args()

    agents = [
        ConveyorSim(args.router, args.port),
        BarcodeSimulator(args.router, args.port),
        BinMonitor(args.router, args.port),
        DiverterSim(args.router, args.port),
    ]
    for agent in agents:
        agent._debug_flag = args.debug

    threads = []
    for agent in agents:
        agent_name = type(agent).__name__

        def make_target(a, name):
            def target():
                try:
                    a.run()
                    a.log_warn("%s thread exited normally", name)
                except Exception:
                    a.log_error("AGENT CRASH — %s thread raised:", name)
            return target

        t = threading.Thread(target=make_target(agent, agent_name),
                             name=agent_name,
                             daemon=True)
        t.start()
        threads.append(t)
        time.sleep(0.1)   # stagger connections

    print(f"\nSorting machine simulation running on {args.router}:{args.port}")
    print("Agents:", ", ".join(type(a).__name__ for a in agents))
    print()
    print("To drive the simulation, in another terminal:")
    print(f"  python3 -m umm.tools.send --port {args.port} --interactive")
    print()
    print("Commands:")
    print("  1001 1            Start button")
    print("  1001 2            E-Stop")
    print("  1001 3            Restart after e-stop")
    print("  1001 4 Int 1      Clear bin 1")
    print("  1003 1            Parcel detected at feed entry (place parcel)")
    print("  1003 2            Parcel detected at barcode reader")
    print()

    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        print("\nSorting simulation stopped.")


if __name__ == '__main__':
    main()