# SESSION 35 NOTES — Chess playback, GUI panel, divergence fix, manuals, teaching ladder

## 1. Playback agent (`examples/chess/playback.py`, mtype 2003)

Replays a parser `--record` JSON-lines recording of a game **at the game
level**: extracts the story (start FEN from NewGame or a pre-move
BoardState; the MoveConfirmed sequence with timestamps; resignation /
agreed-draw endings from the RESIGN / DRAW_ACCEPT input records) and
re-proposes it through the rules agent, waiting for each MoveConfirmed
before pacing the next. The rules agent stays the single source of
truth; every observer animates as if live. Raw verbatim replay remains
`umm.tools.send --replay`'s job — deliberate separation. No python-chess
dependency.

Pacing: `--speed` (multiplier on recorded gaps), `--interval` (fixed
s/move, overrides gaps), `--max-gap` (cap on thinking pauses), `--loop`,
`--hold` (wait for PbPlay). Runtime control on mtype 2003:
PbLoad(100, Char path meta=recording-path) / PbPlay(101) / PbPause(102) /
PbStep(103) / PbSpeed(104, Float meta=speed and/or meta=seconds; seconds
0 clears interval) / PbRestart(105) / PbStatus(106, Char json — state /
file / game / move / total / speed / interval / last / error). The wait
loop polls in 250 ms quanta so a Speed message re-times a gap already in
progress.

Behaviours worth remembering: a mid-file NewGame restarts the story;
standard-start FEN collapses to no TLV; several games with moves in one
file is a hard error unless `--game` picks; a rejected move or missing
confirm → ERROR state with a human reason ("is the rules agent
running?"). PLAY from DONE = replay from move 0.

Started life as `playback_agent.py`; renamed to `playback.py` at Phil's
request. Capabilities additions: the seven 2003 subtypes,
META_REC_PATH = Char 1007 'recording-path', META_SPEED = Float 1001
'speed', PLAYBACK_CAPABILITY declaration. chess.conf subtype names
aligned (had stale pre-implementation numbering: 105 was PbStatus).

## 2. runumm integration

`[agent.chess-playback]` in umm.conf — group `chess-playback`,
after=manual, type 2003, **no restart policy on purpose** (an
auto-restarted playback replays from move 0; restart it deliberately).
Usage:
    runumm start chess-playback -- --file game.json --speed 2
    runumm start chess-playback            # no file: waits for PbLoad
Recording a game:
    runumm start parser -- --channel 1 --record game.json
`umm_ctl validate` passes. Chess section comment in umm.conf updated.

## 3. Chess GUI playback panel (`umm_gui/chess.html`)

Hidden until the first PbStatus proves a playback agent is attached
(same presence philosophy as the rules banner); pure remote control —
all state lives in the agent. Restart / Play-Pause toggle (label becomes
"Replay" at DONE) / Step, a single pace select covering both modes
(¼×–8× recorded → Float meta=speed + Float 0 meta=seconds; 0.5–5 s/move
→ Float meta=seconds), file path + Load (PbLoad by path — the path is on
the *agent's* machine), progress bar, move x/n with last SAN, error
state in red. Buttons enable/disable per state. New tlvFloat() helper;
MT_PB constants added.

## 4. State-divergence detection (the intermittent-GUI bug)

Phil's symptom: playing black, pieces flick back with no move options;
parser showed LegalReq(square 62)/LegalResp "[]"; later: ALL moves slow,
previously fine. Diagnosis: the GUI only queries from S.MY_TURN, so its
FEN said black to move while the rules agent's board disagreed — a
knight on g8 with the move always has f6/h6. State divergence, not a
gesture bug. Prime suspects: (a) rules agent restarted
(restart=always) and lost its in-memory games — self.game(1) silently
recreates at standard start; (b) leftover game state from playback
tests; (c) **two ChessRules instances** with divergent boards — this
one also explains "all moves slow" (every proposal gets a confirm from
one agent AND a reject from the other; every legal query gets two
answers, last writer wins). NOT CONFIRMED at session end — Phil to
check: `ps aux | grep rules_agent`, `runumm status` (PID flapping?),
parser tell-tale = a ,104 rejection paired with every confirmed move.

Fix shipped regardless (divergence is now visible + self-healing):
- rules_agent.py: every LegalResp carries a third TLV,
  Char(board.fen(), meta=fen) — the authority's actual position.
- chess.html: LegalResp handler compares authFen against own fen; on
  mismatch drops the selection and calls resyncFromAuthority() —
  banner + StateReq — **rate-limited to one per 3 s** (with two rules
  agents an unlimited resync would ping-pong StateReq forever).
  Diagnostic: if the out-of-sync banner keeps reappearing after
  resync, there are almost certainly two rules agents attached.

## 5. Tests (all at project root)

- `test_chess_playback.py` — 35 checks, agent level. Part 1: loader unit
  tests on synthetic recordings (standard/custom/BoardState-pinned
  starts, resignation, multi-game ambiguity, mid-file NewGame restart,
  junk lines). Part 2: live router + real rules agent — plays scholar's
  mate, replays it, exercises pause/step/speed/restart, resignation
  ending replayed.
- `test_chess_gui_playback.py` — 14 checks over WebSocket against the
  real GUI server, sending EXACTLY what chess.html sends (Float TLVs,
  Char quote-strip convention): load-by-path → READY, interval speed,
  full replay to DONE with progress/last-SAN, replay-from-done, pause,
  plus the four divergence checks (LegalResp carries standard-start FEN
  on a fresh game; g8 empty on white's turn; [g8f6,g8h6] + advanced FEN
  after 1.e4).
- Test-writing lessons: (1) control messages MUST come from a different
  agent — dont_send_self filters an agent's own sends; (2) GAME_OVER
  from a previous game can land after a clear() — wait for the
  *expected* result tuple, not "any game over"; (3) a 0.05 s/move replay
  finishes before a Pause lands — slow the pace before pausing in tests.

## 6. Mac environment issue (resolved path given)

`runumm start chess` failed: python-chess installed into a different
Python than runumm's `python3` (Homebrew 3.14 —
/opt/homebrew/opt/python@3.14/bin/python3.14, printed by the error
itself). Recommended fix: pin `python = .venv/bin/python3` in umm.conf
[settings] (umm_ctl uses cfg.python verbatim, line ~816) and install
python-chess + websockets into the venv; immune to Homebrew version
bumps silently emptying site-packages. Not yet confirmed applied.

## 7. Manual additions (`UMM_Manual_Chess_Additions.docx`)

Vol 3 gains **Appendix C — The Chess Demo** (after B — Skeletons),
mirroring the sorting appendix: overview (chess = UMM outside the
control loop), Table C.1 (mtypes 2000–2003), the single-authority
pattern, the service channel (incl. the new FEN-on-LegalResp divergence
detection), the machine player, playback (contrasted with send
--replay, ref Vol 2 §8.11), Running it. Part 2 = four exact
before/after edits: Vol 1 §1.3 two→three running examples; Vol 1 §6.4
bullet; the 1000+ mtype-namespace rows in Vol 1's appendix and Vol 2
Appendix A add "chess 2000–2003" AND correct sorting to 1001–1007
(stale since the feeder; Vol 3 Table A.1 caption already right).
Verified facts: engine protocol mtype is 2002 (2005/2006 in umm.conf
are attach identities). Vol 2 Appendix F deliberately not extended —
it scopes itself to system/control/supplied-service messages; demos
aren't catalogued (sorting isn't either). PDFs are made with Apple
Pages, so the deliverable is paste-ready content, not regenerated PDFs.

## 8. Teaching ladder (`UMM_Teaching_Projects.docx`)

"UMM in the Classroom — Six Graded Projects", 5 pp — the skeleton for
the Teacher's Manual (open item since S34). Frame: the design stage IS
the lesson; the message catalogue is the contract and the marked
artefact; each student owns one agent. Ladder: 1 Quiz Buzzer
(pub/sub, router ordering answers "who buzzed first"), 2 Weather
Stations (metas, range matching, no threshold code in the alarm),
3 Traffic Lights (.fsm, safety dimension, event latching), 4 Café
Orders (request/response, channels, capabilities, claim arbitration),
5 Battleship (authority pattern + hidden information via channels as
visibility; chess demo = answer key), 6 Airport Baggage (capstone:
safety FSMs, DB, feed agent, supervisor, bridged routers as two
terminals; sorting demo = answer key). Suggested mtype blocks
3000/3010/…/3050–3059 teach namespace discipline. Closing section on
assessing the catalogue before code exists.

## Open items carried / new

1. **Root-cause the divergence** on Phil's machine (duplicate
   ChessRules vs crash-loop) — evidence commands in §4.
2. Confirm the venv pin in umm.conf [settings] on the Mac.
3. Browser smoke test: the playback panel (appears on PbStatus,
   pace select both modes, Load by path) + the out-of-sync banner.
4. C router port still needs the `_send_confirm` reg_id fix (from S34).
5. Chess meta/mtype names for the generic GUI / umm_names.conf (S34).
6. Manuals: paste Appendix C + the four edits into the Pages sources;
   TOC entry for Vol 3.
7. Teacher's Manual proper: expand the six-project ladder (worked
   catalogue for P1 as the exemplar, marking rubrics, lesson plans).
8. Possible future: rules-agent game persistence (would remove the
   biggest divergence source); catalogue the chess protocol in Vol 2
   Appendix F style if ever wanted (chess_protocol_spec.md has the
   contracts).

## Files changed this session

- NEW  examples/chess/playback.py (renamed from playback_agent.py)
- MOD  examples/chess/capabilities.py (2003 subtypes, metas, capability)
- MOD  examples/chess/chess.conf (playback names aligned, new metas)
- MOD  examples/chess/rules_agent.py (FEN on LegalResp)
- MOD  umm_gui/chess.html (playback panel; divergence resync)
- MOD  umm.conf (chess-playback entry + section comment)
- NEW  test_chess_playback.py (35 checks)
- NEW  test_chess_gui_playback.py (14 checks)
- NEW  UMM_Manual_Chess_Additions.docx (Vol 3 App C + 4 edits)
- NEW  UMM_Teaching_Projects.docx (six-project ladder)
