# SESSION 36 NOTES — GUI chapter (Vol 3 Ch 8), template.html, C router confirm path

## 0. Carry-over status at session start

Items 1–3 and 6 from Session 35 confirmed done by Phil (Mac GUI bug,
venv pin, playback panel smoke test, Appendix C pasted). Item 4 (C
router confirm) done this session — see §4. Remaining from the old
list: expanding the teaching ladder into the Teacher's Manual proper.

## 1. Volume 3 Chapter 8 — Writing a GUI

The manuals had no section on writing a GUI; the whole GUI layer was
folklore spread across five HTML files. New **Chapter 8, Writing a
GUI**, placed with the Python material (Phil's call), bumping The C
Implementation → 9 and Writing a Match Plugin → 10.

Chapter contents: 8.1 How a Page Reaches the Bus (one port serves
HTTP + WS; each tab attaches as its **own agent**; any `.html` dropped
into `umm_gui/` is served at `/<name>.html` with no server change —
the generic fallback route is the deployment story; named aliases like
`/chess` are optional one-liners in server.py). 8.2 The JSON Protocol
(actions table: send / register / unregister + the service actions;
frames table: status / registered / message / sent / error; outbound
TLV spec `{type_id, value, meta, match}` — value always text, packed
server-side, **flat only**, no nested Msg from the page; inbound TLVs
arrive decoded with type_name / meta_name / children; the Char
quote-strip convention). 8.3 The Standard Page Pattern (constants
mirror the .conf → tlv helpers + send() → getTlv → onMsg dispatch →
connect() with register-on-open and 3 s auto-reconnect; conscious
choices: dont_send_self false for log pages / true for control pages;
wide-subscription-plus-JS-dispatch vs channel discipline). 8.4 The
Template (walkthrough + run instructions). 8.5 Patterns from the
Supplied GUIs (state lives in the agents / page is a remote control;
presence detection; authority resync; UI plumbing on its own channel).

**Renumbering sweep**: checked all three volumes. Vols 1–2 refer to
Volume 3 only by name, never by chapter number — nothing outside Vol 3
changes. Inside Vol 3: ten heading edits (8→9, 8.1–8.4→9.1–9.4,
9→10, 9.1–9.4→10.1–10.4) plus ONE body edit — Ch 3 custom types,
"§9 of this volume shows how to write one" → §10. All other §8/§9
citations in Vol 3 point at Volume 2 and are untouched.

Appendix B gains a fourth skeleton, **Minimal GUI page** (script core
only), after FSM controller.

Deliverable: `UMM_Manual_GUI_Chapter.docx` (4 parts: chapter /
renumbering edits / Appendix B skeleton / TOC entries). **Phil has
pasted the chapter into the manual.**

Precedent note: Vol 2 has no GUI-server section (Table 8.1 + Appendix
E.2 only), so Vol 3 Ch 8 carrying the browser-facing protocol mirrors
the match-plugin arrangement (router-side view in Vol 2 §5.3, protocol
in Vol 3).

## 2. umm_gui/template.html

New. The working minimum a GUI starts from, in the house design
language (same palette/fonts as tank/chess), script in eight numbered
commented sections matching Ch 8 §8.3. Claims **mtype 900** (checked
free), one message TextMsg (900,100): Char text + Int seq meta=count
(meta 3). dont_send_self:false so the sender sees its own messages.
Demo doubles as the architecture lesson: two tabs = two agents; send
from one, the other receives. **Phil confirmed it works in the
browser.**

`test_template_gui.py` (project root, 14 checks, passing): serves via
fallback route, two simulated tabs speaking the page's exact JSON —
attach/status, registration, cross-tab delivery, own-send echo, Char
value arrives in one pair of double quotes, Int meta 3 resolves to
"count".

## 3. Incidental finding — Word archive paste artefact

In UMM_Manual_Vol3.docx the Appendix C body paragraphs (Session 35
paste) carry Heading 2 / TOC paragraph styles instead of Body Text —
cosmetic but pollutes the Word TOC. Pages source presumably clean;
glance at it next time the Word export is refreshed.

## 4. C router confirm path (carry-over item 4 — done)

Turned out to be a **port, not a fix**: the C router had no message
confirm machinery at all (only ATTACH_CONFIRM). Implemented
CONFIRM_RTR / CONFIRM_RCV with the Session 34 reg_id stamping correct
from the start.

`umm-c/include/umm_types.h`: new `UMMConfirmSubType` enum
(CST_ERROR=1, CST_ROUTER_CONFIRM=2, CST_RECEIVER_ACK=3, CST_APP_ACK=4)
mirroring Python ConfirmSubType.

`umm-c/src/umm_router.c`:
- `route_message` now **returns** its delivered count (was counted and
  discarded).
- `find_origin_reg_id()` — same triple-bucket lookup as routing
  (wildcard+exact channel; (mt,st)/(mt,0)/(0,0)), restricted to the
  originator's own entries, full `tlv_content_match`. THE fix:
  confirms bypass routing but the agent library dispatches by reg_id,
  and send_confirmed subscribes with Int == source_mtype — a reg_id=0
  confirm is silently dropped by the client. Invariant preserved:
  reg_id > 0 ⇔ the router matched a subscription.
- `router_send_confirm()` — payload Int(source_mtype) + MsgRef
  (origin_router/origin_id/msg_id of the original, !III) [+
  Int(receiver_count) for ROUTER_CONFIRM]; header mtype −1, channel
  CHAN_CONFIRM (2), origin (router_id, 0), delivered **directly to the
  originator only** — all exactly mirroring Python `_send_confirm`.
- `dispatch()` calls it after route_message when flags request it
  (both the UMM-control and app branches).

Wire note: C `umm_msg_encode` already wraps payload in a TLV_MSG
envelope, so the flat payload bytes are wire-identical to Python's
`_make_router_msg(TLVBuffer)` — no extra wrapping needed.

Builds clean, `-Wall -Wextra -Wpedantic`.

`test_c_router_confirm.py` (project root, **20 checks, passing**):
runs the real C binary with Python agents as clients (doubling as a
wire-compat test). Covers: on_router_confirm fires (proves stamping),
receiver_count 0/1/2, on_receiver_ack, raw anatomy (mtype −1,
subtype 2, channel 2, reg_id == the subscription's actual reg_id,
MsgRef carries the sender's attach id and exact msg_id — read from
`sender._msg_id - 1` since agent.send returns None), plain send → no
confirm, third-party (−1,2) subscriber sees nothing.

Scope notes: CONFIRM_APP declared but not auto-sent (same as Python —
needs cooperating receivers). C **agent** library has no
send_confirmed() convenience yet — doable manually (register for −1
with a match, send with the flag); a helper is a natural follow-up if
parity is wanted.

## 5. Open items / next session candidates

- Teaching ladder → Teacher's Manual proper (carried from S35).
- Optional: C agent send_confirmed() helper (§4 scope note).
- Optional: fix Appendix C paragraph styles in the Word export (§3).
- Chess meta/mtype names in umm_names.conf — was item 5 on the S35
  list; not raised this session, still open unless done offline.

## 6. Files touched this session

New:      umm_gui/template.html
          test_template_gui.py
          test_c_router_confirm.py
          UMM_Manual_GUI_Chapter.docx (deliverable, pasted by Phil)
Modified: umm-c/include/umm_types.h   (UMMConfirmSubType)
          umm-c/src/umm_router.c      (confirm path)
