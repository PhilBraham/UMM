"""
examples/plant_demo.py
======================
A complete UMM plant demonstration.

Run the router first in one terminal::

    python -m umm.router --port 5000 --name PlantA

Then run this demo::

    python examples/plant_demo.py

Shows three UMM clients working together on the same bus:
  1. TemperatureSensor  – publishes readings every second
  2. AlarmConsole       – subscribes to readings above 80°C
  3. DatabaseLogger     – subscribes to ALL temperature readings

None of them know about each other.  The router matches and delivers.
"""

import random
import sys
import threading
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(name)-20s  %(message)s',
)

# Add parent dir to path if running from examples/
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from umm import UMMClient, MType
from umm.types.builtin import FloatType, StringType, IntType
from umm.types.manufacturing import (
    TemperatureType, ProcessEventType, AlarmLevelType,
    RobotStateType, RobotStateEnum,
)
from umm.types._base import MatchOp

# ── shared type handlers ──────────────────────────────────────────────────────

temp_type  = TemperatureType()
event_type = ProcessEventType()
alarm_type = AlarmLevelType()
robot_type = RobotStateType()

# ── mtype / subtype constants for this plant ──────────────────────────────────

MT_SENSOR   = 100
ST_TEMP     = 1
ST_PRESSURE = 2

MT_ALARM    = 102
ST_ALERT    = 1

MT_PROCESS  = 103
ST_EVENT    = 1

MT_ROBOT    = 110
ST_STATE    = 1


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 1. Temperature Sensor
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def run_temperature_sensor(host: str, port: int) -> None:
    log = logging.getLogger("TemperatureSensor")

    sensor = UMMClient(
        host         = host,
        port         = port,
        process_name = "TemperatureSensor",
    )
    if not sensor.connect():
        log.error("Could not connect to router")
        return

    log.info("Connected.  Publishing temperature readings every 1s …")

    # Simulate a temperature that drifts up and down around 75°C
    temp = 75.0
    try:
        while True:
            temp += random.uniform(-3.0, 3.5)
            temp  = max(60.0, min(95.0, temp))

            sensor.send(
                mtype  = MT_SENSOR,
                subtype= ST_TEMP,
                tlvs   = [temp_type.make_tlv(temp)],
            )
            log.info("Published temperature: %s", temp_type.to_text(temp))
            time.sleep(1.0)
    except KeyboardInterrupt:
        pass
    finally:
        sensor.disconnect()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 2. Alarm Console  (subscribes to temperature > 80°C)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def run_alarm_console(host: str, port: int) -> None:
    log = logging.getLogger("AlarmConsole")

    console = UMMClient(
        host         = host,
        port         = port,
        process_name = "AlarmConsole",
    )
    if not console.connect():
        log.error("Could not connect to router")
        return

    def on_high_temp(msg):
        from umm.core.tlv import decode_all
        tlvs = decode_all(msg.tdata.value)
        for tlv in tlvs:
            if tlv.type_id == temp_type.TYPE_ID:
                value = temp_type.unpack(tlv.value)
                log.warning("🔥 HIGH TEMPERATURE ALARM: %s", temp_type.to_text(value))

    # Register: "give me sensor readings where temperature > 80°C"
    console.register(
        mtype      = MT_SENSOR,
        subtype    = ST_TEMP,
        callback   = on_high_temp,
        match_tlvs = [temp_type.make_subscription_tlv(80.0, MatchOp.GT)],
    )
    log.info("Subscribed to temperature > 80°C.  Waiting for alarms …")
    console.run()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 3. Database Logger  (subscribes to ALL temperature readings)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def run_database_logger(host: str, port: int) -> None:
    log = logging.getLogger("DatabaseLogger")
    records = []

    logger_client = UMMClient(
        host         = host,
        port         = port,
        process_name = "DatabaseLogger",
    )
    if not logger_client.connect():
        log.error("Could not connect to router")
        return

    def on_any_temp(msg):
        from umm.core.tlv import decode_all
        tlvs = decode_all(msg.tdata.value)
        for tlv in tlvs:
            if tlv.type_id == temp_type.TYPE_ID:
                value = temp_type.unpack(tlv.value)
                ts    = time.time()
                records.append((ts, value))
                log.info("DB logged: t=%.3f  %s  (total records: %d)",
                         ts, temp_type.to_text(value), len(records))

    # Subscribe to ALL temperature readings (no match_tlvs = type/subtype only)
    logger_client.register(
        mtype    = MT_SENSOR,
        subtype  = ST_TEMP,
        callback = on_any_temp,
    )
    log.info("Subscribed to ALL temperature readings …")
    logger_client.run()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 4. Robot Monitor  (subscribes to robot FAULT or ESTOP states)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def run_robot_monitor(host: str, port: int) -> None:
    log = logging.getLogger("RobotMonitor")

    monitor = UMMClient(
        host         = host,
        port         = port,
        process_name = "RobotMonitor",
    )
    if not monitor.connect():
        log.error("Could not connect to router")
        return

    def on_robot_fault(msg):
        from umm.core.tlv import decode_all
        tlvs = decode_all(msg.tdata.value)
        for tlv in tlvs:
            if tlv.type_id == robot_type.TYPE_ID:
                state = robot_type.unpack(tlv.value)
                log.warning("🤖 ROBOT FAULT: unit=%d state=%s",
                            tlv.mword, robot_type.to_text(state))

    # Subscribe to FAULT state (EQ match)
    monitor.register(
        mtype      = MT_ROBOT,
        subtype    = ST_STATE,
        callback   = on_robot_fault,
        match_tlvs = [robot_type.make_subscription_tlv(
                          RobotStateEnum.FAULT, MatchOp.EQ)],
    )
    # Also subscribe to ESTOP
    monitor.register(
        mtype      = MT_ROBOT,
        subtype    = ST_STATE,
        callback   = on_robot_fault,
        match_tlvs = [robot_type.make_subscription_tlv(
                          RobotStateEnum.ESTOP, MatchOp.EQ)],
    )
    log.info("Subscribed to robot FAULT and ESTOP states …")
    monitor.run()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Main
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='UMM plant demo')
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--port', type=int, default=5000)
    args = parser.parse_args()

    print(f"""
UMM Plant Demo
==============
Connecting to router at {args.host}:{args.port}

Running 4 clients simultaneously:
  • TemperatureSensor  – publishes readings every 1s (60–95°C range)
  • AlarmConsole       – alerts when temperature > 80°C
  • DatabaseLogger     – logs ALL temperature readings
  • RobotMonitor       – alerts on FAULT or ESTOP state

Press Ctrl+C to stop.
""")

    # Run all clients as daemon threads
    clients = [
        ("AlarmConsole",    run_alarm_console),
        ("DatabaseLogger",  run_database_logger),
        ("RobotMonitor",    run_robot_monitor),
    ]

    threads = []
    for name, fn in clients:
        t = threading.Thread(
            target=fn, args=(args.host, args.port),
            name=name, daemon=True)
        t.start()
        threads.append(t)
        time.sleep(0.3)   # stagger connections slightly

    # Run sensor in the main thread
    try:
        run_temperature_sensor(args.host, args.port)
    except KeyboardInterrupt:
        print("\nDemo stopped.")
