"""
umm/tools/send.py
=================
umm-send — inject messages into a UMM system from the command line.

Usage
-----
Single message:
    python3 -m umm.tools.send --router localhost --port 5100 \\
        100,1 Float 85.3  Char "sensor_1"

With match operator (for testing subscriptions):
    python3 -m umm.tools.send ... Float > 80.0

Timer request — fire mtype=100,subtype=1 every 5 seconds forever:
    python3 -m umm.tools.send --timer 5 --timer-mtype 100 --timer-subtype 1 \\
        Float 85.3

System shutdown (requires --trusted):
    python3 -m umm.tools.send --trusted --shutdown
    python3 -m umm.tools.send --trusted --shutdown --delay 30 "Scheduled maintenance"

From a script file:
    python3 -m umm.tools.send --file scenario.umm

Replay a parser recording:
    python3 -m umm.tools.send --replay session.json
    python3 -m umm.tools.send --replay session.json --speed 2.0
    python3 -m umm.tools.send --replay session.json --timestamps original

Interactive REPL mode:
    python3 -m umm.tools.send --router localhost --port 5100 --interactive
    python3 -m umm.tools.send --router localhost --port 5100 --trusted --interactive

Script file format
------------------
One message per line.  Blank lines and # comments are ignored.

    # scenario.umm
    # Send a temperature reading
    100,1 Float 85.3 Char "sensor_1"

    # Wait 1 second
    wait 1.0

    # Send an alarm
    102,1 Char "High temperature" Int 3

    # Send a timer request (fires mtype=100,subtype=99 every 10s)
    timer 10.0 repeat -1 -> 100,99 Int 1

TLV format in arguments
-----------------------
TypeName [operator] value

TLV type names are case-insensitive: Int, int, INT are all equivalent.

    Int 42
    Float 85.3
    Char "hello world"        (quotes optional if no spaces)
    Bool true
    Int > 80                  (operator for testing match criteria)
    Float >= 0.5
    Temperature 73.5          (manufacturing types)
    UTime 60.0                (relative seconds)

Operators: =  !=  >  <  >=  <=  CI=  CI!=  *=  contains
"""

from __future__ import annotations

import re
import sys
import time
import struct
import argparse
import logging
from pathlib import Path
from typing import List, Optional, Tuple

# On Windows, stdout/stderr default to the console code page (cp1252 / cp437)
# which cannot represent the Unicode characters used in prompts and status
# output (✓, ─, →, ∞, ×, —).  Reconfigure to UTF-8 if possible.
if sys.platform == 'win32':
    import io
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    elif hasattr(sys.stdout, 'buffer'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8',
                                      errors='replace', line_buffering=True)
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8',
                                      errors='replace', line_buffering=True)

# Allow running as script or module
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from umm.agent import UMMAgent, UMMConnectionError
from umm.core.tlv import TLV, TLVBuffer, TLV_MSG, TLV_SUBSPEC, TLV_TERM, TLV_INT, MWORD_NONE
from umm.core.messages import MType, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag, UMMSubType, Channel
from umm.core.registry import registry
from umm.core.meta import meta_registry
from umm.types._base import MatchOp
from umm.types.manufacturing import MANUFACTURING_TYPES

logger = logging.getLogger(__name__)

# Register manufacturing types
for _cls in MANUFACTURING_TYPES:
    registry.register_class(_cls)

# ── operator text → mword index ───────────────────────────────────────────────

OP_MAP = {
    "=":        MatchOp.EQ,
    "!=":       MatchOp.NE,
    ">":        MatchOp.GT,
    "<":        MatchOp.LT,
    ">=":       MatchOp.GE,
    "<=":       MatchOp.LE,
    "CI=":      2,
    "CI!=":     3,
    "*=":       MatchOp.WILDCARD,
    "*!=":      5,
    "contains": MatchOp.CONTAINS,
}

# ── TLV argument parser ───────────────────────────────────────────────────────

def _parse_meta_token(token: str, type_id: int) -> int:
    """
    Parse a [MetaName] or [17] or [] token.  Returns the meta integer value.
    The brackets must already be stripped from the type_name by the caller.
    token is the content inside the brackets (may be empty string → 0).
    """
    token = token.strip()
    if not token:
        return 0
    # Numeric?
    try:
        return int(token)
    except ValueError:
        pass
    # Name lookup in meta registry
    for m, n in meta_registry.entries_for_type(type_id):
        if n.lower() == token.lower():
            return m
    # Unknown name — warn and return 0
    print(f"  WARNING: Unknown meta name '{token}' for type_id={type_id} — using 0")
    return 0


def parse_tlv_args(args: List[str]) -> List[TLV]:
    """
    Parse a list of string arguments into TLV objects.

    Format: TypeName[meta] [operator] value [TypeName[meta] [operator] value ...]

    The optional [meta] bracket directly follows the type name (no space):
        Float[temperature] 85.3       — Float TLV with meta=temperature
        Float[1] 85.3                 — same, by meta number
        Float[] 85.3                  — no meta (explicit empty brackets)
        Float 85.3                    — no meta (brackets omitted)
        Char[filename] "foo.txt"      — Char TLV with meta=filename
        Float[temperature] > 80.0     — subscription: Float temperature > 80

    Examples:
        ["Float[temperature]", "85.3"]
        ["Float[temperature]", ">", "80.0", "Char[filename]", "sensor_1"]
        ["Int", "42", "Bool", "true"]
    """
    import re as _re
    tlvs = []
    i = 0
    while i < len(args):
        raw_name = args[i]
        i += 1

        # Split TypeName[meta] → type_name, meta_token
        m = _re.match(r'(\w+)(?:\[([^\]]*)\])?', raw_name)
        if not m:
            print(f"  ERROR: Cannot parse TLV token '{raw_name}'")
            sys.exit(1)
        type_name  = m.group(1)
        meta_token = m.group(2)  # None if no brackets, '' if empty brackets

        handler = registry.get_by_name(type_name)
        if handler is None:
            # Try case-insensitive fallback
            handler = next(
                (h for h in registry if h.TYPE_NAME.lower() == type_name.lower()),
                None
            )
        if handler is None:
            print(f"  ERROR: Unknown TLV type '{type_name}'")
            print(f"  Known types: {', '.join(h.TYPE_NAME for h in registry)}")
            sys.exit(1)

        # Resolve meta
        meta = 0
        if meta_token is not None:
            meta = _parse_meta_token(meta_token, handler.TYPE_ID)

        # Check for operator
        match = MWORD_NONE
        if i < len(args) and args[i] in OP_MAP:
            match = int(OP_MAP[args[i]])
            i += 1

        # Get value (handle quoted strings)
        value_bytes = b''
        if i < len(args):
            val_str = args[i]
            i += 1
            if val_str.startswith('"') and val_str.endswith('"'):
                val_str = val_str[1:-1]
            elif val_str.startswith("'") and val_str.endswith("'"):
                val_str = val_str[1:-1]
            try:
                value_bytes = handler.pack(handler.from_text(val_str))
            except Exception as exc:
                print(f"  ERROR: Could not parse '{val_str}' as {type_name}: {exc}")
                sys.exit(1)

        tlvs.append(TLV(type_id=handler.TYPE_ID,
                        value=value_bytes,
                        match=match,
                        meta=meta))

        # Display what we parsed
        # Build reverse map preferring the canonical symbol (shorter, no CI= collision)
        _rev = {}
        for _k, _v in OP_MAP.items():
            if int(_v) not in _rev or len(_k) < len(_rev[int(_v)]):
                _rev[int(_v)] = _k
        op_sym   = _rev.get(match, '' if match == 0 else f'{{{match}}}')
        meta_str = ('[' + (meta_registry.name(handler.TYPE_ID, meta) or str(meta)) + ']') if meta else ''
        if value_bytes and handler:
            try:
                display = handler.to_text(handler.unpack(value_bytes))
            except Exception:
                display = value_bytes.hex()
        else:
            display = '(no value)'
        print(f"    {type_name}{meta_str} {op_sym} {display}")

    return tlvs


# ── send one message ──────────────────────────────────────────────────────────

def send_message(agent: UMMAgent, mtype: int, subtype: int,
                 tlv_args: List[str], flags: int = 0,
                 extra_tlvs: list = None) -> None:
    """Parse tlv_args and send a message."""
    print(f"  Sending mtype={mtype} subtype={subtype}")
    tlvs = parse_tlv_args(tlv_args) if tlv_args else []
    if extra_tlvs:
        tlvs = tlvs + list(extra_tlvs)
    agent.send(mtype=mtype, subtype=subtype,
               tlvs=tlvs if tlvs else None,
               flags=flags)
    # Give the router time to receive, match and deliver the message
    # before we disconnect or send the next one
    time.sleep(0.5)


# ── timer request builder ─────────────────────────────────────────────────────

def send_timer_request(agent: UMMAgent,
                       interval: float,
                       target_mtype: int,
                       target_subtype: int,
                       target_tlv_args: List[str],
                       count: int = -1,
                       start: Optional[float] = None,
                       timer_mtype: Optional[int] = None) -> None:
    """
    Send a timer request to the timer agent.

    interval      : seconds between fires (relative)
    target_mtype  : mtype of message to fire
    target_subtype: subtype of message to fire
    target_tlv_args: TLV args for the message to fire
    count         : how many times to fire (-1 = forever)
    start         : absolute start time (None = now + interval)
    timer_mtype   : mtype of the timer *instance* to send the request to
                    (None = the core timer, MType.TIMER).  Use this to address
                    a demo's own timer agent (e.g. a tank timer on mtype 5050)
                    so its scheduled ticks stop when that demo is stopped.
    """
    from umm.types.builtin import UTimeType, IntType

    utime_t = UTimeType()
    int_t   = IntType()

    print(f"  Timer request: every {interval}s × "
          f"{'∞' if count == -1 else count} "
          f"→ mtype={target_mtype} subtype={target_subtype}")

    # Build the inner message (what the timer will fire)
    inner_tlvs = parse_tlv_args(target_tlv_args) if target_tlv_args else []
    inner_buf  = TLVBuffer()
    for t in inner_tlvs:
        inner_buf.add(t)

    # Pack as UMMReg: mtype(4) subtype(4) channel(2) flags(2) TData
    inner_reg = (struct.pack('!iiHH', target_mtype, target_subtype, 1, 0)
                 + inner_buf.encode())

    # Build timer request payload
    outer = TLVBuffer()
    if start is not None:
        outer.add(utime_t.make_tlv(start))    # absolute start
    outer.add(utime_t.make_tlv(interval))      # repeat interval
    outer.add(int_t.make_tlv(0 if count == -1 else count))  # count: 0=continuous
    outer.add(TLV(type_id=TLV_MSG, value=inner_reg))

    from umm.modules.timer import ST_REQUEST as _ST_TIMER_REQUEST
    dest_mtype = timer_mtype if timer_mtype is not None else int(MType.TIMER)
    agent.send(mtype=dest_mtype, subtype=_ST_TIMER_REQUEST, tlvs=list(outer))
    desc = f"every {interval}s → {target_mtype},{target_subtype}"
    if dest_mtype != int(MType.TIMER):
        desc += f"  (via timer mtype {dest_mtype})"
    next_id = (max(_active_timers.keys()) + 1) if _active_timers else 1
    _active_timers[next_id] = desc
    print(f"  Timer request sent ✓  ({desc})")
    print(f"  To cancel: type 'timer cancel {next_id}'  (uses ref from Confirmed message)")


# ── script file parser ────────────────────────────────────────────────────────

def _parse_mtype_subtype(token: str, next_token: str = None):
    """
    Parse mtype and subtype from either 'mtype,subtype' (preferred) or
    legacy 'mtype subtype' (two separate tokens).

    Returns (mtype, subtype, consumed_next) where consumed_next is True
    if next_token was used as the subtype.
    """
    if ',' in token:
        parts = token.split(',', 1)
        return int(parts[0]), int(parts[1]), False
    elif next_token is not None:
        return int(token), int(next_token), True
    else:
        raise ValueError(f"Expected mtype,subtype but got '{token}' with no following token")


def run_script(agent: UMMAgent, script_file: str) -> None:
    """
    Execute a .umm script file.

    Line formats:
        mtype,subtype [TypeName [op] value ...]   — send a message
        wait seconds                               — pause
        timer interval [repeat count] -> mtype,subtype [TLVs]
        # comment
    """
    path = Path(script_file)
    if not path.exists():
        print(f"ERROR: Script file not found: {script_file}")
        sys.exit(1)

    print(f"Running script: {script_file}")
    lines = path.read_text().splitlines()

    for lineno, raw in enumerate(lines, 1):
        line = raw.split('#')[0].strip()
        if not line:
            continue

        tokens = _split_line(line)
        if not tokens:
            continue

        print(f"\nLine {lineno}: {line}")

        # wait N
        if tokens[0].lower() == 'wait':
            secs = float(tokens[1]) if len(tokens) > 1 else 1.0
            print(f"  Waiting {secs}s...")
            time.sleep(secs)

        # timer interval [repeat count] -> mtype,subtype [TLVs]
        elif tokens[0].lower() == 'timer':
            _parse_timer_line(agent, tokens[1:])

        # mtype,subtype [TLVs]  (also accepts legacy: mtype subtype [TLVs])
        else:
            try:
                mtype, subtype, consumed = _parse_mtype_subtype(
                    tokens[0], tokens[1] if len(tokens) > 1 else None)
                tlv_args = tokens[2:] if consumed else tokens[1:]
                send_message(agent, mtype, subtype, tlv_args)
            except (ValueError, IndexError) as exc:
                print(f"  ERROR on line {lineno}: {exc}")


def _parse_timer_line(agent: UMMAgent, tokens: List[str]) -> None:
    """Parse: interval [repeat count] [@timer_mtype] -> mtype,subtype [TLVs]

    The optional @<mtype> addresses a specific timer instance (e.g. a demo's
    own timer agent) instead of the core timer (MType.TIMER).  Example:
        timer 10.0 @5050 -> 5000,101
    """
    interval    = float(tokens[0])
    count       = -1
    timer_mtype = None
    i           = 1

    # Optional 'repeat N' and '@<mtype>' before the arrow, in any order.
    while i < len(tokens) and tokens[i] != '->':
        tok = tokens[i]
        if tok.lower() == 'repeat':
            count = int(tokens[i + 1]); i += 2
        elif tok.startswith('@'):
            timer_mtype = int(tok[1:]); i += 1
        else:
            break

    # Find the -> separator
    if '->' not in tokens:
        print("  ERROR: timer line needs '->' separator")
        return

    arrow = tokens.index('->')
    target_mtype, target_subtype, consumed = _parse_mtype_subtype(
        tokens[arrow + 1], tokens[arrow + 2] if len(tokens) > arrow + 2 else None)
    target_tlv_args = tokens[arrow + 3:] if consumed else tokens[arrow + 2:]

    send_timer_request(agent, interval, target_mtype, target_subtype,
                       target_tlv_args, count=count, timer_mtype=timer_mtype)


def _split_line(line: str) -> List[str]:
    """Split a line respecting quoted strings."""
    tokens = []
    for m in re.finditer(r'"[^"]*"|\'[^\']*\'|\S+', line):
        tokens.append(m.group())
    return tokens



# ── recording replay ──────────────────────────────────────────────────────────

def replay_recording(agent: UMMAgent,
                     record_file: str,
                     speed: float = 1.0,
                     timestamps: str = 'relative') -> None:
    """
    Replay a JSON-lines recording made by the parser --record option.

    Parameters
    ----------
    agent       : connected UMMAgent to send through
    record_file : path to the .json recording file
    speed       : playback speed multiplier (1.0 = real time, 2.0 = double speed)
    timestamps  : 'relative'  — shift all timestamps to start from now (default)
                  'original'  — send with the exact recorded UTime values
                  'now'       — ignore recorded timestamps, use current time
    """
    import json as _json
    from umm.core.messages import UTime as _UTime
    from pathlib import Path as _Path

    path = _Path(record_file)
    if not path.exists():
        print(f"ERROR: Recording file not found: {record_file}")
        sys.exit(1)

    lines = [l.strip() for l in path.read_text(encoding='utf-8').splitlines()
             if l.strip() and not l.strip().startswith('//')]

    # Parse all records, skipping the header line and any metadata objects
    records = []
    for line in lines:
        try:
            rec = _json.loads(line)
        except Exception:
            continue
        if '_umm_recording' in rec:
            continue   # header line
        if 'mtype' not in rec:
            continue   # not a message record
        records.append(rec)

    if not records:
        print("No messages found in recording.")
        return

    total = len(records)
    print(f"Replaying {total} messages from {record_file}")
    print(f"  speed={speed}x  timestamps={timestamps}")

    # Compute replay base time for 'relative' mode
    first_ts = records[0]['ts_secs'] + records[0]['ts_ms'] / 1000.0
    replay_start = time.time()

    for i, rec in enumerate(records):
        rec_ts   = rec['ts_secs'] + rec['ts_ms'] / 1000.0
        channel  = rec.get('channel', 1)
        mtype    = rec['mtype']
        subtype  = rec['subtype']
        flags    = rec.get('flags', 0)
        tlvs_hex = rec.get('tlvs_hex', '')

        # Decode TLV payload
        from umm.core.tlv import decode_all as _decode_all, TLV_TERM as _TLV_TERM
        tlvs = None
        if tlvs_hex:
            try:
                raw = bytes.fromhex(tlvs_hex)
                tlvs = _decode_all(raw) if raw else None
            except Exception as exc:
                logger.warning("Replay: bad TLV on record %d: %s", i + 1, exc)
                tlvs = None

        # Determine send timestamp
        if timestamps == 'original':
            tm = _UTime(secs=rec['ts_secs'], ms=rec['ts_ms'])
        elif timestamps == 'relative':
            offset_secs = rec_ts - first_ts
            abs_secs = replay_start + offset_secs
            secs_int = int(abs_secs)
            ms_int   = int((abs_secs - secs_int) * 1000)
            tm = _UTime(secs=secs_int, ms=ms_int)
        else:   # 'now'
            tm = None   # agent._make_msg will call UTime.now()

        # Sleep to honour inter-message timing (skip for first message)
        if i > 0 and speed > 0:
            prev_ts = records[i - 1]['ts_secs'] + records[i - 1]['ts_ms'] / 1000.0
            gap = (rec_ts - prev_ts) / speed
            if gap > 0:
                time.sleep(gap)

        try:
            agent.send(mtype=mtype, subtype=subtype, tlvs=tlvs,
                       flags=flags, channel=channel, tm=tm)
            print(f"  [{i+1}/{total}] ch={channel} mtype={mtype} subtype={subtype}")
        except Exception as exc:
            logger.warning("Replay: send failed on record %d: %s", i + 1, exc)

    print(f"Replay complete — {total} messages sent.")


# ── interactive REPL ──────────────────────────────────────────────────────────

REPL_HELP = """
UMM Send — Interactive Mode
───────────────────────────
Commands:
  mtype,subtype [TypeName [op] value ...]   send a message
  timer interval [repeat N] -> mtype,subtype [TLVs]   send timer request
  timer cancel [reg_id]                     cancel a timer (omit = cancel last)
  timer list                                list active timers
  shutdown [delay] [message]                system shutdown (trusted agents only)
  wait seconds                              pause
  types                                     list available TLV types
  help                                      show this help
  quit / exit                               exit

TLV type names are case-insensitive: Int, int, INT are all equivalent.

Examples:
  100,1 Float 85.3
  100,1 Float[temperature] 85.3
  100,1 Float[temperature] 85.3 Char[filename] "sensor_1.log"
  102,1 Char "High temperature alarm" Int 3
  timer 5.0 -> 100,1 Float[temperature] 1.0
  timer 60.0 repeat 10 -> 100,1 Int 42
  timer cancel        (cancel most recent timer)
  timer cancel 3      (cancel timer with reg_id 3)
  shutdown            (immediate, no message — requires --trusted)
  shutdown 30 "Scheduled maintenance"

Operators (for match testing):  =  !=  >  <  >=  <=  contains  *=
Meta (optional, in brackets):   Float[temperature]  Char[filename]  Int[status]  Float[1]
"""

# Track active timers: reg_id → description
_active_timers: dict = {}

def _handle_line(agent: UMMAgent, line: str) -> bool:
    """
    Handle one input line. Returns False if the user wants to quit.
    Raises ValueError/TypeError on bad input — caller prints the error.
    """
    import struct as _struct
    tokens = _split_line(line)
    if not tokens:
        return True

    cmd = tokens[0].lower()

    if cmd in ('quit', 'exit', 'q'):
        return False

    elif cmd == 'help':
        print(REPL_HELP)

    elif cmd == 'types':
        print("\nAvailable TLV types:")
        for h in registry:
            ops = ', '.join(
                {v: k for k, v in OP_MAP.items()}.get(op, str(op))
                for op in h.MATCH_OPS.keys()
            ) if h.MATCH_OPS else 'none'
            unit = f"  [{h.UNIT}]" if h.UNIT else ''
            print(f"  {h.TYPE_ID:3d}  {h.TYPE_NAME:<20} {h.DESCRIPTION}{unit}")
            if ops:
                print(f"       operators: {ops}")
        print()

    elif cmd == 'wait':
        secs = float(tokens[1]) if len(tokens) > 1 else 1.0
        print(f"  Waiting {secs}s...")
        time.sleep(secs)

    elif cmd == 'shutdown':
        # shutdown [delay_secs] [message]
        delay = 0
        message = ''
        if len(tokens) > 1:
            try:
                delay = int(tokens[1])
                if len(tokens) > 2:
                    message = ' '.join(tokens[2:]).strip('"\'')
            except ValueError:
                message = ' '.join(tokens[1:]).strip('"\'')
        import struct as _struct2
        tlvs = [TLV(type_id=TLV_INT, value=_struct2.pack('!i', delay))]
        if message:
            tlvs.append(TLV(type_id=8,   # TLV_STRING
                            value=message.encode('utf-8') + b'\x00'))
        label = f"in {delay}s" if delay > 0 else "immediately"
        print(f"  Sending system shutdown {label}"
              + (f': "{message}"' if message else '') + "...")
        agent.send(mtype=int(MType.UMM),
                   subtype=int(UMMSubType.SYSTEM_SHUTDOWN),
                   tlvs=tlvs, flags=0)
        time.sleep(0.5)
        print("  System shutdown sent ✓")

    elif cmd == 'timer':
        subcmd = tokens[1].lower() if len(tokens) > 1 else ''

        if subcmd == 'cancel':
            if len(tokens) > 2:
                reg_id = int(tokens[2])
            elif _active_timers:
                reg_id = max(_active_timers.keys())
            else:
                print("  No active timers to cancel.")
                return True
            tlv = TLV(type_id=TLV_INT, value=_struct.pack('!i', reg_id))
            from umm.modules.timer import ST_CANCEL as _ST_TIMER_CANCEL
            send_message(agent, int(MType.TIMER), _ST_TIMER_CANCEL, [], extra_tlvs=[tlv])
            desc = _active_timers.pop(reg_id, f'reg_id={reg_id}')
            print(f"  Cancel sent for timer {reg_id} ({desc}) ✓")

        elif subcmd == 'list':
            if _active_timers:
                print("  Active timers:")
                for rid, desc in sorted(_active_timers.items()):
                    print(f"    reg_id={rid}  {desc}")
            else:
                print("  No active timers.")

        elif not subcmd:
            print("  Usage: timer interval [repeat N] -> mtype,subtype [TLVs]")
            print("         timer cancel [reg_id]")
            print("         timer list")

        else:
            # timer interval [repeat N] -> mtype,subtype [TLVs]
            _parse_timer_line(agent, tokens[1:])

    else:
        # Default: mtype,subtype [TLVs]
        if len(tokens) < 1:
            print("  ERROR: Expected: mtype,subtype [TypeName value ...]")
            print("  Type 'help' for usage.")
            return True
        try:
            mtype, subtype, consumed = _parse_mtype_subtype(
                tokens[0], tokens[1] if len(tokens) > 1 else None)
        except ValueError:
            print(f"  ERROR: '{tokens[0]}' is not a recognised command.")
            print("  Commands: timer, wait, types, help, quit")
            print("  Or enter: mtype,subtype [TLVs]")
            return True
        tlv_args = tokens[2:] if consumed else tokens[1:]
        send_message(agent, mtype, subtype, tlv_args)
        print("  Sent ✓")

    return True


def run_interactive(agent: UMMAgent) -> None:
    """Interactive REPL for sending messages."""
    print(REPL_HELP)
    while True:
        try:
            line = input('umm> ').strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        if not line or line.startswith('#'):
            continue

        try:
            if not _handle_line(agent, line):
                print("Exiting.")
                break
        except Exception as exc:
            print(f"  ERROR: {exc}")
            print("  Type 'help' for usage.")

# ── main ──────────────────────────────────────────────────────────────────────

def _main() -> None:
    logging.basicConfig(
        level=logging.WARNING,
        format='%(levelname)s %(name)s: %(message)s',
    )

    p = argparse.ArgumentParser(
        description='UMM Send — inject messages into a UMM system',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Send a temperature reading (with meta qualifier)
  python3 -m umm.tools.send --port 5100 100,1 Float[temperature] 85.3

  # Send with a filename string (meta qualifier)
  python3 -m umm.tools.send --port 5100 100,1 Float[temperature] 85.3 Char[filename] "sensor_1.log"

  # Send a timer request (every 5 seconds, forever)
  python3 -m umm.tools.send --port 5100 --timer 5.0 --timer-mtype 100 --timer-subtype 1 Float 1.0

  # Interactive mode
  python3 -m umm.tools.send --port 5100 --interactive

  # Run a script
  python3 -m umm.tools.send --port 5100 --file scenario.umm
""")

    p.add_argument('--version', action='store_true',
                   help='Show version and exit')
    p.add_argument('--router',  default='localhost', dest='host')
    p.add_argument('--port',    type=int, default=DEFAULT_PORT)
    p.add_argument('--mtype',   type=int, default=None,
                   help='Message type (can also be first positional arg)')
    p.add_argument('--subtype', type=int, default=None,
                   help='Message sub-type (can also be second positional arg)')
    p.add_argument('--name',    default='UMMSend')
    p.add_argument('--trusted', action='store_true',
                   help='Attach as a trusted agent (AttachFlag.TRUSTED) — '
                        'required to send privileged commands such as system shutdown')
    p.add_argument('--attach-mtype', type=int, default=None, metavar='MTYPE',
                   help='Advertise a specific agent mtype on attach '
                        '(default: let router assign)')

    # Modes
    p.add_argument('--interactive', '-i', action='store_true',
                   help='Interactive REPL mode')
    p.add_argument('--file', '-f', default=None, metavar='SCRIPT',
                   help='Run a .umm script file')
    p.add_argument('--replay', default=None, metavar='FILE',
                   help='Replay a JSON-lines recording made by: '
                        'python3 -m umm.modules.parser --record FILE')
    p.add_argument('--speed', type=float, default=1.0, metavar='N',
                   help='Replay speed multiplier (default 1.0 = real time, '
                        '2.0 = double speed, 0 = no delay between messages)')
    p.add_argument('--timestamps', default='relative',
                   choices=['relative', 'original', 'now'],
                   help='Timestamp mode for replay: '
                        'relative (default) = shift to start from now; '
                        'original = use exact recorded timestamps; '
                        'now = always use current time')

    # Timer shortcut
    p.add_argument('--timer',          type=float, default=None,
                   metavar='SECONDS',
                   help='Send as a timer request with this interval')
    p.add_argument('--timer-mtype',    type=int,   default=None)
    p.add_argument('--timer-subtype',  type=int,   default=None)
    p.add_argument('--timer-count',    type=int,   default=-1,
                   help='Repeat count (-1 = forever)')

    # System shutdown shortcut (requires --trusted)
    p.add_argument('--shutdown', action='store_true',
                   help='Send a system shutdown command (requires --trusted). '
                        'Use --delay for countdown and positional args for message.')
    p.add_argument('--delay', type=int, default=0,
                   help='Shutdown delay in seconds (default: 0 = immediate)')

    p.add_argument('--wait', type=float, default=0.5, metavar='SECS',
                   help='Seconds to wait after connecting before sending '
                        '(default: 0.5) — increase if subscribers miss messages')
    p.add_argument('--typedir', action='append', default=[],
                   help='Extra type plugin directories')
    p.add_argument('--debug', action='store_true')

    # Positional: mtype,subtype TLV TLV ...
    p.add_argument('args', nargs='*',
                   help='mtype,subtype [TypeName [op] value ...]')

    args = p.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    for d in args.typedir:
        registry.add_search_dir(d)

    # Connect
    print(f"Connecting to router at {args.host}:{args.port}...")
    attach_flags = int(AttachFlag.TRUSTED) if args.trusted else 0
    agent = UMMAgent(host=args.host, port=args.port,
                     process_name=args.name,
                     flags=attach_flags)
    if not agent.connect():
        print("ERROR: Could not connect to router")
        sys.exit(1)
    print(f"Connected — attach_id={agent.attach_id.id}")
    # Brief pause so any subscribing agents (parser etc.) have time to
    # register before we send — avoids race condition on fast sends
    time.sleep(args.wait)
    print()

    try:
        # Script file and replay take priority over --interactive so that
        # umm.conf entries (which pass --interactive as a default) still work
        # when --file or --replay are added via runumm flags.
        if args.file:
            run_script(agent, args.file)

        # Replay a parser recording
        elif args.replay:
            replay_recording(agent, args.replay,
                             speed=args.speed,
                             timestamps=args.timestamps)

        # Interactive mode
        elif args.interactive:
            run_interactive(agent)

        # System shutdown shortcut
        elif args.shutdown:
            import struct as _struct2
            delay   = args.delay
            message = ' '.join(args.args).strip('"\'') if args.args else ''
            tlvs = [TLV(type_id=TLV_INT, value=_struct2.pack('!i', delay))]
            if message:
                tlvs.append(TLV(type_id=8,
                                value=message.encode('utf-8') + b'\x00'))
            label = f"in {delay}s" if delay > 0 else "immediately"
            print(f"  Sending system shutdown {label}"
                  + (f': "{message}"' if message else '') + "...")
            agent.send(mtype=int(MType.UMM),
                       subtype=int(UMMSubType.SYSTEM_SHUTDOWN),
                       tlvs=tlvs, flags=0)
            time.sleep(0.5)
            print("  System shutdown sent ✓")

        # Timer shortcut
        elif args.timer is not None:
            tm = args.timer
            tm_mtype   = args.timer_mtype
            tm_subtype = args.timer_subtype
            if tm_mtype is None or tm_subtype is None:
                print("ERROR: --timer requires --timer-mtype and --timer-subtype")
                sys.exit(1)
            # Remaining positional args are the payload TLVs
            tlv_args = args.args
            send_timer_request(agent, tm, tm_mtype, tm_subtype,
                               tlv_args, count=args.timer_count)

        # Single message from positional args
        elif args.args:
            positional = args.args
            # mtype and subtype can come from --mtype/--subtype or positional
            if args.mtype is not None:
                mtype   = args.mtype
                subtype = args.subtype or 0
                tlv_args = positional
            else:
                if len(positional) < 1:
                    print("ERROR: Need at least mtype,subtype")
                    p.print_help()
                    sys.exit(1)
                mtype, subtype, consumed = _parse_mtype_subtype(
                    positional[0], positional[1] if len(positional) > 1 else None)
                tlv_args = positional[2:] if consumed else positional[1:]
            send_message(agent, mtype, subtype, tlv_args)
            print("  Sent ✓")

        else:
            # No mode specified — drop into interactive
            print("No message specified — entering interactive mode.")
            print("(Use --help for command line usage)\n")
            run_interactive(agent)

    finally:
        agent.disconnect()


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)
