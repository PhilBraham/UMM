"""
umm.iface — compatibility shim
UMMClient has been renamed to UMMAgent. Import from umm.agent instead.
"""
from .agent import UMMAgent
UMMClient = UMMAgent
__all__ = ['UMMAgent', 'UMMClient']