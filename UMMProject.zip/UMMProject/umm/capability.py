"""
umm.capability
==============
Capability descriptor system for UMM agents.

Subtype sign convention
-----------------------
Positive subtype   → any published message (commands, events, status updates)
                     This is the normal case — the vast majority of messages
Negative subtype   → direct response to a specific request
                     ONLY when the agent explicitly sends one back
                     Whether this happens is declared in the capability descriptor

Examples:
    mtype=2, subtype=101  schedule a timer              → sent to timer agent
    mtype=2, subtype=-101 timer fired event             ← timer agent publishes

Capability protocol
-------------------
Capability queries and responses travel on mtype=1 (UMM system layer), NOT on
the agent's own mtype.  This keeps application mtype namespaces completely
clean — no subtypes are reserved by the capability system.

    Query:    (MType.UMM, 10)  Int(target_mtype)      → targeted query
              (MType.UMM, 10)  (no payload)            → broadcast to all agents
    Response: (MType.UMM, 11)  Int(responding_mtype)  Char(json)

Each agent registers a content-match subscription on (UMM, 10) with
Int == its own mtype.  For broadcasts every agent also subscribes with
no match_tlvs.  The response always carries Int(mtype) so the requester
can identify who responded.

Mtype range convention
----------------------
    1          UMM router control (reserved)
    2          Timer
    3          Command processor
    4          Metadata
    5          FSM
    6          File send / 7 File receive
    8          Database
    9          Microbilling
    10         Type directory
    11         Bridge
    12–99      Reserved for future standard agents
    100–199    Sensor family
    200–299    Actuator family
    300–399    Alarm family
    400–499    Process control
    500–999    Reserved
    1000–1999  Site A / application block
    2000–2999  Site B / application block
    3000+      User defined

Discovery
---------
Send (MType.UMM, 10) with no payload and every capability-aware agent
responds on (MType.UMM, 11), identifying itself by name, instance, mtype
and attach_id. This gives a complete live map of what is running.

Usage
-----
Adding capability support to an agent module (two lines):

    class TimerModule(CapabilityMixin):

        CAPABILITY = TIMER_CAPABILITY     # define once

        def run(self):
            self._client.connect()
            self.register_capability_handler(self._client)   # auto-handles queries
            # ... rest of module unchanged

Querying a live agent:

    from umm.capability import query_capability

    def on_cap(cap):
        print(cap.to_json())

    query_capability(agent, mtype=2, callback=on_cap)

CLI:

    python3 -m umm.capability --mtype 2 --router localhost --port 5100
    python3 -m umm.capability --discover --router localhost --port 5100
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Callable, Dict, List, Optional

# ── subtype constants ─────────────────────────────────────────────────────────

ST_CAPABILITY_QUERY    = 51    # (UMM, 51)  Int(mtype) for targeted, no payload for broadcast
ST_CAPABILITY_RESPONSE = 52    # (UMM, 52)  Int(mtype)  Char(json)


# ── standard reserved subtypes (injected into every capability response) ──────
#
# These are automatically added to every agent's capability descriptor when
# the response is built. Agents do not need to declare them manually.
# See DESIGN_NOTES.md section 10.

STANDARD_RESERVED_SUBTYPES: List[SubtypeSpec] = []  # populated after SubtypeSpec defined


# ── mtype range table ─────────────────────────────────────────────────────────

MTYPE_RANGES = [
    ( 1,    1,    "UMM router control (reserved)"),
    ( 2,    2,    "Timer"),
    ( 3,    3,    "Command processor"),
    ( 4,    4,    "Metadata"),
    ( 5,    5,    "FSM"),
    ( 6,    7,    "File transfer (send/receive)"),
    ( 8,    8,    "Database"),
    ( 9,    9,    "Microbilling"),
    (10,   10,    "Type directory"),
    (11,   11,    "Bridge"),
    (12,   99,    "Reserved — future standard agents"),
    (100,  199,   "Sensor family"),
    (200,  299,   "Actuator family"),
    (300,  399,   "Alarm family"),
    (400,  499,   "Process control family"),
    (500,  999,   "Reserved"),
    (1000, 1999,  "Application block A"),
    (2000, 2999,  "Application block B"),
    (3000, 99999, "User / application defined"),
]

def mtype_range_description(mtype: int) -> str:
    for lo, hi, desc in MTYPE_RANGES:
        if lo <= mtype <= hi:
            return desc
    return "Unknown range"


# ── descriptor dataclasses ────────────────────────────────────────────────────

@dataclass
class TLVSpec:
    """Describes one TLV field in a message."""
    type_id:     int
    name:        str
    description: str
    required:    bool      = True
    repeated:    bool      = False
    unit:        str       = ""
    operators:   List[str] = field(default_factory=list)
    notes:       str       = ""


@dataclass
class SubtypeSpec:
    """
    Describes one subtype of an agent's mtype.

    Convention:
      Positive subtype  → any published message (commands, events, status)
      Negative subtype  → direct response to a specific request
                          ONLY when the agent explicitly sends one back
      Zero              → capability query (universal)

    Whether a request has a paired response is declared in the capability:
      response_subtype = -N  means "subscribe to subtype -N before sending"
      response_subtype = None means fire-and-forget, no response expected

    This is the contract between requester and agent.
    """
    subtype:          int
    name:             str
    description:      str
    direction:        str            = "in"    # "in"=TO agent, "out"=FROM agent
    input_tlvs:       List[TLVSpec] = field(default_factory=list)
    output_tlvs:      List[TLVSpec] = field(default_factory=list)
    response_subtype: Optional[int] = None     # if set: subscribe here before sending
    responds_to:      Optional[int] = None     # if set: this is the response to that subtype
    notes:            str           = ""


@dataclass
class AgentCapability:
    """
    Complete capability descriptor for a UMM agent.

    The 'what' field is the canonical identity — independent of mtype.
    The 'instance' field distinguishes multiple agents of the same type.
    The 'attach_id' is stamped in by the agent at response time.
    """
    what:        str              # canonical agent type name e.g. "Timer"
    instance:    str              # instance name e.g. "PlantA-Timer-Conveyor"
    mtype:       int
    description: str
    subtypes:    List[SubtypeSpec] = field(default_factory=list)
    version:     str               = "1.0"
    author:      str               = ""
    notes:       str               = ""
    attach_id:   str               = ""   # stamped at response time

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(asdict(self), indent=indent)

    @classmethod
    def from_json(cls, text: str) -> "AgentCapability":
        d = json.loads(text)
        subtypes = []
        for s in d.get("subtypes", []):
            in_tlvs  = [TLVSpec(**t) for t in s.pop("input_tlvs",  [])]
            out_tlvs = [TLVSpec(**t) for t in s.pop("output_tlvs", [])]
            subtypes.append(SubtypeSpec(**s,
                                        input_tlvs=in_tlvs,
                                        output_tlvs=out_tlvs))
        d.pop("subtypes", None)
        return cls(**d, subtypes=subtypes)

    def subtype_spec(self, subtype: int) -> Optional[SubtypeSpec]:
        for s in self.subtypes:
            if s.subtype == subtype:
                return s
        return None

    def summary(self) -> str:
        """One-line human-readable identity."""
        inst = f" ({self.instance})" if self.instance else ""
        aid  = f" attach={self.attach_id}" if self.attach_id else ""
        return f"{self.what}{inst}  mtype={self.mtype}{aid}"


def make_capability(what: str, mtype: int, description: str,
                    subtypes: List[SubtypeSpec],
                    instance: str = "",
                    version:  str = "1.0",
                    author:   str = "",
                    notes:    str = "") -> AgentCapability:
    """
    Build an AgentCapability.

    Capability queries and responses now travel on mtype=1 (UMM system layer)
    via (UMM, ST_CAPABILITY_QUERY) and (UMM, ST_CAPABILITY_RESPONSE), so they
    are NOT prepended to the application mtype's subtype list here.
    """
    return AgentCapability(
        what        = what,
        instance    = instance,
        mtype       = mtype,
        description = description,
        subtypes    = list(subtypes),
        version     = version,
        author      = author,
        notes       = notes,
    )


# ── standard reserved subtypes ────────────────────────────────────────────────
# Populated here after SubtypeSpec is defined.
# Injected into every capability response automatically by CapabilityMixin.

STANDARD_RESERVED_SUBTYPES = [
    SubtypeSpec(
        subtype     = 1,
        name        = "GetCapability",
        direction   = "in",
        description = "Query this agent's capability descriptor.",
        notes       = "Response sent on channel=META (4), mtype=UMM, subtype=52 (CAPABILITY_RESPONSE). "
                      "No payload required. Send to mtype=0 for broadcast.",
    ),
    SubtypeSpec(
        subtype     = 2,
        name        = "GetVersion",
        direction   = "in",
        description = "Query this agent's version information.",
        output_tlvs = [
            TLVSpec(type_id=8, name="Char", required=True,
                    description='JSON: {"system":"1.2","group":"1.0.0",'
                                '"agent":"1.0.0","build":"dev"}'),
        ],
        notes       = "Response sent on channel=META (4), mtype=UMM, subtype=54 (VERSION_RESPONSE).",
    ),
    SubtypeSpec(
        subtype     = 3,
        name        = "SetDebug",
        direction   = "in",
        description = "Enable or disable debug message publishing on channel=DEBUG (3).",
        input_tlvs  = [
            TLVSpec(type_id=3, name="Bool", required=True,
                    description="true=enable debug publishing, false=disable."),
        ],
        notes       = "No response. When enabled, the agent publishes log records "
                      "on the DEBUG channel (3) using its OWN mtype and subtype "
                      "DEBUG_MSG (13): Int(source_mtype) Int(level) Char(text). "
                      "A malformed request (missing Bool) draws an error on the "
                      "CONFIRM channel (2).",
    ),
    SubtypeSpec(
        subtype     = 4,
        name        = "Shutdown",
        direction   = "in",
        description = "Request graceful shutdown of this agent.",
        notes       = "No payload. No response. Agent disconnects from the router "
                      "and exits cleanly. The supervisor/watchdog uses this to "
                      "stop managed agents without sending OS signals.",
    ),
]


# ── capability mixin ──────────────────────────────────────────────────────────

class CapabilityMixin:
    """
    Mixin that adds automatic capability query handling to any agent module.

    Define CAPABILITY as a class attribute, then call
    register_capability_handler(agent) after connecting.

    The mixin registers TWO subscriptions on mtype=1 (UMM system layer):

      1. (UMM, ST_CAPABILITY_QUERY=51)  with Int == cap.mtype  — targeted query
      2. (UMM, ST_CAPABILITY_QUERY=51)  with no match_tlvs    — broadcast query

    Responses are sent on (UMM, ST_CAPABILITY_RESPONSE=52) with
    Int(cap.mtype) so the requester can identify the responder.

    Application mtype namespaces are completely unaffected — no subtypes
    are reserved by the capability system.
    """

    CAPABILITY: Optional[AgentCapability] = None

    def register_capability_handler(self, agent,
                                     instance: str = "",
                                     mtype_override: int = 0) -> None:
        """
        Register the capability query handler on *agent*.

        Parameters
        ----------
        agent          : UMMAgent — must be connected before calling this
        instance       : str      — optional instance name override
        mtype_override : int      — if nonzero, overrides the mtype in the
                                    capability response (used when the same
                                    bridge agent attaches with different mtypes
                                    on each side)
        """
        from umm.core.messages import MType
        from umm.core.registry import registry
        from umm.types._base import MatchOp

        cap = self.CAPABILITY
        if cap is None:
            raise ValueError(f"{type(self).__name__} must define CAPABILITY")

        if instance:
            from dataclasses import replace as _replace
            cap = _replace(cap, instance=instance)
        if mtype_override:
            from dataclasses import replace as _replace
            cap = _replace(cap, mtype=mtype_override)

        def _send_response(cap_snapshot, msg_id: int = 0,
                           use_meta_channel: bool = False) -> None:
            """Build and send a capability response.

            Legacy path: (UMM, 11) — used for broadcast discovery.
            New path:    (-3, 1)   — used for reserved subtype 1 queries,
                                     includes MsgRef for correlation.
            """
            from umm.core.tlv import TLV
            import logging as _logging

            # Inject standard reserved subtypes (GetCapability, GetVersion,
            # SetDebug) at the front of the subtype list if not already present.
            existing_subtypes = {s.subtype for s in cap_snapshot.subtypes}
            injected = [s for s in STANDARD_RESERVED_SUBTYPES
                        if s.subtype not in existing_subtypes]
            if injected:
                from dataclasses import replace as _replace
                cap_snapshot = _replace(
                    cap_snapshot,
                    subtypes=injected + list(cap_snapshot.subtypes)
                )

            response_cap = AgentCapability(
                **{**asdict(cap_snapshot),
                   'attach_id': f"{agent.attach_id.router}.{agent.attach_id.id}"})
            try:
                import struct as _struct
                int_type   = registry.get_by_id(2)   # IntType  TYPE_ID=2
                json_bytes = response_cap.to_json().encode('utf-8') + b'\x00'

                loop = agent._loop
                if loop is None:
                    return

                if use_meta_channel:
                    # New path: (-3, 1) with standard envelope
                    # Int(source_mtype)  MsgRef(msg_id)  Char(json)
                    msgref_val = _struct.pack('!III', 0, 0, msg_id)
                    tlvs = []
                    if int_type:
                        tlvs.append(int_type.make_tlv(cap_snapshot.mtype))
                    tlvs.append(TLV(type_id=16, value=msgref_val))
                    tlvs.append(TLV(type_id=8,  value=json_bytes))

                    async def _send_meta():
                        try:
                            from umm.core.messages import Channel as _CH
                            await agent._async_send(
                                int(MType.UMM), ST_CAPABILITY_RESPONSE, tlvs, 0,
                                channel=int(_CH.META))
                        except Exception as exc:
                            _logging.getLogger(__name__).warning(
                                "Capability meta response failed: %s", exc)

                    loop.call_soon_threadsafe(
                        lambda: loop.create_task(_send_meta()))
                else:
                    # Legacy path: (UMM, 11) for broadcast discovery
                    tlvs = []
                    if int_type:
                        tlvs.append(int_type.make_tlv(cap_snapshot.mtype))
                    tlvs.append(TLV(type_id=8, value=json_bytes))

                    async def _send_cap():
                        try:
                            from umm.core.messages import Channel as _CH
                            await agent._async_send(MType.UMM,
                                                    ST_CAPABILITY_RESPONSE,
                                                    tlvs, 0,
                                                    channel=int(_CH.META))
                        except Exception as exc:
                            _logging.getLogger(__name__).warning(
                                "Capability response failed: %s", exc)

                    loop.call_soon_threadsafe(
                        lambda: loop.create_task(_send_cap()))

            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning(
                    "Capability response failed: %s", exc)

        def on_query_targeted(msg) -> None:
            msg_id = getattr(msg, 'msg_id', 0)
            _send_response(cap, msg_id=msg_id, use_meta_channel=True)

        def on_reserved_get_capability(msg) -> None:
            """Handle GetCapability on reserved subtype 1 — respond on channel META."""
            msg_id = getattr(msg, 'msg_id', 0)
            _send_response(cap, msg_id=msg_id, use_meta_channel=True)

        int_type = registry.get_by_id(2)

        def on_query_broadcast(msg) -> None:
            # If the query contains an Int(mtype) payload it is a targeted
            # query. When the targeted subscription (content-match Int ==
            # cap.mtype) is registered, it alone handles targeted queries —
            # responding here as well would send a duplicate response.
            # Broadcast queries have no Int payload.
            if msg.tdata.value:
                try:
                    from umm.core.tlv import decode_all as _da
                    for tlv in _da(msg.tdata.value):
                        if tlv.type_id == 2:   # Int — targeted mtype
                            if int_type:
                                return   # targeted sub handles it
                            import struct as _struct
                            target = _struct.unpack('!i', tlv.value[:4])[0]
                            if target != cap.mtype:
                                return   # not for us
                            break
                except Exception:
                    pass
            msg_id = getattr(msg, 'msg_id', 0)
            _send_response(cap, msg_id=msg_id, use_meta_channel=True)

        # Subscription 1: targeted — only reaches this agent
        if int_type:
            agent.register(
                mtype          = MType.UMM,
                subtype        = ST_CAPABILITY_QUERY,
                callback       = on_query_targeted,
                dont_send_self = False,
                match_tlvs     = [int_type.make_subscription_tlv(
                                      cap.mtype, MatchOp.EQ)],
            )

        # Subscription 2: broadcast — no content match, reaches all agents
        agent.register(
            mtype          = MType.UMM,
            subtype        = ST_CAPABILITY_QUERY,
            callback       = on_query_broadcast,
            dont_send_self = False,
        )

        # Subscription 3: reserved subtype 1 (GetCapability) on own mtype
        # Responds on (-3, 1) with MsgRef for correlation — new convention.
        agent.register(
            mtype          = cap.mtype,
            subtype        = 1,   # ReservedSubType.GET_CAPABILITY
            callback       = on_reserved_get_capability,
            dont_send_self = False,
        )


# ── query helpers ─────────────────────────────────────────────────────────────

def register_capability_handler(agent, cap: 'AgentCapability') -> None:
    """
    Standalone helper — register capability query handlers on *agent*.

    Equivalent to CapabilityMixin.register_capability_handler but usable
    by any agent that isn't a CapabilityMixin subclass (e.g. the GUI server).
    """
    m = CapabilityMixin()
    m.CAPABILITY = cap
    m.register_capability_handler(agent)


def query_capability(agent, mtype: int,
                     callback: Callable[[Optional[AgentCapability]], None],
                     timeout:  float = 3.0) -> None:
    """
    Query one agent's capabilities.

    Sends (UMM, ST_CAPABILITY_QUERY=51) with Int(mtype) payload.
    Registers a one-shot subscription on (UMM, ST_CAPABILITY_RESPONSE=52)
    with a content match Int == mtype so only the target agent's response
    is delivered.  Calls callback with the AgentCapability (or None on timeout).
    """
    from umm.core.messages import MType
    from umm.core.registry import registry
    from umm.types._base import MatchOp

    got    = threading.Event()
    result: List[Optional[AgentCapability]] = [None]

    def on_response(msg) -> None:
        if msg.tdata.value:
            try:
                from umm.core.tlv import decode_all
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == 8:
                        text = tlv.value.rstrip(b'\x00').decode('utf-8')
                        result[0] = AgentCapability.from_json(text)
                        got.set()
                        return
            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning(
                    "Capability parse error: %s", exc)
                got.set()

    int_type = registry.get_by_id(2)

    # Listen for the response: (UMM, 52) filtered to this agent's mtype.
    # Responses travel on channel META (4) — subscribe there, not on the
    # default APP channel, or the response is never delivered.
    from umm.core.messages import Channel as _CH
    reg_id = agent.register(
        mtype          = MType.UMM,
        subtype        = ST_CAPABILITY_RESPONSE,
        callback       = on_response,
        dont_send_self = False,
        channel        = int(_CH.META),
        match_tlvs     = ([int_type.make_subscription_tlv(mtype, MatchOp.EQ)]
                          if int_type else []),
    )

    # Send the query: (UMM, 10) Int(target_mtype)
    tlvs = [int_type.make_tlv(mtype)] if int_type else []
    agent.send(mtype=MType.UMM, subtype=ST_CAPABILITY_QUERY, tlvs=tlvs)

    def wait_and_cleanup() -> None:
        got.wait(timeout=timeout)
        agent.unregister(reg_id)
        callback(result[0])

    threading.Thread(target=wait_and_cleanup, daemon=True).start()


def discover_agents(agent, timeout: float = 3.0,
                    callback: Callable[[List[AgentCapability]], None] = None
                    ) -> List[AgentCapability]:
    """
    Broadcast a capability query to ALL agents.

    Sends (UMM, ST_CAPABILITY_QUERY=51) with no payload.
    Every capability-aware agent on the bus responds on (UMM, 11).
    Waits for *timeout* seconds to collect all responses.

    Returns a list of AgentCapability objects sorted by mtype.
    If *callback* is provided, it is called as each response arrives.
    """
    from umm.core.messages import MType

    responses: Dict[str, AgentCapability] = {}   # attach_id → cap
    lock = threading.Lock()

    def on_response(msg) -> None:
        if not msg.tdata.value:
            return
        try:
            from umm.core.tlv import decode_all
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == 8:
                    text = tlv.value.rstrip(b'\x00').decode('utf-8')
                    cap  = AgentCapability.from_json(text)
                    with lock:
                        responses[cap.attach_id or str(msg.origin.id)] = cap
                    if callback:
                        callback([cap])
                    return
        except Exception:
            pass

    # Responses travel on channel META (4) — subscribe there, not on the
    # default APP channel, or the responses are never delivered.
    from umm.core.messages import Channel as _CH
    reg_id = agent.register(
        mtype          = MType.UMM,
        subtype        = ST_CAPABILITY_RESPONSE,
        callback       = on_response,
        dont_send_self = False,
        channel        = int(_CH.META),
    )
    # Broadcast: no Int(mtype) payload → all agents respond
    agent.send(mtype=MType.UMM, subtype=ST_CAPABILITY_QUERY)
    time.sleep(timeout)
    agent.unregister(reg_id)

    with lock:
        return sorted(responses.values(), key=lambda c: c.mtype)


# ── built-in descriptors ──────────────────────────────────────────────────────

TIMER_CAPABILITY = make_capability(
    what        = "Timer",
    mtype       = 2,
    description = (
        "Fires UMM messages on a schedule. "
        "Supports one-shot, fixed-count and repeating timers. "
        "Times below 1,000,000,000 are relative seconds from now; "
        "larger values are absolute Unix timestamps."
    ),
    subtypes = [
        SubtypeSpec(
            subtype          = 101,
            name             = "Request",
            direction        = "in",
            response_subtype = 103,     # timer responds on subtype=103 (Confirmed)
            description      = "Schedule a message to fire at a future time or repeatedly.",
            input_tlvs  = [
                TLVSpec(type_id=9,  name="UTime", required=True,  unit="seconds",
                        description="Fire interval or absolute start time. "
                                    "Values < 1,000,000,000 = relative seconds from now."),
                TLVSpec(type_id=2,  name="Int",   required=True,
                        description="Repeat count. -1 = forever, 1 = once, N = N times."),
                TLVSpec(type_id=9,  name="UTime", required=False, unit="seconds",
                        description="Optional repeat interval if different from start delay."),
                TLVSpec(type_id=11, name="Msg",   required=True,
                        description="Message to fire: mtype(4 bytes NBO) + subtype(4 bytes NBO) + TLV payload.",
                        notes="The entire inner message is re-sent unchanged each time."),
            ],
            notes="Timer agent must be running: python3 -m umm.modules.timer --port 5100",
        ),
        SubtypeSpec(
            subtype          = 102,
            name             = "Cancel",
            direction        = "in",
            response_subtype = None,
            description      = "Cancel a previously registered timer.",
            input_tlvs  = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="reg_id of the timer to cancel."),
            ],
        ),
        SubtypeSpec(
            subtype      = 103,
            name         = "Confirmed",
            direction    = "out",
            responds_to  = 101,
            description  = "Timer successfully created. "
                           "Int(ref) is the timer reference for later cancellation. "
                           "MsgRef(corr) matches the msg_id of the original Request.",
            output_tlvs  = [
                TLVSpec(type_id=2,  name="Int",    required=True,
                        description="Timer ref assigned (use for cancel)."),
                TLVSpec(type_id=16, name="MsgRef", required=True,
                        description="Correlation ID: globally unique reference to the "
                                    "original Request (router.agent.msg_id). "
                                    "Use to match this response to your request."),
            ],
        ),
        SubtypeSpec(
            subtype      = 104,
            name         = "Error",
            direction    = "out",
            responds_to  = 101,
            description  = "Timer request failed. "
                           "Char(message) describes the error. "
                           "MsgRef(corr) matches the msg_id of the original Request.",
            output_tlvs  = [
                TLVSpec(type_id=8,  name="Char",   required=True,
                        description="Error message."),
                TLVSpec(type_id=16, name="MsgRef", required=True,
                        description="Correlation ID matching the original Request."),
            ],
        ),
        SubtypeSpec(
            subtype     = -101,
            name        = "Fired",
            direction   = "out",
            description = "Published by the timer agent each time a timer fires.",
            output_tlvs = [
                TLVSpec(type_id=2, name="Int", required=True,
                        description="reg_id of the timer that fired."),
                TLVSpec(type_id=2, name="Int", required=True,
                        description="Fire count — how many times this timer has fired."),
            ],
        ),
    ],
    author = "Realtime Software Pty Ltd",
)

FSM_CAPABILITY = make_capability(
    what        = "FSM",
    mtype       = 5,
    description = "Finite State Machine agent driven by a plain-text config file.",
    subtypes    = [
        SubtypeSpec(
            subtype     = -101,
            name        = "StateChange",
            direction   = "out",
            description = "Published when the FSM transitions to a new state.",
            output_tlvs = [
                TLVSpec(type_id=8, name="Char", required=True,  description="New state name."),
                TLVSpec(type_id=8, name="Char", required=False, description="Previous state name."),
            ],
        ),
    ],
    author = "Realtime Software Pty Ltd",
)

TYPEDIR_CAPABILITY = make_capability(
    what        = "TypeDirectory",
    mtype       = 10,
    description = "Maintains a registry of all TLV types known to the UMM network.",
    subtypes    = [
        SubtypeSpec(subtype=101, name="GetNextId", direction="in",
                    description="Returns next available free type ID.",
                    output_tlvs=[TLVSpec(type_id=2, name="Int",
                                         description="Next free type ID.")]),
        SubtypeSpec(subtype=102, name="Register", direction="in",
                    description="Register a new type definition.",
                    input_tlvs=[
                        TLVSpec(type_id=2, name="Int",  description="Type ID."),
                        TLVSpec(type_id=8, name="Char", description="Type name."),
                        TLVSpec(type_id=8, name="Char", description="Description."),
                        TLVSpec(type_id=8, name="Char", description="Base type name."),
                    ]),
        SubtypeSpec(subtype=103, name="QueryByName", direction="in",
                    description="Find a type by name.",
                    input_tlvs=[TLVSpec(type_id=8, name="Char",
                                        description="Type name.")],
                    output_tlvs=[TLVSpec(type_id=8, name="Char",
                                          description="JSON type descriptor.")]),
        SubtypeSpec(subtype=-101, name="TypeAdded", direction="out",
                    description="Published when a new type is registered.",
                    output_tlvs=[TLVSpec(type_id=8, name="Char",
                                          description="JSON descriptor of new type.")]),
    ],
    author = "Realtime Software Pty Ltd",
)

BRIDGE_CAPABILITY = make_capability(
    what        = "Bridge",
    mtype       = 11,
    description = "Links two UMM routers. Agents on either side subscribe to messages from the other transparently.",
    subtypes    = [
        SubtypeSpec(subtype=101, name="Subscribe", direction="in",
                    description="Request a bridge subscription on the remote router.",
                    input_tlvs=[TLVSpec(type_id=11, name="Msg",
                                        description="mtype(4) subtype(4) + match TLVs.")]),
        SubtypeSpec(subtype=102, name="Unsubscribe", direction="in",
                    description="Remove a bridge subscription.",
                    input_tlvs=[TLVSpec(type_id=2, name="Int",
                                        description="reg_id to remove.")]),
        SubtypeSpec(subtype=-101, name="Status", direction="out",
                    description="Bridge status response.",
                    output_tlvs=[TLVSpec(type_id=8, name="Char",
                                          description="JSON: router addresses, subscription counts.")]),
    ],
    author = "Realtime Software Pty Ltd",
)

SUPERVISOR_CAPABILITY = make_capability(
    what        = "Supervisor",
    mtype       = 12,
    description = (
        "Process manager and liveness monitor. "
        "Reads supervisor.conf, starts all configured agents, and restarts "
        "them on failure using exponential backoff. Supports critical (C), "
        "essential (E), and heartbeat (H) monitoring policies."
    ),
    subtypes    = [
        SubtypeSpec(subtype=101, name="StartAgent", direction="in",
                    description="Dynamically start a new agent.",
                    input_tlvs=[
                        TLVSpec(type_id=8, name="Char", required=True,
                                description="Shell command to start the agent."),
                        TLVSpec(type_id=2, name="Int",  required=False,
                                description="Policy flags: 1=Critical, 2=Essential, 4=Heartbeat."),
                    ]),
        SubtypeSpec(subtype=102, name="StopAgent", direction="in",
                    description="Send Shutdown to a managed agent.",
                    input_tlvs=[TLVSpec(type_id=8, name="Char", required=True,
                                        description="Agent name as given in supervisor.conf.")]),
        SubtypeSpec(subtype=103, name="RestartAgent", direction="in",
                    description="Stop then restart a managed agent.",
                    input_tlvs=[TLVSpec(type_id=8, name="Char", required=True,
                                        description="Agent name.")]),
        SubtypeSpec(subtype=104, name="AgentStatus", direction="in",
                    description="Request status of all managed agents. "
                                "Supervisor responds with AgentStatusResponse (105)."),
        SubtypeSpec(subtype=105, name="AgentStatusResponse", direction="out",
                    description="Response to AgentStatus request. "
                                "Contains a JSON TLV with a list of all managed agents "
                                "and their current state (name, status, pid, mtype, policy, restarts).",
                    output_tlvs=[
                        TLVSpec(type_id=18, name="JSON",
                                description='{"agents": [{"name":…, "status":…, "pid":…, '
                                            '"mtype":…, "policy":…, "restarts":…}]}'),
                    ]),
        SubtypeSpec(subtype=-101, name="AgentStarted", direction="out",
                    description="Published when an agent process starts.",
                    output_tlvs=[
                        TLVSpec(type_id=8, name="Char", description="Agent name."),
                        TLVSpec(type_id=2, name="Int",  description="OS PID."),
                    ]),
        SubtypeSpec(subtype=-102, name="AgentStopped", direction="out",
                    description="Published when an agent process exits.",
                    output_tlvs=[
                        TLVSpec(type_id=8, name="Char", description="Agent name."),
                        TLVSpec(type_id=2, name="Int",  description="OS PID."),
                        TLVSpec(type_id=2, name="Int",  description="Exit code."),
                    ]),
        SubtypeSpec(subtype=-103, name="AgentFailed", direction="out",
                    description="Published when an agent exceeds max restart attempts.",
                    output_tlvs=[
                        TLVSpec(type_id=8, name="Char", description="Agent name."),
                        TLVSpec(type_id=2, name="Int",  description="Attempt count."),
                    ]),
    ],
    author = "Realtime Software Pty Ltd",
)

BUILTIN_CAPABILITIES: Dict[int, AgentCapability] = {
    cap.mtype: cap for cap in [
        TIMER_CAPABILITY,
        FSM_CAPABILITY,
        TYPEDIR_CAPABILITY,
        BRIDGE_CAPABILITY,
        SUPERVISOR_CAPABILITY,
    ]
}


# ── CLI ───────────────────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    from umm.agent import UMMAgent

    p = argparse.ArgumentParser(
        description='Query UMM agent capabilities')
    p.add_argument('--mtype',    type=int, default=None)
    p.add_argument('--router',   default='localhost')
    p.add_argument('--port',     type=int, default=5000)
    p.add_argument('--timeout',  type=float, default=3.0)
    p.add_argument('--discover', action='store_true',
                   help='Discover all capability-aware agents on the bus')
    p.add_argument('--builtin',  action='store_true',
                   help='Show built-in descriptor without connecting')
    args = p.parse_args()

    if args.builtin:
        if args.mtype:
            cap = BUILTIN_CAPABILITIES.get(args.mtype)
            print(cap.to_json() if cap else f"No built-in for mtype={args.mtype}")
        else:
            for cap in BUILTIN_CAPABILITIES.values():
                print(f"\n{'='*60}")
                print(cap.to_json())
        return

    agent = UMMAgent(host=args.router, port=args.port,
                     process_name='CapQuery')
    if not agent.connect():
        print(f"Could not connect to {args.router}:{args.port}")
        return

    if args.discover:
        print(f"Discovering agents on {args.router}:{args.port} "
              f"(waiting {args.timeout}s)...\n")
        caps = discover_agents(agent, timeout=args.timeout)
        if caps:
            for cap in caps:
                print(f"  {cap.summary()}")
                print(f"  {cap.description[:70]}")
                print()
        else:
            print("No capability-aware agents found.")
    elif args.mtype is not None:
        done = threading.Event()

        def on_result(cap) -> None:
            if cap:
                print(cap.to_json())
            else:
                print(f"No response from mtype={args.mtype} "
                      f"within {args.timeout}s")
                builtin = BUILTIN_CAPABILITIES.get(args.mtype)
                if builtin:
                    print("\nBuilt-in descriptor:")
                    print(builtin.to_json())
            done.set()

        query_capability(agent, args.mtype, on_result, args.timeout)
        done.wait(timeout=args.timeout + 1)
    else:
        p.print_help()

    agent.disconnect()


if __name__ == '__main__':
    _main()