"""
umm.logsetup
============
Shared logging configuration for all UMM processes (router, agents, tools).

Two independent axes, controlled separately:

  * **Level** — how much is logged. Default is WARNING (warnings and errors
    only), so a production system is quiet. Raised or lowered at runtime by
    sending a ``SetLogLevel`` message (reserved subtype 5) carrying an
    ``Int(DebugLevel)`` to an agent's own mtype, or ``--debug`` at startup.

  * **Destination** — where surviving records go. Everything goes to the
    process's stderr, which ``umm_ctl`` captures into the shared
    ``logs/umm_<timestamp>.log`` file. Agents that mix in ``DebugMixin`` can
    *also* publish records onto the DEBUG bus channel when ``SetDebug(true)``
    has been sent — that is the separate "log with messages as well as to
    file" boolean.

The wire ``DebugLevel`` scale (DEBUG=0, INFO=1, WARN=2, ERROR=3) is mapped to
Python's logging levels here so the two systems stay in step.
"""
from __future__ import annotations

import logging
import sys

# Default for every UMM process: warnings and errors only.
DEFAULT_LEVEL = logging.WARNING

_LOG_FORMAT = '%(asctime)s %(levelname)-7s %(name)s: %(message)s'

# Wire DebugLevel (umm.core.messages.DebugLevel) → Python logging level.
_DEBUGLEVEL_TO_LOGGING = {
    0: logging.DEBUG,    # DebugLevel.DEBUG
    1: logging.INFO,     # DebugLevel.INFO
    2: logging.WARNING,  # DebugLevel.WARN
    3: logging.ERROR,    # DebugLevel.ERROR
}
_LOGGING_TO_DEBUGLEVEL = {
    logging.DEBUG:    0,
    logging.INFO:     1,
    logging.WARNING:  2,
    logging.ERROR:    3,
    logging.CRITICAL: 3,
}


def init_logging(debug: bool = False, level: int = None) -> None:
    """Configure root logging for a UMM process.

    Idempotent: installs a single stderr handler the first time and only
    adjusts the level on later calls. ``debug=True`` (the ``--debug`` flag)
    forces DEBUG; otherwise ``level`` (a Python logging level) or the
    WARNING default applies.
    """
    if level is None:
        level = logging.DEBUG if debug else DEFAULT_LEVEL
    root = logging.getLogger()
    already = any(getattr(h, '_umm_handler', False) for h in root.handlers)
    if not already:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter(_LOG_FORMAT))
        handler._umm_handler = True            # marker so we don't double-add
        root.addHandler(handler)
    root.setLevel(level)


def logging_level_for(debug_level: int) -> int:
    """Map a wire DebugLevel (0–3) to a Python logging level (clamped)."""
    if debug_level < 0:
        debug_level = 0
    elif debug_level > 3:
        debug_level = 3
    return _DEBUGLEVEL_TO_LOGGING.get(debug_level, logging.WARNING)


def debug_level_for(logging_level: int) -> int:
    """Map a Python logging level to the nearest wire DebugLevel (0–3)."""
    return _LOGGING_TO_DEBUGLEVEL.get(logging_level, 2)


def set_log_level(debug_level: int) -> int:
    """Set the process-wide logging level from a wire DebugLevel (0–3).

    Returns the Python logging level that was applied. This affects the file
    (and any console) sink; agents additionally gate their *bus* output by the
    same DebugLevel so "raise/lower the level" applies to both sinks.
    """
    py_level = logging_level_for(debug_level)
    logging.getLogger().setLevel(py_level)
    return py_level
