"""
umm.project
===========
Load a single per-project definitions file that consolidates the three display
configurations into one place, so every message type associated with a project
is defined together:

    [names]    mtype / subtype display names      -> NameRegistry
    [meta]     meta-word display names            -> meta_registry
    [colors]   parser colour rules                -> parser colour config
    [display]  (reserved for future use)

Example (``examples/sorting/sorting.conf``)::

    [names]
    1004      Barcode
    1004 102  ScanSuccess

    [meta]
    Int 100   sort-code

    [colors]
    mtype 1004 102  bright_green

The file layers on top of the built-in UMM names/metas, so a project file only
needs to list its own definitions.

The top-level ``project.conf`` (at the project root, alongside ``umm.conf``) is
always loaded first by the parser; per-project files (e.g. ``sorting.conf``) are
added with ``--project`` and may be repeated.  The last file loaded wins on any
overlap.

Backward compatibility
-----------------------
This does not replace the existing files — it unifies them.  A legacy
``umm_names.conf`` (no section headers) still loads as names, and a ``parser.conf``
with only a ``[colors]`` section still loads as colours.  Each section loader
ignores the sections it does not own, so any of the three files may be passed to
``load_project`` and only its relevant sections take effect.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional, Tuple

from .names import NameRegistry
from .core.meta import meta_registry

logger = logging.getLogger(__name__)


def load_project(path,
                 names: Optional[NameRegistry] = None,
                 color_rules: Optional[dict] = None
                 ) -> Tuple[NameRegistry, dict, List[str]]:
    """
    Load names + meta names + parser colours from one project file.

    Parameters
    ----------
    path : str | Path
        The project file to load.
    names : NameRegistry, optional
        Registry to load ``[names]`` into.  A fresh one (with built-in
        capabilities preloaded) is created if not supplied.
    color_rules : dict, optional
        Colour-rule dict to merge ``[colors]`` into.  A fresh empty one is
        created if not supplied.

    Returns
    -------
    (names, color_rules, warnings)
        The populated registry, the colour-rule dict, and a list of
        human-readable warnings (missing file, unparseable colour lines, …).
        Loading is never fatal: bad lines are reported and skipped.
    """
    # Colour parsing lives in the parser module; import lazily so importing
    # umm.project never pulls the parser in at module load (and no cycle).
    from umm.modules.parser import load_parser_config, _empty_color_rules

    warnings: List[str] = []

    if names is None:
        names = NameRegistry()
        names.load_capabilities()
    if color_rules is None:
        color_rules = _empty_color_rules()

    p = Path(path)
    if not p.exists():
        warnings.append(f"project file not found: {path}")
        return names, color_rules, warnings

    names.load_file(str(p))          # [names]  (ignores other sections)
    meta_registry.load_file(str(p))  # [meta]   (ignores other sections)
    _, w = load_parser_config(str(p), color_rules)  # [colors]
    warnings += w

    logger.info("Loaded project definitions from %s", path)
    return names, color_rules, warnings
