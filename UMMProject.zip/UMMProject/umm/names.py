"""
umm.names
=========
Extensible name registry for mtype and subtype display names.

Used by the parser and GUI to show human-readable names instead of
raw numbers. Three sources, applied in priority order:

  1. User config file  (highest priority — site-specific names)
  2. Capability registry (names from registered AgentCapability objects)
  3. Built-in table    (fallback — standard UMM mtypes)

Config file format  (umm_names.conf or passed via --names)
-----------------------------------------------------------
Lines starting with # are comments. Blank lines ignored.

    # mtype name
    1001    Control
    1002    Conveyor

    # mtype  subtype  name
    1001     1        Start
    1001     2        EStop
    1002     1        CmdC1
    1002     3        C1StateChanged

Usage
-----
    from umm.names import NameRegistry

    reg = NameRegistry()
    reg.load_capabilities()          # load from capability.py
    reg.load_file('umm_names.conf')  # load site-specific names

    reg.mtype_name(1002)             # → "Conveyor"
    reg.subtype_name(1002, 1)        # → "CmdC1"
    reg.full_name(1002, 1)           # → "Conveyor,CmdC1"
    reg.full_name(1002, 99)          # → "Conveyor,99"
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)

# ── built-in mtype names ──────────────────────────────────────────────────────

BUILTIN_MTYPE_NAMES: Dict[int, str] = {
    # Negative mtypes — infrastructure channels (DESIGN_NOTES.md section 10)
    -1:  'Confirm',
    -2:  'Debug',
    -3:  'Meta',
    # Positive mtypes
    0:   'NULL',
    1:   'UMM',
    2:   'Timer',
    3:   'Command',
    4:   'Metadata',
    5:   'FSM',
    6:   'FileSend',
    7:   'FileRecv',
    8:   'Database',
    9:   'MicroBill',
    10:  'TypeDir',
    11:  'Bridge',
    100: 'Sensor',
    101: 'Actuator',
    102: 'Alarm',
    103: 'Process',
    104: 'Console',
}

# Reserved subtypes 1–3 common to all positive mtypes (DESIGN_NOTES.md section 10)
# These are registered for every known positive mtype at NameRegistry init time.
BUILTIN_RESERVED_SUBTYPE_NAMES: Dict[int, str] = {
    1: 'GetCapability',
    2: 'GetVersion',
    3: 'SetDebug',
}

# Subtype names for mtype=-1 (Confirm channel)
BUILTIN_CONFIRM_SUBTYPE_NAMES: Dict[int, str] = {
    1: 'Error',
    2: 'RouterConfirm',
    3: 'ReceiverAck',
    4: 'AppAck',
}

# Subtype names for mtype=-2 (Debug channel)
BUILTIN_DEBUG_SUBTYPE_NAMES: Dict[int, str] = {
    1: 'DebugMsg',
}

# Subtype names for mtype=-3 (Meta channel)
BUILTIN_META_SUBTYPE_NAMES: Dict[int, str] = {
    1: 'Capability',
    2: 'Version',
}

# Built-in subtype names for mtype=1 (UMM system layer)
BUILTIN_UMM_SUBTYPE_NAMES: Dict[int, str] = {
    # Router control (1–99)
    -1:  'Version',
     0:  'Init',
     1:  'Attach',
     2:  'AttachConfirm',
     3:  'Detach',
     4:  'Register',
     5:  'Unregister',
     6:  'Shutdown',
     7:  'AgentAttached',
     8:  'AgentDetached',
     9:  'AgentReattached',
     10: 'CapabilityQuery',
     11: 'CapabilityResponse',
     20: 'StatusRequest',
     21: 'StatusResponse',
    # System messages (100+)
    100: 'SysError',
    101: 'SysInfo',
    102: 'SysWarn',
    110: 'ListAgents',
    111: 'ListAgentsResponse',
}


# ── name registry ─────────────────────────────────────────────────────────────

class NameRegistry:
    """
    Extensible lookup table for mtype and subtype names.

    Priority (highest first):
      1. Names loaded from user config file
      2. Names loaded from capability descriptors
      3. Built-in names
    """

    def __init__(self) -> None:
        # mtype → name
        self._mtype: Dict[int, str] = dict(BUILTIN_MTYPE_NAMES)
        # (mtype, subtype) → name
        self._subtype: Dict[Tuple[int, int], str] = {}

        # Seed with UMM control subtypes (mtype=1)
        for sub, name in BUILTIN_UMM_SUBTYPE_NAMES.items():
            self._subtype[(1, sub)] = name

        # Seed negative mtype channel subtypes
        for sub, name in BUILTIN_CONFIRM_SUBTYPE_NAMES.items():
            self._subtype[(-1, sub)] = name
        for sub, name in BUILTIN_DEBUG_SUBTYPE_NAMES.items():
            self._subtype[(-2, sub)] = name
        for sub, name in BUILTIN_META_SUBTYPE_NAMES.items():
            self._subtype[(-3, sub)] = name

        # Seed reserved subtypes 1–3 on all known positive mtypes.
        # These are the system-wide standard subtypes (GetCapability,
        # GetVersion, SetDebug) that apply to every agent by convention.
        # Application agents starting at mtype=100 are not seeded here —
        # they pick up the names when their capability descriptor is loaded.
        _STANDARD_POSITIVE_MTYPES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
        for mtype in _STANDARD_POSITIVE_MTYPES:
            for sub, name in BUILTIN_RESERVED_SUBTYPE_NAMES.items():
                key = (mtype, sub)
                if key not in self._subtype:   # don't override mtype=1 specifics
                    self._subtype[key] = name

    # ── loading ───────────────────────────────────────────────────────────────

    def load_capabilities(self) -> None:
        """
        Load names from all registered AgentCapability objects.
        Imports from umm.capability — safe to call even if no capabilities
        are registered yet.
        """
        try:
            from umm.capability import BUILTIN_CAPABILITIES
            for mtype, cap in BUILTIN_CAPABILITIES.items():
                # mtype name from capability 'what' field
                if mtype not in self._mtype:
                    self._mtype[mtype] = cap.what
                # subtype names from SubtypeSpec list
                for spec in cap.subtypes:
                    key = (mtype, spec.subtype)
                    if key not in self._subtype:
                        self._subtype[key] = spec.name
            logger.debug("NameRegistry: loaded %d capabilities",
                         len(BUILTIN_CAPABILITIES))
        except ImportError:
            pass
        except Exception as exc:
            logger.warning("NameRegistry: capability load failed: %s", exc)

    def load_file(self, path: str) -> int:
        """
        Load names from a config file. Returns number of entries loaded.

        File format:
            mtype name                 — mtype name only
            mtype subtype name         — mtype + subtype name
            # comment

        Section-aware: if the file uses ``[section]`` headers (e.g. a
        consolidated project file), only the ``[names]`` section is read and
        other sections (``[meta]``, ``[colors]``) are ignored.  A legacy
        ``umm_names.conf`` with no section headers is read in full.
        """
        p = Path(path)
        if not p.exists():
            logger.debug("NameRegistry: config file not found: %s", path)
            return 0

        count = 0
        # Default 'names' so a header-less legacy file is read entirely.
        section = 'names'
        for lineno, raw in enumerate(p.read_text().splitlines(), 1):
            line = raw.split('#')[0].strip()
            if not line:
                continue
            if line.startswith('[') and line.endswith(']'):
                section = line[1:-1].strip().lower()
                continue
            if section != 'names':
                continue
            parts = line.split()
            try:
                if len(parts) == 2:
                    mtype = int(parts[0])
                    name  = parts[1]
                    self._mtype[mtype] = name
                    count += 1
                elif len(parts) == 3:
                    mtype   = int(parts[0])
                    subtype = int(parts[1])
                    name    = parts[2]
                    self._subtype[(mtype, subtype)] = name
                    # Also register mtype name if not already known
                    if mtype not in self._mtype:
                        self._mtype[mtype] = f"mtype{mtype}"
                    count += 1
                else:
                    logger.warning("NameRegistry: bad line %d in %s: %r",
                                   lineno, path, raw)
            except ValueError as exc:
                logger.warning("NameRegistry: parse error line %d in %s: %s",
                               lineno, path, exc)

        logger.info("NameRegistry: loaded %d names from %s", count, path)
        return count

    def register_capability(self, cap) -> None:
        """Register names from a single AgentCapability object."""
        if cap.mtype not in self._mtype:
            self._mtype[cap.mtype] = cap.what
        for spec in cap.subtypes:
            key = (cap.mtype, spec.subtype)
            if key not in self._subtype:
                self._subtype[key] = spec.name

    def add_mtype(self, mtype: int, name: str) -> None:
        """Add or override a single mtype name."""
        self._mtype[mtype] = name

    def add_subtype(self, mtype: int, subtype: int, name: str) -> None:
        """Add or override a single subtype name."""
        self._subtype[(mtype, subtype)] = name

    # ── lookup ────────────────────────────────────────────────────────────────

    def mtype_name(self, mtype: int) -> str:
        """Return the name for an mtype, or the number as a string."""
        return self._mtype.get(mtype, str(mtype))

    def subtype_name(self, mtype: int, subtype: int) -> Optional[str]:
        """
        Return the name for a subtype, or None if unknown.
        Checks (mtype, subtype) first; returns None if not registered.
        Capability subtypes now live on mtype=1 and are registered there
        like any other subtype — no universal fallback needed.
        """
        return self._subtype.get((mtype, subtype))

    def full_name(self, mtype: int, subtype: int,
                  show_numbers: bool = True, channel: int = 1) -> str:
        """
        Return a formatted display name.

        If name is known:    "Timer,Request"
        If only mtype known: "Timer,42"
        If nothing known:    "2,1"
        If show_numbers:     "Timer(2),Request(1)"  — shown for unknown names

        channel: if > 1, use channel-specific subtype names instead of the
                 UMM control subtype table (avoids collisions e.g. VERSION=2
                 vs ATTACH_CONFIRM=2).
        """
        # Channel-specific subtype name tables (override UMM control names)
        _CHANNEL_SUBTYPES = {
            1: {1:'Error', 2:'RouterConfirm', 3:'ReceiverConfirm', 4:'AppConfirm'},
            2: {1:'DebugMsg'},
            3: {1:'CapabilityResponse', 2:'VersionResponse', 11:'CapabilityResponse'},
            4: {1:'Ping', 2:'Pong'},
            5: {1:'Ping', 2:'Pong'},
        }
        if channel > 1:
            ch_subtypes = _CHANNEL_SUBTYPES.get(channel, {})
            sn = ch_subtypes.get(subtype)
            mn = self.mtype_name(mtype)
            mtype_known = mn != str(mtype)
            mpart = mn if mtype_known else str(mtype)
            if sn:
                return f"{mpart},{sn}"
            else:
                return f"{mpart},{subtype}"
        mn = self.mtype_name(mtype)
        sn = self.subtype_name(mtype, subtype)

        mtype_known = mn != str(mtype)
        stype_known = sn is not None

        if show_numbers:
            # Show number in parens only when name is NOT known
            mpart = mn if mtype_known else str(mtype)
            if not mtype_known:
                mpart = str(mtype)
            elif show_numbers:
                mpart = mn   # name known — no need to repeat number

            spart = sn if stype_known else str(subtype)
        else:
            mpart = mn
            spart = sn or str(subtype)

        return f"{mpart},{spart}"

    def known_mtypes(self) -> Dict[int, str]:
        """Return all known mtype → name mappings."""
        return dict(self._mtype)

    def known_subtypes(self, mtype: int) -> Dict[int, str]:
        """Return all known subtype → name mappings for a given mtype."""
        return {sub: name
                for (mt, sub), name in self._subtype.items()
                if mt == mtype}


# ── global default registry ───────────────────────────────────────────────────

_default_registry: Optional[NameRegistry] = None


def get_registry() -> NameRegistry:
    """Get (or create) the global default name registry."""
    global _default_registry
    if _default_registry is None:
        _default_registry = NameRegistry()
        _default_registry.load_capabilities()
        # Auto-load umm_names.conf from current directory if present
        for candidate in ['umm_names.conf', 'names.conf']:
            if Path(candidate).exists():
                _default_registry.load_file(candidate)
                break
    return _default_registry