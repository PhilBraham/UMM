"""
umm.agent
=========
Client interface — the API that every UMM application uses.

Provides both a synchronous API (for simple scripts and device drivers)
and an async API (for asyncio applications).

Synchronous usage::

    from umm.agent import UMMAgent
    from umm.types.builtin import FloatType, IntType
    from umm.types._base import MatchOp

    client = UMMAgent(host='192.168.1.1', port=5000,
                       process_name='TemperatureSensor')
    client.connect()

    # Publish a temperature reading
    float_type = FloatType()
    client.send(mtype=100, subtype=1,
                tlvs=[float_type.make_tlv(73.5)])

    # Subscribe to readings above 80°C
    def on_high_temp(msg):
        print("High temp alert:", msg)

    client.register(mtype=100, subtype=1,
                    match_tlvs=[float_type.make_subscription_tlv(80.0, MatchOp.GT)],
                    callback=on_high_temp)

    client.run()           # blocks, dispatching callbacks

Async usage::

    async def main():
        client = UMMAgent(host='localhost')
        await client.aconnect()
        await client.asend(mtype=100, subtype=1, tlvs=[...])
        await client.aregister(...)
        await client.arun()
"""

from __future__ import annotations

import asyncio
import logging
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .core.tlv import (
    TLV, TLVBuffer, decode_one, decode_all,
    TLV_TERM, TLV_INT, TLV_STRING, TLV_MSG, TLV_SUBSPEC,
    HEADER_SIZE,
)
from .core.messages import (
    UMMMsg, AttachId, VersionId, UTime, LogId,
    MType, UMMSubType, SType, Channel,
    AttachFlag, RequestFlag, MsgFlag,
    FIXED_HEADER_SIZE, DEFAULT_PORT, MAX_REGISTRATIONS,
)

logger = logging.getLogger(__name__)


# ── connection error ──────────────────────────────────────────────────────────

class UMMConnectionError(Exception):
    """
    Raised when UMMAgent cannot connect to the router.

    More informative than the raw OS exceptions — includes host, port,
    and a suggestion for what to check.
    """



# ── registration record ───────────────────────────────────────────────────────

@dataclass
class Registration:
    reg_id:      int
    mtype:       int
    subtype:     int
    callback:    Callable[[UMMMsg], None]
    flags:       int = 0
    channel:     int = 1   # logical channel this subscription is on; 0=ALL wildcard
    match_tlvs:  Optional[List['TLV']] = None   # content-match criteria for reconnect


# ── UMMAgent ─────────────────────────────────────────────────────────────────

class UMMAgent:
    """
    UMM agent.  Connects to a router and provides send/register/callback.

    Parameters
    ----------
    host : str
        Router hostname or IP.
    port : int
        Router TCP port.  Resolved at import time in priority order:
        ``UMM_ROUTER`` env var (``host:port``) → ``umm.conf``
        ``[settings] port`` → hard-coded fallback 5300.
    process_name : str
        Name used to identify this process to the router.
    login : str
        Optional login name.
    password : str
        Optional password.
    flags : AttachFlag
        Attach flags (permanent connection, monitor mode etc.).
    reconnect : bool
        If True, automatically reconnect on disconnect.
    reconnect_delay : float
        Seconds to wait between reconnect attempts.
    """

    def __init__(self,
                 host:            str   = 'localhost',
                 port:            int   = DEFAULT_PORT,
                 process_name:    str   = 'UMMAgent',
                 login:           str   = '',
                 password:        str   = '',
                 flags:           int   = AttachFlag.NORMAL,
                 reconnect:       bool  = False,
                 reconnect_delay: float = 5.0,
                 on_reconnect:    Optional[Callable[[], None]] = None,
                 agent_mtype:     int   = 0,
                 sim_channel:     int   = 0) -> None:
        """
        Parameters
        ----------
        host : str
            Router hostname or IP.  Default 'localhost'.
            When using umm_ctl, the UMM_ROUTER environment variable is read
            at startup and passed explicitly via --router/--port, so agents
            managed by umm_ctl always connect to the right router.
        port : int
            Router TCP port.  Defaults to the value resolved from
            ``UMM_ROUTER`` env var, ``umm.conf``, or 5300 — in that order.
        agent_mtype : int
            The primary mtype this agent publishes/handles.
            Included in the ATTACH message so the router can publish it
            in AgentAttached lifecycle notifications.
            0 means the agent has no primary mtype (e.g. a monitoring agent).
        sim_channel : int
            Default channel for outgoing sends from this agent.  When non-zero,
            any call to send() or asend() that does not pass an explicit channel
            uses this value instead of 1 (APP).  Useful for simulation agents whose
            traffic should be invisible on the application bus (channel 1) but
            observable by tools that subscribe on the sim channel.
            Default 0 means no override — sends use channel 1 (APP).
            Set to Channel.SIM (128) or similar to route all sends off the app bus.
        """
        self.host            = host
        self.port            = port
        self.process_name    = process_name
        self.login           = login
        self.password        = password
        self.attach_flags    = flags
        self.reconnect       = reconnect
        self.reconnect_delay = reconnect_delay
        self.on_reconnect    = on_reconnect
        self.agent_mtype     = agent_mtype
        self.sim_channel     = sim_channel   # default outgoing channel for this agent

        # Set by _dispatch_application() for the duration of each callback.
        # Callbacks can read agent.reply_channel to discover which channel
        # the incoming message arrived on (useful for channel-aware replies).
        self._current_channel: int = 1

        # State assigned by router
        self.attach_id:  AttachId = AttachId()
        self.router_id:  int      = 0
        self._msg_id:    int      = 1
        self._next_reg:  int      = 1

        # Registered subscriptions
        self._registrations: Dict[int, Registration] = {}

        # Attach callback (called on confirm / shutdown)
        self._attach_callback: Optional[Callable[[UMMMsg], None]] = None

        # Async internals
        self._reader: Optional[asyncio.StreamReader]  = None
        self._writer: Optional[asyncio.StreamWriter]  = None
        self._connected     = False
        self._attached      = False
        self._closing       = False   # set before intentional disconnect to suppress spurious warning
        self._attach_event  = asyncio.Event() if self._have_loop() else None

        # Sync wrapper state
        self._loop:   Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread]          = None

    @staticmethod
    def _have_loop() -> bool:
        try:
            asyncio.get_running_loop()
            return True
        except RuntimeError:
            return False

    def _on_loop_thread(self) -> bool:
        """True if the caller is running on this agent's event-loop thread.

        When this is the case (e.g. inside a plain message callback), the
        synchronous send()/register()/unregister() wrappers must not block on
        run_coroutine_threadsafe(...).result() — that would deadlock the loop.
        """
        try:
            return asyncio.get_running_loop() is self._loop
        except RuntimeError:
            return False

    # ── sync public API ───────────────────────────────────────────────────────

    def connect(self) -> bool:
        """
        Connect and attach synchronously.  Starts a background asyncio loop.
        Returns True on success.
        """
        self._loop = asyncio.new_event_loop()
        self._stop_event = threading.Event()
        ready = threading.Event()
        error_box: List[Exception] = []

        def _run() -> None:
            asyncio.set_event_loop(self._loop)

            def _handle_task_exception(loop, context):
                # Suppress "Task exception was never retrieved" noise for
                # UMMConnectionError — the exception is already in error_box
                # and will be re-raised by connect().  All other unhandled
                # task exceptions still go to the default handler.
                exc = context.get('exception')
                if isinstance(exc, UMMConnectionError):
                    return
                loop.default_exception_handler(context)

            self._loop.set_exception_handler(_handle_task_exception)

            # Schedule connect+attach as a task so run_forever()
            # is the only thing driving the loop — this prevents
            # the race condition where run_until_complete() and
            # run_coroutine_threadsafe() compete for the loop.
            self._loop.call_soon(
                lambda: self._loop.create_task(
                    self._async_connect_and_attach(ready, error_box)))
            try:
                self._loop.run_forever()
            except Exception as exc:
                error_box.append(exc)
                ready.set()
            finally:
                # Cancel all pending tasks cleanly before closing
                try:
                    pending = asyncio.all_tasks(self._loop)
                    for task in pending:
                        task.cancel()
                    if pending:
                        self._loop.run_until_complete(
                            asyncio.gather(*pending, return_exceptions=True))
                except Exception:
                    pass
                self._loop.close()
                self._stop_event.set()

        self._thread = threading.Thread(target=_run, daemon=True, name='umm-client')
        self._thread.start()

        ready.wait(timeout=10.0)
        if error_box:
            raise error_box[0]
        # Give the loop a moment to finish its current cycle
        # before run_coroutine_threadsafe calls begin
        time.sleep(0.05)
        return self._attached

    def disconnect(self) -> None:
        """Detach cleanly and stop the event loop."""
        if not self._loop or not self._loop.is_running():
            return
        self._closing = True   # tell _read_loop this is intentional
        # Schedule the full async shutdown on the event loop
        # This runs detach + cleanup in the right async context
        async def _shutdown():
            if self._connected:
                await self._async_detach()
            self._loop.stop()
        asyncio.run_coroutine_threadsafe(_shutdown(), self._loop)
        # Wait for the background thread to finish cleanly
        stop = getattr(self, '_stop_event', None)
        if stop:
            stop.wait(timeout=3.0)
        elif self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)

    @property
    def reply_channel(self) -> int:
        """Channel of the message currently being dispatched to a callback.

        Read this inside a registered callback to discover which channel the
        incoming message arrived on.  Zero outside of a callback context.

        Typical use: pass through to the response send so replies travel on
        the same channel as the request.  Particularly useful for simulation
        channels — a request on channel 150 gets its response on channel 150
        so both directions are visible (or invisible) together.
        """
        return self._current_channel

    def send(self, mtype: int, subtype: int,
             tlvs: Optional[List[TLV]] = None,
             flags: int = 0,
             channel: int = -1,
             tm: Optional['UTime'] = None) -> None:
        """
        Send a message with an optional list of TLV payloads.

        Parameters
        ----------
        mtype, subtype : int
            Message type and sub-type.
        tlvs : list[TLV], optional
            Payload TLVs (built using type handlers).
        flags : int
            Message flags (MsgFlag values).
        channel : int
            Logical channel (Channel enum).  If omitted, uses sim_channel
            (set at construction time; default 0 = application bus).
            Pass channel=1 (Channel.APP) explicitly to force the application bus
            regardless of sim_channel.  channel=0 means ALL (subscription wildcard)
            and should not be passed to send().
        """
        if not self._loop:
            raise RuntimeError("Not connected – call connect() first")
        effective_channel = (self.sim_channel or 1) if channel == -1 else channel
        if self._on_loop_thread():
            # Called from within a plain message callback (runs on the loop
            # thread).  Blocking on .result() here would deadlock the loop, so
            # schedule the send and return without waiting.  Use asend() from an
            # async callback if you need to await completion.
            self._loop.create_task(
                self._async_send(mtype, subtype, tlvs, flags,
                                 channel=effective_channel, tm=tm))
            return
        fut = asyncio.run_coroutine_threadsafe(
            self._async_send(mtype, subtype, tlvs, flags,
                             channel=effective_channel, tm=tm),
            self._loop)
        fut.result(timeout=5.0)

    def register(self, mtype: int, subtype: int,
                 callback: Callable[[UMMMsg], None],
                 match_tlvs: Optional[List[TLV]] = None,
                 flags: int = 0,
                 channel: int = 1,
                 dont_send_self: bool = True) -> int:
        """
        Register a subscription.

        Parameters
        ----------
        mtype : int
            Message type to subscribe to (0 = all).
        subtype : int
            Sub-type to subscribe to (0 = all of this mtype).
        callback : callable
            Called with the UMMMsg when a matching message arrives.
        match_tlvs : list[TLV], optional
            Content-matching criteria.  Each TLV's M-word carries the
            operator; value carries the threshold.
        flags : int
            RequestFlag values.
        channel : int
            Logical channel to subscribe on (Channel enum); default 1 = APP.
            Pass channel=0 (Channel.ALL) to subscribe on all channels.
        dont_send_self : bool
            If True, don't deliver messages sent by this client back to itself.

        Returns
        -------
        int
            Registration ID (use to unregister later).
        """
        if not self._loop:
            raise RuntimeError("Not connected")
        if dont_send_self:
            flags |= RequestFlag.DONT_SEND_SELF

        if self._on_loop_thread():
            # Called from within a plain message callback, which runs on the
            # event-loop thread (e.g. the FSM re-registering its subscriptions
            # on a state transition).  Blocking on run_coroutine_threadsafe(...)
            # .result() here would deadlock the loop.  The reg_id is allocated
            # locally and needs no reply from the router, so register
            # synchronously and schedule the network write.
            reg_id, msg = self._register_local(mtype, subtype, callback,
                                               match_tlvs, flags, channel)
            self._loop.create_task(self._write(msg))
            return reg_id

        fut = asyncio.run_coroutine_threadsafe(
            self._async_register(mtype, subtype, callback, match_tlvs, flags,
                                 channel),
            self._loop)
        return fut.result(timeout=5.0)

    def unregister(self, reg_id: int) -> None:
        if not self._loop:
            return
        if self._on_loop_thread():
            self._loop.create_task(self._async_unregister(reg_id))
            return
        asyncio.run_coroutine_threadsafe(
            self._async_unregister(reg_id), self._loop)

    def send_confirmed(self,
                       mtype: int, subtype: int,
                       tlvs: Optional[List[TLV]] = None,
                       on_router_confirm: Optional[Callable[[int], None]] = None,
                       on_receiver_ack:   Optional[Callable[[], None]]    = None,
                       on_app_ack:        Optional[Callable[[], None]]    = None,
                       timeout: float = 5.0) -> int:
        """
        Send a message and register one-shot callbacks for confirm responses.

        Uses MsgFlag.CONFIRM_RTR / CONFIRM_RCV / CONFIRM_APP to request
        router, receiver, and/or application-level acknowledgements.
        Responses arrive on MType.CONFIRM (-1).

        Parameters
        ----------
        mtype, subtype : int
            Message type and sub-type.
        tlvs : list[TLV], optional
            Payload TLVs.
        on_router_confirm : callable(receiver_count), optional
            Called when the router confirms delivery.  Receives the number
            of agents the message was forwarded to.
        on_receiver_ack : callable(), optional
            Called when the router acknowledges receipt on behalf of receivers.
        on_app_ack : callable(), optional
            Called when a receiving agent explicitly calls send_app_confirm().
            Requires CONFIRM_APP flag; the receiving agent must cooperate.
        timeout : float
            Seconds to wait before auto-unregistering confirm subscriptions.

        Returns
        -------
        int
            The msg_id of the sent message (for correlation).
        """
        import threading as _threading
        from .core.messages import ConfirmSubType as _CST, MType as _MT
        from .core.registry import registry as _reg
        from .types._base import MatchOp as _MatchOp

        if not self._loop:
            raise RuntimeError("Not connected – call connect() first")

        flags = 0
        if on_router_confirm:
            flags |= MsgFlag.CONFIRM_RTR
        if on_receiver_ack:
            flags |= MsgFlag.CONFIRM_RCV
        if on_app_ack:
            flags |= MsgFlag.CONFIRM_APP

        int_type = _reg.get_by_id(2)
        if not int_type or not flags:
            # No confirm callbacks (or Int type unavailable) — plain send.
            fut = asyncio.run_coroutine_threadsafe(
                self._async_send(mtype, subtype, tlvs, flags), self._loop)
            fut.result(timeout=timeout)
            return self._msg_id - 1

        # Subscribe to (-1, ROUTER_CONFIRM) and (-1, RECEIVER_ACK) filtered
        # by source_mtype so we only receive confirms for our own message type.
        #
        # ORDER MATTERS: the subscriptions must be registered BEFORE the
        # message is sent.  The router generates ROUTER_CONFIRM immediately
        # after routing, so registering afterwards guarantees the confirm
        # arrives before the subscription exists and is dropped.  Registering
        # first is sufficient — REGISTER and the send travel the same ordered
        # TCP stream, so the router processes them in that order.
        reg_ids = []

        if on_router_confirm and int_type:
            match = [int_type.make_subscription_tlv(mtype, _MatchOp.EQ)]
            def _rtr_cb(msg):
                import struct as _s
                # TLVs: Int(source_mtype), MsgRef(msg_id), Int(receiver_count)
                tlvs_in = []
                try:
                    from .core.tlv import decode_all as _da
                    tlvs_in = list(_da(msg.tdata.value)) if msg.tdata.value else []
                except Exception:
                    pass
                count = 0
                if len(tlvs_in) >= 3 and tlvs_in[2].value:
                    try:
                        count = _s.unpack('!i', tlvs_in[2].value[:4])[0]
                    except Exception:
                        pass
                on_router_confirm(count)
                for rid in reg_ids:
                    self.unregister(rid)

            rid = self.register(
                mtype=_MT.CONFIRM, subtype=int(_CST.ROUTER_CONFIRM),
                callback=_rtr_cb, match_tlvs=match, dont_send_self=False,
                channel=int(Channel.CONFIRM))
            reg_ids.append(rid)

        if on_receiver_ack and int_type:
            match = [int_type.make_subscription_tlv(mtype, _MatchOp.EQ)]
            def _rcv_cb(msg):
                on_receiver_ack()
                for rid in reg_ids:
                    self.unregister(rid)

            rid = self.register(
                mtype=_MT.CONFIRM, subtype=int(_CST.RECEIVER_ACK),
                callback=_rcv_cb, match_tlvs=match, dont_send_self=False,
                channel=int(Channel.CONFIRM))
            reg_ids.append(rid)

        if on_app_ack and int_type:
            match = [int_type.make_subscription_tlv(mtype, _MatchOp.EQ)]
            def _app_cb(msg):
                on_app_ack()
                for rid in reg_ids:
                    self.unregister(rid)

            rid = self.register(
                mtype=_MT.CONFIRM, subtype=int(_CST.APP_ACK),
                callback=_app_cb, match_tlvs=match, dont_send_self=False,
                channel=int(Channel.CONFIRM))
            reg_ids.append(rid)

        # Now send the message; capture its msg_id for correlation
        fut = asyncio.run_coroutine_threadsafe(
            self._async_send(mtype, subtype, tlvs, flags), self._loop)
        fut.result(timeout=timeout)
        sent_msg_id = self._msg_id - 1   # _msg_id was incremented after send

        # Auto-cleanup after timeout
        def _cleanup():
            _threading.Event().wait(timeout)
            for rid in reg_ids:
                try:
                    self.unregister(rid)
                except Exception:
                    pass
        _threading.Thread(target=_cleanup, daemon=True,
                          name='confirm-cleanup').start()

        return sent_msg_id

    def send_app_confirm(self, original_msg: 'UMMMsg') -> None:
        """
        Send an application-level acknowledgement for a received message.

        Call this after successfully processing a message that was sent with
        MsgFlag.CONFIRM_APP.  Sends (-1, ConfirmSubType.APP_ACK) back to the
        originating agent so its on_app_ack callback fires.

        Parameters
        ----------
        original_msg : UMMMsg
            The message being acknowledged.  The origin AttachId and msg_id
            are read from it to build the correlation TLVs.
        """
        import struct as _struct
        from .core.messages import ConfirmSubType as _CST, MType as _MT
        from .core.tlv import TLV_INT, TLV_MSGREF

        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_INT,
                    value=_struct.pack('!i', original_msg.mtype)))
        buf.add(TLV(type_id=TLV_MSGREF,
                    value=_struct.pack('!III',
                                       original_msg.origin.router,
                                       original_msg.origin.id,
                                       original_msg.msg_id)))
        self.send(mtype=int(_MT.CONFIRM),
                  subtype=int(_CST.APP_ACK),
                  tlvs=list(buf),
                  channel=int(Channel.CONFIRM))


        """Block the calling thread until disconnected."""
        if self._thread:
            self._thread.join()

    def set_attach_callback(self, cb: Callable[[UMMMsg], None]) -> None:
        """Set a callback invoked on attach confirm and shutdown."""
        self._attach_callback = cb

    def query_matches(self,
                      mtype:    int,
                      subtype:  int,
                      tlvs:     Optional[List[TLV]] = None,
                      callback: Optional[Callable[[dict], None]] = None,
                      timeout:  float = 5.0) -> Optional[dict]:
        """
        Ask the router which subscriptions would receive a hypothetical message.

        Sends a MATCH_QUERY (UMM, 22) to the router with the supplied mtype,
        subtype, and optional TLV payload.  The router runs its full match
        logic — including delegating Char TLVs to any connected match
        plugin — and returns MATCH_RESULT (UMM, 23) with every subscription
        that would have matched.  Nothing is delivered to any subscriber.

        Parameters
        ----------
        mtype, subtype : int
            The hypothetical message type and sub-type.
        tlvs : list[TLV], optional
            Content-match payload.  The same TLVs you would include in the
            real message.  Omit for a subtype-only probe.
        callback : callable(result_dict), optional
            If supplied, returns immediately and invokes *callback* when the
            result arrives (non-blocking).  Useful when the payload contains
            Char TLVs that need async plugin evaluation — in that case
            two calls may arrive: one for sync matches and one for plugin
            matches.  Each call receives a complete result dict.
        timeout : float
            Seconds to wait when called without a callback (blocking mode).
            Ignored in callback mode.

        Returns
        -------
        dict or None
            In blocking mode: the result dict (see below).
            In callback mode: None (result delivered to callback instead).

        Result dict
        -----------
        ::

            {
              "query": {"mtype": <int>, "subtype": <int>},
              "matches": [
                {
                  "attach_id":   <int>,
                  "reg_id":      <int>,
                  "agent_name":  <str>,
                  "agent_mtype": <int>
                },
                ...
              ],
              "plugin_pending": <bool>   # True if a second call follows
            }

        ``plugin_pending`` is True when the payload contains TLV types owned
        by a match plugin (e.g. Char strings).  In that case the first result
        contains only sync (non-plugin) matches; a second result arrives
        shortly after with the plugin matches (``plugin_pending`` will be
        False).  In callback mode both calls are delivered to *callback*.  In
        blocking mode only the first (sync) result is returned.
        """
        import json as _json
        import struct as _struct
        from .core.messages import UMMSubType as _UST, MType as _MT
        from .core.tlv import TLVBuffer as _Buf

        if not self._loop:
            raise RuntimeError("Not connected – call connect() first")

        # ── Build the MATCH_QUERY payload ─────────────────────────────────────
        # Same layout as REGISTER: TLV_MSG wrapping mtype(4) subtype(4) <tlvs>
        inner = _struct.pack('!ii', mtype, subtype)
        if tlvs:
            tbuf = _Buf()
            for t in tlvs:
                tbuf.add(t)
            inner += tbuf.encode()

        outer = _Buf()
        outer.add(TLV(type_id=TLV_SUBSPEC, value=inner))

        # ── Send and capture msg_id ───────────────────────────────────────────
        fut = asyncio.run_coroutine_threadsafe(
            self._async_send(int(_MT.UMM), int(_UST.MATCH_QUERY),
                             list(outer), 0),
            self._loop)
        fut.result(timeout=timeout)
        sent_msg_id = self._msg_id - 1

        # ── Register for MATCH_RESULT correlated by msg_id ───────────────────
        # The router stamps the response with the same msg_id as the request
        # so we can filter precisely.
        from .core.registry import registry as _reg
        from .types._base import MatchOp as _MO
        import threading as _threading

        msgref_type = _reg.get_by_id(16)   # MsgRef

        result_holder: list = []
        done_event = _threading.Event()
        reg_ids: list = []

        def _on_result(msg) -> None:
            if not msg.tdata.value:
                return
            try:
                text = msg.tdata.value.rstrip(b'\x00').decode('utf-8')
                data = _json.loads(text)
            except Exception:
                return
            if callback:
                try:
                    callback(data)
                except Exception as exc:
                    logger.exception("query_matches callback error: %s", exc)
                if not data.get('plugin_pending'):
                    for rid in reg_ids:
                        self.unregister(rid)
            else:
                result_holder.append(data)
                done_event.set()
                for rid in reg_ids:
                    self.unregister(rid)

        # MsgRef match: router_id(4) attach_id(4) msg_id(4)
        match_tlvs = None
        if msgref_type:
            match_tlvs = [msgref_type.make_subscription_tlv(
                _struct.pack('!III', self.router_id,
                             0,       # router's attach_id is 0
                             sent_msg_id),
                _MO.EQ)]

        rid = self.register(
            mtype          = int(_MT.UMM),
            subtype        = int(_UST.MATCH_RESULT),
            callback       = _on_result,
            match_tlvs     = match_tlvs,
            dont_send_self = False,
        )
        reg_ids.append(rid)

        if callback:
            return None

        # Blocking: wait for the result
        if not done_event.wait(timeout=timeout):
            for rid in reg_ids:
                try:
                    self.unregister(rid)
                except Exception:
                    pass
            raise TimeoutError(
                f"query_matches: no response within {timeout}s")

        return result_holder[0] if result_holder else None

    # ── async public API ──────────────────────────────────────────────────────

    async def aconnect(self) -> bool:
        ready = threading.Event()
        error_box: List[Exception] = []
        await self._async_connect_and_attach(ready, error_box)
        return self._attached

    async def asend(self, mtype: int, subtype: int,
                    tlvs: Optional[List[TLV]] = None,
                    flags: int = 0,
                    channel: int = -1) -> None:
        effective_channel = (self.sim_channel or 1) if channel == -1 else channel
        await self._async_send(mtype, subtype, tlvs, flags, channel=effective_channel)

    async def aregister(self, mtype: int, subtype: int,
                        callback: Callable[[UMMMsg], None],
                        match_tlvs: Optional[List[TLV]] = None,
                        flags: int = 0,
                        channel: int = 1,
                        dont_send_self: bool = True) -> int:
        if dont_send_self:
            flags |= RequestFlag.DONT_SEND_SELF
        return await self._async_register(mtype, subtype, callback, match_tlvs,
                                          flags, channel)
    def run(self) -> None:
        """Block until the agent disconnects.

        Call this after connect() to keep the main thread alive while the
        agent runs in its background event loop.  Returns when the router
        closes the connection, disconnect() is called, or the process exits.

            agent.connect()
            # ... register subscriptions ...
            agent.run()   # blocks here until done

        The wait is done in short slices rather than a single indefinite
        Event.wait().  A blocking, no-timeout wait on the main thread can leave
        a pending Ctrl-C (SIGINT) unprocessed on Windows — the interpreter
        never returns to a point where it runs the signal handler, so the
        process appears unkillable from the console.  Waking every slice lets a
        pending SIGINT raise KeyboardInterrupt promptly, on every platform.
        """
        if not self._stop_event:
            return
        try:
            while not self._stop_event.wait(0.25):
                pass
        except KeyboardInterrupt:
            # Ctrl-C.  The event loop runs in a *daemon* thread and may be
            # mid-write to stdout (e.g. the parser printing a message).  If the
            # interpreter starts finalizing while that daemon thread holds the
            # stdout lock, CPython aborts with:
            #   Fatal Python error: _enter_buffered_busy: could not acquire
            #   lock for <stdout> at interpreter shutdown, possibly due to
            #   daemon threads
            # disconnect() stops the loop at a callback boundary and joins the
            # thread, so no daemon thread is left writing during finalization.
            self.disconnect()
            raise

    async def arun(self) -> None:
        await self._read_loop()

    # ── async internals ───────────────────────────────────────────────────────

    async def _async_connect_and_attach(self,
                                         ready: threading.Event,
                                         error_box: list) -> None:
        try:
            self._reader, self._writer = await asyncio.open_connection(
                self.host, self.port)
            self._connected = True
            logger.info("Connected to router at %s:%d", self.host, self.port)

            # Start background reader
            asyncio.get_event_loop().create_task(self._read_loop())

            # Wait for INIT message (router sends our attach ID)
            await asyncio.wait_for(self._wait_for_init(), timeout=10.0)

            # Send ATTACH
            await self._async_attach()

            # Wait for ATTACH_CONFIRM
            await asyncio.wait_for(self._wait_for_attach_confirm(), timeout=10.0)

            ready.set()
        except ConnectionRefusedError:
            exc = UMMConnectionError(
                f"Cannot connect to router at {self.host}:{self.port} — "
                f"connection refused. Is the router running?")
            error_box.append(exc)
            ready.set()
            raise exc
        except asyncio.TimeoutError:
            exc = UMMConnectionError(
                f"Cannot connect to router at {self.host}:{self.port} — "
                f"timed out. Check host address and port, and that the router "
                f"is not blocked by a firewall.")
            error_box.append(exc)
            ready.set()
            raise exc
        except OSError as orig:
            exc = UMMConnectionError(
                f"Cannot connect to router at {self.host}:{self.port} — "
                f"{orig}")
            error_box.append(exc)
            ready.set()
            raise exc
        except Exception as exc:
            error_box.append(exc)
            ready.set()
            raise

    async def _wait_for_init(self) -> None:
        while not self.attach_id.id:
            await asyncio.sleep(0.01)

    async def _wait_for_attach_confirm(self) -> None:
        while not self._attached:
            await asyncio.sleep(0.01)

    async def _read_loop(self) -> None:
        """Background task: read messages from the router."""
        while self._connected:
            try:
                msg = await self._read_one()
                if msg:
                    await self._handle_incoming(msg)
            except (asyncio.IncompleteReadError, ConnectionResetError):
                self._connected = False
                if not self._closing:
                    logger.warning("Connection to router lost")
                if self.reconnect:
                    await self._attempt_reconnect()
                break
            except Exception as exc:
                logger.exception("Read loop error: %s", exc)
                break

    async def _read_one(self) -> Optional[UMMMsg]:
        if not self._reader:
            return None
        header = await self._reader.readexactly(FIXED_HEADER_SIZE)
        msg = UMMMsg.decode(header)

        tlv_hdr = await self._reader.readexactly(HEADER_SIZE)
        tlv_type, tlv_match, tlv_meta, tlv_len = struct.unpack("!IIII", tlv_hdr)

        from .core.tlv import _padded_len
        padded = _padded_len(tlv_len)
        raw = await self._reader.readexactly(padded)
        msg.tdata = TLV(type_id=tlv_type, value=raw[:tlv_len], match=tlv_match, meta=tlv_meta)
        return msg

    async def _handle_incoming(self, msg: UMMMsg) -> None:
        if msg.mtype == MType.UMM and msg.reg_id == 0:
            # reg_id=0 means this is a genuine router→agent control message
            # (INIT, ATTACH_CONFIRM, SHUTDOWN etc.) — handle internally
            await self._handle_control(msg)
        else:
            # reg_id > 0 means the router matched this against a subscription
            # and dispatched it — route to the registered callback.
            # This includes mtype=1 messages forwarded as bus notifications
            # (ATTACH, REGISTER etc. that agents subscribed to).
            reg = self._registrations.get(msg.reg_id)
            if reg:
                try:
                    self._dispatch_application(msg, reg)
                except Exception as exc:
                    logger.exception("Callback error for reg %d: %s",
                                     msg.reg_id, exc)
            else:
                logger.debug("No callback for reg_id=%d mtype=%d subtype=%d",
                             msg.reg_id, msg.mtype, msg.subtype)

    def _dispatch_application(self, msg: UMMMsg, reg: 'Registration') -> None:
        """Invoke the application callback for a delivered message.

        Sets self._current_channel (readable via self.reply_channel) for the
        duration of the callback so handlers can echo the incoming channel on
        any responses they send.  Restored to 0 after the callback returns.

        Both plain and ``async def`` callbacks are supported:

        * **Plain callbacks** run synchronously on the event loop thread.
          They must *not* call ``agent.send()`` — that would deadlock.
          Use ``await agent.asend()`` in an async callback instead.

        * **Async callbacks** are scheduled as a new task on the running
          event loop so they can ``await agent.asend()``, ``asyncio.sleep()``,
          and other coroutines freely.

        Override in a subclass or mixin to add buffering, ordering, or
        filtering logic.
        """
        import inspect
        self._current_channel = msg.channel
        result = reg.callback(msg)
        if inspect.isawaitable(result):
            # Async callback — schedule it and restore _current_channel when done.
            async def _run():
                try:
                    await result
                finally:
                    self._current_channel = 1
            if self._loop and self._loop.is_running():
                self._loop.create_task(_run())
        else:
            self._current_channel = 1

    async def _handle_control(self, msg: UMMMsg) -> None:
        st = msg.subtype
        if st == UMMSubType.INIT:
            # Router is telling us our attach ID
            if msg.tdata.value:
                tlvs = decode_all(msg.tdata.value)
                for tlv in tlvs:
                    if tlv.type_id == 12:   # TLV_ATTID
                        router_id, client_id = struct.unpack("!II", tlv.value)
                        self.attach_id = AttachId(router=router_id, id=client_id)
                        self.router_id = router_id
                        logger.info("Got attach ID: router=%d id=%d",
                                    router_id, client_id)
                        break

        elif st == UMMSubType.ATTACH_CONFIRM:
            self._attached = True
            logger.info("Attach confirmed by router")
            if self._attach_callback:
                self._attach_callback(msg)

        elif st == UMMSubType.SHUTDOWN:
            logger.warning("Router sent shutdown")
            self._connected = False
            if self._attach_callback:
                self._attach_callback(msg)

        elif st in (UMMSubType.SYS_ERROR, UMMSubType.SYS_WARN, UMMSubType.SYS_INFO):
            # Router system message — extract text and log at appropriate level
            text = self._extract_string(msg)
            level = {UMMSubType.SYS_ERROR: logger.error,
                     UMMSubType.SYS_WARN:  logger.warning,
                     UMMSubType.SYS_INFO:  logger.info}.get(st, logger.info)
            level("Router: %s", text)

    async def _async_attach(self) -> None:
        """Send the MTUMMAttach message."""
        buf = TLVBuffer()
        # Pack our AttachId
        buf.add(TLV(type_id=12,
                    value=struct.pack("!II",
                                     self.attach_id.router,
                                     self.attach_id.id)))
        # Pack LogId (process_name + login + password, null-separated)
        log_bytes = (self.process_name.encode() + b'\x00' +
                     self.login.encode()        + b'\x00' +
                     self.password.encode()     + b'\x00')
        buf.add(TLV(type_id=15, value=log_bytes))  # TLV_LOGID

        # Pack primary mtype so router can include it in lifecycle notifications
        if self.agent_mtype != 0:
            buf.add(TLV(type_id=TLV_INT,
                        value=struct.pack("!i", self.agent_mtype)))

        msg = self._make_msg(MType.UMM, UMMSubType.ATTACH, buf,
                             flags=self.attach_flags)
        await self._write(msg)

    async def _async_send(self, mtype: int, subtype: int,
                           tlvs: Optional[List[TLV]],
                           flags: int,
                           msg_id: Optional[int] = None,
                           channel: int = 1,
                           tm: Optional['UTime'] = None) -> None:
        buf = TLVBuffer()
        if tlvs:
            buf.add_all(tlvs)
        msg = self._make_msg(mtype, subtype, buf, flags=flags, msg_id=msg_id,
                             channel=channel, tm=tm)
        await self._write(msg)

    def _register_local(self, mtype: int, subtype: int,
                        callback: Callable[[UMMMsg], None],
                        match_tlvs: Optional[List[TLV]],
                        flags: int,
                        channel: int = 1) -> Tuple[int, UMMMsg]:
        """Synchronous part of registration.

        Allocates the registration id, stores the Registration, and builds
        the REGISTER message.  Performs no I/O and no awaiting, so it is safe
        to call from any thread — including the event-loop thread (e.g. from
        within a message callback).  Returns ``(reg_id, msg)``; the caller is
        responsible for writing ``msg`` to the router.
        """
        # Allocate the lowest free reg_id in [1, MAX_REGISTRATIONS).  The router
        # rejects reg_id >= MAX_REGISTRATIONS, and reg_ids are chosen by the
        # client, so a monotonic counter would eventually exhaust the space for
        # any agent that re-subscribes over time (e.g. an FSM that re-registers
        # its triggers on every state change).  Reusing freed slots keeps the
        # id bounded by the number of *concurrently* active registrations.
        reg_id = self._next_reg
        if reg_id >= MAX_REGISTRATIONS or reg_id in self._registrations:
            reg_id = next((rid for rid in range(1, MAX_REGISTRATIONS)
                           if rid not in self._registrations), 0)
            if reg_id == 0:
                raise RuntimeError(
                    f"registration table full ({MAX_REGISTRATIONS} active)")
        # Advance the hint past the chosen id (wrapping) so sequential
        # registrations spread out and don't collide with in-flight unregisters.
        self._next_reg = reg_id + 1 if reg_id + 1 < MAX_REGISTRATIONS else 1

        reg = Registration(reg_id=reg_id, mtype=mtype, subtype=subtype,
                           callback=callback, flags=flags, channel=channel,
                           match_tlvs=match_tlvs)
        self._registrations[reg_id] = reg

        # The registration message header carries mtype=UMM subtype=REGISTER
        # so the router knows this is a control message.
        #
        # The subscription mtype/subtype and match criteria travel inside
        # TData as a UMMReg structure:
        #
        #   UMMReg {
        #       long mtype;       ← subscription mtype (NBO, 4 bytes)
        #       long subtype;     ← subscription subtype (NBO, 4 bytes)
        #       TLV  TData;       ← match criteria TLVs
        #   }
        #
        # The subscription channel travels in the message header channel field,
        # just like any other message.  The router reads msg.channel from the
        # header — it is NOT encoded in the UMMReg payload.
        #
        # This is wrapped in a TLV_MSG TLV inside the message TData.

        # Build match criteria payload
        match_buf = TLVBuffer()
        if match_tlvs:
            match_buf.add_all(match_tlvs)

        # Build UMMReg: mtype(4) + subtype(4) + match TLV bytes
        import struct as _struct
        umm_reg = _struct.pack('!ii', mtype, subtype) + match_buf.encode()

        # Wrap in TLV_SUBSPEC — subscription spec: mtype(4)+subtype(4)+match_bytes
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_SUBSPEC, value=umm_reg))

        # Channel goes in the message header — router reads msg.channel
        msg = self._make_msg(MType.UMM, UMMSubType.REGISTER, buf,
                             flags=flags, reg_id=reg_id, channel=channel)
        return reg_id, msg

    async def _async_register(self, mtype: int, subtype: int,
                               callback: Callable[[UMMMsg], None],
                               match_tlvs: Optional[List[TLV]],
                               flags: int,
                               channel: int = 1) -> int:
        reg_id, msg = self._register_local(mtype, subtype, callback,
                                           match_tlvs, flags, channel)
        await self._write(msg)
        logger.debug("Registered ch=%d mtype=%d subtype=%d reg_id=%d",
                     channel, mtype, subtype, reg_id)
        return reg_id

    async def _async_unregister(self, reg_id: int) -> None:
        msg = self._make_msg(MType.UMM, UMMSubType.UNREGISTER,
                             reg_id=reg_id)
        await self._write(msg)
        self._registrations.pop(reg_id, None)

    async def _async_detach(self) -> None:
        try:
            msg = self._make_msg(MType.UMM, UMMSubType.DETACH)
            await self._write(msg)
        except Exception:
            pass
        self._connected = False
        # Give the read loop a moment to notice and exit cleanly
        await asyncio.sleep(0.05)
        if self._writer:
            try:
                self._writer.close()
                await asyncio.wait_for(self._writer.wait_closed(), timeout=1.0)
            except Exception:
                pass

    async def _write(self, msg: UMMMsg) -> None:
        if not self._writer:
            raise RuntimeError("Not connected")
        wire = msg.encode()
        self._writer.write(wire)
        await self._writer.drain()

    async def _attempt_reconnect(self) -> None:
        while self.reconnect:
            await asyncio.sleep(self.reconnect_delay)
            logger.info("Attempting reconnect to %s:%d", self.host, self.port)
            try:
                self._reader, self._writer = await asyncio.open_connection(
                    self.host, self.port)
                self._connected = True
                await self._wait_for_init()
                await self._async_attach()
                await self._wait_for_attach_confirm()
                # Re-register all subscriptions with their original match criteria
                for reg in self._registrations.values():
                    await self._async_register(reg.mtype, reg.subtype,
                                               reg.callback, reg.match_tlvs,
                                               reg.flags, reg.channel)
                logger.info("Reconnected successfully")
                asyncio.get_event_loop().create_task(self._read_loop())
                if self.on_reconnect:
                    try:
                        self.on_reconnect()
                    except Exception as exc:
                        logger.warning("on_reconnect callback failed: %s", exc)
                return
            except ConnectionRefusedError:
                logger.warning("Reconnect failed: router not running at %s:%d",
                               self.host, self.port)
            except asyncio.TimeoutError:
                logger.warning("Reconnect failed: timeout connecting to %s:%d",
                               self.host, self.port)
            except Exception as exc:
                logger.warning("Reconnect failed: %s", exc)

    # ── message factory ───────────────────────────────────────────────────────

    def _make_msg(self, mtype: int, subtype: int,
                   buf: Optional[TLVBuffer] = None,
                   flags: int = 0,
                   reg_id: int = 0,
                   msg_id: Optional[int] = None,
                   channel: int = 1,
                   tm: Optional['UTime'] = None) -> UMMMsg:
        payload = buf.encode() if buf else b''
        return UMMMsg(
            version   = VersionId(),
            attach_id = self.attach_id,
            origin    = self.attach_id,
            tm        = tm if tm is not None else UTime.now(),
            flags     = flags,
            reg_id    = reg_id,
            msg_id    = msg_id if msg_id is not None else self._next_msg_id(),
            mtype     = mtype,
            subtype   = subtype,
            channel   = channel,
            tdata     = TLV(type_id=TLV_MSG, value=payload) if payload
                        else TLV(type_id=TLV_TERM),
        )

    def _next_msg_id(self) -> int:
        mid = self._msg_id
        self._msg_id += 1
        return mid

    def _peek_msg_id(self) -> int:
        """Return the next msg_id without consuming it."""
        return self._msg_id

    def _extract_string(self, msg: UMMMsg) -> str:
        if not msg.tdata.value:
            return ''
        try:
            tlvs = decode_all(msg.tdata.value)
            for tlv in tlvs:
                if tlv.type_id == TLV_STRING:
                    return tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
        except Exception:
            pass
        return ''
