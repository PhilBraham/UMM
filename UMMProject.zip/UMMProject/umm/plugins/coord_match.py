"""
umm.plugins.coord_match
=======================
External match plugin for CoOrd (type 13) TLV values.

Handles all spatial comparison operators for 2D and 3D coordinates,
keeping geometry logic out of the router core.  New operators (polygon
containment, nearest-N, bearing range, etc.) can be added here without
touching the router or any other module.

Wire format of a CoOrd TLV value
---------------------------------
2D point:  two IEEE-754 doubles, big-endian  (16 bytes)
3D point:  three IEEE-754 doubles, big-endian (24 bytes)

Operators
---------
  match  symbol      subscription value          behaviour
  -----  ----------  --------------------------  ------------------------------------
    0    =           (x, y) or (x, y, z)         exact equality
    1    !=          (x, y) or (x, y, z)         not equal
   11    within      (cx, cy, radius)             msg point within 2D circle
   12    within3d    (cx, cy, cz, radius)         msg point within 3D sphere
   13    bbox        (x1, y1, x2, y2)             msg point inside 2D bounding box

Adding new operators
--------------------
1. Assign the next free match-word value (14+).
2. Add a ``case`` in ``_eval_coord_op``.
3. Verify the subscription encoding in ``_decode_sub`` handles the new value
   count (the decoder is length-driven so this is usually automatic).
4. Add the match-word → symbol entry to ``CoOrdType.MATCH_OPS`` in builtin.py
   for the fallback registry matcher and the Types GUI display.
5. Document it in DESIGN_NOTES.md §11.

Usage
-----
    python3 -m umm.plugins.coord_match --router localhost --port 5100
    # plugin port defaults to agent_port + 1 (5101)

    python3 -m umm.plugins.coord_match --router localhost --plugin-port 5101
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import math
import struct
from typing import Any, Optional, Tuple

from ._base import MatchPluginBase

logger = logging.getLogger(__name__)

TLV_COORD = 13


# ── coordinate decoding ───────────────────────────────────────────────────────

def _decode_coord(value: bytes) -> Optional[Tuple[float, ...]]:
    """
    Decode a CoOrd TLV value to a tuple of floats.

    Returns a 2-tuple for 16-byte values, a 3-tuple for 24-byte values,
    a 4-tuple for 32-byte values (used by WITHIN_3D: cx,cy,cz,radius),
    and so on.  Returns None if the length is not a multiple of 8.
    """
    n = len(value) // 8
    if n == 0 or len(value) % 8 != 0:
        return None
    fmt = f'!{n}d'
    try:
        return struct.unpack(fmt, value)
    except struct.error:
        return None


# ── operator dispatch ─────────────────────────────────────────────────────────

def _dist2d(ax: float, ay: float, bx: float, by: float) -> float:
    return math.sqrt((ax - bx) ** 2 + (ay - by) ** 2)


def _dist3d(ax: float, ay: float, az: float,
            bx: float, by: float, bz: float) -> float:
    return math.sqrt((ax - bx) ** 2 + (ay - by) ** 2 + (az - bz) ** 2)


def _eval_coord_op(msg: Tuple[float, ...],
                   sub: Tuple[float, ...],
                   mword: int) -> bool:
    """
    Evaluate one spatial comparison.

    msg  — coordinate from the message  (2- or 3-tuple)
    sub  — subscription value           (encoding depends on match)
    """
    if match == 0:   # EQ — exact equality
        return msg == sub

    if match == 1:   # NE — not equal
        return msg != sub

    if match == 11:  # WITHIN — 2D circle: sub = (cx, cy, radius)
        if len(sub) < 3:
            return False
        return _dist2d(msg[0], msg[1], sub[0], sub[1]) <= sub[2]

    if match == 12:  # WITHIN_3D — sphere: sub = (cx, cy, cz, radius)
        if len(sub) < 4:
            return False
        mz = msg[2] if len(msg) > 2 else 0.0
        return _dist3d(msg[0], msg[1], mz, sub[0], sub[1], sub[2]) <= sub[3]

    if match == 13:  # BBOX — 2D axis-aligned bounding box: sub = (x1,y1,x2,y2)
        if len(sub) < 4:
            return False
        x1, y1, x2, y2 = sub[0], sub[1], sub[2], sub[3]
        # Normalise so min/max order doesn't matter
        if x1 > x2: x1, x2 = x2, x1
        if y1 > y2: y1, y2 = y2, y1
        return x1 <= msg[0] <= x2 and y1 <= msg[1] <= y2

    logger.warning("Unknown CoOrd match-word %d — defaulting to False", match)
    return False


# ── plugin ────────────────────────────────────────────────────────────────────

class CoOrdMatchPlugin(MatchPluginBase):
    """
    Match plugin for CoOrd (TLV type 13).

    Subscription criteria are stored as decoded float tuples; evaluation
    is pure Python with no external dependencies.
    """

    HANDLED_TYPE_IDS = [TLV_COORD]
    NAME             = 'CoOrdMatch'

    def _decode_sub(self, type_id: int, match: int, meta: int,
                    value: bytes) -> Optional[Tuple[float, ...]]:
        """Decode subscription TLV value to a float tuple."""
        result = _decode_coord(value)
        if result is None:
            logger.warning("CoOrd sub_add: cannot decode %d bytes for match=%d",
                           len(value), match)
        return result

    def _eval(self, msg_value: bytes, match: int,
              criteria: Any) -> bool:
        """Compare message coordinate against subscription criteria."""
        msg = _decode_coord(msg_value)
        if msg is None or criteria is None:
            return False
        return _eval_coord_op(msg, criteria, match)


# ── entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description='UMM coordinate match plugin')
    p.add_argument('--router',      default='localhost')
    p.add_argument('--port',        type=int, default=5000,
                   help='Agent port (plugin port = this + 1 unless --plugin-port given)')
    p.add_argument('--plugin-port', type=int, default=0,
                   dest='plugin_port',
                   help='Plugin port (overrides --port + 1)')
    p.add_argument('--name',        default='CoOrdMatch')
    p.add_argument('--debug',       action='store_true')
    args = p.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format='%(asctime)s %(levelname)s [%(name)s] %(message)s',
    )

    plugin_port = args.plugin_port or (args.port + 1)
    plugin = CoOrdMatchPlugin(host=args.router, plugin_port=plugin_port)
    plugin.NAME = args.name
    try:
        asyncio.run(plugin.run())
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
