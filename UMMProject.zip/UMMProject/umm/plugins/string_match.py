"""
umm.plugins.string_match
========================
External match plugin for Char (type 8) TLV type.

Connects to the router's plugin port and handles all string matching,
making the router core independent of string comparison logic.  New
string operators (regex, locale-aware collation, better phonetics) can
be added here without touching the router.

Operators
---------
  mword  operator    behaviour
  -----  ----------  -------------------------------------------------
    0    =           exact match
    1    !=          not equal
    2    CI=         case-insensitive equal
    3    CI!=        case-insensitive not equal
    5    *!=         wildcard not match
    6    contains    substring, case-insensitive
    7    *=  / ~=    wildcard (fnmatch — *, ?, [seq]), case-insensitive
    8    soundslike  phonetic match (first letter + consonant skeleton)

Usage
-----
    python3 -m umm.plugins.string_match --router localhost --port 5100
"""

from __future__ import annotations

import argparse
import asyncio
import fnmatch
import logging
from typing import Any, Optional

from ._base import MatchPluginBase

logger = logging.getLogger(__name__)

TLV_STRING = 8


def _soundex(s: str) -> str:
    """
    Standard Soundex algorithm (Russell & Odell, 1918).
    Returns a 4-character code: first letter + 3 digits.
    Pure Python, no imports required.
    """
    if not s:
        return ''
    s = s.upper().strip()
    # Soundex digit map
    table = str.maketrans('BFPVCGJKQSXZDTLMNR', '111122222222334556')
    keep  = str.maketrans('', '', 'AEIOUYHW')

    first = s[0]
    # Encode full string, drop non-alpha
    coded = s.translate(table)
    # Remove H and W (don't separate same-coded consonants)
    # but keep first char position for dedup logic
    result = first
    prev   = coded[0] if coded[0].isdigit() else ''
    for ch, digit in zip(s[1:], coded[1:]):
        if not digit.isdigit():
            prev = ''   # vowels reset the run so B0B → 11 not 1
            continue
        if digit != prev:
            result += digit
            prev = digit
        if len(result) == 4:
            break

    return result.ljust(4, '0')


def _soundslike(a: str, b: str) -> bool:
    """Phonetic match using standard Soundex algorithm."""
    return bool(a and b and _soundex(a) == _soundex(b))


def _eval_string_op(msg_str: str, sub_str: str, match: int) -> bool:
    if match == 0:   return msg_str == sub_str
    if match == 1:   return msg_str != sub_str
    if match == 2:   return msg_str.lower() == sub_str.lower()
    if match == 3:   return msg_str.lower() != sub_str.lower()
    if match == 5:   return not fnmatch.fnmatch(msg_str.lower(), sub_str.lower())
    if match == 6:   return sub_str.lower() in msg_str.lower()
    if match == 7:   return fnmatch.fnmatch(msg_str.lower(), sub_str.lower())
    if match == 8:   return _soundslike(msg_str, sub_str)
    logger.warning("Unknown string match-word %d – defaulting to False", match)
    return False


class StringMatchPlugin(MatchPluginBase):
    """Match plugin for Char (type 8) TLV type."""

    HANDLED_TYPE_IDS = [TLV_STRING]
    NAME             = 'StringMatch'

    def _decode_sub(self, type_id: int, match: int, meta: int,
                    value: bytes) -> Optional[str]:
        return value.rstrip(b'\x00').decode('utf-8', errors='replace')

    def _eval(self, msg_value: bytes, match: int, criteria: Any) -> bool:
        msg_str = msg_value.rstrip(b'\x00').decode('utf-8', errors='replace')
        return _eval_string_op(msg_str, criteria, match)


def main() -> None:
    p = argparse.ArgumentParser(description='UMM string match plugin')
    p.add_argument('--router',      default='localhost')
    p.add_argument('--port',        type=int, default=5000)
    p.add_argument('--plugin-port', type=int, default=0, dest='plugin_port')
    p.add_argument('--name',        default='StringMatch')
    p.add_argument('--debug',       action='store_true')
    args = p.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format='%(asctime)s %(levelname)s [%(name)s] %(message)s',
    )

    plugin_port = args.plugin_port or (args.port + 1)
    plugin = StringMatchPlugin(host=args.router, plugin_port=plugin_port)
    plugin.NAME = args.name
    try:
        asyncio.run(plugin.run())
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
