"""
umm.plugins._base
=================
Base class for UMM match plugins.

All match plugins inherit from ``MatchPluginBase`` and implement two methods:

``_decode_sub(type_id, match, meta, value) → criteria``
    Called when a subscription TLV owned by this plugin is stored.
    Return an opaque criteria object that will be passed to ``_eval`` later.
    Return ``None`` to skip storing (e.g. unknown type_id).

``_eval(msg_value, match, criteria) → bool``
    Called once per subscription TLV during match evaluation.
    ``msg_value`` is the raw bytes of the message TLV value.
    Return True if it matches.

Everything else — TCP connection, JSON protocol, sub_add/sub_remove,
match_req/match_resp, retry logic — is handled here.

Example skeleton
----------------
::

    from umm.plugins._base import MatchPluginBase

    class MyPlugin(MatchPluginBase):
        HANDLED_TYPE_IDS = [42]
        NAME = 'MyPlugin'

        def _decode_sub(self, type_id, match, meta, value):
            return value          # store raw bytes as criteria

        def _eval(self, msg_value, match, criteria):
            return msg_value == criteria   # exact match only

    if __name__ == '__main__':
        import asyncio
        plugin = MyPlugin()
        asyncio.run(plugin.run())
"""

from __future__ import annotations

import asyncio
import json
import logging
import struct
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── TLV wire decoding ─────────────────────────────────────────────────────────

def decode_tlvs(data: bytes) -> List[Tuple[int, int, int, bytes]]:
    """
    Decode a TLV payload into ``(type_id, match, meta, value)`` tuples.

    Wire format per TLV (16-byte header, network byte order):
        type_id  (4 bytes) — the TLV type id
        match    (4 bytes) — operator (subscription) / qualifier (message)
        meta     (4 bytes) — semantic qualifier (0 = absent)
        length   (4 bytes) — byte length of the value field
        value    (length bytes)
        padding  (0–3 bytes to reach the next 4-byte boundary)

    Iteration stops at ``type_id == 0`` (TLV_TERM) or end of buffer.
    """
    results: List[Tuple[int, int, int, bytes]] = []
    offset = 0
    while offset + 16 <= len(data):
        type_id, match, meta, length = struct.unpack_from('!IIII', data, offset)
        if type_id == 0:
            break
        offset += 16
        value = data[offset:offset + length]
        offset += (length + 3) & ~3   # advance past value + padding
        results.append((type_id, match, meta, value))
    return results


# ── base plugin ───────────────────────────────────────────────────────────────

class MatchPluginBase:
    """
    Base class for UMM external match plugins.

    Subclasses set ``HANDLED_TYPE_IDS`` and ``NAME``, then override
    ``_decode_sub`` and ``_eval``.

    Subscription store layout
    -------------------------
    ``_subs`` maps ``reg_id`` → list of ``(type_id, match, meta, criteria)`` tuples,
    one entry per plugin-owned TLV in that subscription's match data.
    A subscription matches when ALL its entries match (AND logic).
    """

    #: TLV type IDs owned by this plugin — override in subclass.
    HANDLED_TYPE_IDS: List[int] = []

    #: Display name sent to the router on registration — override in subclass.
    NAME: str = 'MatchPlugin'

    def __init__(self, host: str = 'localhost', plugin_port: int = 5001) -> None:
        self.host        = host
        self.plugin_port = plugin_port
        # reg_id → [(type_id, match, meta, criteria), ...]
        self._subs:   Dict[int, List[Tuple[int, int, Any]]] = {}
        self._writer: Optional[asyncio.StreamWriter]        = None

    # ── subclass interface ────────────────────────────────────────────────────

    def _decode_sub(self, type_id: int, match: int, meta: int,
                    value: bytes) -> Optional[Any]:
        """
        Decode a subscription TLV value into an opaque criteria object.

        Called once per plugin-owned TLV when a subscription is registered.
        The returned object is stored and passed to ``_eval`` on every match
        request.  Return ``None`` to ignore this TLV.
        """
        raise NotImplementedError

    def _eval(self, msg_value: bytes, match: int, criteria: Any) -> bool:
        """
        Evaluate one match criterion against an incoming message TLV value.

        Called once per stored criterion during a ``match_req``.
        ``msg_value`` is the raw bytes of the message TLV.
        ``match``     is the operator stored in the subscription.
        ``criteria``  is whatever ``_decode_sub`` returned.
        Return True if the message TLV satisfies the criterion.
        """
        raise NotImplementedError

    # ── connection ────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Connect to the router plugin port, run protocol loop, then return."""
        reader, writer = await asyncio.open_connection(self.host, self.plugin_port)
        self._writer = writer
        logger.info("Connected to router plugin port %s:%d",
                    self.host, self.plugin_port)

        await self._send({"msg":      "register",
                          "type_ids": self.HANDLED_TYPE_IDS,
                          "name":     self.NAME})
        try:
            while True:
                line = await reader.readline()
                if not line:
                    logger.info("Router closed plugin connection")
                    break
                try:
                    await self._dispatch(json.loads(line))
                except json.JSONDecodeError as exc:
                    logger.warning("Bad JSON from router: %s", exc)
        except (asyncio.IncompleteReadError, ConnectionResetError):
            logger.info("Router disconnected")
        except Exception as exc:
            logger.exception("Plugin error: %s", exc)

    async def _send(self, obj: Any) -> None:
        if self._writer:
            self._writer.write((json.dumps(obj) + '\n').encode())
            await self._writer.drain()

    # ── protocol dispatch ─────────────────────────────────────────────────────

    async def _dispatch(self, msg: dict) -> None:
        kind = msg.get('msg')
        if   kind == 'sub_add':    self._on_sub_add(msg)
        elif kind == 'sub_remove': self._on_sub_remove(msg)
        elif kind == 'match_req':  await self._on_match_req(msg)
        else: logger.debug("Unknown plugin message: %s", kind)

    def _on_sub_add(self, msg: dict) -> None:
        reg_id   = msg['reg_id']
        hex_data = msg.get('sub_tlvs', '')
        data     = bytes.fromhex(hex_data) if hex_data else b''

        handled = set(self.HANDLED_TYPE_IDS)
        criteria_list: List[Tuple[int, int, Any]] = []
        for type_id, match, meta, value in decode_tlvs(data):
            if type_id not in handled:
                continue
            c = self._decode_sub(type_id, match, meta, value)
            if c is not None:
                criteria_list.append((type_id, match, meta, c))

        if criteria_list:
            self._subs[reg_id] = criteria_list
            logger.debug("sub_add reg_id=%d  %d criteria", reg_id, len(criteria_list))

    def _on_sub_remove(self, msg: dict) -> None:
        for reg_id in msg.get('reg_ids', []):
            self._subs.pop(reg_id, None)
            logger.debug("sub_remove reg_id=%d", reg_id)

    async def _on_match_req(self, msg: dict) -> None:
        req_id   = msg['req_id']
        hex_data = msg.get('msg_tlvs', '')
        data     = bytes.fromhex(hex_data) if hex_data else b''
        reg_ids  = msg.get('reg_ids', list(self._subs.keys()))

        msg_tlvs = decode_tlvs(data)   # [(type_id, match, meta, value), ...]
        results: List[List] = []

        for reg_id in reg_ids:
            criteria_list = self._subs.get(reg_id)
            if criteria_list is None:
                results.append([reg_id, False])
                continue
            results.append([reg_id, self._match_all(criteria_list, msg_tlvs)])

        await self._send({"msg": "match_resp", "req_id": req_id,
                          "results": results})

    def _match_all(self,
                   criteria_list: List[Tuple[int, int, Any]],
                   msg_tlvs: List[Tuple[int, int, int, bytes]]) -> bool:
        """
        All criteria must match (AND logic), positional per type_id.

        For each criterion, find the next message TLV of the same type_id
        (advancing a per-type cursor) and call ``_eval``.  Returns False
        immediately if any criterion fails or its type_id is absent.
        """
        pos: Dict[int, int] = {}   # type_id → next msg index to check

        for (sub_type_id, match, meta, criteria) in criteria_list:
            start = pos.get(sub_type_id, 0)
            found = False
            for i in range(start, len(msg_tlvs)):
                m_type_id, _m_match, m_meta, m_value = msg_tlvs[i]
                if m_type_id == sub_type_id:
                    if not self._eval(m_value, match, criteria):
                        return False
                    pos[sub_type_id] = i + 1
                    found = True
                    break
            if not found:
                return False

        return True

    # ── run loop ──────────────────────────────────────────────────────────────

    async def run(self) -> None:
        """Connect with exponential-backoff retry until the process exits."""
        retry_delay = 1.0
        while True:
            try:
                await self.connect()
            except (ConnectionRefusedError, OSError) as exc:
                logger.warning("Plugin port not available (%s) — retrying in %.0fs",
                               exc, retry_delay)
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 30.0)
            else:
                retry_delay = 1.0
