"""
umm.proxy
=========
UMM WebSocket Proxy — allows browser-based applications to participate
as full UMM agents.

Browsers cannot open raw TCP sockets, so this proxy accepts WebSocket
connections from browsers and forwards UMM binary protocol unchanged
to/from the router over TCP.  Each browser connection gets its own
TCP connection to the router — it is a fully independent UMM agent
with its own AttachId.

The proxy is transparent:
  - It does not interpret, filter or modify UMM messages
  - The browser speaks exactly the same binary UMM protocol
  - The router sees each browser as a normal agent
  - Any number of browser tabs can connect simultaneously

Wire format over WebSocket:
  Binary WebSocket frames containing raw UMM message bytes.
  Identical to what would be sent over a raw TCP socket.

Usage::

    # Start the proxy (run once, shared by all browser apps)
    python -m umm.proxy --router localhost:5000 --ws-port 8765

    # In the browser (JavaScript):
    const ws = new WebSocket('ws://localhost:8765');
    ws.binaryType = 'arraybuffer';
    // Then send/receive raw UMM binary frames exactly as over TCP

Run standalone::

    python -m umm.proxy --router localhost --port 5000 --ws-port 8765

Or embed::

    from umm.proxy import UMMProxy
    proxy = UMMProxy(router_host='localhost', router_port=5000, ws_port=8765)
    asyncio.run(proxy.serve())
"""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import Optional

try:
    import websockets
    from websockets.server import WebSocketServerProtocol
except ImportError:
    print("Please install websockets:  pip install websockets")
    sys.exit(1)

logger = logging.getLogger(__name__)


class BrowserSession:
    """
    One browser connection ↔ one TCP connection to the router.

    Bytes flow in both directions unchanged.  The browser is a full
    UMM agent — it sends its own Attach, Register, Send messages and
    receives its own AttachId from the router.
    """

    def __init__(self, ws: WebSocketServerProtocol,
                 router_host: str, router_port: int) -> None:
        self.ws           = ws
        self.router_host  = router_host
        self.router_port  = router_port
        self._tcp_reader: Optional[asyncio.StreamReader]  = None
        self._tcp_writer: Optional[asyncio.StreamWriter]  = None
        self._addr = ws.remote_address

    async def run(self) -> None:
        """Open TCP connection to router and bridge both directions."""
        try:
            self._tcp_reader, self._tcp_writer = \
                await asyncio.open_connection(self.router_host, self.router_port)
        except Exception as exc:
            logger.warning("Proxy: could not connect to router for %s: %s",
                           self._addr, exc)
            await self.ws.close(1011, "Router unavailable")
            return

        logger.info("Proxy: browser %s connected → router %s:%d",
                    self._addr, self.router_host, self.router_port)

        # Run both directions concurrently; stop when either closes
        try:
            await asyncio.gather(
                self._router_to_browser(),
                self._browser_to_router(),
                return_exceptions=True,
            )
        finally:
            if self._tcp_writer:
                try:
                    self._tcp_writer.close()
                    await self._tcp_writer.wait_closed()
                except Exception:
                    pass
            logger.info("Proxy: browser %s disconnected", self._addr)

    async def _router_to_browser(self) -> None:
        """Forward bytes from router TCP → browser WebSocket."""
        try:
            while True:
                # Read in chunks — WebSocket frames can be any size
                data = await self._tcp_reader.read(65536)
                if not data:
                    break
                await self.ws.send(data)
        except Exception:
            pass
        finally:
            try:
                await self.ws.close()
            except Exception:
                pass

    async def _browser_to_router(self) -> None:
        """Forward bytes from browser WebSocket → router TCP."""
        try:
            async for message in self.ws:
                if isinstance(message, bytes):
                    self._tcp_writer.write(message)
                    await self._tcp_writer.drain()
                # Ignore text frames (shouldn't occur with binary UMM protocol)
        except Exception:
            pass
        finally:
            try:
                self._tcp_writer.close()
            except Exception:
                pass


class UMMProxy:
    """
    UMM WebSocket Proxy.

    Accepts WebSocket connections from browsers and proxies each one
    to the UMM router as an independent TCP connection.

    Parameters
    ----------
    router_host : str
        Hostname of the UMM router.
    router_port : int
        TCP port of the UMM router.
    ws_host : str
        WebSocket bind address (default: all interfaces).
    ws_port : int
        WebSocket listen port (default: 8765).
    """

    def __init__(self,
                 router_host: str = 'localhost',
                 router_port: int = 5000,
                 ws_host:     str = '',
                 ws_port:     int = 8765) -> None:
        self.router_host = router_host
        self.router_port = router_port
        self.ws_host     = ws_host
        self.ws_port     = ws_port
        self._sessions: set = set()

    async def _handle(self, ws: WebSocketServerProtocol) -> None:
        session = BrowserSession(ws, self.router_host, self.router_port)
        self._sessions.add(session)
        try:
            await session.run()
        finally:
            self._sessions.discard(session)

    async def serve(self) -> None:
        async with websockets.serve(self._handle, self.ws_host, self.ws_port):
            addr = self.ws_host or '*'
            logger.info(
                "UMM WebSocket Proxy listening on ws://%s:%d → %s:%d",
                addr, self.ws_port, self.router_host, self.router_port)
            print(f"\nUMM WebSocket Proxy")
            print(f"  WebSocket : ws://{addr}:{self.ws_port}")
            print(f"  Router    : {self.router_host}:{self.router_port}")
            print(f"\nBrowser agents connect to ws://localhost:{self.ws_port}")
            print("Press Ctrl+C to stop.\n")
            await asyncio.Future()

    @property
    def session_count(self) -> int:
        return len(self._sessions)


# ── CLI entry point ────────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    p = argparse.ArgumentParser(
        description='UMM WebSocket Proxy — connects browser agents to a UMM router')
    p.add_argument('--router',   default='localhost', dest='router_host',
                   help='Router hostname (default: localhost)')
    p.add_argument('--port',     type=int, default=5000, dest='router_port',
                   help='Router TCP port (default: 5000)')
    p.add_argument('--ws-port',  type=int, default=8765,
                   help='WebSocket listen port (default: 8765)')
    p.add_argument('--ws-host',  default='',
                   help='WebSocket bind address (default: all interfaces)')
    p.add_argument('--debug',    action='store_true')
    args = p.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    proxy = UMMProxy(
        router_host = args.router_host,
        router_port = args.router_port,
        ws_host     = args.ws_host,
        ws_port     = args.ws_port,
    )
    try:
        asyncio.run(proxy.serve())
    except KeyboardInterrupt:
        print("\nProxy stopped.")


if __name__ == '__main__':
    _main()
