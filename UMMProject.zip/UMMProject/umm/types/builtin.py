"""
umm.types.builtin
=================
All built-in TLV type handlers.

Each class is a concrete BaseUMMType with:
  - TYPE_ID matching the original C++ TlvUserArray index
  - MATCH_OPS covering all meaningful comparison operators
  - pack / unpack / to_text / from_text
"""

from __future__ import annotations

import fnmatch
import struct
import time
from typing import Any

from ..core.tlv import (
    TLV_TERM, TLV_RAW, TLV_INT, TLV_UINT, TLV_SHORT, TLV_USHORT,
    TLV_FLOAT, TLV_BOOL, TLV_STRING, TLV_UTIME, TLV_METADATA,
    TLV_MSG, TLV_SUBSPEC, TLV_ATTID, TLV_COORD, TLV_LOGID, TLV_MSGREF,
    TLV_ROUTER_ID, TLV_JSON,
)
from ._base import BaseUMMType, MatchOp


# ── helpers ───────────────────────────────────────────────────────────────────

def _soundslike(a: str, b: str) -> bool:
    """Very simple phonetic match: first letter + consonant skeleton."""
    def skeleton(s: str) -> str:
        vowels = set('aeiouAEIOU ')
        s = s.lower().strip()
        return s[0] + ''.join(c for c in s[1:] if c not in vowels) if s else ''
    return skeleton(a) == skeleton(b)


# ── Raw ───────────────────────────────────────────────────────────────────────

class RawType(BaseUMMType):
    TYPE_ID     = TLV_RAW
    TYPE_NAME   = "Raw"
    DESCRIPTION = "Raw bytes – no interpretation"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
    }

    def pack(self, value: bytes) -> bytes:
        return bytes(value)

    def unpack(self, data: bytes) -> bytes:
        return data

    def to_text(self, value: bytes) -> str:
        return value.hex()

    def from_text(self, text: str) -> bytes:
        return bytes.fromhex(text)


# ── Int ───────────────────────────────────────────────────────────────────────

class IntType(BaseUMMType):
    TYPE_ID     = TLV_INT
    TYPE_NAME   = "Int"
    DESCRIPTION = "Signed 32-bit integer"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: int) -> bytes:
        return struct.pack('!i', int(value))

    def unpack(self, data: bytes) -> int:
        return struct.unpack('!i', data)[0]

    def to_text(self, value: int) -> str:
        return str(value)

    OP_TEXT = {
        "=":  int(MatchOp.EQ),
        "!=": int(MatchOp.NE),
        ">":  int(MatchOp.GT),
        "<":  int(MatchOp.LT),
        ">=": int(MatchOp.GE),
        "<=": int(MatchOp.LE),
    }
    def from_text(self, text: str) -> int:
        return int(text)


# ── UInt ──────────────────────────────────────────────────────────────────────

class UIntType(BaseUMMType):
    TYPE_ID     = TLV_UINT
    TYPE_NAME   = "UInt"
    DESCRIPTION = "Unsigned 32-bit integer"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: int) -> bytes:
        return struct.pack('!I', int(value))

    def unpack(self, data: bytes) -> int:
        return struct.unpack('!I', data)[0]

    def to_text(self, value: int) -> str:
        return str(value)

    OP_TEXT = {
        "=":  int(MatchOp.EQ),
        "!=": int(MatchOp.NE),
        ">":  int(MatchOp.GT),
        "<":  int(MatchOp.LT),
        ">=": int(MatchOp.GE),
        "<=": int(MatchOp.LE),
    }
    def from_text(self, text: str) -> int:
        return int(text)


# ── Short ─────────────────────────────────────────────────────────────────────

class ShortType(BaseUMMType):
    TYPE_ID     = TLV_SHORT
    TYPE_NAME   = "Short"
    DESCRIPTION = "Signed 16-bit integer"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: int) -> bytes:
        return struct.pack('!h', int(value))

    def unpack(self, data: bytes) -> int:
        return struct.unpack('!h', data)[0]

    def to_text(self, value: int) -> str:
        return str(value)

    OP_TEXT = {
        "=":  int(MatchOp.EQ),
        "!=": int(MatchOp.NE),
        ">":  int(MatchOp.GT),
        "<":  int(MatchOp.LT),
        ">=": int(MatchOp.GE),
        "<=": int(MatchOp.LE),
    }
    def from_text(self, text: str) -> int:
        return int(text)


# ── UShort ────────────────────────────────────────────────────────────────────

class UShortType(BaseUMMType):
    TYPE_ID     = TLV_USHORT
    TYPE_NAME   = "UShort"
    DESCRIPTION = "Unsigned 16-bit integer"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: int) -> bytes:
        return struct.pack('!H', int(value))

    def unpack(self, data: bytes) -> int:
        return struct.unpack('!H', data)[0]

    def to_text(self, value: int) -> str:
        return str(value)

    OP_TEXT = {
        "=":  int(MatchOp.EQ),
        "!=": int(MatchOp.NE),
        ">":  int(MatchOp.GT),
        "<":  int(MatchOp.LT),
        ">=": int(MatchOp.GE),
        "<=": int(MatchOp.LE),
    }
    def from_text(self, text: str) -> int:
        return int(text)


# ── Float ─────────────────────────────────────────────────────────────────────

class FloatType(BaseUMMType):
    TYPE_ID     = TLV_FLOAT
    TYPE_NAME   = "Float"
    DESCRIPTION = "64-bit double-precision float"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: abs(a - b) < 1e-9,
        MatchOp.NE: lambda a, b: abs(a - b) >= 1e-9,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: float) -> bytes:
        return struct.pack('!d', float(value))

    def unpack(self, data: bytes) -> float:
        return struct.unpack('!d', data)[0]

    def to_text(self, value: float) -> str:
        return f"{value:.6g}"

    OP_TEXT = {
        "=":  int(MatchOp.EQ),
        "!=": int(MatchOp.NE),
        ">":  int(MatchOp.GT),
        "<":  int(MatchOp.LT),
        ">=": int(MatchOp.GE),
        "<=": int(MatchOp.LE),
    }
    def from_text(self, text: str) -> float:
        return float(text)


# ── Bool ──────────────────────────────────────────────────────────────────────

class BoolType(BaseUMMType):
    TYPE_ID     = TLV_BOOL
    TYPE_NAME   = "Bool"
    DESCRIPTION = "Boolean true/false"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
    }

    def pack(self, value: bool) -> bytes:
        return struct.pack('!I', 1 if value else 0)

    def unpack(self, data: bytes) -> bool:
        return struct.unpack('!I', data)[0] != 0

    def to_text(self, value: bool) -> str:
        return "true" if value else "false"

    def from_text(self, text: str) -> bool:
        return text.strip().lower() in ('true', '1', 'yes', 'on')


# ── String ────────────────────────────────────────────────────────────────────

class StringType(BaseUMMType):
    TYPE_ID     = TLV_STRING
    TYPE_NAME   = "Char"          # matches original TlvUserArray "Char"
    DESCRIPTION = "Null-terminated UTF-8 string"
    # Original operators from TlvUString.cpp TLVMatchArray:
    #   index 0 = "="   exact match
    #   index 1 = "!="  not equal
    #   index 2 = "CI=" case-insensitive equal
    #   index 3 = "CI!=" case-insensitive not equal
    #   index 4 = "*="  wildcard match (fnmatch)
    #   index 5 = "*!=" wildcard not match
    # Extended with UMM-standard additions:
    #   index 6 = "contains"
    #   index 7 = "soundslike"
    MATCH_OPS   = {
        MatchOp.EQ:        lambda a, b: a == b,
        MatchOp.NE:        lambda a, b: a != b,
        2:                 lambda a, b: a.lower() == b.lower(),   # CI=
        3:                 lambda a, b: a.lower() != b.lower(),   # CI!=
        MatchOp.WILDCARD:  lambda a, b: fnmatch.fnmatch(a.lower(), b.lower()),  # *=
        5:                 lambda a, b: not fnmatch.fnmatch(a.lower(), b.lower()),  # *!=
        MatchOp.CONTAINS:  lambda a, b: b.lower() in a.lower(),
        MatchOp.SOUNDSLIKE:lambda a, b: _soundslike(a, b),
    }
    # Text operator aliases — must use MatchOp values as keys so that
    # mword values stored in subscription TLVs match MATCH_OPS keys.
    OP_TEXT = {
        "=":          int(MatchOp.EQ),        # 0
        "!=":         int(MatchOp.NE),        # 1
        "CI=":        2,
        "CI!=":       3,
        "*=":         int(MatchOp.WILDCARD),  # 7 — was incorrectly 4
        "~=":         int(MatchOp.WILDCARD),  # alias for *=
        "*!=":        5,
        "contains":   int(MatchOp.CONTAINS),  # 6
        "soundslike": int(MatchOp.SOUNDSLIKE),
    }
    # mword → canonical display symbol for directory_entry()
    # (built from OP_TEXT; alias ~= is dropped in favour of *=)
    _OP_DISPLAY = {v: k for k, v in OP_TEXT.items() if k != "~="}

    def directory_entry(self) -> dict:
        ops = [
            {"match": mword, "symbol": self._OP_DISPLAY.get(mword, str(mword))}
            for mword in self.MATCH_OPS
        ]
        return {
            "type_id":     self.TYPE_ID,
            "name":        self.TYPE_NAME,
            "base_type":   self.BASE_TYPE,
            "description": self.DESCRIPTION,
            "unit":        self.UNIT,
            "match_ops":   ops,
        }

    def pack(self, value: str) -> bytes:
        return value.encode('utf-8') + b'\x00'

    def unpack(self, data: bytes) -> str:
        return data.rstrip(b'\x00').decode('utf-8', errors='replace')

    def to_text(self, value: str) -> str:
        return f'"{value}"'

    def from_text(self, text: str) -> str:
        return text.strip('"\'')



# ── JSON ──────────────────────────────────────────────────────────────────────

class JsonType(StringType):
    """
    JSON data — wire-identical to Char (null-terminated UTF-8) but carries a
    distinct type_id so the router and tooling can identify it as JSON.

    Match operators are the same as Char: EQ, NE, CI=, CI!=, *=, *!=,
    contains, soundslike — all operating on the full JSON text.  A dedicated
    JSON match plugin (JSONPath etc.) can be added later by registering for
    type_id 18.
    """
    TYPE_ID     = TLV_JSON
    TYPE_NAME   = "JSON"
    DESCRIPTION = "JSON data (null-terminated UTF-8; wire-identical to Char)"


# ── UTime ─────────────────────────────────────────────────────────────────────

class UTimeType(BaseUMMType):
    TYPE_ID     = TLV_UTIME
    TYPE_NAME   = "UTime"
    DESCRIPTION = "UMM timestamp (secs + millisecs)"
    # UTime wire: secs(4,NBO) ms(2,NBO) tz(2,NBO) dst(2,NBO) pad(2)
    _FMT = "!IHhhxx"
    MATCH_OPS   = {
        MatchOp.EQ:     lambda a, b: a == b,
        MatchOp.NE:     lambda a, b: a != b,
        MatchOp.BEFORE: lambda a, b: a <  b,
        MatchOp.AFTER:  lambda a, b: a >  b,
        MatchOp.GE:     lambda a, b: a >= b,
        MatchOp.LE:     lambda a, b: a <= b,
    }

    def pack(self, value: float) -> bytes:
        """Pack a Unix timestamp (float) as UTime."""
        secs = int(value)
        ms   = int((value - secs) * 1000)
        return struct.pack(self._FMT, secs, ms, 0, 0)

    def unpack(self, data: bytes) -> float:
        """Unpack UTime bytes to a Unix timestamp float."""
        secs, ms, _, _ = struct.unpack(self._FMT, data)
        return secs + ms / 1000.0

    # Values below this threshold are treated as relative durations (seconds)
    # rather than absolute Unix timestamps. 1,000,000,000 = Sept 2001.
    RELATIVE_THRESHOLD = 1_000_000_000

    def to_text(self, value: float) -> str:
        if value < self.RELATIVE_THRESHOLD:
            # Relative duration — show as human-readable seconds
            secs = int(value)
            ms   = int((value - secs) * 1000)
            if ms:
                return f"{value:.3f}s"
            elif secs >= 3600:
                h, r = divmod(secs, 3600)
                m, s = divmod(r, 60)
                return f"{h}h{m:02d}m{s:02d}s"
            elif secs >= 60:
                m, s = divmod(secs, 60)
                return f"{m}m{s:02d}s"
            else:
                return f"{secs}s"
        else:
            import datetime
            return datetime.datetime.fromtimestamp(
                value).isoformat(timespec='milliseconds')

    def from_text(self, text: str) -> float:
        import datetime
        # Accept plain number as seconds
        try:
            return float(text.rstrip('s'))
        except ValueError:
            pass
        dt = datetime.datetime.fromisoformat(text)
        return dt.timestamp()


# ── Metadata ──────────────────────────────────────────────────────────────────

class MetadataType(BaseUMMType):
    """
    Metadata TLV.  M-word = MetadataField enum value identifying the field.
    The value bytes contain the actual data encoded in whatever sub-type
    is appropriate (string, int, utime …).

    Matching: two metadata TLVs match if they have the same M-word (field)
    AND the values match according to the standard string/int rules.
    User can override match() for richer behaviour.
    """
    TYPE_ID     = TLV_METADATA
    TYPE_NAME   = "MDNum"
    DESCRIPTION = "Metadata field (M-word = field identifier)"
    MATCH_OPS   = {}    # M-word is field ID, not operator – see match()

    def pack(self, value: bytes) -> bytes:
        """Value bytes are pre-encoded by the caller."""
        return bytes(value)

    def unpack(self, data: bytes) -> bytes:
        return data

    def to_text(self, value: bytes) -> str:
        try:
            return value.decode('utf-8').rstrip('\x00')
        except Exception:
            return value.hex()

    def from_text(self, text: str) -> bytes:
        return text.encode('utf-8') + b'\x00'

    def match(self, msg_tlv, sub_tlv) -> bool:
        """Match on M-word (field) equality, then raw value equality."""
        if msg_tlv.mword != sub_tlv.mword:
            return False
        if not sub_tlv.value:   # subscription has no value = match any
            return True
        return msg_tlv.value == sub_tlv.value


# ── AttId ─────────────────────────────────────────────────────────────────────

class AttIdType(BaseUMMType):
    TYPE_ID     = TLV_ATTID
    TYPE_NAME   = "AttId"
    DESCRIPTION = "Attach ID (router_id + client_id)"
    _FMT = "!II"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
    }

    def pack(self, value: tuple) -> bytes:
        router_id, client_id = value
        return struct.pack(self._FMT, router_id, client_id)

    def unpack(self, data: bytes) -> tuple:
        return struct.unpack(self._FMT, data)

    def to_text(self, value: tuple) -> str:
        return f"{value[0]}.{value[1]}"

    def from_text(self, text: str) -> tuple:
        parts = text.split('.')
        return (int(parts[0]), int(parts[1]))


# ── CoOrd ─────────────────────────────────────────────────────────────────────

class CoOrdType(BaseUMMType):
    TYPE_ID     = TLV_COORD
    TYPE_NAME   = "CoOrd"
    DESCRIPTION = "2D or 3D coordinate (x, y, z as doubles)"
    _FMT2 = "!dd"
    _FMT3 = "!ddd"
    MATCH_OPS   = {
        MatchOp.EQ:    lambda a, b: a == b,
        MatchOp.NE:    lambda a, b: a != b,
        MatchOp.WITHIN: lambda a, b: (
            ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5 <= (b[2] if len(b) > 2 else 0)
        ),
        MatchOp.WITHIN_3D: lambda a, b: (
            ((a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2] if len(a) > 2 else 0)**2) ** 0.5
            <= (b[3] if len(b) > 3 else 0)
        ),
        MatchOp.BBOX: lambda a, b: (
            b[0] <= a[0] <= b[2] and b[1] <= a[1] <= b[3]
        ),
    }

    def pack(self, value: tuple) -> bytes:
        if len(value) == 2:
            return struct.pack(self._FMT2, *value)
        return struct.pack(self._FMT3, *value)

    def unpack(self, data: bytes) -> tuple:
        if len(data) == 16:
            return struct.unpack(self._FMT2, data)
        return struct.unpack(self._FMT3, data)

    def to_text(self, value: tuple) -> str:
        return ','.join(f"{v:.4f}" for v in value)

    def from_text(self, text: str) -> tuple:
        return tuple(float(x) for x in text.split(','))


# ── LogId ─────────────────────────────────────────────────────────────────────

class LogIdType(BaseUMMType):
    TYPE_ID     = TLV_LOGID
    TYPE_NAME   = "LogId"
    DESCRIPTION = "Login credentials (process_name / login / password)"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a[0] == b[0],   # match on process_name
    }

    def pack(self, value: tuple) -> bytes:
        """value = (process_name, login_name, password)"""
        return (b'\x00'.join(s.encode('utf-8') for s in value) + b'\x00')

    def unpack(self, data: bytes) -> tuple:
        parts = data.split(b'\x00')
        names = [p.decode('utf-8', errors='replace') for p in parts[:3]]
        while len(names) < 3:
            names.append('')
        return tuple(names)

    def to_text(self, value: tuple) -> str:
        return f"{value[0]}:{value[1]}"

    def from_text(self, text: str) -> tuple:
        parts = text.split(':')
        return (parts[0], parts[1] if len(parts) > 1 else '', '')


# ── MsgRef ───────────────────────────────────────────────────────────────────

class MsgRefType(BaseUMMType):
    """
    MsgRef TLV — a globally unique message reference.

    Identifies a specific message by the combination of:
        router_id  (4 bytes, NBO unsigned)
        attach_id  (4 bytes, NBO unsigned)
        msg_id     (4 bytes, NBO unsigned)

    Displayed as "router.attach.msg_id"  e.g. "1.3.5"

    Used as a correlation ID in request/response pairs:
        - Requester includes its (origin, msg_id) in a MsgRef
        - Responder echoes the MsgRef so the requester can match
          the response to the original request unambiguously.

    Also used in plugin/filter systems where the router needs to
    identify which specific messages to deliver.
    """
    TYPE_ID     = TLV_MSGREF
    TYPE_NAME   = "MsgRef"
    DESCRIPTION = "Globally unique message reference (router.agent.msg_id)"
    UNIT        = ""
    _FMT        = "!III"   # router_id, attach_id, msg_id  (all unsigned 32-bit)
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
    }

    def pack(self, value: tuple) -> bytes:
        """value = (router_id, attach_id, msg_id)"""
        return struct.pack(self._FMT, *value)

    def unpack(self, data: bytes) -> tuple:
        """Returns (router_id, attach_id, msg_id)."""
        return struct.unpack(self._FMT, data[:12])

    def to_text(self, value: tuple) -> str:
        return f"{value[0]}.{value[1]}.{value[2]}"

    def from_text(self, text: str) -> tuple:
        parts = text.split('.')
        if len(parts) != 3:
            raise ValueError(f"MsgRef must be 'router.agent.msg_id', got {text!r}")
        return (int(parts[0]), int(parts[1]), int(parts[2]))

    @classmethod
    def make_tlv(cls, router_id: int, attach_id: int, msg_id: int):
        """Convenience: make a MsgRef TLV from components."""
        from ..core.tlv import TLV
        return TLV(type_id=TLV_MSGREF,
                   value=struct.pack(cls._FMT, router_id, attach_id, msg_id))


# ── RouterId ──────────────────────────────────────────────────────────────────

class RouterIdType(BaseUMMType):
    """
    Router identifier — two arbitrary 16-bit integers (site, node).

    Used as the first TLV in a subscription to request messages from a
    specific remote router via a bridge.  The values are chosen by site
    preference; there is no implied hierarchy.

    Wire format: site(2, NBO) + node(2, NBO) — 4 bytes total.

    Text representation: ``site.node``  e.g. ``1.3`` or ``2.12``.

    Special values:
        ``0.0``   — any router (wildcard; match messages from all routers)

    Match operators:
        EQ / NE  — exact site.node match
        (range operators are not meaningful for router IDs)

    Example subscription requesting messages from router 1.3::

        register(mtype=1050, subtype=1,
                 match_tlvs=[RouterIdType.make_tlv(1, 3)],
                 callback=on_temperature)
    """
    TYPE_ID     = TLV_ROUTER_ID
    TYPE_NAME   = "RouterId"
    DESCRIPTION = "Router identifier (site.node) for inter-router subscriptions"
    UNIT        = ""
    _FMT        = "!HH"   # site(2) + node(2), unsigned 16-bit each

    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b or b == (0, 0),  # (0,0) = wildcard
        MatchOp.NE: lambda a, b: a != b and b != (0, 0),
    }

    def pack(self, value: tuple) -> bytes:
        """value = (site, node) as ints."""
        site, node = int(value[0]) & 0xFFFF, int(value[1]) & 0xFFFF
        return struct.pack(self._FMT, site, node)

    def unpack(self, data: bytes) -> tuple:
        """Returns (site, node)."""
        return struct.unpack(self._FMT, data[:4])

    def to_text(self, value: tuple) -> str:
        return f"{value[0]}.{value[1]}"

    def from_text(self, text: str) -> tuple:
        parts = text.strip().split('.', 1)
        if len(parts) != 2:
            raise ValueError(
                f"RouterId must be 'site.node' (e.g. '1.3'), got {text!r}")
        try:
            return (int(parts[0]), int(parts[1]))
        except ValueError:
            raise ValueError(
                f"RouterId site and node must be integers, got {text!r}")

    @classmethod
    def make_tlv(cls, site: int, node: int):
        """Convenience: make a RouterId TLV from site and node."""
        from ..core.tlv import TLV
        return TLV(type_id=TLV_ROUTER_ID,
                   value=struct.pack(cls._FMT, site & 0xFFFF, node & 0xFFFF))

    @classmethod
    def wildcard_tlv(cls):
        """Make a RouterId TLV matching any router (site=0, node=0)."""
        return cls.make_tlv(0, 0)


# ── registry of all built-in types ───────────────────────────────────────────

BUILTIN_TYPES: list[type[BaseUMMType]] = [
    RawType,
    IntType,
    UIntType,
    ShortType,
    UShortType,
    FloatType,
    BoolType,
    StringType,
    UTimeType,
    MetadataType,
    AttIdType,
    CoOrdType,
    JsonType,
    LogIdType,
    MsgRefType,
    RouterIdType,
]