"""
umm.types._base
===============
Base class and plugin contract for all UMM TLV types.

Every TLV type is a subclass of BaseUMMType.  The type registry
(umm.core.registry) auto-discovers all such subclasses found in the
umm/types/ directory and any user-supplied type directories.

To create a new type, subclass BaseUMMType, set TYPE_ID and TYPE_NAME,
fill in MATCH_OPS, and implement pack() / unpack() / to_text() /
from_text().  Drop the file anywhere in the types/ search path and the
router will pick it up automatically on next start.

M-word semantics
----------------
The M-word is a 32-bit unsigned integer whose meaning is entirely owned
by the type handler.  The base class provides a common convention for
the built-in numeric / string types (M-word = operator index into
MATCH_OPS), but user types are free to use M-word however they wish
(e.g. encoding format, field identifier, link operation …).

Match operator index 0 is always EQ (exact equality) when MATCH_OPS is
indexed.  A published message carries M-word=0; a subscription carries
the operator the subscriber wants applied.

Example
-------
    from umm.types._base import BaseUMMType, MatchOp

    class TemperatureType(BaseUMMType):
        TYPE_ID   = 50
        TYPE_NAME = "Temperature"
        MATCH_OPS = {
            MatchOp.EQ: lambda a, b: a == b,
            MatchOp.GT: lambda a, b: a > b,
            MatchOp.LT: lambda a, b: a < b,
        }
        def pack(self, value):
            import struct
            return struct.pack('!f', float(value))
        def unpack(self, data):
            import struct
            return struct.unpack('!f', data)[0]
        def to_text(self, value):
            return f"{value:.2f}"
        def from_text(self, text):
            return float(text)
"""

from __future__ import annotations

import struct
from enum import IntEnum
from typing import Any, Callable, Dict, Optional, Tuple

from ..core.tlv import TLV, MWORD_NONE, META_NONE, MWORD_IGNORE_MATCH


# ── standard match operators ──────────────────────────────────────────────────

class MatchOp(IntEnum):
    """
    Standard comparison operators.  These are the conventional M-word values
    for numeric and string types.  User types may define their own M-word
    table and ignore this enum entirely.
    """
    EQ       = 0   # equal                     =
    NE       = 1   # not equal                 !=
    GT       = 2   # greater than              >
    LT       = 3   # less than                 <
    GE       = 4   # greater than or equal     >=
    LE       = 5   # less than or equal        <=
    CONTAINS = 6   # substring / membership
    WILDCARD = 7   # glob-style wildcard  (* ?)
    SOUNDSLIKE = 8 # phonetic similarity
    BEFORE   = 9   # for time types
    AFTER    = 10  # for time types
    WITHIN   = 11  # within range / radius (2D)
    WITHIN_3D = 12 # within 3D sphere radius
    BBOX     = 13  # within 2D axis-aligned bounding box


OP_SYMBOLS: Dict[MatchOp, str] = {
    MatchOp.EQ:       "=",
    MatchOp.NE:       "!=",
    MatchOp.GT:       ">",
    MatchOp.LT:       "<",
    MatchOp.GE:       ">=",
    MatchOp.LE:       "<=",
    MatchOp.CONTAINS: "contains",
    MatchOp.WILDCARD: "wildcard",
    MatchOp.SOUNDSLIKE: "soundslike",
    MatchOp.BEFORE:   "before",
    MatchOp.AFTER:    "after",
    MatchOp.WITHIN:   "within",
    MatchOp.WITHIN_3D: "within3d",
    MatchOp.BBOX:     "bbox",
}

# Special M-word value — not a MatchOp, so kept outside the enum.
# Displayed as "ignore" in any context that formats M-word values.
MWORD_IGNORE_MATCH_SYMBOL = "ignore"


# ── base type ─────────────────────────────────────────────────────────────────

class BaseUMMType:
    """
    Contract that every UMM TLV type must satisfy.

    Class attributes
    ----------------
    TYPE_ID : int
        Unique identifier for this type.  IDs 0-49 are reserved for core
        UMM types.  IDs 50-99 are for manufacturing types.  IDs 100+
        are for user / application types.
    TYPE_NAME : str
        Human-readable name (e.g. "Int", "Temperature").  Used by the
        parser, type directory, and config files.
    BASE_TYPE : Optional[str]
        For specialised types, the name of the base type they extend
        (e.g. "Float").  Used by the type directory for queries like
        "give me all Float-based types".
    DESCRIPTION : str
        One-line description shown in the type directory.
    MATCH_OPS : dict[MatchOp|int, Callable[[Any, Any], bool]]
        Map from M-word value to a two-argument predicate
        ``(message_value, subscription_value) -> bool``.
        Key 0 should always be EQ (exact match).
        User types that use M-word for a different purpose should leave
        this empty and override ``match()`` directly.
    UNIT : str
        Optional unit string for display (e.g. "°C", "PSI", "m/s").
    """

    TYPE_ID:     int          = -1       # must be overridden
    TYPE_NAME:   str          = ""       # must be overridden
    BASE_TYPE:   Optional[str]= None
    DESCRIPTION: str          = ""
    MATCH_OPS:   Dict[int, Callable[[Any, Any], bool]] = {}
    UNIT:        str          = ""

    # ── core interface ────────────────────────────────────────────────────────

    def pack(self, value: Any) -> bytes:
        """
        Encode *value* to raw bytes suitable for the TLV value field.
        Must be overridden by every concrete type.
        """
        raise NotImplementedError(f"{self.__class__.__name__}.pack()")

    def unpack(self, data: bytes) -> Any:
        """
        Decode the TLV value bytes back to a Python object.
        Must be overridden by every concrete type.
        """
        raise NotImplementedError(f"{self.__class__.__name__}.unpack()")

    def to_text(self, value: Any) -> str:
        """
        Convert *value* to a human-readable string.
        Used by the parser / CLI display.  Default falls back to str().
        """
        return str(value)

    def from_text(self, text: str) -> Any:
        """
        Parse *text* (as produced by to_text) back to a Python value.
        Used by the parser / CLI for ad-hoc message entry.
        """
        raise NotImplementedError(f"{self.__class__.__name__}.from_text()")

    # ── matching ──────────────────────────────────────────────────────────────

    def match(self, msg_tlv: TLV, sub_tlv: TLV) -> bool:
        """
        Return True if *msg_tlv* (from a published message) satisfies the
        criterion expressed by *sub_tlv* (from a subscription).

        The default implementation:
          1. Reads the match-word from *sub_tlv* as an operator index.
          2. Looks up the operator in MATCH_OPS.
          3. Unpacks both values and applies the operator.

        Note: type_id and meta matching are handled upstream by the registry
        before this method is called.  This method only handles value matching.

        User types that use the match-word for a purpose other than operator
        selection should override this method entirely.
        """
        if not self.MATCH_OPS:
            # No operators defined → always match (type-only match)
            return True

        op_index = sub_tlv.match
        if op_index == MWORD_IGNORE_MATCH:
            # Subscriber wants to skip this positional slot entirely
            return True
        op_fn = self.MATCH_OPS.get(op_index)
        if op_fn is None:
            # Unknown operator → no match
            return False

        try:
            msg_val = self.unpack(msg_tlv.value)
            sub_val = self.unpack(sub_tlv.value)
            return bool(op_fn(msg_val, sub_val))
        except Exception:
            return False

    # ── TLV factory helpers ───────────────────────────────────────────────────

    def make_tlv(self, value: Any, match: int = MWORD_NONE,
                 meta: int = META_NONE) -> TLV:
        """
        Build a published TLV for *value*.

        Parameters
        ----------
        match : int
            Match-word.  In published messages this is passed through by the
            router unchanged.  Agents may use it as a sub-qualifier (e.g.
            to distinguish current/max/min readings of the same type).
        meta : int
            Meta-word.  Semantic qualifier (0 = absent).  Subscribers can
            filter on this value; 0 on either side always passes.
        """
        return TLV(type_id=self.TYPE_ID, value=self.pack(value),
                   match=match, meta=meta)

    def make_subscription_tlv(self, value: Any,
                               op: MatchOp = MatchOp.EQ,
                               meta: int = META_NONE) -> TLV:
        """
        Build a subscription TLV: match-word carries the operator index.

        Parameters
        ----------
        op : MatchOp
            Comparison operator for the value field.
        meta : int
            If non-zero, only published TLVs with the same non-zero meta
            value will pass.  0 (default) matches any meta value.
        """
        return TLV(type_id=self.TYPE_ID, value=self.pack(value),
                   match=int(op), meta=meta)

    @staticmethod
    def make_ignore_tlv(type_id: int = 0) -> TLV:
        """
        Build an IGNORE_MATCH subscription TLV for a positional slot.

        The router will skip this slot entirely (always passes), regardless
        of what type, meta, or value the message carries at that position.

        ``type_id`` is purely cosmetic — the router ignores it when
        ``match == MWORD_IGNORE_MATCH``.  Passing the expected type_id is
        good practice for readability but not required.

        Example — subscribe to temperature at position 1, ignore city at 0::

            from umm import MWORD_IGNORE_MATCH
            from umm.types._base import BaseUMMType
            from umm.types.builtin import FloatType
            from umm.core.meta import FLOAT_META_TEMPERATURE

            subs = [
                BaseUMMType.make_ignore_tlv(),
                FloatType().make_subscription_tlv(30.0, MatchOp.GT,
                                                  meta=FLOAT_META_TEMPERATURE),
            ]
        """
        return TLV(type_id=type_id, value=b'', match=MWORD_IGNORE_MATCH)

    # ── type-directory metadata ───────────────────────────────────────────────

    def directory_entry(self) -> dict:
        """
        Return a dict describing this type for the type directory service.
        """
        ops = [
            {"match": k, "symbol": OP_SYMBOLS.get(k, str(k))}
            for k in self.MATCH_OPS
        ]
        return {
            "type_id":     self.TYPE_ID,
            "name":        self.TYPE_NAME,
            "base_type":   self.BASE_TYPE,
            "description": self.DESCRIPTION,
            "unit":        self.UNIT,
            "match_ops":   ops,
        }

    # ── validation ────────────────────────────────────────────────────────────

    @classmethod
    def validate(cls) -> None:
        """
        Called by the registry after loading.  Raises ValueError if the
        type definition is incomplete.
        """
        if cls.TYPE_ID < 0:
            raise ValueError(f"Type {cls.__name__} has no TYPE_ID set")
        if not cls.TYPE_NAME:
            raise ValueError(f"Type {cls.__name__} has no TYPE_NAME set")

    def __repr__(self) -> str:
        return f"<UMMType {self.TYPE_NAME} id={self.TYPE_ID}>"


# ── bridge match-word constants ──────────────────────────────────────────────

class BridgeOp(IntEnum):
    """Match-word values for Type = TLV_ROUTERLINK (UMM Bridge messages)."""
    SUBSCRIBE   = 0
    UNSUBSCRIBE = 1
    FORWARD     = 2
    HEARTBEAT   = 3
    DISCONNECT  = 4
