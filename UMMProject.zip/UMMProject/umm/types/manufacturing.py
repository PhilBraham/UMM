"""
umm.types.manufacturing
=======================
Standard TLV types for manufacturing / industrial plant applications.

Drop this file into any type search directory and the router will pick
it up automatically.  Or import directly::

    from umm.types.manufacturing import TemperatureType, PressureType

Type IDs 50-99 are reserved for this manufacturing pack.
"""

from __future__ import annotations

import struct
from enum import IntEnum
from typing import Any

from ._base import BaseUMMType, MatchOp


# ── Temperature (ID=50) ───────────────────────────────────────────────────────

class TemperatureType(BaseUMMType):
    """
    Temperature reading in degrees Celsius.

    Wire format: 64-bit IEEE 754 double, network byte order.

    Example subscription – alert above 80°C::

        from umm.types.manufacturing import TemperatureType
        from umm.types._base import MatchOp

        t = TemperatureType()
        match_tlv = t.make_subscription_tlv(80.0, MatchOp.GT)
    """
    TYPE_ID     = 50
    TYPE_NAME   = "Temperature"
    BASE_TYPE   = "Float"
    DESCRIPTION = "Temperature reading"
    UNIT        = "°C"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: abs(a - b) < 0.001,
        MatchOp.NE: lambda a, b: abs(a - b) >= 0.001,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: float) -> bytes:
        return struct.pack('!d', float(value))

    def unpack(self, data: bytes) -> float:
        return struct.unpack('!d', data)[0]

    def to_text(self, value: float) -> str:
        return f"{value:.2f}°C"

    def from_text(self, text: str) -> float:
        return float(text.replace('°C', '').strip())


# ── Pressure (ID=51) ──────────────────────────────────────────────────────────

class PressureType(BaseUMMType):
    """
    Pressure reading in PSI (pounds per square inch).
    Use M-word=1 (MWORD_BAR) to indicate the value is in Bar instead.
    """
    TYPE_ID     = 51
    TYPE_NAME   = "Pressure"
    BASE_TYPE   = "Float"
    DESCRIPTION = "Pressure reading (PSI or Bar)"
    UNIT        = "PSI"

    # M-word as unit selector (not operator) for published data
    MWORD_PSI   = 0
    MWORD_BAR   = 1

    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: abs(a - b) < 0.001,
        MatchOp.NE: lambda a, b: abs(a - b) >= 0.001,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: float) -> bytes:
        return struct.pack('!d', float(value))

    def unpack(self, data: bytes) -> float:
        return struct.unpack('!d', data)[0]

    def to_text(self, value: float) -> str:
        return f"{value:.3f} PSI"

    def from_text(self, text: str) -> float:
        return float(text.replace('PSI', '').replace('Bar', '').strip())


# ── ConveyorSpeed (ID=52) ─────────────────────────────────────────────────────

class ConveyorSpeedType(BaseUMMType):
    """
    Conveyor belt speed in metres per second.

    M-word (in published data) encodes direction:
      0 = forward, 1 = reverse, 2 = stopped
    """
    TYPE_ID     = 52
    TYPE_NAME   = "ConveyorSpeed"
    BASE_TYPE   = "Float"
    DESCRIPTION = "Conveyor belt speed (m/s)"
    UNIT        = "m/s"

    MWORD_FORWARD = 0
    MWORD_REVERSE = 1
    MWORD_STOPPED = 2

    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: abs(a - b) < 0.001,
        MatchOp.NE: lambda a, b: abs(a - b) >= 0.001,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LT: lambda a, b: a <  b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.LE: lambda a, b: a <= b,
    }

    def pack(self, value: float) -> bytes:
        return struct.pack('!d', float(value))

    def unpack(self, data: bytes) -> float:
        return struct.unpack('!d', data)[0]

    def to_text(self, value: float) -> str:
        return f"{value:.3f} m/s"

    def from_text(self, text: str) -> float:
        return float(text.replace('m/s', '').strip())


# ── RobotState (ID=53) ────────────────────────────────────────────────────────

class RobotStateEnum(IntEnum):
    IDLE        = 0
    RUNNING     = 1
    PAUSED      = 2
    FAULT       = 3
    HOMING      = 4
    ESTOP       = 5
    MAINTENANCE = 6


class RobotStateType(BaseUMMType):
    """
    Robot arm / cell state enumeration.

    Wire format: unsigned 32-bit integer (RobotStateEnum value).
    M-word in published data = robot unit number (0-based).
    """
    TYPE_ID     = 53
    TYPE_NAME   = "RobotState"
    BASE_TYPE   = "UInt"
    DESCRIPTION = "Robot state enumeration"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
    }

    def pack(self, value: int) -> bytes:
        return struct.pack('!I', int(value))

    def unpack(self, data: bytes) -> int:
        return struct.unpack('!I', data)[0]

    def to_text(self, value: int) -> str:
        try:
            return RobotStateEnum(value).name
        except ValueError:
            return str(value)

    def from_text(self, text: str) -> int:
        text = text.strip().upper()
        for member in RobotStateEnum:
            if member.name == text:
                return member.value
        return int(text)


# ── ProcessEvent (ID=54) ──────────────────────────────────────────────────────

class ProcessEventType(BaseUMMType):
    """
    Plant process event.

    Wire format: null-terminated UTF-8 string carrying the event description.
    M-word = severity level:
      0 = INFO, 1 = WARNING, 2 = ALARM, 3 = CRITICAL, 4 = FAULT
    """
    TYPE_ID     = 54
    TYPE_NAME   = "ProcessEvent"
    BASE_TYPE   = "Char"
    DESCRIPTION = "Plant process event with severity"

    MWORD_INFO     = 0
    MWORD_WARNING  = 1
    MWORD_ALARM    = 2
    MWORD_CRITICAL = 3
    MWORD_FAULT    = 4

    SEVERITY_NAMES = {0: "INFO", 1: "WARNING", 2: "ALARM",
                      3: "CRITICAL", 4: "FAULT"}

    MATCH_OPS   = {
        MatchOp.EQ:       lambda a, b: a == b,
        MatchOp.NE:       lambda a, b: a != b,
        MatchOp.CONTAINS: lambda a, b: b.lower() in a.lower(),
    }

    def pack(self, value: str) -> bytes:
        return value.encode('utf-8') + b'\x00'

    def unpack(self, data: bytes) -> str:
        return data.rstrip(b'\x00').decode('utf-8', errors='replace')

    def to_text(self, value: str) -> str:
        return f'"{value}"'

    def from_text(self, text: str) -> str:
        return text.strip('"\'')


# ── AlarmLevel (ID=55) ────────────────────────────────────────────────────────

class AlarmLevelType(BaseUMMType):
    """
    Plant alarm level (integer 0-4, matches ProcessEvent M-word conventions).
    Subscribers can request alarms at or above a certain level::

        alarm = AlarmLevelType()
        # Alert me for WARNING and above
        match_tlv = alarm.make_subscription_tlv(1, MatchOp.GE)
    """
    TYPE_ID     = 55
    TYPE_NAME   = "AlarmLevel"
    BASE_TYPE   = "UInt"
    DESCRIPTION = "Plant alarm severity level (0=INFO … 4=FAULT)"
    MATCH_OPS   = {
        MatchOp.EQ: lambda a, b: a == b,
        MatchOp.NE: lambda a, b: a != b,
        MatchOp.GE: lambda a, b: a >= b,
        MatchOp.GT: lambda a, b: a >  b,
        MatchOp.LE: lambda a, b: a <= b,
        MatchOp.LT: lambda a, b: a <  b,
    }

    LEVEL_NAMES = {0: "INFO", 1: "WARNING", 2: "ALARM", 3: "CRITICAL", 4: "FAULT"}

    def pack(self, value: int) -> bytes:
        return struct.pack('!I', int(value))

    def unpack(self, data: bytes) -> int:
        return struct.unpack('!I', data)[0]

    def to_text(self, value: int) -> str:
        return self.LEVEL_NAMES.get(value, str(value))

    def from_text(self, text: str) -> int:
        text = text.strip().upper()
        for k, v in self.LEVEL_NAMES.items():
            if v == text:
                return k
        return int(text)


# ── convenience list for direct import ───────────────────────────────────────

MANUFACTURING_TYPES = [
    TemperatureType,
    PressureType,
    ConveyorSpeedType,
    RobotStateType,
    ProcessEventType,
    AlarmLevelType,
]
