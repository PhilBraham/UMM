"""
umm.router
==========
The UMM Router.

Listens on a TCP port.  Every connecting client gets an AttachId.
Clients then:
  1. Send MTUMMAttach    → router confirms with MTUMMAttachConfirm
  2. Send MTUMMRegister  → subscription stored in CLookup
  3. Send normal messages → router matches and delivers to subscribers
  4. Send MTUMMDetach    → cleanup

All messages are UMMMsg structs with TLV payloads.

Run from the command line::

    python -m umm.router --port 5000 --name PlantA

Or embed in a larger application::

    from umm.router import UMMRouter
    router = UMMRouter(port=5000, name="PlantA")
    asyncio.run(router.serve())
"""

from __future__ import annotations

import asyncio
import copy
import json
import logging
import struct
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Set, Tuple

from .core.tlv import (
    TLV, TLVBuffer, decode_one, decode_all,
    TLV_TERM, TLV_INT, TLV_STRING, TLV_JSON, TLV_MSG, TLV_SUBSPEC, TLV_MSGREF, TLV_BOOL,
    HEADER_SIZE, MWORD_IGNORE_MATCH, META_NONE,
)
from .core.messages import (
    UMMMsg, AttachId, VersionId, UTime, LogId,
    MType, UMMSubType, SType, MetaSubType, ReservedSubType, Channel,
    DebugLevel,
    AttachFlag, DetachFlag, AttachConfFlag, RequestFlag, MsgFlag,
    FIXED_HEADER_SIZE, MAX_ATTACHES, MAX_REGISTRATIONS,
    UMM_VERSION_STR, VERSION_MAJOR, VERSION_MINOR, DEFAULT_PORT,
)
from .core.registry import registry as _global_registry

logger = logging.getLogger(__name__)


# ── attach status flags ───────────────────────────────────────────────────────

EAS_UNUSED         = 0x00
EAS_INUSE          = 0x01
EAS_UNCLEARED_STATS= 0x02
EAS_DETACHED       = 0x04
EAS_OFFLINE        = 0x08
EAS_REATTACH       = 0x10
EAS_RUNNING        = 0x20

MAX_ACCOUNTS       = 100
MAX_REGISTRATION   = MAX_REGISTRATIONS


# ── data structures ───────────────────────────────────────────────────────────

@dataclass
class AccountInfo:
    mtype:   int = 0
    subtype: int = 0
    count:   int = 0


@dataclass
class RegEntry:
    """One registered subscription."""
    reg_id:    int
    attach_id: int
    msg:       UMMMsg          # original registration message
    flags:     int = 0
    channel:   int = 1         # logical channel (Channel enum); 1=APP, 0=ALL wildcard


@dataclass
class AttachInfo:
    """Per-client state."""
    attach_id:    int
    status:       int = EAS_UNUSED
    attach_flags: int = 0
    login:        Optional[LogId] = None
    writer:       Optional[asyncio.StreamWriter] = None
    agent_mtype:  int = 0    # primary mtype declared by agent in ATTACH
    reg_list:     Dict[int, RegEntry] = field(default_factory=dict)
    accounts:     List[AccountInfo]   = field(default_factory=list)
    queue:        List[bytes]         = field(default_factory=list)
    remote_router_id: int = 0

    def is_online(self) -> bool:
        return bool(self.status & EAS_INUSE) and not bool(self.status & EAS_OFFLINE)

    def is_permanent(self) -> bool:
        return bool(self.attach_flags & AttachFlag.PERM_KEEP_CONN)


# ── CLookup ───────────────────────────────────────────────────────────────────

class CLookup:
    """
    Subscription store.

    Organised as a three-level dict:
        _table[channel][mtype][subtype] = list[RegEntry]

    channel=1  application bus (APP, default).  channel=0 is the subscription wildcard.
    mtype=0 and subtype=0 are wildcards (match everything / all of mtype).
    """

    def __init__(self) -> None:
        # _table[channel][mtype][subtype] → list of RegEntry
        self._table: Dict[int, Dict[int, Dict[int, List[RegEntry]]]] = {}

    def add(self, entry: RegEntry) -> None:
        ch      = entry.channel
        mtype   = entry.msg.mtype
        subtype = entry.msg.subtype
        (self._table
             .setdefault(ch, {})
             .setdefault(mtype, {})
             .setdefault(subtype, [])
             .append(entry))
        logger.debug("Registered ch=%d mtype=%d subtype=%d attach=%d reg=%d",
                     ch, mtype, subtype, entry.attach_id, entry.reg_id)

    def remove(self, attach_id: int, reg_id: int) -> bool:
        for ch_dict in self._table.values():
            for mtype_dict in ch_dict.values():
                for subtype_list in mtype_dict.values():
                    for i, e in enumerate(subtype_list):
                        if e.attach_id == attach_id and e.reg_id == reg_id:
                            subtype_list.pop(i)
                            return True
        return False

    def remove_all_for(self, attach_id: int) -> None:
        for ch_dict in self._table.values():
            for mtype_dict in ch_dict.values():
                for subtype_list in mtype_dict.values():
                    subtype_list[:] = [e for e in subtype_list
                                       if e.attach_id != attach_id]

    def find_matches(self, msg: UMMMsg) -> List[RegEntry]:
        """
        Return all RegEntry objects whose subscription criteria are
        satisfied by *msg*.

        Channel matching: subscription channel=0 (ALL) is a wildcard (matches any
        channel). Subscription channel>=1 must match msg.channel exactly.
        """
        candidates: List[RegEntry] = []

        # Collect from exact channel match AND from channel=0 (wildcard)
        for ch in set([msg.channel, 0]):
            ch_dict = self._table.get(ch, {})

            def _collect(mtype: int, subtype: int) -> None:
                entries = ch_dict.get(mtype, {}).get(subtype, [])
                candidates.extend(entries)

            _collect(msg.mtype,  msg.subtype)
            _collect(msg.mtype,  0)
            _collect(0, 0)

        if not candidates:
            return []

        matched = []
        seen = set()
        for entry in candidates:
            if id(entry) in seen:
                continue
            seen.add(id(entry))
            if self._matches(msg, entry):
                matched.append(entry)
        return matched

    def _matches(self, msg: UMMMsg, entry: RegEntry) -> bool:
        """
        Check mtype / subtype AND TLV content match.
        entry.channel=0 (ALL) is a wildcard (matches any channel).
        entry.channel>=1 must equal msg.channel (already filtered by caller).
        """
        sub_msg = entry.msg

        # mtype=0 → match all
        if sub_msg.mtype != 0 and sub_msg.mtype != msg.mtype:
            return False
        # subtype=0 → match all of this mtype
        if sub_msg.subtype != 0 and sub_msg.subtype != msg.subtype:
            return False

        # TLV content match
        sub_tdata = sub_msg.tdata
        msg_tdata = msg.tdata

        # If subscription has no data (TLV_TERM), match on mtype/subtype only
        if sub_tdata.type_id == TLV_TERM or not sub_tdata.value:
            return True

        # Decode both TLV payloads and match element-by-element
        try:
            sub_tlvs = decode_all(sub_tdata.value)
            msg_tlvs = decode_all(msg_tdata.value)
        except Exception:
            return False

        # Match each subscription condition.  A condition whose meta is 0 is
        # matched POSITIONALLY (condition N against message field N) exactly as
        # before.  A condition with a non-zero meta is matched by KEY: it is
        # tested against the message field carrying the same (type_id, meta).
        # Several conditions sharing one (type, meta) therefore AND together
        # against that single field — e.g. a range expressed as
        #   Int meta=K >= lo   and   Int meta=K <= hi.
        # All conditions must pass (a single registration is a conjunction).
        pos = 0
        for sub_tlv in sub_tlvs:
            if sub_tlv.type_id == TLV_TERM:
                break
            if sub_tlv.match == MWORD_IGNORE_MATCH:
                pos += 1        # positional wildcard — skip this slot, always passes
                continue
            if sub_tlv.meta == META_NONE:
                if pos >= len(msg_tlvs):
                    return False
                if not _global_registry.match(msg_tlvs[pos], sub_tlv):
                    return False
                pos += 1
            else:
                target = next((m for m in msg_tlvs
                               if m.type_id == sub_tlv.type_id
                               and m.meta == sub_tlv.meta), None)
                if target is None or not _global_registry.match(target, sub_tlv):
                    return False

        return True

    def find_candidates_split(
        self,
        msg: 'UMMMsg',
        plugin_type_ids: Set[int],
    ) -> Tuple[List['RegEntry'], List['RegEntry']]:
        """
        Like find_matches() but separates immediately-matched entries from
        those that need async plugin evaluation.

        Returns (sync_matches, plugin_pending).

        For each candidate entry:
        - Non-plugin TLVs are checked synchronously as usual.
        - If any non-plugin check fails → entry is excluded.
        - If all pass and the entry contains plugin-owned TLVs → plugin_pending.
        - If all pass and no plugin TLVs → sync_matches.
        """
        candidates: List[RegEntry] = []

        # channel=0 subscriptions are wildcards — collect from both
        for ch in set([msg.channel, 0]):
            ch_dict = self._table.get(ch, {})

            def _collect(mtype: int, subtype: int) -> None:
                candidates.extend(ch_dict.get(mtype, {}).get(subtype, []))

            _collect(msg.mtype, msg.subtype)
            _collect(msg.mtype, 0)
            _collect(0, 0)

        # Deduplicate (same entry may appear via both channel paths)
        seen: set = set()
        deduped: List[RegEntry] = []
        for e in candidates:
            if id(e) not in seen:
                seen.add(id(e))
                deduped.append(e)
        candidates = deduped

        sync_matches:   List[RegEntry] = []
        plugin_pending: List[RegEntry] = []

        for entry in candidates:
            passed, has_plugin = self._sync_check(msg, entry, plugin_type_ids)
            if not passed:
                continue
            if has_plugin:
                plugin_pending.append(entry)
            else:
                sync_matches.append(entry)

        return sync_matches, plugin_pending

    def _sync_check(
        self,
        msg: 'UMMMsg',
        entry: 'RegEntry',
        plugin_type_ids: Set[int],
    ) -> Tuple[bool, bool]:
        """
        Check one entry against *msg*, skipping plugin-owned TLVs.

        Returns (passed, has_plugin):
          passed     — True if all non-plugin checks pass
          has_plugin — True if the entry contains at least one plugin-owned TLV
                       (caller should send those to the plugin)
        """
        sub_msg = entry.msg

        if sub_msg.mtype != 0 and sub_msg.mtype != msg.mtype:
            return False, False
        if sub_msg.subtype != 0 and sub_msg.subtype != msg.subtype:
            return False, False

        sub_tdata = sub_msg.tdata
        msg_tdata = msg.tdata

        if sub_tdata.type_id == TLV_TERM or not sub_tdata.value:
            return True, False

        try:
            sub_tlvs = list(decode_all(sub_tdata.value))
            msg_tlvs = list(decode_all(msg_tdata.value if msg_tdata.value else b''))
        except Exception:
            return False, False

        has_plugin = False
        pos = 0
        for sub_tlv in sub_tlvs:
            if sub_tlv.type_id == TLV_TERM:
                break
            if sub_tlv.match == MWORD_IGNORE_MATCH:
                pos += 1        # positional wildcard — skip this slot, always passes
                continue
            # Resolve which message field this condition tests: positionally
            # when meta==0 (unchanged), or by (type_id, meta) key otherwise.
            if sub_tlv.meta == META_NONE:
                if pos >= len(msg_tlvs):
                    return False, False
                target = msg_tlvs[pos]
                pos += 1
            else:
                target = next((m for m in msg_tlvs
                               if m.type_id == sub_tlv.type_id
                               and m.meta == sub_tlv.meta), None)
                if target is None:
                    return False, False
            if sub_tlv.type_id in plugin_type_ids:
                has_plugin = True
                continue        # defer to plugin
            if not _global_registry.match(target, sub_tlv):
                return False, False

        return True, has_plugin


# ── Plugin support ────────────────────────────────────────────────────────────

class _PluginConn:
    """One connected match plugin."""
    def __init__(self, name: str, type_ids: List[int],
                 writer: asyncio.StreamWriter) -> None:
        self.name     = name
        self.type_ids = type_ids
        self.writer   = writer

    async def send(self, obj: dict) -> None:
        line = (json.dumps(obj) + '\n').encode()
        self.writer.write(line)
        await self.writer.drain()

    def close(self) -> None:
        try:
            self.writer.close()
        except Exception:
            pass


@dataclass
class _PendingPluginReq:
    """Inflight async plugin match request."""
    msg:            'UMMMsg'
    from_attach:    int
    entries:        List['RegEntry']
    sync_delivered: int
    needs_confirm:  bool
    # Set for MATCH_QUERY dry-runs — deliver a second MATCH_RESULT instead
    dry_run:               bool = False
    dry_run_req_msg_id:    int  = 0
    dry_run_q_mtype:       int  = 0
    dry_run_q_subtype:     int  = 0


# ── Router ────────────────────────────────────────────────────────────────────

class UMMRouter:
    """
    The UMM Router.

    Parameters
    ----------
    port : int
        TCP port to listen on.  Default 5100.
    host : str
        Bind address.  Default '' (all interfaces).
    router_id : int
        Numeric identity of this router (used in AttachId.router).
    name : str
        Human-readable name for logging / type-directory.
    type_dirs : list[str]
        Extra directories to scan for TLV type plugins.
    """

    def __init__(self,
                 port:        int  = DEFAULT_PORT,
                 host:        str  = '',
                 router_id:   int  = 1,
                 name:        str  = 'UMMRouter',
                 type_dirs:   Optional[List[str]] = None,
                 plugin_port: int  = 0) -> None:
        self.port      = port
        self.host      = host
        self.router_id = router_id
        self.name      = name
        # Plugin port: 0 = auto (agent_port + 1), -1 = disabled
        self.plugin_port = plugin_port if plugin_port != 0 else port + 1

        self._registry = _global_registry
        if type_dirs:
            for d in type_dirs:
                self._registry.add_search_dir(d)

        self._attaches:     Dict[int, AttachInfo] = {}
        self._lookup:       CLookup               = CLookup()
        self._next_attach:  int                   = 1
        self._msg_id:       int                   = 1
        self._server:       Optional[asyncio.AbstractServer] = None
        self._plugin_server: Optional[asyncio.AbstractServer] = None

        # type_id → _PluginConn
        self._plugins:      Dict[int, _PluginConn] = {}
        # req_id → _PendingPluginReq
        self._plugin_reqs:  Dict[int, _PendingPluginReq] = {}
        self._plugin_req_counter: int = 0

        # Callbacks registered by embedded modules (e.g. type directory)
        self._mtype_handlers: Dict[int, Callable] = {}

        # Runtime debug publishing (enabled via SetDebug on mtype=UMM)
        self._debug_enabled: bool = False
        self._debug_min_level: int = 0   # bus gate: DebugLevel below this dropped

    # ── server lifecycle ──────────────────────────────────────────────────────

    async def serve(self) -> None:
        """Start the router and serve forever."""
        self._server = await asyncio.start_server(
            self._handle_client, self.host, self.port
        )
        addr = self._server.sockets[0].getsockname()
        site = (self.router_id >> 16) & 0xFFFF
        node = self.router_id & 0xFFFF
        logger.info("UMM Router '%s' listening on %s:%d (id=%d.%d)",
                    self.name, addr[0] or '*', addr[1], site, node)

        if self.plugin_port > 0:
            self._plugin_server = await asyncio.start_server(
                self._handle_plugin_client, self.host, self.plugin_port
            )
            paddr = self._plugin_server.sockets[0].getsockname()
            logger.info("Plugin port listening on %s:%d", paddr[0] or '*', paddr[1])

        async with self._server:
            await self._server.serve_forever()

    def stop(self) -> None:
        if self._plugin_server:
            self._plugin_server.close()
        if self._server:
            self._server.close()

    # ── client connection handler ─────────────────────────────────────────────

    async def _handle_client(self,
                              reader: asyncio.StreamReader,
                              writer: asyncio.StreamWriter) -> None:
        addr = writer.get_extra_info('peername')
        attach_id = self._alloc_attach(writer)
        logger.info("Client connected from %s → attach_id=%d", addr, attach_id)

        # Send INIT message so the client knows its attach ID
        await self._send_init(attach_id)

        try:
            await self._read_loop(reader, attach_id)
        except (asyncio.IncompleteReadError, ConnectionResetError):
            pass
        except Exception as exc:
            logger.exception("Error in client %d loop: %s", attach_id, exc)
        finally:
            logger.info("Client %d disconnected", attach_id)
            # Publish lifecycle notification for unexpected disconnects
            # (clean detach already published in _svc_detach)
            info = self._attaches.get(attach_id)
            if info and not (info.status & EAS_DETACHED):
                await self._publish_lifecycle(UMMSubType.AGENT_DETACHED,
                                              attach_id)
            await self._handle_disconnect(attach_id)
            writer.close()

    async def _read_loop(self, reader: asyncio.StreamReader,
                         attach_id: int) -> None:
        """Read and dispatch messages from one client.

        Network/framing errors (IncompleteReadError, struct.error on the
        fixed header) terminate the loop — the connection is unrecoverable.

        Dispatch errors (bad message content, handler bugs) are logged and
        skipped — the connection stays open so the client can keep running.
        """
        from .core.tlv import _padded_len
        while True:
            # ── framing — errors here are fatal for this connection ────────
            try:
                header_bytes = await reader.readexactly(FIXED_HEADER_SIZE)
                msg = UMMMsg.decode(header_bytes)

                tlv_header = await reader.readexactly(HEADER_SIZE)
                tlv_type, tlv_match, tlv_meta, tlv_len = struct.unpack("!IIII", tlv_header)

                padded = _padded_len(tlv_len)
                tlv_value = await reader.readexactly(padded)
                tlv_value = tlv_value[:tlv_len]

                msg.tdata = TLV(type_id=tlv_type, value=tlv_value, match=tlv_match, meta=tlv_meta)
            except (asyncio.IncompleteReadError, ConnectionResetError):
                # Clean EOF or peer reset — normal disconnect
                return
            except Exception as exc:
                # Unrecoverable framing error — stream is out of sync
                logger.error("Client %d: framing error, closing connection: %s",
                             attach_id, exc)
                return

            # ── stamp sender ───────────────────────────────────────────────
            info = self._attaches.get(attach_id)
            if info and msg.attach_id.id == 0:
                msg.attach_id = AttachId(router=self.router_id, id=attach_id)
            if msg.origin.id == 0:
                msg.origin = AttachId(router=self.router_id, id=attach_id)

            # ── dispatch — errors here are non-fatal ───────────────────────
            try:
                await self._dispatch(msg, attach_id)
            except Exception as exc:
                logger.error(
                    "Client %d: dispatch error mtype=%d subtype=%d — %s",
                    attach_id, msg.mtype, msg.subtype, exc,
                )
                logger.debug("Dispatch traceback:", exc_info=True)

    # ── message dispatch ──────────────────────────────────────────────────────

    async def _dispatch(self, msg: UMMMsg, from_attach: int) -> None:
        """Route an incoming message."""
        logger.debug("DISPATCH mtype=%d subtype=%d from=%d reg=%d tdata_type=%d tdata_len=%d",
                     msg.mtype, msg.subtype, from_attach, msg.reg_id,
                     msg.tdata.type_id, len(msg.tdata.value))
        if msg.mtype == MType.UMM:
            await self._process_umm(msg, from_attach)
        else:
            await self._process_msg(msg, from_attach)

    async def _process_umm(self, msg: UMMMsg, from_attach: int) -> None:
        """
        Handle UMM control messages (mtype=1).

        Subtypes 1–99 (router control) are handled by the router AND dispatched
        normally through the subscription system — any agent subscribing to
        mtype=1 receives them just like any other message.

        Subtypes 100+ (system messages) are NOT consumed by the router; they
        are dispatched through the subscription system only.  The router handles
        a specific subset (LIST_AGENTS) but still delivers them to subscribers.
        """
        st = msg.subtype

        # Messages on infrastructure channels (channel > 0) that are NOT
        # router control subtypes are agent-to-agent responses (version,
        # capability, debug, heartbeat etc.) that happen to use mtype=UMM.
        # Dispatch them directly without router interception.
        #
        # Exception: REGISTER and UNREGISTER must always go through the router
        # control path regardless of channel, because for a Register message the
        # channel field carries the *subscription* channel, not a routing channel.
        # A subscription on ch=3 still arrives as a Register message on ch=3,
        # and the router must intercept it to store the subscription entry.
        _ALWAYS_CONTROL = {
            int(UMMSubType.ATTACH),
            int(UMMSubType.DETACH),
            int(UMMSubType.REGISTER),
            int(UMMSubType.UNREGISTER),
        }
        if msg.channel != 1 and st not in _ALWAYS_CONTROL:
            await self._process_msg(msg, from_attach)
            return

        # ── Router control (subtypes 1–99): router acts, then also dispatches ──
        if   st == UMMSubType.ATTACH:
            await self._svc_attach(msg, from_attach)
        elif st == UMMSubType.DETACH:
            await self._svc_detach(msg, from_attach)
        elif st == UMMSubType.REGISTER:
            await self._svc_register(msg, from_attach)
        elif st == UMMSubType.UNREGISTER:
            await self._svc_unregister(msg, from_attach)
        elif st == UMMSubType.VERSION or st == UMMSubType.VERSION_REQUEST:
            await self._svc_version(msg, from_attach)
        elif st == UMMSubType.SHUTDOWN:
            logger.warning("Shutdown requested by attach_id=%d", from_attach)
        elif st == int(ReservedSubType.SET_DEBUG):
            await self._svc_set_debug(msg)
        elif st == int(ReservedSubType.SET_LOG_LEVEL):
            await self._svc_set_log_level(msg)
        elif st == UMMSubType.CAPABILITY_QUERY:
            await self._svc_capability_query(msg, from_attach)
        elif st == UMMSubType.STATUS_REQUEST:
            await self._svc_status(from_attach, msg.reg_id)
        elif st == UMMSubType.MATCH_QUERY:
            await self._svc_match_query(msg, from_attach)
        elif st == UMMSubType.SYSTEM_SHUTDOWN:
            await self._svc_system_shutdown(msg, from_attach)
        elif 1 <= st <= 99:
            # Reserved router-control subtype — not yet implemented
            pass

        # ── System messages (subtypes 100+): router handles select subtypes ──
        elif st == UMMSubType.LIST_AGENTS:
            await self._svc_list_agents(from_attach, msg.reg_id)
        elif st == UMMSubType.LIST_TYPES:
            await self._svc_list_types(from_attach)
        elif st == UMMSubType.LIST_SUBS:
            await self._svc_list_subs(from_attach)
        # All other 100+ subtypes fall through to normal pub/sub dispatch below

        # ALSO dispatch through normal subscription system so any agent
        # subscribing to mtype=1 (or wildcard 0,0) sees control messages
        # just like any other message. Stamp origin so subscribers know
        # who sent it.
        stamped = UMMMsg(
            version   = msg.version,
            attach_id = msg.attach_id,
            origin    = AttachId(router=self.router_id, id=from_attach),
            tm        = msg.tm,
            flags     = msg.flags,
            reg_id    = msg.reg_id,
            msg_id    = msg.msg_id,
            mtype     = msg.mtype,
            subtype   = msg.subtype,
            channel   = msg.channel,
            tdata     = msg.tdata,
        )
        await self._process_msg(stamped, from_attach)

    async def _process_msg(self, msg: UMMMsg, from_attach: int) -> None:
        """Route a normal (non-UMM-control) message to subscribers."""
        if self._plugins:
            sync_matches, plugin_pending = self._lookup.find_candidates_split(
                msg, set(self._plugins.keys()))
        else:
            sync_matches = self._lookup.find_matches(msg)
            plugin_pending = []

        logger.debug("msg mtype=%d subtype=%d from=%d → %d sync + %d plugin",
                     msg.mtype, msg.subtype, from_attach,
                     len(sync_matches), len(plugin_pending))
        if self._debug_enabled:
            self._rdebug(int(DebugLevel.DEBUG),
                         f"Dispatch: mtype={msg.mtype} subtype={msg.subtype} "
                         f"ch={msg.channel} from={from_attach} "
                         f"→ {len(sync_matches)+len(plugin_pending)} subscriber(s)")
        delivered = 0
        for entry in sync_matches:
            # Don't send to self if DONT_SEND_SELF
            if (entry.attach_id == from_attach and
                    entry.flags & RequestFlag.DONT_SEND_SELF):
                continue
            # Stamp the reg_id from the matching subscription
            msg.reg_id = entry.reg_id
            msg.attach_id = AttachId(router=self.router_id, id=entry.attach_id)
            await self._deliver(entry.attach_id, msg)
            delivered += 1

        # Send confirmation(s) if the sender requested them
        needs_confirm = bool(msg.flags & (MsgFlag.CONFIRM_RTR | MsgFlag.CONFIRM_RCV))

        if plugin_pending:
            await self._dispatch_plugin_match(
                msg, from_attach, plugin_pending, delivered, needs_confirm)
        elif needs_confirm and from_attach != 0:
            await self._send_confirm(msg, delivered)

    # ── UMM control handlers ──────────────────────────────────────────────────

    async def _svc_capability_query(self, msg: UMMMsg,
                                     from_attach: int) -> None:
        """
        Respond to a capability query targeted at the router (mtype=1).

        Responds if:
          - The query has no Int payload (broadcast — all agents respond)
          - The query has Int(1) payload (targeted at mtype=1)

        Response goes through _process_msg so any subscriber to
        (UMM, CAPABILITY_RESPONSE) receives it with the correct reg_id.
        """
        import struct as _struct, json as _json

        # Check if this is a targeted query — if so, only respond if target==1
        if msg.tdata.value:
            try:
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == TLV_INT and len(tlv.value) >= 4:
                        target = _struct.unpack('!i', tlv.value[:4])[0]
                        if target != MType.UMM:
                            return   # targeted at a different mtype
                        break
            except Exception:
                pass

        cap = {
            "what":        "Router",
            "instance":    self.name,
            "mtype":       MType.UMM,
            "version":     f"{VERSION_MAJOR}.{VERSION_MINOR}",
            "description": (
                f"UMM message router '{self.name}'. "
                "Manages agent attach/detach, subscription registration, "
                "and message delivery. Publishes lifecycle events and "
                "responds to system queries."
            ),
            "attach_id":   f"{self.router_id}.0",
            "subtypes": [
                {"subtype":  1, "name": "Attach",           "direction": "in",
                 "description": "Agent connect and authenticate."},
                {"subtype":  2, "name": "AttachConfirm",    "direction": "out",
                 "description": "Router confirms attach, assigns attach_id."},
                {"subtype":  3, "name": "Detach",           "direction": "in",
                 "description": "Agent graceful disconnect."},
                {"subtype":  4, "name": "Register",         "direction": "in",
                 "description": "Register a subscription with optional content match."},
                {"subtype":  5, "name": "Unregister",       "direction": "in",
                 "description": "Remove a subscription by reg_id."},
                {"subtype":  6, "name": "Shutdown",         "direction": "in",
                 "description": "Request router shutdown."},
                {"subtype":  7, "name": "AgentAttached",    "direction": "out",
                 "description": "Published when an agent joins the bus."},
                {"subtype":  8, "name": "AgentDetached",    "direction": "out",
                 "description": "Published when an agent leaves the bus."},
                {"subtype":  9, "name": "AgentReattached",  "direction": "out",
                 "description": "Published when a permanent agent reconnects."},
                {"subtype": 51, "name": "CapabilityQuery",  "direction": "in",
                 "description": "Query agent capabilities. Int(mtype) for targeted, no payload for broadcast."},
                {"subtype": 52, "name": "CapabilityResponse","direction": "out",
                 "description": "Capability descriptor response. Int(mtype) Char(json)."},
                {"subtype": 53, "name": "VersionRequest",   "direction": "in",
                 "description": "Request router version. Response on (UMM, VersionResponse=13)."},
                {"subtype": 54, "name": "VersionResponse",   "direction": "out",
                 "description": "Router version: Int(mtype=1) Char(json with version info)."},
                {"subtype": 55, "name": "StatusRequest",    "direction": "in",
                 "description": "Request full subscription table."},
                {"subtype": 56, "name": "StatusResponse",   "direction": "out",
                 "description": "Full subscription table as JSON."},
                {"subtype": 59, "name": "SystemShutdown",  "direction": "in",
                 "description": "Trusted agents only. Int(delay_secs) [Char(reason)]. Broadcasts shutdown then exits."},
                {"subtype": 100,"name": "SysError",         "direction": "out",
                 "description": "Router error message directed to one client."},
                {"subtype": 101,"name": "SysInfo",          "direction": "out",
                 "description": "Router informational message to one client."},
                {"subtype": 110,"name": "ListAgents",       "direction": "in",
                 "description": "Request list of all attached agents."},
                {"subtype": 111,"name": "ListAgentsResponse","direction": "out",
                 "description": "List of attached agents as JSON."},
            ],
            "author": "Realtime Software Pty Ltd",
            "notes":  "",
        }

        json_bytes = _json.dumps(cap).encode('utf-8') + b'\x00'

        buf = TLVBuffer()
        # Int(mtype=1) so the requester knows who responded
        buf.add(TLV(type_id=TLV_INT,
                    value=_struct.pack('!i', MType.UMM)))
        buf.add(TLV(type_id=TLV_STRING, value=json_bytes))

        resp = self._make_router_msg(0, UMMSubType.CAPABILITY_RESPONSE, buf,
                                     channel=int(Channel.META))
        await self._process_msg(resp, 0)

    async def _svc_version(self, msg: UMMMsg, from_attach: int) -> None:
        """
        Respond to a VersionRequest (UMMSubType.VERSION_REQUEST=53, or legacy -1).

        Response on (MType.UMM=1, UMMSubType.VERSION_RESPONSE=54), channel=1:
            Int(source_mtype=1)  MsgRef(msg_id)  Char(json_version)

        JSON format matches all other agents (VersionMixin):
            {"system": "1.2", "group": "1.0.0", "agent": "1.0.0", "build": "python"}
        """
        import json as _json, struct as _struct

        version_json = _json.dumps({
            "system": UMM_VERSION_STR.split()[2].lstrip('v') if ' ' in UMM_VERSION_STR else f"{VERSION_MAJOR}.{VERSION_MINOR}",
            "group":  f"{VERSION_MAJOR}.{VERSION_MINOR}.0",
            "agent":  f"{VERSION_MAJOR}.{VERSION_MINOR}.0",
            "build":  "python",
        })

        buf = TLVBuffer()
        # Int(source_mtype) — identifies the router
        buf.add(TLV(type_id=TLV_INT,
                    value=_struct.pack('!i', MType.UMM)))
        # MsgRef(msg_id) — correlates to the original request
        buf.add(TLV(type_id=16,   # TLV_MSGREF
                    value=_struct.pack('!III',
                                       msg.origin.router,
                                       msg.origin.id,
                                       msg.msg_id)))
        # Char(json)
        buf.add(TLV(type_id=TLV_STRING,
                    value=version_json.encode('utf-8') + b'\x00'))

        resp = self._make_router_msg(0, UMMSubType.VERSION_RESPONSE, buf,
                                     channel=int(Channel.APP))
        await self._process_msg(resp, 0)


        """
        Respond to a STATUS_REQUEST with the full subscription table as JSON.

        Response: mtype=1, subtype=STATUS_RESPONSE, Char(JSON)

        JSON structure:
        {
          "router_id": 1,
          "agents": [
            {
              "attach_id": 3,
              "name": "Timer",
              "agent_mtype": 2,
              "online": true,
              "subscriptions": [
                {"reg_id": 1, "mtype": 2, "subtype": 1, "match": ""}
              ]
            }
          ]
        }
        """
        import json as _json

        agents = []
        for aid, info in sorted(self._attaches.items()):
            if info.status == EAS_UNUSED:
                continue
            name = info.login.process_name if info.login else f"agent{aid}"
            subs = []
            for reg_id, entry in sorted(info.reg_list.items()):
                reg_mtype   = entry.msg.mtype
                reg_subtype = entry.msg.subtype
                match_str   = ""
                if entry.msg.tdata.value:
                    try:
                        from .core.tlv import decode_all
                        tlvs = decode_all(entry.msg.tdata.value)
                        match_str = " ".join(
                            f"Type{t.type_id}={t.value.hex()}"
                            for t in tlvs if t.value
                        )
                    except Exception:
                        pass
                subs.append({
                    "reg_id":  reg_id,
                    "channel": entry.channel,
                    "mtype":   reg_mtype,
                    "subtype": reg_subtype,
                    "match":   match_str,
                })
            agents.append({
                "attach_id":   aid,
                "name":        name,
                "agent_mtype": info.agent_mtype,
                "online":      info.is_online(),
                "subscriptions": subs,
            })

        data = {"router_id": self.router_id, "agents": agents}
        json_bytes = _json.dumps(data, indent=2).encode() + b'\x00'

        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING, value=json_bytes))
        resp = self._make_router_msg(0, UMMSubType.STATUS_RESPONSE, buf)
        await self._process_msg(resp, 0)

    def _is_trusted(self, attach_id: int) -> bool:
        """Return True if the attached agent has AttachFlag.TRUSTED set."""
        info = self._attaches.get(attach_id)
        return info is not None and bool(info.attach_flags & AttachFlag.TRUSTED)

    def _send_denied(self, to_attach: int, message: str) -> None:
        """Send a SYS_DENIED (103) message directly to one client."""
        import struct as _struct
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING,
                    value=message.encode('utf-8') + b'\x00'))
        msg = self._make_router_msg(to_attach, UMMSubType.SYS_DENIED, buf)
        asyncio.ensure_future(self._process_msg(msg, 0))

    async def _svc_system_shutdown(self, msg: UMMMsg, from_attach: int) -> None:
        """
        Handle a SYSTEM_SHUTDOWN request (UMMSubType.SYSTEM_SHUTDOWN=59).

        Only trusted agents (AttachFlag.TRUSTED) may issue this command.
        Non-trusted requesters receive SYS_DENIED (103) and the request
        is silently dropped.

        Payload: Int(delay_seconds) [Char(message)]
            delay_seconds — 0 = immediate; positive = countdown in seconds.
            message       — optional human-readable reason string.

        Sequence:
          1. Validate trust.
          2. Broadcast SYSTEM_SHUTDOWN to all agents (same mtype=1, subtype=59)
             with the same payload so they can log/display the reason.
          3. Wait delay_seconds.
          4. Send SHUTDOWN (subtype=6) to every attached agent.
          5. Allow a brief grace period for agents to detach cleanly.
          6. Stop the router event loop.
        """
        import struct as _struct

        if not self._is_trusted(from_attach):
            logger.warning("SYSTEM_SHUTDOWN refused — attach_id=%d not trusted", from_attach)
            self._send_denied(from_attach, "System shutdown refused: not a trusted agent")
            return

        # Parse payload: Int(delay) [Char(message)]
        delay_secs = 0
        reason     = "System shutdown initiated"
        try:
            from .core.tlv import decode_all as _decode_all
            tlvs = list(_decode_all(msg.tdata.value))
            if tlvs and tlvs[0].type_id == TLV_INT:
                delay_secs = _struct.unpack('!i', tlvs[0].value)[0]
            if len(tlvs) >= 2 and tlvs[1].type_id == TLV_STRING:
                reason = tlvs[1].value.rstrip(b'\x00').decode('utf-8', errors='replace')
        except Exception:
            pass

        delay_secs = max(0, delay_secs)
        logger.warning("SYSTEM_SHUTDOWN in %ds: %s (requested by attach_id=%d)",
                       delay_secs, reason, from_attach)

        # Broadcast the shutdown notice to all agents (same payload passthrough)
        await self._process_msg(msg, 0)

        async def _do_shutdown():
            if delay_secs > 0:
                await asyncio.sleep(delay_secs)

            # Send SHUTDOWN (6) to every attached agent
            for aid in list(self._attaches.keys()):
                try:
                    buf = TLVBuffer()
                    buf.add(TLV(type_id=TLV_STRING,
                                value=reason.encode('utf-8') + b'\x00'))
                    shutdown_msg = self._make_router_msg(
                        aid, UMMSubType.SHUTDOWN, buf)
                    await self._process_msg(shutdown_msg, 0)
                except Exception as exc:
                    logger.warning("Shutdown send to attach_id=%d failed: %s", aid, exc)

            # Brief grace period for agents to detach cleanly
            await asyncio.sleep(1.0)

            logger.warning("SYSTEM_SHUTDOWN: stopping router event loop")
            loop = asyncio.get_event_loop()
            loop.stop()

        asyncio.ensure_future(_do_shutdown())

    async def _svc_match_query(self, msg: UMMMsg, from_attach: int) -> None:
        """
        Handle a MATCH_QUERY (UMM subtype 57) from a client.

        The client sends a hypothetical message — the mtype, subtype, and TLV
        payload it is *thinking about* publishing.  The router runs the full
        match logic (including any plugin delegations for Char TLVs) and
        replies with MATCH_RESULT (UMM subtype 58): a JSON list of every
        subscription that would have matched, together with the attach_id,
        reg_id, agent name, and agent mtype of the owner.

        Nothing is delivered to any subscriber.  The query message itself is
        still dispatched through the normal subscription system so monitors
        subscribed to (1, 22) can observe it — this is the standard mtype=1
        behaviour.

        Wire format of the request payload
        -----------------------------------
        The TData of the MATCH_QUERY message is a TLV_SUBSPEC whose value is:

            mtype   (4 bytes, NBO signed int)  — target mtype
            subtype (4 bytes, NBO signed int)  — target subtype
            <optional TLV payload bytes>        — content-match data

        This is identical to the layout used for REGISTER (subtype 4), so the
        same encoding path can be reused from the agent side.

        Wire format of the response (UMM, 23)
        --------------------------------------
        A single Char TLV containing a UTF-8 JSON string:

            {
              "query": {
                "mtype":   <int>,
                "subtype": <int>
              },
              "matches": [
                {
                  "attach_id":  <int>,
                  "reg_id":     <int>,
                  "agent_name": <str>,
                  "agent_mtype":<int>
                },
                ...
              ],
              "plugin_pending": <bool>   // true if result may be incomplete
                                         // because a plugin is not connected
            }

        Plugin interaction
        ------------------
        If the query payload contains TLV types owned by a connected plugin
        (e.g. Char strings handled by string_match.py), the router
        sends the plugin an asynchronous match_req exactly as it would for a
        real message.  Because the result is async, the synchronous portion
        (subscriptions with no plugin TLVs) is returned immediately in
        MATCH_RESULT with ``plugin_pending: false``.  The plugin result, when
        it arrives, is sent as a second MATCH_RESULT on the same correlation
        reg_id with ``plugin_pending: false``.

        If the query payload contains plugin TLV types but no plugin is
        currently connected, those subscriptions are evaluated using the
        built-in fallback (registry.match) and ``plugin_pending: false`` is
        set.  This matches the router's normal fallback behaviour.

        Correlation
        -----------
        The response is published through _process_msg so every agent
        subscribed to (UMM, MATCH_RESULT) receives it.  The ``reg_id`` field
        on the request is carried through to the response origin so the
        requesting agent can correlate responses to queries — identical to the
        ListAgents / StatusRequest pattern.
        """
        import json as _json

        # ── Decode the hypothetical message parameters ────────────────────────
        q_mtype   = 0
        q_subtype = 0
        q_payload = b''

        if msg.tdata.value:
            try:
                from .core.tlv import decode_all as _da
                for tlv in _da(msg.tdata.value):
                    if tlv.type_id == TLV_SUBSPEC and len(tlv.value) >= 8:
                        q_mtype, q_subtype = struct.unpack_from('!ii', tlv.value, 0)
                        q_payload = tlv.value[8:]
                        break
            except Exception as exc:
                logger.warning("MATCH_QUERY: could not decode payload: %s", exc)

        # ── Build a synthetic message to run through match logic ──────────────
        fake_msg = UMMMsg(
            version   = msg.version,
            attach_id = msg.attach_id,
            origin    = AttachId(router=self.router_id, id=from_attach),
            tm        = msg.tm,
            flags     = 0,
            reg_id    = 0,
            msg_id    = msg.msg_id,
            mtype     = q_mtype,
            subtype   = q_subtype,
            channel   = msg.channel,   # query on the same channel as the request
            tdata     = TLV(type_id=TLV_MSG, value=q_payload)
                        if q_payload else TLV(type_id=TLV_TERM),
        )

        # ── Split into sync matches and plugin-pending ────────────────────────
        if self._plugins:
            sync_entries, plugin_entries = self._lookup.find_candidates_split(
                fake_msg, set(self._plugins.keys()))
        else:
            sync_entries = self._lookup.find_matches(fake_msg)
            plugin_entries = []

        # ── Build sync result list ────────────────────────────────────────────
        def _entry_to_dict(entry: RegEntry) -> dict:
            info = self._attaches.get(entry.attach_id, None)
            name = (info.login.process_name
                    if info and info.login else f"agent{entry.attach_id}")
            mtype = info.agent_mtype if info else 0
            return {
                "attach_id":   entry.attach_id,
                "reg_id":      entry.reg_id,
                "agent_name":  name,
                "agent_mtype": mtype,
            }

        sync_matches = [_entry_to_dict(e) for e in sync_entries
                        if e.attach_id != from_attach or
                        not (e.flags & RequestFlag.DONT_SEND_SELF)]

        # ── Send the sync result immediately ─────────────────────────────────
        await self._send_match_result(
            from_attach  = from_attach,
            req_msg_id   = msg.msg_id,
            q_mtype      = q_mtype,
            q_subtype    = q_subtype,
            matches      = sync_matches,
            plugin_pending = bool(plugin_entries),
        )

        # ── Dispatch plugin match if needed ───────────────────────────────────
        if plugin_entries:
            req_id = self._plugin_req_counter
            self._plugin_req_counter += 1
            self._plugin_reqs[req_id] = _PendingPluginReq(
                msg            = fake_msg,
                from_attach    = from_attach,
                entries        = plugin_entries,
                sync_delivered = 0,
                needs_confirm  = False,
                dry_run        = True,
                dry_run_req_msg_id = msg.msg_id,
                dry_run_q_mtype    = q_mtype,
                dry_run_q_subtype  = q_subtype,
            )
            msg_tlvs_hex = q_payload.hex() if q_payload else ''
            by_plugin: Dict[int, Tuple[_PluginConn, List[int]]] = {}
            for entry in plugin_entries:
                tdata = entry.msg.tdata
                if tdata.value:
                    try:
                        for tlv in decode_all(tdata.value):
                            plugin = self._plugins.get(tlv.type_id)
                            if plugin:
                                pid = id(plugin)
                                if pid not in by_plugin:
                                    by_plugin[pid] = (plugin, [])
                                by_plugin[pid][1].append(entry.reg_id)
                                break
                    except Exception:
                        pass
            for plugin, reg_ids in by_plugin.values():
                try:
                    await plugin.send({
                        'msg':      'match_req',
                        'req_id':   req_id,
                        'msg_tlvs': msg_tlvs_hex,
                        'reg_ids':  reg_ids,
                    })
                except Exception as exc:
                    logger.warning("MATCH_QUERY: plugin send error: %s", exc)

    async def _send_match_result(self,
                                  from_attach: int,
                                  req_msg_id: int,
                                  q_mtype: int,
                                  q_subtype: int,
                                  matches: list,
                                  plugin_pending: bool) -> None:
        """Send a MATCH_RESULT (UMM, 23) back through _process_msg."""
        import json as _json
        data = {
            "query":          {"mtype": q_mtype, "subtype": q_subtype},
            "matches":        matches,
            "plugin_pending": plugin_pending,
        }
        json_bytes = _json.dumps(data).encode() + b'\x00'
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING, value=json_bytes))
        resp = self._make_router_msg(from_attach,
                                     UMMSubType.MATCH_RESULT, buf)
        # Stamp req_msg_id so the agent can correlate using MsgRef matching
        resp.msg_id = req_msg_id
        await self._process_msg(resp, 0)

    async def _svc_list_agents(self, from_attach: int,
                                req_reg_id: int = 0) -> None:
        """
        Respond to a LIST_AGENTS request.

        The response is published on (UMM, LIST_AGENTS_RESPONSE) and routed
        through _process_msg so the subscription lookup stamps the correct
        reg_id for each subscriber.  Any agent subscribed to (UMM, 111)
        receives it — not just the requester.
        """
        import json as _json

        # Router appears first as a synthetic entry (attach_id=0)
        agents = [{
            "attach_id": 0,
            "name":      self.name,
            "mtype":     int(MType.UMM),
            "online":    True,
        }]
        for aid, info in sorted(self._attaches.items()):
            if info.status == EAS_UNUSED:
                continue
            if not info.is_online():
                continue
            name = info.login.process_name if info.login else f"agent{aid}"
            agents.append({
                "attach_id": aid,
                "name":      name,
                "mtype":     info.agent_mtype,
                "online":    True,
            })

        data = {
            "router_id":   self.router_id,
            "router_name": self.name,
            "agents":      agents,
        }
        json_bytes = _json.dumps(data).encode() + b'\x00'

        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING, value=json_bytes))
        # Route through _process_msg so the subscription lookup assigns the
        # correct reg_id for each subscriber — direct _deliver bypasses this.
        resp = self._make_router_msg(0, UMMSubType.LIST_AGENTS_RESPONSE, buf)
        await self._process_msg(resp, 0)

    async def _svc_list_types(self, from_attach: int) -> None:
        """
        Respond to a LIST_TYPES request (UMM subtype 112).

        Returns all TLV types currently registered in the router's type
        registry, together with their match operators.  The response is
        published on (UMM, LIST_TYPES_RESPONSE) and routed through
        _process_msg so any agent subscribed to (UMM, 113) receives it.

        Response payload: Char(json)  — see DESIGN_NOTES.md §3 for schema.
        """
        import json as _json

        types = self._registry.directory_entries()
        json_bytes = _json.dumps({"types": types}).encode() + b'\x00'
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING, value=json_bytes))
        resp = self._make_router_msg(0, UMMSubType.LIST_TYPES_RESPONSE, buf)
        await self._process_msg(resp, 0)

    async def _svc_list_subs(self, from_attach: int) -> None:
        """
        Respond to a LIST_SUBS request (UMM subtype 114).

        Returns all current subscriptions across all attached agents.
        The response is published on (UMM, LIST_SUBS_RESPONSE) and routed
        through _process_msg so any agent subscribed to (UMM, 115) receives it.

        Response payload: Char(json) with schema::

            {
              "router_id": <int>,
              "subscriptions": [
                {
                  "reg_id":     <int>,
                  "attach_id":  <int>,
                  "agent_name": <str>,
                  "agent_mtype":<int>,
                  "channel":    <int>,
                  "mtype":      <int>,
                  "subtype":    <int>,
                  "match_hex":  <str>   # hex-encoded raw match TLV bytes; "" if none
                },
                ...
              ]
            }

        The ``match_hex`` field carries the raw match TLV bytes exactly as
        the agent supplied them, so a bridge or other consumer can re-register
        the subscription verbatim using the same parse path as a live REGISTER
        event (``parse_register_msg`` / ``strip_router_id_tlv``).
        """
        import json as _json

        subs = []
        for aid, info in sorted(self._attaches.items()):
            if info.status == EAS_UNUSED:
                continue
            name = info.login.process_name if info.login else f"agent{aid}"
            for reg_id, entry in sorted(info.reg_list.items()):
                match_bytes = (entry.msg.tdata.value
                               if entry.msg.tdata.type_id == TLV_MSG
                               else b'')
                subs.append({
                    "reg_id":      reg_id,
                    "attach_id":   aid,
                    "agent_name":  name,
                    "agent_mtype": info.agent_mtype,
                    "channel":     entry.channel,
                    "mtype":       entry.msg.mtype,
                    "subtype":     entry.msg.subtype,
                    "match_hex":   match_bytes.hex(),
                })

        data = {"router_id": self.router_id, "subscriptions": subs}
        json_bytes = _json.dumps(data).encode() + b'\x00'
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_JSON, value=json_bytes))
        resp = self._make_router_msg(0, UMMSubType.LIST_SUBS_RESPONSE, buf)
        await self._process_msg(resp, 0)

    async def _svc_attach(self, msg: UMMMsg, from_attach: int) -> None:
        info = self._attaches.get(from_attach)
        if info is None:
            await self._send_error(from_attach, "Unknown attach id")
            return

        info.attach_flags = msg.flags

        # Decode TLVs from TData: LogId(15) and optional Int(2) agent_mtype
        if msg.tdata.value:
            tlvs = decode_all(msg.tdata.value)
            for tlv in tlvs:
                if tlv.type_id == 15:   # TLV_LOGID
                    handler = self._registry.get_by_id(15)
                    if handler:
                        parts = handler.unpack(tlv.value)
                        info.login = LogId(*parts)
                elif tlv.type_id == TLV_INT and len(tlv.value) >= 4:
                    info.agent_mtype = struct.unpack('!i', tlv.value[:4])[0]

        # Check for permanent re-attach.
        # If this is a returning permanent agent (same process name, old slot
        # still offline), migrate the new TCP connection back onto the old slot
        # so queued messages and retained subscriptions are preserved.
        flag = AttachConfFlag.NORMAL
        if info.attach_flags & AttachFlag.PERM_KEEP_CONN:
            process_name = info.login.process_name if info.login else ''
            old_id = None
            if process_name:
                for aid, ainfo in self._attaches.items():
                    if (aid != from_attach
                            and ainfo.is_permanent()
                            and (ainfo.status & EAS_OFFLINE)
                            and ainfo.login
                            and ainfo.login.process_name == process_name):
                        old_id = aid
                        break

            if old_id is not None:
                # Re-attach: migrate writer onto the old slot, free temp slot.
                old_info = self._attaches[old_id]
                old_info.writer       = info.writer
                old_info.attach_flags = info.attach_flags
                old_info.login        = info.login
                old_info.agent_mtype  = info.agent_mtype
                old_info.status       = EAS_INUSE | EAS_RUNNING | EAS_REATTACH
                # Release the temporary slot that _alloc_attach created.
                self._attaches[from_attach].status = EAS_UNUSED
                self._attaches[from_attach].writer = None
                from_attach = old_id
                info        = old_info
                flag        = AttachConfFlag.PERM_REATT
                logger.info("Permanent re-attach: process=%r reinstated as "
                            "attach=%d (%d queued messages)",
                            process_name, old_id, len(old_info.queue))
            else:
                flag        = AttachConfFlag.PERM_NEW
                info.status = EAS_INUSE | EAS_RUNNING

        await self._send_attach_confirm(from_attach, flag)
        logger.info("Attach confirmed: id=%d login=%s flags=0x%x",
                    from_attach,
                    info.login.process_name if info.login else 'anon',
                    info.attach_flags)
        self._rdebug(int(DebugLevel.INFO),
                     f"Attach: id={from_attach} "
                     f"name={info.login.process_name if info.login else 'anon'} "
                     f"mtype={info.agent_mtype}")

        # Flush queued messages immediately after ATTACH_CONFIRM so the agent
        # receives them before any new traffic arrives.  On PERM_NEW there is
        # nothing to flush; on PERM_REATT we flush the offline queue.
        if flag == AttachConfFlag.PERM_REATT:
            await self._flush_queue(from_attach)

        # Publish the appropriate lifecycle event.
        lifecycle = (UMMSubType.AGENT_REATTACHED
                     if flag == AttachConfFlag.PERM_REATT
                     else UMMSubType.AGENT_ATTACHED)
        await self._publish_lifecycle(lifecycle, from_attach)

    async def _svc_detach(self, msg: UMMMsg, from_attach: int) -> None:
        info = self._attaches.get(from_attach)
        if info:
            info.status |= EAS_DETACHED
            self._rdebug(int(DebugLevel.INFO),
                         f"Detach: id={from_attach} "
                         f"name={info.login.process_name if info.login else 'anon'}")
            # Publish lifecycle so supervisor (and any other listener) sees the
            # clean detach — without this, clean shutdowns are invisible.
            await self._publish_lifecycle(UMMSubType.AGENT_DETACHED, from_attach)
        await self._handle_disconnect(from_attach)

    async def _svc_register(self, msg: UMMMsg, from_attach: int) -> None:
        info = self._attaches.get(from_attach)
        if info is None:
            return
        logger.info("_svc_register: attach=%d reg=%d ch=%d",
                    from_attach, msg.reg_id, msg.channel)

        # Skip re-registrations on re-attach (we already have them)
        if info.status & EAS_REATTACH:
            logger.info("_svc_register: skipping re-attach reg attach=%d reg=%d",
                        from_attach, msg.reg_id)
            if msg.flags & RequestFlag.LAST_REQUEST:
                await self._flush_queue(from_attach)
            return

        if msg.reg_id <= 0 or msg.reg_id >= MAX_REGISTRATION:
            logger.info("_svc_register: invalid reg_id=%d attach=%d",
                        msg.reg_id, from_attach)
            await self._send_error(from_attach,
                f"Invalid reg_id {msg.reg_id}")
            return

        # Extract the UMMReg from TData.
        # TData contains a TLV_MSG whose value is:
        #   mtype(4,NBO) + subtype(4,NBO) + match_tlv_bytes
        # The subscription channel comes from the message header (msg.channel).
        sub_mtype   = 0
        sub_subtype = 0
        sub_channel = msg.channel   # ← header field, set by agent _async_register
        match_bytes = b''

        if msg.tdata.value:
            try:
                from .core.tlv import decode_all as _da
                for tlv in _da(msg.tdata.value):
                    if tlv.type_id == TLV_SUBSPEC and len(tlv.value) >= 8:
                        sub_mtype, sub_subtype = struct.unpack_from(
                            '!ii', tlv.value, 0)
                        match_bytes = tlv.value[8:]
                        break
            except Exception as exc:
                logger.warning("Could not parse registration TData: %s", exc)

        # Build a synthetic UMMMsg to store as the subscription record.
        # This carries the subscription mtype/subtype and match criteria.
        sub_msg = UMMMsg(
            version   = msg.version,
            attach_id = msg.attach_id,
            origin    = msg.origin,
            tm        = msg.tm,
            flags     = msg.flags,
            reg_id    = msg.reg_id,
            msg_id    = msg.msg_id,
            mtype     = sub_mtype,
            subtype   = sub_subtype,
            channel   = sub_channel,
            tdata     = TLV(type_id=TLV_MSG, value=match_bytes)
                        if match_bytes else TLV(type_id=TLV_TERM),
        )

        # Deduplicate: if this attach already has an identical subscription
        # (same channel, mtype, subtype, match bytes) return the existing reg_id.
        # Duplicate registrations cause double delivery and serve no purpose.
        for existing in info.reg_list.values():
            ex_msg = existing.msg
            ex_match = ex_msg.tdata.value if ex_msg.tdata.type_id == TLV_MSG else b''
            if (existing.channel == sub_channel and
                    ex_msg.mtype == sub_mtype and
                    ex_msg.subtype == sub_subtype and
                    ex_match == match_bytes):
                logger.info("_svc_register: duplicate ignored attach=%d "
                             "ch=%d mtype=%d subtype=%d → existing reg=%d",
                             from_attach, sub_channel, sub_mtype, sub_subtype,
                             existing.reg_id)
                if msg.flags & RequestFlag.LAST_REQUEST:
                    await self._flush_queue(from_attach)
                return

        entry = RegEntry(
            reg_id    = msg.reg_id,
            attach_id = from_attach,
            msg       = sub_msg,
            flags     = msg.flags,
            channel   = sub_channel,
        )
        self._lookup.add(entry)
        info.reg_list[msg.reg_id] = entry
        logger.info("Subscription stored: attach=%d reg=%d ch=%d mtype=%d subtype=%d",
                    from_attach, msg.reg_id, sub_channel, sub_mtype, sub_subtype)
        self._rdebug(int(DebugLevel.DEBUG),
                     f"Register: attach={from_attach} reg={msg.reg_id} "
                     f"ch={sub_channel} mtype={sub_mtype} subtype={sub_subtype}")

        # Notify plugin if this subscription has plugin-owned match TLVs
        if self._plugins and match_bytes:
            await self._notify_plugin_sub_add(msg.reg_id, entry)

        if msg.flags & RequestFlag.LAST_REQUEST:
            await self._flush_queue(from_attach)

    async def _svc_unregister(self, msg: UMMMsg, from_attach: int) -> None:
        removed = self._lookup.remove(from_attach, msg.reg_id)
        info = self._attaches.get(from_attach)
        if info and msg.reg_id in info.reg_list:
            del info.reg_list[msg.reg_id]
        if not removed:
            await self._send_error(from_attach,
                f"No registration {msg.reg_id} to remove")

    # ── delivery ──────────────────────────────────────────────────────────────

    async def _deliver(self, attach_id: int, msg: UMMMsg) -> None:
        """Send *msg* to the client identified by *attach_id*."""
        info = self._attaches.get(attach_id)
        if info is None:
            return

        wire = msg.encode()

        if info.is_online() and info.writer:
            try:
                info.writer.write(wire)
                await info.writer.drain()
                self._update_accounts(attach_id, msg.mtype, msg.subtype)
            except Exception as exc:
                logger.warning("Delivery to %d failed: %s", attach_id, exc)
                info.status |= EAS_OFFLINE
                if info.is_permanent():
                    info.queue.append(wire)
        elif info.is_permanent() and (info.status & EAS_OFFLINE):
            info.queue.append(wire)
            logger.debug("Queued msg for offline permanent client %d", attach_id)

    async def _flush_queue(self, attach_id: int) -> None:
        """Send any queued messages to a re-attaching permanent client."""
        info = self._attaches.get(attach_id)
        if info is None or not info.queue:
            # Nothing to flush — still clear status flags so normal operation
            # resumes even when the queue was empty.
            if info is not None:
                info.status &= ~(EAS_OFFLINE | EAS_REATTACH)
            return
        logger.info("Flushing %d queued messages to client %d",
                    len(info.queue), attach_id)
        for wire in info.queue:
            if info.writer:
                try:
                    info.writer.write(wire)
                    await info.writer.drain()
                except Exception:
                    logger.warning("Queue flush to %d failed mid-way; "
                                   "remaining messages re-queued", attach_id)
                    # Re-queue undelivered tail so nothing is lost
                    delivered_up_to = info.queue.index(wire)
                    info.queue = info.queue[delivered_up_to:]
                    info.status |= EAS_OFFLINE
                    return
        info.queue.clear()
        info.status &= ~(EAS_OFFLINE | EAS_REATTACH)

    # ── router-originated messages ────────────────────────────────────────────

    async def _send_init(self, attach_id: int) -> None:
        """Send MTUMMInit so the client learns its attach ID."""
        buf = TLVBuffer()
        # Pack attach ID as a raw 8-byte TLV
        buf.add(TLV(type_id=12,   # TLV_ATTID
                    value=struct.pack("!II", self.router_id, attach_id)))
        msg = self._make_router_msg(attach_id, UMMSubType.INIT, buf)
        info = self._attaches.get(attach_id)
        if info and info.writer:
            info.writer.write(msg.encode())
            await info.writer.drain()

    async def _send_attach_confirm(self, attach_id: int,
                                    flag: AttachConfFlag) -> None:
        buf = TLVBuffer()
        buf.add(TLV(type_id=12,
                    value=struct.pack("!II", self.router_id, attach_id)))
        buf.add(TLV(type_id=TLV_INT,
                    value=struct.pack("!i", int(flag))))
        msg = self._make_router_msg(attach_id, UMMSubType.ATTACH_CONFIRM, buf)
        msg.flags = int(flag)
        await self._deliver(attach_id, msg)

    async def _send_error(self, attach_id: int, text: str) -> None:
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING,
                    value=text.encode('utf-8') + b'\x00'))
        msg = self._make_router_msg(attach_id, UMMSubType.SYS_ERROR, buf)
        await self._deliver(attach_id, msg)
        logger.warning("Sent error to %d: %s", attach_id, text)

    async def _send_info(self, attach_id: int, text: str) -> None:
        buf = TLVBuffer()
        buf.add(TLV(type_id=TLV_STRING,
                    value=text.encode('utf-8') + b'\x00'))
        msg = self._make_router_msg(attach_id, UMMSubType.SYS_INFO, buf)
        await self._deliver(attach_id, msg)

    # ── match plugin ──────────────────────────────────────────────────────────

    async def _handle_plugin_client(self,
                                     reader: asyncio.StreamReader,
                                     writer: asyncio.StreamWriter) -> None:
        """Handle an incoming plugin connection on the plugin port."""
        addr = writer.get_extra_info('peername')
        logger.info("Plugin client connected from %s", addr)

        # First message must be a register
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=10.0)
        except asyncio.TimeoutError:
            logger.warning("Plugin did not send register within 10s – closing")
            writer.close()
            return

        try:
            reg_msg = json.loads(line)
        except json.JSONDecodeError:
            logger.warning("Plugin sent invalid JSON on connect – closing")
            writer.close()
            return

        if reg_msg.get('msg') != 'register':
            logger.warning("Plugin first message was not 'register' – closing")
            writer.close()
            return

        type_ids: List[int] = reg_msg.get('type_ids', [])
        name: str           = reg_msg.get('name', 'unknown')
        conn = _PluginConn(name, type_ids, writer)

        # Register type IDs (last writer wins if conflict)
        for tid in type_ids:
            if tid in self._plugins:
                logger.warning("type_id %d already owned by plugin '%s' – overriding",
                               tid, self._plugins[tid].name)
            self._plugins[tid] = conn
        logger.info("Match plugin '%s' registered for type IDs %s", name, type_ids)

        # Replay all existing subscriptions that use this plugin's types
        # (agents may have registered before the plugin connected)
        plugin_set = set(type_ids)
        for attach_info in self._attaches.values():
            for reg_id, entry in attach_info.reg_list.items():
                if self._entry_uses_plugin(entry, plugin_set):
                    await conn.send({
                        'msg':      'sub_add',
                        'reg_id':   reg_id,
                        'sub_tlvs': (entry.msg.tdata.value.hex()
                                     if entry.msg.tdata.value else ''),
                    })

        # Read responses from plugin
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                try:
                    resp = json.loads(line)
                    await self._on_plugin_message(resp)
                except json.JSONDecodeError as exc:
                    logger.warning("Bad JSON from plugin '%s': %s", name, exc)
        except (asyncio.IncompleteReadError, ConnectionResetError):
            pass
        except Exception as exc:
            logger.exception("Error reading from plugin '%s': %s", name, exc)
        finally:
            for tid in list(self._plugins.keys()):
                if self._plugins[tid] is conn:
                    del self._plugins[tid]
            conn.close()
            logger.info("Match plugin '%s' disconnected – falling back to internal match",
                        name)

    @staticmethod
    def _entry_uses_plugin(entry: 'RegEntry', plugin_type_ids: Set[int]) -> bool:
        """Return True if *entry*'s match criteria contain any plugin-owned TLV type."""
        tdata = entry.msg.tdata
        if tdata.type_id == TLV_TERM or not tdata.value:
            return False
        try:
            for tlv in decode_all(tdata.value):
                if tlv.type_id in plugin_type_ids:
                    return True
        except Exception:
            pass
        return False

    async def _notify_plugin_sub_add(self, reg_id: int,
                                      entry: 'RegEntry') -> None:
        """Tell the appropriate plugin(s) about a new subscription."""
        tdata = entry.msg.tdata
        if tdata.type_id == TLV_TERM or not tdata.value:
            return
        # Find which plugins care about this entry's TLV types
        seen: set = set()
        try:
            for tlv in decode_all(tdata.value):
                plugin = self._plugins.get(tlv.type_id)
                if plugin and id(plugin) not in seen:
                    seen.add(id(plugin))
                    await plugin.send({
                        'msg':      'sub_add',
                        'reg_id':   reg_id,
                        'sub_tlvs': tdata.value.hex(),
                    })
        except Exception as exc:
            logger.warning("Error notifying plugin of sub_add: %s", exc)

    async def _notify_plugin_sub_remove(self, reg_ids: List[int]) -> None:
        """Tell all plugins to discard the given subscription reg_ids."""
        # Broadcast to all distinct plugin connections
        seen: set = set()
        for conn in self._plugins.values():
            if id(conn) not in seen:
                seen.add(id(conn))
                try:
                    await conn.send({'msg': 'sub_remove', 'reg_ids': reg_ids})
                except Exception as exc:
                    logger.warning("Error notifying plugin of sub_remove: %s", exc)

    # ── bridge subscription notification ──────────────────────────────────────

    async def _dispatch_plugin_match(self,
                                      msg: UMMMsg,
                                      from_attach: int,
                                      plugin_entries: List['RegEntry'],
                                      sync_delivered: int,
                                      needs_confirm: bool) -> None:
        """Send a match_req to the plugin(s) and store the pending delivery."""
        req_id = self._plugin_req_counter
        self._plugin_req_counter += 1

        # Store a snapshot (msg is mutated by delivery stamping)
        self._plugin_reqs[req_id] = _PendingPluginReq(
            msg            = copy.copy(msg),
            from_attach    = from_attach,
            entries        = plugin_entries,
            sync_delivered = sync_delivered,
            needs_confirm  = needs_confirm,
        )

        msg_tlvs_hex = msg.tdata.value.hex() if msg.tdata.value else ''

        # Group entries by their plugin connection (usually just one)
        by_plugin: Dict[int, Tuple[_PluginConn, List[int]]] = {}
        for entry in plugin_entries:
            # Find the plugin that handles the first plugin-owned TLV
            tdata = entry.msg.tdata
            if tdata.value:
                try:
                    for tlv in decode_all(tdata.value):
                        plugin = self._plugins.get(tlv.type_id)
                        if plugin:
                            pid = id(plugin)
                            if pid not in by_plugin:
                                by_plugin[pid] = (plugin, [])
                            by_plugin[pid][1].append(entry.reg_id)
                            break
                except Exception:
                    pass

        for plugin, reg_ids in by_plugin.values():
            try:
                await plugin.send({
                    'msg':      'match_req',
                    'req_id':   req_id,
                    'msg_tlvs': msg_tlvs_hex,
                    'reg_ids':  reg_ids,
                })
            except Exception as exc:
                logger.warning("Error sending match_req to plugin: %s", exc)
                # Fallback: treat all entries as no-match (don't deliver)

    async def _on_plugin_message(self, msg: dict) -> None:
        """Dispatch an incoming message from a plugin."""
        kind = msg.get('msg')
        if kind == 'match_resp':
            await self._on_plugin_match_resp(msg)
        else:
            logger.debug("Unknown plugin message type: %s", kind)

    async def _on_plugin_match_resp(self, msg: dict) -> None:
        """Deliver messages whose plugin match returned True."""
        req_id  = msg.get('req_id')
        results = msg.get('results', [])

        pending = self._plugin_reqs.pop(req_id, None)
        if pending is None:
            logger.debug("match_resp for unknown req_id=%s – ignoring", req_id)
            return

        matched_ids: Set[int] = {r[0] for r in results if r[1]}

        if pending.dry_run:
            # MATCH_QUERY: send a second MATCH_RESULT with the plugin results
            def _entry_to_dict(entry: RegEntry) -> dict:
                info = self._attaches.get(entry.attach_id)
                name = (info.login.process_name
                        if info and info.login else f"agent{entry.attach_id}")
                return {
                    "attach_id":   entry.attach_id,
                    "reg_id":      entry.reg_id,
                    "agent_name":  name,
                    "agent_mtype": info.agent_mtype if info else 0,
                }
            plugin_matches = [
                _entry_to_dict(e) for e in pending.entries
                if e.reg_id in matched_ids and not (
                    e.attach_id == pending.from_attach and
                    e.flags & RequestFlag.DONT_SEND_SELF)
            ]
            await self._send_match_result(
                from_attach    = pending.from_attach,
                req_msg_id     = pending.dry_run_req_msg_id,
                q_mtype        = pending.dry_run_q_mtype,
                q_subtype      = pending.dry_run_q_subtype,
                matches        = plugin_matches,
                plugin_pending = False,
            )
            return

        omsg      = pending.msg
        delivered = pending.sync_delivered

        for entry in pending.entries:
            if entry.reg_id not in matched_ids:
                continue
            if (entry.attach_id == pending.from_attach and
                    entry.flags & RequestFlag.DONT_SEND_SELF):
                continue
            omsg.reg_id    = entry.reg_id
            omsg.attach_id = AttachId(router=self.router_id, id=entry.attach_id)
            await self._deliver(entry.attach_id, omsg)
            delivered += 1

        if pending.needs_confirm and pending.from_attach != 0:
            await self._send_confirm(omsg, delivered)

    async def _send_confirm(self, msg: UMMMsg, receiver_count: int) -> None:
        """
        Send confirmation messages on MType.CONFIRM (-1) based on MsgFlag bits.

        CONFIRM_RTR (0x02) → (-1, ConfirmSubType.ROUTER_CONFIRM)
            Int(source_mtype)  MsgRef(msg_id)  Int(receiver_count)
            Sent to the originating agent after routing is complete.

        CONFIRM_RCV (0x04) → (-1, ConfirmSubType.RECEIVER_ACK)
            Int(source_mtype)  MsgRef(msg_id)
            Sent by each receiving agent to the originator.
            Currently sent by the router on behalf of receivers (simplified).

        CONFIRM_APP (0x08) is declared but not auto-sent — it requires
            explicit application-level acknowledgement (Stage 4+).
        """
        import struct as _struct
        from .core.messages import ConfirmSubType as _CST

        origin_attach = msg.origin.id

        def _confirm_buf(source_mtype: int, include_count: bool,
                         count: int = 0) -> TLVBuffer:
            buf = TLVBuffer()
            buf.add(TLV(type_id=TLV_INT,
                        value=_struct.pack('!i', source_mtype)))
            buf.add(TLV(type_id=TLV_MSGREF,
                        value=_struct.pack('!III',
                                           msg.origin.router,
                                           msg.origin.id,
                                           msg.msg_id)))
            if include_count:
                buf.add(TLV(type_id=TLV_INT,
                            value=_struct.pack('!i', count)))
            return buf

        def _stamp_reg_id(resp: UMMMsg) -> None:
            # Direct-delivered confirms bypass normal routing, but the agent
            # dispatches incoming messages by reg_id — a confirm delivered
            # with reg_id=0 is silently dropped on the client.  Match the
            # confirm against the ORIGIN's own registrations (including any
            # content-match criteria, e.g. send_confirmed's Int==source_mtype)
            # and stamp the matching reg_id, preserving the invariant that
            # reg_id > 0 ⇔ the router matched a subscription.
            resp.reg_id = 0
            for entry in self._lookup.find_matches(resp):
                if entry.attach_id == origin_attach:
                    resp.reg_id = entry.reg_id
                    break

        if msg.flags & MsgFlag.CONFIRM_RTR:
            buf = _confirm_buf(msg.mtype, True, receiver_count)
            resp = self._make_router_msg(0, int(_CST.ROUTER_CONFIRM), buf,
                                         channel=int(Channel.CONFIRM))
            resp.mtype = MType.CONFIRM
            resp.attach_id = AttachId(router=self.router_id, id=origin_attach)
            _stamp_reg_id(resp)
            await self._deliver(origin_attach, resp)

        if msg.flags & MsgFlag.CONFIRM_RCV:
            # Router sends a ReceiverAck on behalf of each receiver.
            # True application-level acks (CONFIRM_APP) require explicit
            # agent support and are not auto-generated here.
            buf = _confirm_buf(msg.mtype, False)
            resp = self._make_router_msg(0, int(_CST.RECEIVER_ACK), buf,
                                         channel=int(Channel.CONFIRM))
            resp.mtype = MType.CONFIRM
            resp.attach_id = AttachId(router=self.router_id, id=origin_attach)
            _stamp_reg_id(resp)
            await self._deliver(origin_attach, resp)



    # ── router debug publishing ───────────────────────────────────────────────

    async def _svc_set_debug(self, msg: UMMMsg) -> None:
        """
        Handle SetDebug (UMM, ReservedSubType.SET_DEBUG=3).
        Parses Bool TLV and enables/disables router debug publishing.
        """
        enable = None
        if msg.tdata.value:
            try:
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == TLV_BOOL:
                        handler = self._registry.get_by_id(TLV_BOOL)
                        if handler:
                            enable = handler.unpack(tlv.value)
                        break
            except Exception:
                pass

        if enable is None:
            return

        self._debug_enabled = enable
        state = "enabled" if enable else "disabled"
        logger.info("Router debug publishing %s", state)
        await self._publish_router_debug(
            int(DebugLevel.INFO),
            f"Router debug {state}",
        )

    async def _svc_set_log_level(self, msg: UMMMsg) -> None:
        """
        Handle SetLogLevel (UMM, ReservedSubType.SET_LOG_LEVEL=5).
        Parses Int(DebugLevel 0-3) and sets the router's logging verbosity
        (file sink) and bus-output threshold, so the level applies to both.
        """
        level = None
        if msg.tdata.value:
            try:
                int_handler = self._registry.get_by_id(TLV_INT)
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == TLV_INT and int_handler:
                        level = int_handler.unpack(tlv.value)
                        break
            except Exception:
                pass
        if level is None:
            return
        level = max(0, min(3, int(level)))
        from .logsetup import set_log_level
        set_log_level(level)
        self._debug_min_level = level
        logger.warning("Router log level set to %d (DebugLevel) via message", level)

    async def _publish_router_debug(self, level: int, text: str) -> None:
        """
        Publish a debug message on channel=DEBUG.

        Envelope matches DebugMixin:
            Int(source_mtype=1)   Int(level)   Char(text)
        """
        if not self._debug_enabled and level > int(DebugLevel.INFO):
            return
        if int(level) < self._debug_min_level:
            return   # below the configured verbosity
        # Always publish the enable/disable announcement; otherwise gate on flag
        try:
            text_bytes = text.encode('utf-8') + b'\x00'
            buf = TLVBuffer()
            buf.add(TLV(type_id=TLV_INT,
                        value=struct.pack('!i', int(MType.UMM))))   # source mtype
            buf.add(TLV(type_id=TLV_INT,
                        value=struct.pack('!i', level)))             # level
            buf.add(TLV(type_id=TLV_STRING, value=text_bytes))      # text

            msg = self._make_router_msg(0, 1, buf,
                                        channel=int(Channel.DEBUG))
            await self._process_msg(msg, 0)
        except Exception as exc:
            logger.debug("Router debug publish failed: %s", exc)

    def _rdebug(self, level: int, text: str) -> None:
        """
        Fire-and-forget router debug helper — schedules _publish_router_debug
        on the running event loop. Safe to call from sync context.
        """
        if not self._debug_enabled:
            return
        try:
            loop = asyncio.get_event_loop()
            loop.create_task(self._publish_router_debug(level, text))
        except Exception:
            pass

    def _make_router_msg(self, attach_id: int, subtype: int,
                          buf: Optional[TLVBuffer] = None,
                          channel: int = 1) -> UMMMsg:
        payload = buf.encode() if buf else b''
        return UMMMsg(
            version   = VersionId(),
            attach_id = AttachId(router=self.router_id, id=attach_id),
            origin    = AttachId(router=self.router_id, id=0),
            tm        = UTime.now(),
            flags     = 0,
            reg_id    = 0,
            msg_id    = self._next_msg_id(),
            mtype     = MType.UMM,
            subtype   = subtype,
            channel   = channel,
            tdata     = TLV(type_id=TLV_MSG, value=payload) if payload
                        else TLV(type_id=TLV_TERM),
        )

    # ── attach table management ───────────────────────────────────────────────

    def _alloc_attach(self, writer: asyncio.StreamWriter) -> int:
        # Reuse a free slot if available
        for i in range(1, self._next_attach):
            info = self._attaches.get(i)
            if info and info.status == EAS_UNUSED:
                info.status = EAS_INUSE
                info.writer = writer
                return i
        # Allocate new slot
        attach_id = self._next_attach
        self._next_attach += 1
        self._attaches[attach_id] = AttachInfo(
            attach_id = attach_id,
            status    = EAS_INUSE,
            writer    = writer,
        )
        return attach_id

    async def _publish_lifecycle(self, subtype: int,
                                  attach_id: int) -> None:
        """
        Publish an agent lifecycle notification on mtype=UMM.

        subtype=AGENT_ATTACHED  — agent joined
        subtype=AGENT_DETACHED  — agent left

        TLVs:
          TLVAttId    attach_id
          TLVInt      agent_mtype (0 if unknown)
          TLVLogId    process_name (if known)
        """
        info = self._attaches.get(attach_id)
        if info is None:
            return

        buf = TLVBuffer()
        # Attach ID of the agent
        buf.add(TLV(type_id=12,
                    value=struct.pack("!II", self.router_id, attach_id)))
        # Primary mtype
        buf.add(TLV(type_id=TLV_INT,
                    value=struct.pack("!i", getattr(info, 'agent_mtype', 0))))
        # Process name
        if info.login and info.login.process_name:
            name_bytes = info.login.process_name.encode() + b'\x00'
            buf.add(TLV(type_id=TLV_STRING, value=name_bytes))

        # Send to all subscribers of (mtype=UMM, subtype=lifecycle_subtype)
        # We broadcast by creating a synthetic message and routing it
        notify_msg = self._make_router_msg(0, subtype, buf)
        notify_msg.mtype = MType.UMM

        matches = self._lookup.find_matches(notify_msg)
        for entry in matches:
            if entry.attach_id == attach_id:
                continue   # don't notify the agent about itself
            notify_msg.reg_id    = entry.reg_id
            notify_msg.attach_id = AttachId(router=self.router_id,
                                            id=entry.attach_id)
            await self._deliver(entry.attach_id, notify_msg)

        logger.debug("Lifecycle %s: attach=%d mtype=%d name=%s",
                     subtype.name if hasattr(subtype, 'name') else subtype,
                     attach_id,
                     getattr(info, 'agent_mtype', 0),
                     info.login.process_name if info.login else 'anon')

    async def _handle_disconnect(self, attach_id: int) -> None:
        info = self._attaches.get(attach_id)
        if info is None:
            return

        if info.is_permanent():
            # Keep subscriptions, mark offline
            info.status |= EAS_OFFLINE
            info.status &= ~EAS_RUNNING
            logger.info("Permanent client %d went offline – subscriptions retained",
                        attach_id)
        else:
            # Synthesise (UMM, UNREGISTER) for each subscription so that any
            # agent watching the bus (e.g. the bridge) sees the same events it
            # would see if the agent had unregistered cleanly before detaching.
            if info.reg_list:
                if self._plugins:
                    asyncio.ensure_future(
                        self._notify_plugin_sub_remove(list(info.reg_list.keys())))
                for reg_id, entry in list(info.reg_list.items()):
                    unregister_msg = UMMMsg(
                        version   = VersionId(),
                        attach_id = AttachId(router=self.router_id, id=attach_id),
                        origin    = AttachId(router=self.router_id, id=attach_id),
                        tm        = UTime.now(),
                        flags     = 0,
                        reg_id    = reg_id,
                        msg_id    = self._next_msg_id(),
                        mtype     = MType.UMM,
                        subtype   = UMMSubType.UNREGISTER,
                        channel   = 1,
                        tdata     = TLV(type_id=TLV_TERM),
                    )
                    asyncio.ensure_future(self._process_msg(unregister_msg, attach_id))
            self._lookup.remove_all_for(attach_id)
            info.status = EAS_UNUSED
            info.reg_list.clear()
            logger.info("Client %d detached – subscriptions removed", attach_id)

    # ── accounts (microbilling hooks) ─────────────────────────────────────────

    def _update_accounts(self, attach_id: int, mtype: int, subtype: int) -> None:
        info = self._attaches.get(attach_id)
        if info is None:
            return
        for acc in info.accounts:
            if acc.mtype == mtype and acc.subtype == subtype:
                acc.count += 1
                info.status |= EAS_UNCLEARED_STATS
                return
        if len(info.accounts) < MAX_ACCOUNTS:
            info.accounts.append(AccountInfo(mtype=mtype, subtype=subtype, count=1))
            info.status |= EAS_UNCLEARED_STATS

    # ── helpers ───────────────────────────────────────────────────────────────

    def _next_msg_id(self) -> int:
        mid = self._msg_id
        self._msg_id += 1
        return mid

    # ── module registration (for embedded modules) ────────────────────────────

    def register_mtype_handler(self, mtype: int,
                                handler: Callable[[UMMMsg, int], None]) -> None:
        """
        Allow embedded modules (type directory, bridge, FSM …) to register
        a handler for a specific mtype.  When a message with that mtype
        arrives the handler is called INSTEAD OF normal pub/sub routing.
        """
        self._mtype_handlers[mtype] = handler
        logger.debug("mtype handler registered for mtype=%d", mtype)

    # ── status / introspection ────────────────────────────────────────────────

    def client_count(self) -> int:
        return sum(1 for i in self._attaches.values()
                   if i.status & EAS_INUSE)

    def subscription_count(self) -> int:
        count = 0
        for mtype_dict in self._lookup._table.values():
            for lst in mtype_dict.values():
                count += len(lst)
        return count


# ── CLI entry point ───────────────────────────────────────────────────────────

def _main() -> None:
    import argparse, sys, faulthandler

    # A hard crash (access violation, C-level stack overflow, fatal asyncio
    # error) can terminate the process without leaving a Python traceback in
    # the log.  faulthandler dumps a native traceback to stderr on such a
    # fault, so "nothing in the log" becomes something actionable.
    try:
        faulthandler.enable()
    except Exception:
        pass

    # On Windows the console / redirected log file defaults to the locale code
    # page (e.g. cp1252), which cannot encode the arrow/dash characters this
    # router writes in its log messages ("… → attach_id=N", "… – subscriptions
    # removed").  Without this, those log lines fail to encode and are dropped,
    # which is why a Windows crash can leave the log looking empty.  This
    # matches the guard already used in parser.py, server.py and umm_ctl.py.
    if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )

    parser = argparse.ArgumentParser(description='UMM Router')
    parser.add_argument('--version', action='store_true',
                        help='Show version and exit')
    parser.add_argument('--port',        type=int, default=DEFAULT_PORT)
    parser.add_argument('--host',        default='')
    parser.add_argument('--id',          default='1.1', dest='router_id',
                        help='Router ID as site.node (e.g. 1.3). Both numbers '
                             'are arbitrary integers chosen by site preference. '
                             'Read from UMM_ROUTER_ID env var if not given.')
    parser.add_argument('--name',        default='UMMRouter')
    parser.add_argument('--typedir',     action='append', default=[],
                        help='Extra type plugin directories (repeatable)')
    parser.add_argument('--plugin-port', type=int, default=0, dest='plugin_port',
                        help='Plugin port (default: agent port + 1; -1 to disable)')
    parser.add_argument('--debug',       action='store_true')
    args = parser.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    import os as _os

    # UMM_ROUTER env var → host and port (if not overridden by CLI)
    # The router itself reads this so it knows which interface to bind on
    # when host is not explicitly given.
    #
    # IMPORTANT: if UMM_ROUTER is set to localhost or 127.0.0.1 (which is
    # the typical setting for agents on the same machine), do NOT use that
    # as the bind address — it would prevent remote agents from connecting.
    # The router binds to '' (all interfaces) unless --host is given explicitly
    # or UMM_ROUTER names a specific non-loopback interface address.
    env_router = _os.environ.get('UMM_ROUTER', '').strip()
    host = args.host   # '' unless --host was passed on CLI
    port = args.port
    if env_router and not host:
        if ':' in env_router:
            env_host, _, env_port_str = env_router.rpartition(':')
            try:
                env_host = env_host.strip()
                port = int(env_port_str.strip())
                # Only adopt the host if it is a real network address,
                # not a loopback alias that would restrict the bind.
                if env_host not in ('localhost', '127.0.0.1', '::1'):
                    host = env_host
            except ValueError:
                pass
        else:
            env_host = env_router.strip()
            if env_host not in ('localhost', '127.0.0.1', '::1'):
                host = env_host

    # UMM_ROUTER_ID env var → router ID (if not overridden by CLI)
    router_id_str = args.router_id
    if router_id_str == '1.1':   # still at default — check env
        env_id = _os.environ.get('UMM_ROUTER_ID', '').strip()
        if env_id:
            router_id_str = env_id

    # Parse site.node or plain integer
    def _parse_router_id(s: str) -> int:
        """Parse 'site.node' → (site << 16 | node), or plain int."""
        s = s.strip()
        if '.' in s:
            parts = s.split('.', 1)
            try:
                site = int(parts[0]) & 0xFFFF
                node = int(parts[1]) & 0xFFFF
                return (site << 16) | node
            except ValueError:
                raise ValueError(
                    f"Router ID {s!r} must be site.node (e.g. 1.3) "
                    f"or a plain integer")
        try:
            return int(s)
        except ValueError:
            raise ValueError(
                f"Router ID {s!r} must be site.node (e.g. 1.3) "
                f"or a plain integer")

    try:
        router_id = _parse_router_id(router_id_str)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return

    router = UMMRouter(
        port        = port,
        host        = host,
        router_id   = router_id,
        name        = args.name,
        type_dirs   = args.typedir,
        plugin_port = args.plugin_port,
    )

    try:
        asyncio.run(router.serve())
    except KeyboardInterrupt:
        print("\nRouter stopped.")


if __name__ == '__main__':
    _main()