"""
umm.mixins
==========
Standard agent mixins implementing the reserved subtype convention.

See DESIGN_NOTES.md section 10 for the full protocol specification.

DebugMixin
----------
Adds runtime-controllable debug publishing to any agent.

- Replaces Python ``logging`` with UMM bus publishing on mtype=-2
- Handles ``SetDebug`` (reserved subtype 3): ``Bool(true)`` enables,
  ``Bool(false)`` disables
- ``--debug`` flag at startup is implemented as ``SetDebug(true)`` sent
  to self — one code path, two ways to trigger
- Publishes on ``(-2, 1)`` with envelope::

      Int(source_mtype)   — which agent
      Int(level)          — DebugLevel value (0=DEBUG 1=INFO 2=WARN 3=ERROR)
      Char(text)          — human-readable message

VersionMixin
------------
Responds to ``GetVersion`` (reserved subtype 2) on ``(-3, 2)``::

      Int(source_mtype)   MsgRef(msg_id)   Char(json_version)

The JSON version string carries four fields::

    {
        "system": "1.2",          # UMM framework version (UMM_VERSION)
        "group":  "1.0.0",        # application group version
        "agent":  "1.0.0",        # this agent's version
        "build":  "dev"           # build number or git hash
    }

Agents define class attributes ``GROUP_VERSION``, ``AGENT_VERSION``,
``BUILD`` — all default to ``"0.0.0"`` / ``"dev"`` if absent.

Usage
-----
Adding both mixins to an agent (three lines of change)::

    class TimerModule(CapabilityMixin, DebugMixin, VersionMixin):

        CAPABILITY     = TIMER_CAPABILITY
        AGENT_VERSION  = "1.0.0"
        GROUP_VERSION  = "1.0.0"
        BUILD          = "dev"

        def run(self) -> None:
            self._client.connect()
            self.register_capability_handler(self._client)
            self.register_debug_handler(self._client, MT_TIMER, debug=args.debug)
            self.register_version_handler(self._client, MT_TIMER)
            # replace all logger.xxx() calls with self.log_xxx()
            self.log_info("Timer running on %s:%d", host, port)
"""

from __future__ import annotations

import json
import struct
import threading
from typing import Optional

from .core.messages import (MType, ReservedSubType, DebugLevel,
                             ConfirmSubType, ConfirmError,
                             MetaSubType, UMM_VERSION, Channel)


# ── DebugMixin ────────────────────────────────────────────────────────────────

class DebugMixin:
    """
    Mixin that adds runtime-controllable debug publishing to an agent.

    Replaces Python logging with UMM bus publishing on mtype=-2 (DEBUG channel).
    All log_xxx() calls are no-ops when debug is disabled, so there is zero
    bus overhead in production if no one has called SetDebug(true).

    The mixin also mirrors output to Python's standard logging at the
    corresponding level, so console/file logging continues to work.
    """

    # ── class-level defaults, override in subclass if desired ─────────────────
    DEBUG_ENABLED: bool = False   # runtime state — do not set True here

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

    def _ensure_debug_logger(self):
        """Lazily initialise logger if register_debug_handler hasn't been called yet."""
        if not hasattr(self, '_debug_logger'):
            import logging as _logging
            self._debug_logger  = _logging.getLogger(type(self).__module__)
            self._debug_enabled = False
            self._debug_lock    = __import__('threading').Lock()
            self._debug_agent   = None
            self._debug_source_mtype = 0
            self._debug_min_level = 0   # bus gate: DebugLevel below this is dropped

    def register_debug_handler(self,
                               agent,
                               source_mtype: int,
                               debug: bool = False) -> None:
        """
        Register SetDebug handler and optionally enable debug at startup.

        Parameters
        ----------
        agent        : UMMAgent — must be connected before calling this
        source_mtype : int      — this agent's primary mtype (Int TLV in messages)
        debug        : bool     — if True, enable debug immediately (--debug flag)
        """
        import logging as _logging
        self._debug_agent        = agent
        self._debug_source_mtype = source_mtype
        self._debug_lock         = threading.Lock()
        self._debug_logger       = _logging.getLogger(
                                       type(self).__module__)
        self._debug_enabled      = False
        self._debug_min_level    = 0   # bus gate: DebugLevel below this is dropped

        from .core.registry import registry
        from .types._base import MatchOp

        bool_type = registry.get_by_name('Bool')
        int_type  = registry.get_by_id(2)

        def on_set_debug(msg) -> None:
            """Handle SetDebug (reserved subtype 3)."""
            # Parse Bool TLV
            enable = None
            if msg.tdata.value:
                try:
                    from .core.tlv import decode_all as _da, TLV_BOOL
                    from .core.registry import registry as _reg
                    bool_handler = _reg.get_by_id(TLV_BOOL)
                    for tlv in _da(msg.tdata.value):
                        if tlv.type_id == TLV_BOOL and bool_handler:
                            enable = bool_handler.unpack(tlv.value)
                            break
                except Exception:
                    pass

            if enable is None:
                # Malformed — send error on (-1, 1)
                self._send_confirm_error(
                    msg_id      = getattr(msg, 'msg_id', 0),
                    error_code  = int(ConfirmError.MISSING_TLV),
                    description = "SetDebug requires Bool TLV",
                )
                return

            with self._debug_lock:
                self._debug_enabled = enable

            state = "enabled" if enable else "disabled"
            self._debug_logger.info("Debug %s for mtype=%d via message",
                                    state, source_mtype)
            # Publish the state change on the debug channel if now enabled,
            # or as a final INFO before going silent if now disabled
            self._publish_debug(
                DebugLevel.INFO,
                f"Debug {state} for mtype={source_mtype}",
            )

        # Subscribe to SetDebug on our own mtype
        agent.register(
            mtype          = source_mtype,
            subtype        = int(ReservedSubType.SET_DEBUG),
            callback       = on_set_debug,
            dont_send_self = False,
        )

        def on_set_log_level(msg) -> None:
            """Handle SetLogLevel (reserved subtype 5): Int(DebugLevel 0-3).

            Raises/lowers this process's logging verbosity (the file sink) and
            the bus-output threshold, so the level applies to both sinks.
            """
            level = None
            if msg.tdata.value:
                try:
                    from .core.tlv import decode_all as _da
                    for tlv in _da(msg.tdata.value):
                        if tlv.type_id == 2 and int_type:   # Int
                            level = int_type.unpack(tlv.value)
                            break
                except Exception:
                    pass
            if level is None:
                self._send_confirm_error(
                    msg_id      = getattr(msg, 'msg_id', 0),
                    error_code  = int(ConfirmError.MISSING_TLV),
                    description = "SetLogLevel requires Int(level 0-3) TLV",
                )
                return
            level = max(0, min(3, int(level)))
            from .logsetup import set_log_level, logging_level_for
            set_log_level(level)
            with self._debug_lock:
                self._debug_min_level = level
            self._debug_logger.warning(
                "Log level set to %d (DebugLevel) for mtype=%d via message",
                level, source_mtype)

        # Subscribe to SetLogLevel on our own mtype
        agent.register(
            mtype          = source_mtype,
            subtype        = int(ReservedSubType.SET_LOG_LEVEL),
            callback       = on_set_log_level,
            dont_send_self = False,
        )

        # Enable immediately if --debug flag was passed
        if debug:
            with self._debug_lock:
                self._debug_enabled = True
            self._debug_logger.info("Debug enabled at startup for mtype=%d",
                                    source_mtype)

    # ── logging API ───────────────────────────────────────────────────────────

    def log_debug(self, fmt: str, *args) -> None:
        """Publish a DEBUG-level message (no-op on bus if debug disabled)."""
        self._ensure_debug_logger()
        with self._debug_lock:
            enabled = self._debug_enabled
        if not enabled:
            return
        msg = fmt % args if args else fmt
        self._debug_logger.debug(msg)
        self._publish_debug(DebugLevel.DEBUG, msg)

    def log_info(self, fmt: str, *args) -> None:
        """Log INFO — always to Python logging, bus only when debug enabled."""
        self._ensure_debug_logger()
        msg = fmt % args if args else fmt
        self._debug_logger.info(msg)
        with self._debug_lock:
            enabled = self._debug_enabled
        if enabled:
            self._publish_debug(DebugLevel.INFO, msg)

    def log_warn(self, fmt: str, *args) -> None:
        """Log WARN — always to Python logging, bus only when debug enabled."""
        self._ensure_debug_logger()
        msg = fmt % args if args else fmt
        self._debug_logger.warning(msg)
        with self._debug_lock:
            enabled = self._debug_enabled
        if enabled:
            self._publish_debug(DebugLevel.WARN, msg)

    def log_error(self, fmt: str, *args) -> None:
        """Log ERROR — always to Python logging, bus only when debug enabled."""
        self._ensure_debug_logger()
        msg = fmt % args if args else fmt
        self._debug_logger.error(msg)
        with self._debug_lock:
            enabled = self._debug_enabled
        if enabled:
            self._publish_debug(DebugLevel.ERROR, msg)

    # ── internal ──────────────────────────────────────────────────────────────

    def _publish_debug(self, level: DebugLevel, text: str) -> None:
        """
        Publish a debug message on (-2, 1).

        Envelope: Int(source_mtype)  Int(level)  Char(text)

        No-ops silently if agent not yet connected or loop not available.
        """
        self._ensure_debug_logger()
        if int(level) < getattr(self, '_debug_min_level', 0):
            return   # below the configured verbosity — don't put it on the bus
        agent = self._debug_agent
        if agent is None:
            return

        loop = getattr(agent, '_loop', None)
        if loop is None:
            return

        from .core.tlv import TLV
        from .core.registry import registry

        int_type = registry.get_by_id(2)
        if int_type is None:
            return

        try:
            text_bytes = text.encode('utf-8') + b'\x00'
            tlvs = [
                int_type.make_tlv(self._debug_source_mtype),  # Int(source_mtype)
                int_type.make_tlv(int(level)),                 # Int(level)
                TLV(type_id=8, value=text_bytes),              # Char(text)
            ]

            async def _send():
                try:
                    await agent._async_send(
                        int(self._debug_source_mtype),       # issuing agent's own mtype
                        int(ReservedSubType.DEBUG_MSG),      # 13 — not a router-control subtype
                        tlvs,
                        0,
                        channel=int(Channel.DEBUG),
                    )
                except Exception:
                    pass  # never let debug publishing crash the agent

            loop.call_soon_threadsafe(lambda: loop.create_task(_send()))
        except Exception:
            pass

    def _send_confirm_error(self, msg_id: int,
                            error_code: int,
                            description: str) -> None:
        """Send an error response on (-1, 1)."""
        agent = getattr(self, '_debug_agent', None)
        if agent is None:
            return
        loop = getattr(agent, '_loop', None)
        if loop is None:
            return

        from .core.tlv import TLV
        from .core.registry import registry

        int_type  = registry.get_by_id(2)
        msgref_id = 16   # MsgRef TLV type_id

        if int_type is None:
            return

        try:
            # MsgRef TLV: router(4) + agent(4) + msg(4) — use zeros for correlation
            msgref_val  = struct.pack('!III', 0, 0, msg_id)
            desc_bytes  = description.encode('utf-8') + b'\x00'
            tlvs = [
                int_type.make_tlv(self._debug_source_mtype),   # Int(source_mtype)
                TLV(type_id=msgref_id, value=msgref_val),       # MsgRef(msg_id)
                int_type.make_tlv(error_code),                  # Int(error_code)
                TLV(type_id=8, value=desc_bytes),               # Char(description)
            ]

            async def _send():
                try:
                    await agent._async_send(
                        int(MType.CONFIRM),
                        int(ConfirmSubType.ERROR),
                        tlvs,
                        0,
                        channel=int(Channel.CONFIRM),
                    )
                except Exception:
                    pass

            loop.call_soon_threadsafe(lambda: loop.create_task(_send()))
        except Exception:
            pass


# ── VersionMixin ──────────────────────────────────────────────────────────────

class VersionMixin:
    """
    Mixin that handles GetVersion (reserved subtype 2) queries.

    Responds on (-3, 2) with a JSON version descriptor::

        {
            "system": "1.2",    # UMM framework version
            "group":  "1.0.0",  # application group version
            "agent":  "1.0.0",  # this agent's version
            "build":  "dev"     # build number or git hash
        }

    Define GROUP_VERSION, AGENT_VERSION, BUILD as class attributes.
    All default to "0.0.0" / "dev" if not defined.
    """

    GROUP_VERSION: str = "0.0.0"
    AGENT_VERSION: str = "0.0.0"
    BUILD:         str = "dev"

    def register_version_handler(self,
                                 agent,
                                 source_mtype: int) -> None:
        """
        Register GetVersion handler on *agent*.

        Parameters
        ----------
        agent        : UMMAgent — must be connected before calling this
        source_mtype : int      — this agent's primary mtype
        """
        self._version_agent        = agent
        self._version_source_mtype = source_mtype

        def on_get_version(msg) -> None:
            """Handle GetVersion (reserved subtype 2)."""
            msg_id = getattr(msg, 'msg_id', 0)
            self._send_version_response(msg_id)

        agent.register(
            mtype          = source_mtype,
            subtype        = int(ReservedSubType.GET_VERSION),
            callback       = on_get_version,
            dont_send_self = False,
        )

    def _send_version_response(self, msg_id: int) -> None:
        """Send version response on (-3, 2)."""
        agent = getattr(self, '_version_agent', None)
        if agent is None:
            return
        loop = getattr(agent, '_loop', None)
        if loop is None:
            return

        from .core.tlv import TLV
        from .core.registry import registry

        int_type  = registry.get_by_id(2)
        msgref_id = 16

        if int_type is None:
            return

        version_data = {
            "system": UMM_VERSION,
            "group":  getattr(self, 'GROUP_VERSION', "0.0.0"),
            "agent":  getattr(self, 'AGENT_VERSION', "0.0.0"),
            "build":  getattr(self, 'BUILD',          "dev"),
        }
        json_bytes  = json.dumps(version_data).encode('utf-8') + b'\x00'
        msgref_val  = struct.pack('!III', 0, 0, msg_id)

        try:
            tlvs = [
                int_type.make_tlv(self._version_source_mtype),  # Int(source_mtype)
                TLV(type_id=msgref_id, value=msgref_val),        # MsgRef(msg_id)
                TLV(type_id=8, value=json_bytes),                # Char(json)
            ]

            async def _send():
                try:
                    await agent._async_send(
                        int(MType.UMM),
                        int(MetaSubType.VERSION),
                        tlvs,
                        0,
                        channel=int(Channel.META),
                    )
                except Exception:
                    pass

            loop.call_soon_threadsafe(lambda: loop.create_task(_send()))
        except Exception:
            pass

# ── ShutdownMixin ─────────────────────────────────────────────────────────────

class ShutdownMixin:
    """
    Mixin that handles Shutdown (reserved subtype 4) messages.

    When the agent receives (own_mtype, 4) it calls ``_on_shutdown_request()``,
    which by default disconnects cleanly and calls ``sys.exit(0)``.

    Override ``_on_shutdown_request()`` in your subclass if you need to do
    cleanup (flush buffers, save state, etc.) before exiting::

        class MyAgent(ShutdownMixin, DebugMixin, VersionMixin, CapabilityMixin):
            def _on_shutdown_request(self):
                self.log_info("Shutting down — flushing buffers")
                self._flush()
                super()._on_shutdown_request()   # disconnects and exits

    The shutdown message carries no payload and sends no response.
    The supervisor/watchdog uses this subtype to stop managed agents
    gracefully without sending OS signals.
    """

    def register_shutdown_handler(self,
                                  agent,
                                  source_mtype: int) -> None:
        """
        Register Shutdown handler on *agent*.

        Parameters
        ----------
        agent        : UMMAgent — must be connected before calling this
        source_mtype : int      — this agent's primary mtype
        """
        self._shutdown_agent = agent

        def on_shutdown(msg) -> None:
            """Handle Shutdown (reserved subtype 4)."""
            import logging as _log
            _log.getLogger(__name__).info(
                "Shutdown requested via message for mtype=%d", source_mtype)
            self._on_shutdown_request()

        agent.register(
            mtype          = source_mtype,
            subtype        = int(ReservedSubType.SHUTDOWN),
            callback       = on_shutdown,
            dont_send_self = False,
        )

    def _on_shutdown_request(self) -> None:
        """
        Default shutdown handler — disconnect and exit.

        Override this to perform cleanup before the exit.  Call
        ``super()._on_shutdown_request()`` at the end of your override.
        """
        agent = getattr(self, '_shutdown_agent', None)
        if agent is not None:
            try:
                agent.disconnect()
            except Exception:
                pass
        # Do NOT call sys.exit() here — disconnect() stops the event loop
        # which unblocks agent.run() in the main thread, causing a clean exit.
        # Calling sys.exit() from inside an asyncio callback raises SystemExit
        # through the event loop internals, producing spurious tracebacks on
        # Python 3.12+.


# ── HeartbeatMixin ────────────────────────────────────────────────────────────

class HeartbeatMixin:
    """
    Mixin that responds to supervisor heartbeat pings on mtype=-4.

    The supervisor sends ``(-4, HB_PING=1)`` with ``Int(seq)``.
    This mixin subscribes to that message and responds with
    ``(-4, HB_PONG=2)`` with the same ``Int(seq)``, identifying
    the agent via its ``attach_id`` in the message header.

    Usage::

        class MyAgent(HeartbeatMixin, ShutdownMixin, DebugMixin, VersionMixin):
            ...
            def setup(self, agent, source_mtype):
                self.register_heartbeat_handler(agent, source_mtype)

    The heartbeat channel is ``mtype=-4`` (``MType.HEARTBEAT``), keeping
    liveness traffic completely off the application bus.  Agents that do
    not call ``register_heartbeat_handler`` simply never participate.
    """

    def register_heartbeat_handler(self, agent, source_mtype: int) -> None:
        """
        Subscribe to heartbeat pings and register the pong responder.

        Parameters
        ----------
        agent        : UMMAgent — must be connected before calling this
        source_mtype : int      — this agent's primary mtype (used for logging)
        """
        import struct as _struct
        from .core.messages import MType as _MType, HeartbeatSubType as _HB, Channel as _CH
        from .core.tlv import TLV as _TLV, TLV_INT as _INT

        HB_PING = int(_HB.PING)   #  1
        HB_PONG = int(_HB.PONG)   #  2
        CH_HB   = int(_CH.HEARTBEAT)  # channel 4

        def on_ping(msg) -> None:
            """Echo the sequence number back as a pong."""
            seq = 0
            if msg.tdata.value:
                try:
                    from .core.tlv import decode_all as _da, TLV_INT as _I
                    for tlv in _da(msg.tdata.value):
                        if tlv.type_id == _I and len(tlv.value) == 4:
                            seq = _struct.unpack('!i', tlv.value)[0]
                            break
                except Exception:
                    pass
            try:
                agent.send(int(_MType.UMM), HB_PONG,
                           tlvs=[_TLV(type_id=_INT,
                                      value=_struct.pack('!i', seq))],
                           channel=CH_HB)
            except Exception as exc:
                import logging as _log
                _log.getLogger(__name__).warning(
                    "HeartbeatMixin: pong send failed for mtype=%d: %s",
                    source_mtype, exc)

        agent.register(
            mtype          = int(_MType.UMM),
            subtype        = HB_PING,
            callback       = on_ping,
            channel        = CH_HB,
            dont_send_self = False,
        )


# ── ResequenceMixin ───────────────────────────────────────────────────────────

class ResequenceMixin:
    """
    Optional mixin that briefly buffers incoming messages to correct out-of-order
    delivery caused by async plugin match results or inter-router bridges.

    Off by default and completely zero-overhead when not enabled.  Enable by
    calling ``enable_resequencing()`` after connecting::

        class MyAgent(ResequenceMixin, UMMAgent):
            ...

        agent = MyAgent(host='localhost', port=5100, agent_mtype=1002)
        agent.connect()
        agent.enable_resequencing(window=0.1)

    How it works
    ------------
    Every application message carries a ``(origin.router, origin.id, msg_id)``
    triple that uniquely identifies it across the system.  For each active
    subscription the mixin tracks the last ``msg_id`` dispatched from each
    source agent.  When a message arrives with a gap (i.e. the previous one
    hasn't landed yet), it is held in a small buffer.  If the missing message
    arrives within *window* seconds the buffer is flushed in order.  If it
    doesn't, the gap is logged, the buffer is flushed anyway, and the sequence
    counter advances.

    Applications that do not require ordering simply don't call
    ``enable_resequencing()`` — the default ``_dispatch_application`` path in
    ``UMMAgent`` is unchanged and dispatches every message immediately.

    Parameters
    ----------
    window : float
        Seconds to hold a gap open waiting for the missing message (default 0.1).
        Values under ~0.01 are unlikely to help; values over 1.0 risk stale
        data being delivered long after the event.
    """

    def enable_resequencing(self, window: float = 0.1) -> None:
        """Enable the hold buffer.  Safe to call after connect()."""
        import logging as _logging
        self._reseq_enabled: bool  = True
        self._reseq_window:  float = window
        # (reg_id, src_router, src_attach) → next expected msg_id (None = any)
        self._reseq_next:    dict  = {}
        # (reg_id, src_router, src_attach) → sorted list of (msg_id, msg, reg)
        self._reseq_buf:     dict  = {}
        # (reg_id, src_router, src_attach) → asyncio.TimerHandle or None
        self._reseq_timers:  dict  = {}
        self._reseq_logger = _logging.getLogger(__name__)

    # ── override of UMMAgent hook ─────────────────────────────────────────────

    def _dispatch_application(self, msg, reg) -> None:
        """Buffer and resequence before dispatching."""
        if not getattr(self, '_reseq_enabled', False):
            reg.callback(msg)
            return

        origin = msg.origin
        key    = (msg.reg_id, origin.router, origin.id)
        mid    = msg.msg_id

        expected = self._reseq_next.get(key)   # None means first message

        if expected is None or mid == expected:
            # In-sequence (or first message): dispatch and flush
            self._reseq_deliver(key, msg, reg)
            self._flush_from(key, mid + 1, reg)

        elif mid > expected:
            # Gap: buffer this message and start/reset the gap timer
            buf = self._reseq_buf.setdefault(key, [])
            # Insert in sorted order, skip duplicates
            for i, (existing_mid, _, _) in enumerate(buf):
                if existing_mid == mid:
                    return  # duplicate, drop
                if existing_mid > mid:
                    buf.insert(i, (mid, msg, reg))
                    break
            else:
                buf.append((mid, msg, reg))

            self._reseq_logger.debug(
                "reseq: gap at reg_id=%d src=(%d,%d) expected=%d got=%d — buffering",
                msg.reg_id, origin.router, origin.id, expected, mid)
            self._start_gap_timer(key, expected, reg)

        else:
            # mid < expected: old or duplicate message — drop silently
            self._reseq_logger.debug(
                "reseq: drop old/dup reg_id=%d src=(%d,%d) mid=%d (expected=%d)",
                msg.reg_id, origin.router, origin.id, mid, expected)

    # ── internal helpers ──────────────────────────────────────────────────────

    def _reseq_deliver(self, key: tuple, msg, reg) -> None:
        """Dispatch one message and advance the next-expected counter."""
        self._reseq_next[key] = msg.msg_id + 1
        try:
            reg.callback(msg)
        except Exception as exc:
            import logging as _l
            _l.getLogger(__name__).exception(
                "reseq callback error reg_id=%d: %s", msg.reg_id, exc)

    def _flush_from(self, key: tuple, from_mid: int, reg) -> None:
        """Dispatch any buffered messages that are now in sequence."""
        buf = self._reseq_buf.get(key)
        if not buf:
            return

        # Cancel gap timer if we caught up
        self._cancel_gap_timer(key)

        while buf and buf[0][0] == self._reseq_next.get(key, from_mid):
            _mid, bmsg, breg = buf.pop(0)
            self._reseq_deliver(key, bmsg, breg)

        # If buffer is now empty, cancel any remaining timer; if still has
        # entries, they represent a further gap — restart timer
        if not buf:
            self._reseq_buf.pop(key, None)
            self._cancel_gap_timer(key)
        else:
            next_expected = self._reseq_next.get(key)
            if next_expected is not None:
                self._start_gap_timer(key, next_expected, reg)

    def _start_gap_timer(self, key: tuple, missing_mid: int, reg) -> None:
        """(Re)start the gap-timeout timer for *key*."""
        self._cancel_gap_timer(key)
        loop = getattr(self, '_loop', None)
        if loop is None:
            return

        def _on_timeout():
            buf = self._reseq_buf.pop(key, [])
            if not buf:
                return
            self._reseq_logger.warning(
                "reseq: gap timeout for key=%s missing_mid=%d — delivering %d "
                "buffered message(s) out of order",
                key, missing_mid, len(buf))
            for (_mid, bmsg, breg) in buf:
                self._reseq_deliver(key, bmsg, breg)
            self._reseq_timers.pop(key, None)

        handle = loop.call_later(self._reseq_window, _on_timeout)
        self._reseq_timers[key] = handle

    def _cancel_gap_timer(self, key: tuple) -> None:
        handle = self._reseq_timers.pop(key, None)
        if handle is not None:
            handle.cancel()
