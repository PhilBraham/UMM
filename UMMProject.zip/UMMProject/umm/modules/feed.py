"""
umm.modules.feed
================
RSS/Atom feed agent — polls one or more internet feeds and publishes each new
item as a UMM message on ``mtype=MT_FEED_ITEM`` (15).

Why RSS/Atom?
-------------
RSS and Atom are the standard polling-based syndication formats used by news
sites, blogs, podcasts, government data feeds, and many APIs.  The ``feedparser``
library transparently handles RSS 0.9x, 1.0, 2.0, Atom 0.3, Atom 1.0, and a
long list of vendor extensions.

Alternatives (webhooks, scrapers) require either the source to push to you or
brittle HTML parsing.  For general internet feeds, polling RSS/Atom is the
right choice.

Message format
--------------
One ``(MT_FEED_ITEM, ST_ITEM)`` message is published per new feed item.
All fields are individually TLV-encoded so subscribers can match on any of them:

+----------+--------+--------------------------------------------------+
| Position | Type   | Content                                          |
+==========+========+==================================================+
| 0        | Char   | Feed source name  (from config, e.g. "bbc-world")|
| 1        | Char   | Item title                                       |
| 2        | Char   | Item URL (link)                                  |
| 3        | Char   | Author (empty string if not present)             |
| 4+       | Char   | Category/tag — one TLV per tag (may be absent)   |
| —        | UTime  | Published timestamp (Unix epoch float)           |
| —        | Json   | Full item as JSON (title/link/author/summary/...) |
+----------+--------+--------------------------------------------------+

The Char TLVs at positions 0–3 use sequential mword values (0, 1, 2, 3) so
the router's string-match plugin can filter by source name, title, URL, or
author.  Category TLVs start at mword=4 and increment (4, 5, 6, …) for
multiple categories.

Subscription examples::

    # All items from a specific source
    agent.register(mtype=MT_FEED_ITEM, subtype=ST_ITEM, callback=on_item,
                   match_tlvs=[CharType().make_subscription_tlv('bbc-world', MatchOp.EQ)])

    # Items whose title contains "earthquake" (string plugin required)
    agent.register(mtype=MT_FEED_ITEM, subtype=ST_ITEM, callback=on_item,
                   match_tlvs=[
                       BaseUMMType.make_ignore_tlv(),          # skip source
                       CharType().make_subscription_tlv('earthquake', MatchOp.CONTAINS),
                   ])

    # All items published after a given time
    agent.register(mtype=MT_FEED_ITEM, subtype=ST_ITEM, callback=on_item,
                   match_tlvs=[
                       BaseUMMType.make_ignore_tlv(),          # skip source
                       BaseUMMType.make_ignore_tlv(),          # skip title
                       BaseUMMType.make_ignore_tlv(),          # skip url
                       BaseUMMType.make_ignore_tlv(),          # skip author
                       UTimeType().make_subscription_tlv(since_ts, MatchOp.GT),
                   ])

Feed lifecycle messages (``mtype=MT_FEED``, ``mtype=MT_FEED_STATUS``):

    ST_FEED_ADDED   (101)  Char(source_name) Char(url) — source registered
    ST_FEED_REMOVED (102)  Char(source_name)            — source removed
    ST_FEED_ERROR   (103)  Char(source_name) Char(error_message) — fetch/parse failed
    ST_FEED_STATUS  (104)  Json({source_name, url, item_count, last_ok, last_error})

Feed sources are configured entirely via messages — the agent starts with no
sources and receives them at runtime.  ``feed.conf`` holds only connection
defaults (poll interval, dedupe window, user agent); it never lists URLs.

Feed sources are added via the startup script (``init.conf``) run by the
supervisor using ``send --file`` after all agents have started::

    # init.conf (relevant lines)
    wait 2
    14 201 Char "bbc-world" Char "https://feeds.bbci.co.uk/news/world/rss.xml"
    14 201 Char "hacker-news" Char "https://news.ycombinator.com/rss" Int 120
    14 201 Char "nasa" Char "https://www.nasa.gov/rss/dyn/breaking_news.rss" Int 600

The optional third TLV ``Int N`` overrides the default poll interval for that
source (seconds).  The same AddFeed / RemoveFeed messages work at runtime from
any agent or the send tool without restarting the feed agent.

``feed.conf`` (settings only — no URL sections)::

    [settings]
    poll_interval = 300          # default seconds between polls
    dedupe_window = 86400        # seconds to remember seen item IDs
    user_agent    = UMM-Feed/1.0 # HTTP User-Agent header

Run standalone::

    python -m umm.modules.feed --config feed.conf

Or embed::

    from umm.modules.feed import FeedModule
    feed = FeedModule(config_file='feed.conf', host='localhost')
    feed.run()

Requirements::

    pip install feedparser

"""

from __future__ import annotations

import configparser
import hashlib
import json
import logging
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Set

try:
    import feedparser                   # type: ignore
    _FEEDPARSER_OK = True
except ImportError:
    _FEEDPARSER_OK = False

from ..agent import UMMAgent, UMMConnectionError
from ..capability import CapabilityMixin, make_capability, SubtypeSpec
from ..core.messages import MType, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag
from ..core.tlv import (
    TLV, TLVBuffer,
    TLV_STRING, TLV_UTIME, TLV_JSON,
    MWORD_NONE,
)
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin

logger = logging.getLogger(__name__)

# ── mtype / subtype constants ─────────────────────────────────────────────────

MT_FEED      = 14    # Feed agent lifecycle messages (added/removed/error/status)
MT_FEED_ITEM = 15    # One message per new feed item

# Subtypes for MT_FEED (lifecycle)
ST_ITEM         = 101   # (MT_FEED_ITEM) New feed item arrived
ST_FEED_ADDED   = 101   # (MT_FEED) Feed source registered
ST_FEED_REMOVED = 102   # (MT_FEED) Feed source removed
ST_FEED_ERROR   = 103   # (MT_FEED) Fetch or parse failed — Char(source) Char(error)
ST_FEED_STATUS  = 104   # (MT_FEED) Status report        — Json({...})

# Subtypes sent TO the feed agent to control it at runtime
ST_ADD_FEED     = 201   # Char(name) Char(url) [UInt(poll_interval)]
ST_REMOVE_FEED  = 202   # Char(name)
ST_POLL_NOW     = 203   # Char(name) — force an immediate poll of one feed
ST_LIST_FEEDS   = 204   # — request status of all feeds; agent replies ST_FEED_STATUS × N

# TLV mword positions in a feed-item message
MW_SOURCE   = 0   # Char — feed source name
MW_TITLE    = 1   # Char — item title
MW_URL      = 2   # Char — item URL
MW_AUTHOR   = 3   # Char — item author (empty string if absent)
# MW 4+ are categories/tags (sequential integers per tag TLV)

# ── capability descriptor ─────────────────────────────────────────────────────

FEED_CAPABILITY = make_capability(
    what        = 'Feed',
    mtype       = MT_FEED,
    description = 'RSS/Atom feed agent — polls internet feeds and publishes items as UMM messages',
    version     = '1.0.0',
    subtypes    = [
        SubtypeSpec(
            subtype     = ST_ITEM,
            name        = 'Item',
            description = 'New feed item: Char(source) Char(title) Char(url) Char(author) '
                          '[Char(category)…] UTime(published) Json(full_item)',
            direction   = 'out',
        ),
        SubtypeSpec(
            subtype     = ST_FEED_ADDED,
            name        = 'FeedAdded',
            description = 'Feed source registered: Char(name) Char(url)',
            direction   = 'out',
        ),
        SubtypeSpec(
            subtype     = ST_FEED_REMOVED,
            name        = 'FeedRemoved',
            description = 'Feed source removed: Char(name)',
            direction   = 'out',
        ),
        SubtypeSpec(
            subtype     = ST_FEED_ERROR,
            name        = 'FeedError',
            description = 'Fetch/parse failed: Char(source) Char(error)',
            direction   = 'out',
        ),
        SubtypeSpec(
            subtype     = ST_FEED_STATUS,
            name        = 'FeedStatus',
            description = 'Per-source status report: Json({name,url,item_count,last_ok,last_error})',
            direction   = 'out',
        ),
        SubtypeSpec(
            subtype     = ST_ADD_FEED,
            name        = 'AddFeed',
            description = 'Add feed at runtime: Char(name) Char(url) [UInt(poll_interval_secs)]',
            direction   = 'in',
        ),
        SubtypeSpec(
            subtype     = ST_REMOVE_FEED,
            name        = 'RemoveFeed',
            description = 'Remove feed at runtime: Char(name)',
            direction   = 'in',
        ),
        SubtypeSpec(
            subtype     = ST_POLL_NOW,
            name        = 'PollNow',
            description = 'Force immediate poll of one feed: Char(name)',
            direction   = 'in',
        ),
        SubtypeSpec(
            subtype     = ST_LIST_FEEDS,
            name        = 'ListFeeds',
            description = 'Request status of all feeds — agent replies ST_FEED_STATUS × N',
            direction   = 'in',
        ),
    ],
)


# ── data classes ──────────────────────────────────────────────────────────────

@dataclass
class FeedSource:
    """One configured/registered feed."""
    name:          str
    url:           str
    poll_interval: int            = 300     # seconds
    # runtime state
    last_poll:     float          = 0.0     # Unix timestamp of last successful poll
    last_error:    str            = ''
    last_ok:       float          = 0.0     # Unix timestamp of last successful item publish
    item_count:    int            = 0       # total items published from this source
    etag:          Optional[str]  = None    # HTTP ETag for conditional GET
    modified:      Optional[str]  = None    # HTTP Last-Modified for conditional GET
    added_by_router: int = 0                # origin router of the agent that added it
    added_by_id:     int = 0                # origin id of the agent that added it
    _lock:         threading.Lock = field(default_factory=threading.Lock, repr=False)


@dataclass
class FeedConfig:
    poll_interval: int   = 300
    dedupe_window: int   = 86400
    user_agent:    str   = 'UMM-Feed/1.0'
    # Sources are NOT loaded from config — they arrive as AddFeed messages.
    # feed.conf holds only connection-level defaults.


# ── config loader ─────────────────────────────────────────────────────────────

def load_config(path: str) -> FeedConfig:
    cp = configparser.ConfigParser()
    cp.read(path)

    cfg = FeedConfig()

    if cp.has_section('settings'):
        s = cp['settings']
        cfg.poll_interval = int(s.get('poll_interval', cfg.poll_interval))
        cfg.dedupe_window = int(s.get('dedupe_window', cfg.dedupe_window))
        cfg.user_agent    = s.get('user_agent', cfg.user_agent)

    # Warn if someone left [feed.*] sections in the config — they are no longer used.
    stale = [s for s in cp.sections() if s.startswith('feed.')]
    if stale:
        logger.warning(
            "feed.conf has [feed.*] sections which are no longer used: %s  "
            "-- send AddFeed messages (ST_ADD_FEED=201) instead, e.g. via feed_init.conf",
            ', '.join(stale)
        )

    return cfg


# ── TLV encoding helpers ──────────────────────────────────────────────────────

def _char_tlv(text: str, mword: int) -> TLV:
    """Encode a null-terminated UTF-8 Char TLV with a specific mword."""
    raw = text.encode('utf-8', errors='replace') + b'\x00'
    return TLV(type_id=TLV_STRING, match=mword, value=raw)


def _json_tlv(obj: object) -> TLV:
    """Encode an object as a null-terminated JSON TLV."""
    raw = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8') + b'\x00'
    return TLV(type_id=TLV_JSON, match=MWORD_NONE, value=raw)


def _utime_tlv(ts: float) -> TLV:
    """Encode a Unix timestamp as a UTime TLV (secs:uint32 + ms:uint16, NBO)."""
    import struct
    secs = int(ts)
    ms   = int((ts - secs) * 1000)
    raw  = struct.pack('!IH', secs, ms)
    return TLV(type_id=TLV_UTIME, match=MWORD_NONE, value=raw)


# ── item ID deduplication ─────────────────────────────────────────────────────

class SeenItems:
    """Thread-safe bounded cache of item IDs seen recently."""

    def __init__(self, window_secs: int) -> None:
        self._window  = window_secs
        self._seen:   Dict[str, float] = {}   # id → first_seen_timestamp
        self._lock    = threading.Lock()

    def _item_id(self, entry: object, source_name: str) -> str:
        """
        Return a stable ID for a feed entry.  Prefer the entry's own id/guid;
        fall back to a hash of (source, title, link) so items without IDs are
        still deduplicated within a poll window.
        """
        raw_id = getattr(entry, 'id', None) or getattr(entry, 'guid', None)
        if raw_id:
            return f"{source_name}:{raw_id}"
        fingerprint = f"{source_name}|{getattr(entry,'title','')}|{getattr(entry,'link','')}"
        return hashlib.sha1(fingerprint.encode()).hexdigest()

    def is_new(self, entry: object, source_name: str) -> bool:
        """Return True if this entry has not been seen recently; mark it seen."""
        item_id = self._item_id(entry, source_name)
        now = time.time()
        with self._lock:
            self._expire(now)
            if item_id in self._seen:
                return False
            self._seen[item_id] = now
            return True

    def _expire(self, now: float) -> None:
        cutoff = now - self._window
        stale  = [k for k, v in self._seen.items() if v < cutoff]
        for k in stale:
            del self._seen[k]

    def clear_source(self, source_name: str) -> None:
        """Remove all cached IDs for a given source, so its items publish again."""
        prefix = f"{source_name}:"
        with self._lock:
            stale = [k for k in self._seen if k.startswith(prefix)]
            for k in stale:
                del self._seen[k]

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._seen)


# ── feed agent ────────────────────────────────────────────────────────────────

class FeedModule(CapabilityMixin, DebugMixin, VersionMixin, ShutdownMixin):
    """
    UMM Feed agent.

    Polls RSS/Atom feeds on configurable intervals and publishes each new item
    as a ``(MT_FEED_ITEM, ST_ITEM)`` message.
    """

    CAPABILITY    = FEED_CAPABILITY
    AGENT_VERSION = '1.0.0'
    GROUP_VERSION = '1.0.0'
    BUILD         = 'dev'

    def __init__(
        self,
        config_file:    str = 'feed.conf',
        host:           str = 'localhost',
        port:           int = DEFAULT_PORT,
        process_name:   str = 'Feed',
        debug:          bool = False,
    ) -> None:
        if not _FEEDPARSER_OK:
            raise ImportError(
                "The 'feedparser' package is required.\n"
                "Install it with:  pip install feedparser"
            )

        self._config_file  = config_file
        self._host         = host
        self._port         = port
        self._process_name = process_name
        self._debug_flag   = debug

        self._cfg = load_config(config_file)

        self._client = UMMAgent(
            host         = host,
            port         = port,
            process_name = process_name,
            agent_mtype  = MT_FEED,
            flags        = AttachFlag.NORMAL,
        )

        # Feed sources — name → FeedSource (populated entirely via AddFeed messages)
        self._sources:  Dict[str, FeedSource] = {}
        self._sources_lock = threading.Lock()

        self._seen     = SeenItems(self._cfg.dedupe_window)
        self._running  = False
        self._stop_evt = threading.Event()

        # Background polling thread
        self._poll_thread: Optional[threading.Thread] = None

    # ── public API ────────────────────────────────────────────────────────────

    def add_source(self, name: str, url: str, poll_interval: Optional[int] = None,
                   added_by: tuple = (0, 0)) -> None:
        """Add (or replace) a feed source."""
        interval = poll_interval if poll_interval is not None else self._cfg.poll_interval
        src = FeedSource(name=name, url=url, poll_interval=interval,
                         added_by_router=added_by[0], added_by_id=added_by[1])
        with self._sources_lock:
            self._sources[name] = src
        logger.info("Feed source added: %s  (%s)", name, url)
        self._publish_lifecycle(ST_FEED_ADDED, src)

    def remove_source(self, name: str, removed_by: tuple = (0, 0)) -> bool:
        """Remove a feed source.  Returns True if it existed.

        Removal across agents is allowed (consistent with the timer: anyone may
        cancel anyone's request), but a removal by an agent other than the one
        that added the source is logged as a warning and flagged on the
        FeedRemoved lifecycle message, to aid debugging when several agents or
        consoles are running at once.
        """
        with self._sources_lock:
            src = self._sources.pop(name, None)
        if not src:
            return False
        added_by = (src.added_by_router, src.added_by_id)
        cross_agent = (added_by != (0, 0) and removed_by != (0, 0)
                       and removed_by != added_by)
        extra = None
        if cross_agent:
            logger.warning(
                "Feed source '%s' removed by agent %d.%d but was added by "
                "agent %d.%d (cross-agent removal)",
                name, removed_by[0], removed_by[1], added_by[0], added_by[1])
            note = (f"removed by agent {removed_by[0]}.{removed_by[1]} "
                    f"(originally added by agent {added_by[0]}.{added_by[1]})")
            extra = [_char_tlv(note, 2)]
            from ..core.registry import registry as _reg
            from ..types.builtin import MsgRefType as _MsgRef
            bool_t = _reg.get_by_id(7)   # Bool
            if bool_t:
                extra.append(bool_t.make_tlv(True))
            extra.append(_MsgRef.make_tlv(added_by[0], added_by[1], 0))
        else:
            logger.info("Feed source removed: %s", name)
        self._publish_lifecycle(ST_FEED_REMOVED, src, extra_tlvs=extra)
        return True

    # ── run ───────────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Connect and run the polling loop."""
        if not self._client.connect():
            print(f"\n  ERROR: Feed agent could not connect to router at {self._host}:{self._port}")
            print("  Is the router running?")
            sys.exit(1)

        # Standard mixin handlers
        self.register_capability_handler(self._client)
        self.register_version_handler(self._client, MT_FEED)
        self.register_debug_handler(self._client, MT_FEED, debug=self._debug_flag)
        self.register_shutdown_handler(self._client, MT_FEED)

        # Runtime control handlers
        self._client.register(mtype=MT_FEED, subtype=ST_ADD_FEED,    callback=self._on_add_feed)
        self._client.register(mtype=MT_FEED, subtype=ST_REMOVE_FEED, callback=self._on_remove_feed)
        self._client.register(mtype=MT_FEED, subtype=ST_POLL_NOW,    callback=self._on_poll_now)
        self._client.register(mtype=MT_FEED, subtype=ST_LIST_FEEDS,  callback=self._on_list_feeds)

        # Start background polling thread
        self._running = True
        self._poll_thread = threading.Thread(
            target=self._poll_loop, daemon=True, name='umm-feed-poller'
        )
        self._poll_thread.start()

        logger.info(
            "Feed agent running -- default poll interval %ds, "
            "waiting for AddFeed messages (send via feed_init.conf or at runtime)",
            self._cfg.poll_interval
        )

        # Block in UMMAgent.run() — returns when disconnect/shutdown
        self._client.run()

        # Shutdown
        self._running = False
        self._stop_evt.set()
        if self._poll_thread:
            self._poll_thread.join(timeout=5)

    # ── polling loop ──────────────────────────────────────────────────────────

    def _poll_loop(self) -> None:
        """Background thread: poll each source on its own interval."""
        while self._running:
            now = time.time()
            with self._sources_lock:
                sources = list(self._sources.values())

            for src in sources:
                if not self._running:
                    break
                with src._lock:
                    due = src.last_poll + src.poll_interval <= now
                if due:
                    self._poll_source(src)

            # Sleep in small increments so we can respond quickly to stop
            self._stop_evt.wait(timeout=5)
            self._stop_evt.clear()

    def _poll_source(self, src: FeedSource) -> None:
        """Fetch and process one feed source."""
        with src._lock:
            etag     = src.etag
            modified = src.modified

        logger.debug("Polling %s  (%s)", src.name, src.url)

        try:
            kwargs: dict = {
                'agent': self._cfg.user_agent,
            }
            if etag:
                kwargs['etag'] = etag
            if modified:
                kwargs['modified'] = modified

            feed = feedparser.parse(src.url, **kwargs)

            with src._lock:
                src.last_poll = time.time()

            # 304 Not Modified — nothing new
            if getattr(feed, 'status', 0) == 304:
                logger.debug("%s: not modified (304)", src.name)
                return

            if feed.bozo and not feed.entries:
                # bozo means the feed was malformed; if there are entries anyway
                # we try to use them, but if there are none it is a real failure.
                raise ValueError(
                    f"Feed parse error: {feed.get('bozo_exception', 'unknown')}"
                )

            # Update conditional-GET headers for next poll
            with src._lock:
                src.etag     = getattr(feed, 'etag', None)
                src.modified = getattr(feed, 'modified', None)

            # Process entries newest-first so log order is chronological
            entries = list(reversed(feed.entries))
            new_count = 0

            for entry in entries:
                if self._seen.is_new(entry, src.name):
                    self._publish_item(src, entry, feed.feed)
                    new_count += 1

            if new_count:
                logger.info("%s: %d new item(s) published", src.name, new_count)
            else:
                logger.debug("%s: no new items", src.name)

            with src._lock:
                src.last_error = ''
                src.last_ok    = time.time()

        except Exception as exc:
            error_msg = str(exc)
            logger.warning("Feed error [%s]: %s", src.name, error_msg)
            with src._lock:
                src.last_error = error_msg
            self._publish_feed_error(src, error_msg)

    # ── message publishing ────────────────────────────────────────────────────

    def _publish_item(self, src: FeedSource, entry: object, feed_meta: object) -> None:
        """Encode one feed entry as TLVs and publish to the bus."""

        title  = getattr(entry, 'title',  '') or ''
        link   = getattr(entry, 'link',   '') or ''
        author = getattr(entry, 'author', '') or getattr(feed_meta, 'author', '') or ''

        # Resolve published timestamp — prefer published_parsed, then updated_parsed
        pub_struct = (
            getattr(entry, 'published_parsed', None)
            or getattr(entry, 'updated_parsed', None)
        )
        if pub_struct:
            import calendar
            pub_ts = float(calendar.timegm(pub_struct))
        else:
            pub_ts = time.time()

        # Categories/tags
        tags = []
        for t in getattr(entry, 'tags', []):
            label = getattr(t, 'term', None) or getattr(t, 'label', None) or ''
            if label:
                tags.append(label.strip())

        # Build the full-item JSON blob for consumers that want everything
        summary = (
            getattr(entry, 'summary', '')
            or getattr(entry, 'description', '')
            or ''
        )
        # Strip basic HTML tags from summary
        import re
        summary_text = re.sub(r'<[^>]+>', ' ', summary).strip()

        item_json = {
            'source':    src.name,
            'title':     title,
            'link':      link,
            'author':    author,
            'published': pub_ts,
            'summary':   summary_text,
            'tags':      tags,
            'id':        getattr(entry, 'id', link),
        }

        # Assemble TLVs
        tlvs = [
            _char_tlv(src.name, MW_SOURCE),   # pos 0: source name
            _char_tlv(title,    MW_TITLE),     # pos 1: title
            _char_tlv(link,     MW_URL),       # pos 2: url
            _char_tlv(author,   MW_AUTHOR),    # pos 3: author
        ]
        for i, tag in enumerate(tags):
            tlvs.append(_char_tlv(tag, 4 + i))  # pos 4+: categories

        tlvs.append(_utime_tlv(pub_ts))        # published timestamp
        tlvs.append(_json_tlv(item_json))      # full item JSON

        loop = self._client._loop
        if loop and loop.is_running():
            loop.call_soon_threadsafe(
                lambda: loop.create_task(
                    self._client._async_send(MT_FEED_ITEM, ST_ITEM, tlvs, 0)
                )
            )

        with src._lock:
            src.item_count += 1

        self.log_debug("Published [%s] %s", src.name, title[:80])

    def _publish_lifecycle(self, subtype: int, src: FeedSource,
                           extra_tlvs: list = None) -> None:
        """Publish a feed lifecycle event (added/removed/error)."""
        if subtype == ST_FEED_ADDED:
            tlvs = [_char_tlv(src.name, 0), _char_tlv(src.url, 1)]
        elif subtype == ST_FEED_REMOVED:
            tlvs = [_char_tlv(src.name, 0)]
        else:
            return

        if extra_tlvs:
            tlvs.extend(extra_tlvs)

        loop = self._client._loop
        if loop and loop.is_running():
            loop.call_soon_threadsafe(
                lambda: loop.create_task(
                    self._client._async_send(MT_FEED, subtype, tlvs, 0)
                )
            )

    def _publish_feed_error(self, src: FeedSource, error_msg: str) -> None:
        tlvs = [_char_tlv(src.name, 0), _char_tlv(error_msg, 1)]
        loop = self._client._loop
        if loop and loop.is_running():
            loop.call_soon_threadsafe(
                lambda: loop.create_task(
                    self._client._async_send(MT_FEED, ST_FEED_ERROR, tlvs, 0)
                )
            )

    def _publish_status(self, src: FeedSource) -> None:
        with src._lock:
            status = {
                'name':       src.name,
                'url':        src.url,
                'item_count': src.item_count,
                'last_ok':    src.last_ok,
                'last_error': src.last_error,
                'last_poll':  src.last_poll,
            }
        tlvs  = [_char_tlv(src.name, 0), _json_tlv(status)]
        loop  = self._client._loop
        if loop and loop.is_running():
            loop.call_soon_threadsafe(
                lambda: loop.create_task(
                    self._client._async_send(MT_FEED, ST_FEED_STATUS, tlvs, 0)
                )
            )

    # ── runtime control callbacks ─────────────────────────────────────────────

    def _on_add_feed(self, msg) -> None:
        """Handle AddFeed(201): Char(name) Char(url) [Int(poll_interval_secs)].

        The optional poll_interval TLV uses Int (not UInt) so it can be sent
        as Int N by the send tool script without needing a separate UInt syntax.
        """
        from ..core.tlv import decode_all, TLV_STRING, TLV_INT
        import struct
        try:
            tlvs      = decode_all(msg.tdata.value) if msg.tdata and msg.tdata.value else []
            char_tlvs = [t for t in tlvs if t.type_id == TLV_STRING]
            int_tlvs  = [t for t in tlvs if t.type_id == TLV_INT]
            if len(char_tlvs) < 2:
                logger.warning("AddFeed: need Char(name) Char(url) -- got %d Char TLVs", len(char_tlvs))
                return
            name     = char_tlvs[0].value.rstrip(b'\x00').decode('utf-8', errors='replace')
            url      = char_tlvs[1].value.rstrip(b'\x00').decode('utf-8', errors='replace')
            interval = None
            if int_tlvs:
                interval = abs(struct.unpack('!i', int_tlvs[0].value)[0])
            self.add_source(name, url, interval,
                            added_by=(msg.origin.router, msg.origin.id))
        except Exception as exc:
            logger.error("AddFeed handler error: %s", exc)

    def _on_remove_feed(self, msg) -> None:
        """Handle RemoveFeed(202): Char(name)."""
        from ..core.tlv import decode_all, TLV_STRING
        try:
            tlvs = decode_all(msg.tdata.value) if msg.tdata and msg.tdata.value else []
            char_tlvs = [t for t in tlvs if t.type_id == TLV_STRING]
            if not char_tlvs:
                return
            name = char_tlvs[0].value.rstrip(b'\x00').decode('utf-8', errors='replace')
            if not self.remove_source(name, removed_by=(msg.origin.router, msg.origin.id)):
                logger.warning("RemoveFeed: unknown source '%s'", name)
        except Exception as exc:
            logger.error("RemoveFeed handler error: %s", exc)

    def _on_poll_now(self, msg) -> None:
        """Handle PollNow(203): Char(name) — force immediate poll."""
        from ..core.tlv import decode_all, TLV_STRING
        try:
            tlvs = decode_all(msg.tdata.value) if msg.tdata and msg.tdata.value else []
            char_tlvs = [t for t in tlvs if t.type_id == TLV_STRING]
            if not char_tlvs:
                return
            name = char_tlvs[0].value.rstrip(b'\x00').decode('utf-8', errors='replace')
            with self._sources_lock:
                src = self._sources.get(name)
            if not src:
                logger.warning("PollNow: unknown source '%s'", name)
                return
            # Clear seen-item cache for this source so all current feed
            # entries are treated as new, then wake the poll loop.
            self._seen.clear_source(src.name)
            with src._lock:
                src.last_poll = 0.0
            self._stop_evt.set()
            logger.info("PollNow: forced re-poll of '%s' (cache cleared)", name)
        except Exception as exc:
            logger.error("PollNow handler error: %s", exc)

    def _on_list_feeds(self, msg) -> None:
        """Handle ListFeeds(204) — publish ST_FEED_STATUS for every source."""
        with self._sources_lock:
            sources = list(self._sources.values())
        for src in sources:
            self._publish_status(src)

    # ── ShutdownMixin override ────────────────────────────────────────────────

    def _on_shutdown_request(self) -> None:
        logger.info("Feed agent: shutdown requested")
        self._running = False
        self._stop_evt.set()
        self._client.disconnect()


# ── CLI entry point ────────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    p = argparse.ArgumentParser(description='UMM Feed agent — RSS/Atom to UMM bridge')
    p.add_argument('--config', default='feed.conf',
                   help='Config file (default: feed.conf)')
    p.add_argument('--router', default='localhost', dest='host')
    p.add_argument('--port',   type=int, default=DEFAULT_PORT)
    p.add_argument('--name',   default='Feed')
    p.add_argument('--debug',  action='store_true', default=False)
    p.add_argument('--version', action='store_true',
                   help='Print version and exit')
    args = p.parse_args()

    if args.version:
        print(f"UMM Feed agent {FEED_CAPABILITY.version}  (UMM {UMM_VERSION_STR})")
        sys.exit(0)

    if not _FEEDPARSER_OK:
        print("ERROR: 'feedparser' is not installed.")
        print("       pip install feedparser")
        sys.exit(1)

    feed = FeedModule(
        config_file  = args.config,
        host         = args.host,
        port         = args.port,
        process_name = args.name,
        debug        = args.debug,
    )
    try:
        feed.run()
    except UMMConnectionError as exc:
        print(f"\n  ERROR: {exc}")
        print(f"  Is the router running on {args.host}:{args.port}?")
        sys.exit(1)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    _main()
