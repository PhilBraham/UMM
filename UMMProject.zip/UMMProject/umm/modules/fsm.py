"""
umm.modules.fsm
===============
Finite State Machine module — a UMM client that drives state transitions
based on received messages and sends messages on each transition.

Config file format (identical to original C++ FSM)::

    # Comments start with #
    STATE StartState
        NEXT_STATE State_1
            RCV_MSG  100,1 Int 1          # receive mtype=100 subtype=1 Int=1
            RCV_MSG  100,2 Int 1
            SND_MSG  101,1 Char "Going to state_1"
            SND_MSG  100,1 Int 3
        NEXT_STATE State_2
            RCV_MSG  100,1 Int 2
            SND_MSG  101,2 Char "Going to state_2"
    STATE State_1
        NEXT_STATE StartState
            RCV_MSG  100,1 Int 0
            RCV_MSG  110,1                # match mtype/subtype only, any data
            SND_MSG  101,1 Char "Going to StartState"
            SND_MSG  *300,10              # pass-through: re-send with new mtype/subtype

Pass-through SND_MSG (prefixed *): re-sends the received message with the
specified mtype,subtype, preserving the original TLV data.

Run standalone::

    python -m umm.modules.fsm --config plant.fsm --router localhost --port 5000

Or embed::

    from umm.modules.fsm import FSMModule
    fsm = FSMModule(config_file="plant.fsm", host="localhost")
    fsm.run()
"""

from __future__ import annotations

import logging
import re
import sys
import struct
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..agent import UMMAgent, UMMConnectionError
from ..core.tlv import TLV, TLVBuffer, decode_all, TLV_TERM, TLV_INT, TLV_STRING, META_NONE
from ..core.messages import MType, UMMSubType, SType, UMMMsg, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag
from ..core.registry import registry
from ..core.meta import INT_META_INDEX, INT_META_COUNT, CHAR_META_IDENTIFIER
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin
from ..capability import CapabilityMixin, make_capability, SubtypeSpec

logger = logging.getLogger(__name__)

# ── FSM mtype constants ───────────────────────────────────────────────────────

MT_FSM            = MType.FSM
ST_FSM_FORCE      = 101  # Force a state change
ST_FSM_RESTART    = 102  # Reload config, optional new start state
ST_FSM_STATUS     = 103  # Request current state
ST_FSM_STATE_INFO = 104  # Response: current state info

PASS_THROUGH_FLAG = 0x01   # M-word flag on SND_MSG meaning "forward original data"


# ── capability descriptor ─────────────────────────────────────────────────────

FSM_CAPABILITY = make_capability(
    what        = "FSM",
    mtype       = int(MT_FSM),
    description = (
        "Finite state machine controller. Subscribes to the RCV_MSG triggers "
        "of the current state only, sends each transition's SND_MSGs, and moves "
        "to the next state. Control subtypes let other agents force a state, "
        "restart from config, or query the current state."
    ),
    version  = "1.0.1",
    author   = "Realtime Software Pty Ltd",
    subtypes = [
        SubtypeSpec(
            subtype     = ST_FSM_FORCE,           # 101
            name        = "ForceState",
            direction   = "in",
            description = "Force the FSM into a state by index: Int(state_index).",
        ),
        SubtypeSpec(
            subtype     = ST_FSM_RESTART,         # 102
            name        = "Restart",
            direction   = "in",
            description = "Reload the config file, optionally at Int(start_state_index).",
        ),
        SubtypeSpec(
            subtype          = ST_FSM_STATUS,     # 103
            name             = "GetState",
            direction        = "in",
            response_subtype = ST_FSM_STATE_INFO,
            description      = "Request the current state. No payload required.",
        ),
        SubtypeSpec(
            subtype     = ST_FSM_STATE_INFO,      # 104
            name        = "StateInfo",
            direction   = "out",
            responds_to = ST_FSM_STATUS,
            description = ("Current state report: Int(state_index)  Char(state_name)  "
                          "Int(state_count)."),
        ),
    ],
)


# ── multi-dimensional state names ────────────────────────────────────────────
#
# State names can be either:
#   Simple:    "Idle"
#   Tuple:     "(Idle, Running, BinsOK)"
#
# In NEXT_STATE definitions:
#   SAME       — keep current dimension value (only valid in tuple states)
#
# In STATE definitions:
#   *          — match any value for this dimension (wildcard)
#
# Priority: more specific states (fewer wildcards) are checked first.

WILDCARD = '*'
SAME     = 'SAME'


def parse_state_name(name: str) -> tuple:
    """
    Parse a state name into a tuple of dimension strings.

    "Idle"                    → ("Idle",)
    "(Idle, Running, BinsOK)" → ("Idle", "Running", "BinsOK")
    "(*, Running, *)"         → ("*", "Running", "*")
    "(SAME, EStopped, SAME)"  → ("SAME", "EStopped", "SAME")
    """
    name = name.strip()
    if name.startswith('(') and name.endswith(')'):
        parts = [p.strip() for p in name[1:-1].split(',')]
        return tuple(parts)
    return (name,)


def state_matches(current: tuple, pattern: tuple) -> bool:
    """
    Does *current* state match *pattern*?
    Pattern may contain '*' wildcards. SAME is not valid in patterns.
    States must have same number of dimensions.
    """
    if len(current) != len(pattern):
        return False
    return all(p == WILDCARD or p == c
               for c, p in zip(current, pattern))


def apply_next_state(current: tuple, next_spec: tuple) -> tuple:
    """
    Apply a NEXT_STATE spec to the current state.
    SAME in next_spec copies the current dimension value.
    """
    if len(current) != len(next_spec):
        # Different dimensions — just use next_spec as-is (no SAME possible)
        return next_spec
    return tuple(c if n == SAME else n
                 for c, n in zip(current, next_spec))


def wildcard_count(pattern: tuple) -> int:
    """Number of wildcard dimensions — used for priority (fewer = more specific)."""
    return sum(1 for p in pattern if p == WILDCARD)


def state_name_str(state: tuple) -> str:
    """Format a state tuple for display."""
    if len(state) == 1:
        return state[0]
    return f"({', '.join(state)})"


# ── data structures ───────────────────────────────────────────────────────────

@dataclass
class FsmMessage:
    """A RCV_MSG or SND_MSG entry parsed from the config file."""
    mtype:        int
    subtype:      int
    tlvs:         List[TLV]  = field(default_factory=list)
    pass_through: bool       = False   # SND_MSG * prefix


@dataclass
class Transition:
    """One NEXT_STATE block: triggers + actions."""
    next_state:  tuple        # tuple of dimension strings (may contain SAME)
    rcv_msgs:    List[FsmMessage] = field(default_factory=list)
    snd_msgs:    List[FsmMessage] = field(default_factory=list)


@dataclass
class State:
    """One STATE block — may contain wildcards in dimensions."""
    name:        tuple        # tuple of dimension strings (may contain *)
    transitions: List[Transition] = field(default_factory=list)


# ── config file parser ────────────────────────────────────────────────────────

def _parse_msg_line(line: str) -> Optional[FsmMessage]:
    """
    Parse a RCV_MSG or SND_MSG line.

    Format:  mtype,subtype [TypeName value] [TypeName value] ...
    Example: 100,1 Int 42
             100,1 Char "hello world"
             110,1                        (mtype/subtype only, no data match)
    """
    line = line.strip()
    pass_through = False
    if line.startswith('*'):
        pass_through = True
        line = line[1:].strip()

    # Parse mtype,subtype
    m = re.match(r'^(\d+)\s*,\s*(\d+)(.*)', line)
    if not m:
        return None
    mtype   = int(m.group(1))
    subtype = int(m.group(2))
    rest    = m.group(3).strip()

    tlvs: List[TLV] = []
    while rest:
        rest = rest.strip()
        if not rest or rest.startswith('#'):
            break

        # Find type name
        tm = re.match(r'^(\w+)\s*(.*)', rest)
        if not tm:
            break
        type_name = tm.group(1)
        rest      = tm.group(2).strip()

        handler = registry.get_by_name(type_name)
        if handler is None:
            known = ', '.join(sorted(registry.all_names()))
            raise ValueError(
                f"Unknown TLV type '{type_name}'. "
                f"Known types: {known}"
            )

        # Optional meta qualifier, e.g.  Int meta=100 >= 0
        # A non-zero meta switches this condition from positional to key-based
        # matching at the router: it is tested against the message field with
        # the same (type, meta).  Several conditions sharing a meta therefore
        # AND together on one field — that is how a range is expressed:
        #   Int meta=100 >= 0   and   Int meta=100 <= 1999
        meta_word = META_NONE
        mm = re.match(r'^meta\s*=\s*(\d+)\s*(.*)', rest)
        if mm:
            meta_word = int(mm.group(1))
            rest      = mm.group(2).strip()

        # Parse match operator (optional — default EQ=0)
        mword = 0
        op_map = getattr(handler, 'OP_TEXT', {})
        for op_text in sorted(op_map.keys(), key=len, reverse=True):
            if rest.startswith(op_text):
                mword = op_map[op_text]
                rest  = rest[len(op_text):].strip()
                break

        # Parse value
        if not rest or rest.startswith('#'):
            # No value — type-only match
            tlvs.append(TLV(type_id=handler.TYPE_ID, match=mword, meta=meta_word))
            break

        # Quoted string?
        if rest.startswith('"'):
            end = rest.find('"', 1)
            if end == -1:
                value_str = rest[1:]
                rest      = ''
            else:
                value_str = rest[1:end]
                rest      = rest[end+1:].strip()
            value_bytes = handler.pack(value_str)
        else:
            # Unquoted token
            tok = re.match(r'^(\S+)(.*)', rest)
            if tok:
                value_str = tok.group(1)
                rest      = tok.group(2).strip()
                try:
                    value_bytes = handler.pack(handler.from_text(value_str))
                except Exception:
                    value_bytes = value_str.encode() + b'\x00'
            else:
                break

        tlvs.append(TLV(type_id=handler.TYPE_ID, value=value_bytes, match=mword, meta=meta_word))

    return FsmMessage(mtype=mtype, subtype=subtype, tlvs=tlvs,
                      pass_through=pass_through)


def parse_config(config_file: str | Path):
    """
    Parse an FSM config file.

    Returns (states, initial_state, sub_mode) where initial_state is the tuple
    name of the starting state (defaults to first STATE if not declared) and
    sub_mode is 'all', 'per-state', or None (directive absent).

    Supports both simple and multi-dimensional state names:
        STATE Idle
        STATE (Idle, Running, BinsOK)
        STATE (*, EStopped, *)          # wildcard dimensions

    Optional directives (before any STATE):
        INITIAL_STATE (Idle, Running, BinsOK)
        SUBSCRIPTIONS all               # register every trigger once (default)
        SUBSCRIPTIONS per-state         # subscribe per current state, re-sync

    And NEXT_STATE with SAME keyword:
        NEXT_STATE (SAME, EStopped, SAME)
        NEXT_STATE (Idle, Running, SAME)
    """
    states:  List[State]             = []
    current_state: Optional[State]   = None
    current_trans: Optional[Transition] = None
    initial_state_name: Optional[tuple] = None
    sub_mode: Optional[str] = None   # 'all' | 'per-state' | None (unspecified)

    with open(config_file, 'r') as f:
        lines = f.readlines()

    # Join continuation lines (state names may span parens)
    joined = []
    buf    = ""
    for raw in lines:
        line = raw.split('#')[0].rstrip()
        buf += line
        # If we have unclosed parens, continue accumulating
        if buf.count('(') > buf.count(')'):
            buf += ' '
            continue
        joined.append(buf)
        buf = ""
    if buf.strip():
        joined.append(buf)

    for lineno, line in enumerate(joined, start=1):
        stripped = line.strip()
        if not stripped:
            continue

        try:
            if re.match(r'^INITIAL_STATE\s+', stripped, re.IGNORECASE):
                rest = stripped[13:].strip()
                initial_state_name = parse_state_name(rest)
                continue

            elif re.match(r'^SUBSCRIPTIONS\s+', stripped, re.IGNORECASE):
                # SUBSCRIPTIONS all        → register every trigger once (default)
                # SUBSCRIPTIONS per-state  → subscribe per current state, re-sync
                val = stripped.split(None, 1)[1].strip().lower()
                if val in ('per-state', 'per_state', 'dynamic'):
                    sub_mode = 'per-state'
                elif val in ('all', 'static', 'once'):
                    sub_mode = 'all'
                else:
                    raise ValueError(f"SUBSCRIPTIONS must be 'all' or 'per-state', got '{val}'")
                continue

            elif re.match(r'^STATE\s+', stripped, re.IGNORECASE):
                # Extract everything after STATE keyword
                rest = stripped[5:].strip()  # skip "STATE"
                name_tuple = parse_state_name(rest)
                current_state = State(name=name_tuple)
                current_trans = None
                states.append(current_state)

            elif re.match(r'^NEXT_STATE\s+', stripped, re.IGNORECASE):
                if current_state is None:
                    raise ValueError("NEXT_STATE before STATE")
                rest = stripped[10:].strip()  # skip "NEXT_STATE"
                name_tuple = parse_state_name(rest)
                current_trans = Transition(next_state=name_tuple)
                current_state.transitions.append(current_trans)

            elif re.match(r'^RCV_MSG\s+', stripped, re.IGNORECASE):
                if current_trans is None:
                    raise ValueError("RCV_MSG before NEXT_STATE")
                rest = stripped.split(None, 1)[1].strip()
                msg  = _parse_msg_line(rest)
                if msg:
                    current_trans.rcv_msgs.append(msg)

            elif re.match(r'^SND_MSG\s+', stripped, re.IGNORECASE):
                if current_trans is None:
                    raise ValueError("SND_MSG before NEXT_STATE")
                rest = stripped.split(None, 1)[1].strip()
                msg  = _parse_msg_line(rest)
                if msg:
                    current_trans.snd_msgs.append(msg)

        except ValueError as exc:
            raise ValueError(
                f"{config_file}, line {lineno}: {exc}\n"
                f"  >>> {stripped}"
            ) from None

    return states, initial_state_name, sub_mode


# ── FSM engine ────────────────────────────────────────────────────────────────

class FSMModule(CapabilityMixin, DebugMixin, VersionMixin, ShutdownMixin):
    """
    UMM Finite State Machine.

    Reads a config file, registers subscriptions for all RCV_MSGs across
    all states, and dispatches callbacks.  Only transitions whose current
    state matches are acted upon.

    Parameters
    ----------
    config_file : str or Path
        Path to the .fsm config file.
    host : str
        Router hostname.
    port : int
        Router port.
    process_name : str
        Name shown in the type directory.
    """

    AGENT_VERSION = "1.0.0"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    def __init__(self, config_file: str | Path,
                 host: str = 'localhost', port: int = 5000,
                 process_name: str = 'FSM',
                 per_state_subs: bool = False,
                 agent_type: int = None) -> None:
        # Allow overriding the agent mtype for a project-scoped instance
        # (e.g. a tank-project FSM on 5005 instead of the default 5).
        global MT_FSM
        if agent_type is not None:
            MT_FSM = agent_type
        self.config_file  = Path(config_file)
        self.host         = host
        self.port         = port
        self.process_name = process_name
        # Subscription strategy.  Default False = register every trigger once
        # (static) and filter by state in the dispatcher.  True = the older
        # per-state model: subscribe only to the current state's triggers
        # (content-filtered at the router) and re-sync on each transition.
        # A SUBSCRIPTIONS directive in the .fsm file overrides this (set in load()).
        self._per_state_subs = per_state_subs

        self._states:      List[State]                       = []
        self._state_index: Dict[str, int]                   = {}
        self._current:     int                               = 0
        self._reg_map:     Dict[int, Tuple[int, int]]       = {}
        self._prev_reg_ids: set                             = set()
        # Active subscriptions keyed by signature (mtype, subtype, match) →
        # reg_id.  Lets _register_state() diff the desired subscription set
        # against the active one so shared subscriptions are not churned
        # across a state transition.
        self._sub_by_sig:  Dict[tuple, int]                 = {}
        self._initial_name: Optional[tuple]                 = None
        self._current_tuple: tuple                          = ()
        # reg_id → (transition_id, Transition)
        # _prev_reg_ids → reg_ids from the previous state, pending removal

        self._client = UMMAgent(host=host, port=port,
                                 process_name=process_name,
                                 agent_mtype=MT_FSM,
                                 flags=AttachFlag.NORMAL)
        self._last_origin: Optional[Tuple[int, int]] = None
        self._last_msg_id: int = 0

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def load(self) -> None:
        """Parse config file and resolve state references."""
        self._states, self._initial_name, _sub_mode = parse_config(self.config_file)
        # A SUBSCRIPTIONS directive in the file overrides the launch default.
        if _sub_mode == 'per-state':
            self._per_state_subs = True
        elif _sub_mode == 'all':
            self._per_state_subs = False
        self._state_index = {s.name: i for i, s in enumerate(self._states)}

        # Validate NEXT_STATE references — allowing SAME and * placeholders
        all_names = {s.name for s in self._states}
        for state in self._states:
            for trans in state.transitions:
                ns = trans.next_state
                # Build the concrete version (SAME → first dim as placeholder)
                concrete = tuple(
                    state.name[i] if d == SAME else d
                    for i, d in enumerate(ns)
                    if i < len(state.name)
                ) if len(ns) == len(state.name) else ns
                # Check that at least one state matches the concrete name
                # (wildcards in the target are not allowed — only in STATE defs)
                if WILDCARD in ns:
                    raise ValueError(
                        f"NEXT_STATE cannot contain wildcards: {state_name_str(ns)}")

        self.log_info("FSM loaded: %d states from %s",
                    len(self._states), self.config_file)

    def _send(self, mtype: int, subtype: int, tlvs=None) -> None:
        """Non-blocking send from callback thread — avoids deadlocking the event loop.

        FSM callbacks run inside the agent's event loop thread.  Calling
        self._client.send() directly blocks via fut.result(), which deadlocks
        because the event loop is the same thread.  Use call_soon_threadsafe
        to schedule the coroutine without blocking the callback.
        """
        loop = self._client._loop
        if loop is None:
            self.log_error("FSM._send: no event loop")
            return

        async def _coro():
            try:
                await self._client._async_send(mtype, subtype, tlvs, 0)
            except Exception as exc:
                self.log_error("FSM._send failed mtype=%d sub=%d: %s", mtype, subtype, exc)

        loop.call_soon_threadsafe(lambda: loop.create_task(_coro()))

    def run(self) -> None:
        """Connect, register all subscriptions, and run."""
        self.load()
        if not self._client.connect():
            raise RuntimeError("Could not connect to router")

        # Set initial state: INITIAL_STATE directive or first STATE in file
        if self._initial_name is not None:
            self._current_tuple = self._initial_name
        elif self._states:
            self._current_tuple = self._states[0].name
        self._register_all()
        # Register capability handler. If this instance uses a non-default
        # mtype (agent_type was overridden), patch the capability descriptor
        # so the content-match subscription uses the correct mtype.
        from dataclasses import replace as _replace
        cap = FSM_CAPABILITY
        if int(MT_FSM) != int(MType.FSM):
            cap = _replace(cap, mtype=int(MT_FSM))
        self.CAPABILITY = cap
        self.register_capability_handler(self._client,
                                         instance=self.process_name)
        self.register_debug_handler(self._client, MT_FSM,
                                    debug=getattr(self, '_debug_flag', False))
        self.register_version_handler(self._client, MT_FSM)
        self.register_shutdown_handler(self._client, MT_FSM)

        # On reconnect, clear the reg_map and re-register everything for the
        # current state.  The agent's built-in registration replay handles the
        # infrastructure subscriptions (debug, version, shutdown); we only need
        # to re-register the state-machine subscriptions which are managed
        # outside of that mechanism.
        def _on_reconnect():
            self._reg_map.clear()
            self._prev_reg_ids.clear()
            # The router lost all subscriptions on disconnect, so forget the
            # active set — every subscription must be re-registered fresh.
            self._sub_by_sig.clear()
            self._register_state(self._current_tuple)
            self.log_info("FSM re-registered subscriptions after reconnect "
                          "(state: %s)", state_name_str(self._current_tuple))

        self._client.on_reconnect = _on_reconnect

        self.log_info("FSM running. Initial state: %s",
                      state_name_str(self._current_tuple))
        self._client.run()

    def _register_triggers(self) -> None:
        """Register one subscription per distinct (mtype, subtype) that appears
        as an RCV_MSG trigger in ANY state — once, with no content filter.

        Content matching and current-state gating are both done in
        _find_matching_transition (it only scans transitions of the state the
        FSM is currently in, and checks the message TLVs).  So a single static
        set of subscriptions is sufficient: the FSM no longer re-subscribes on
        every state change, which removes the per-transition register/unregister
        churn (and the reg_id pressure that came with it).

        Trade-off: the router no longer content-filters per state, so the FSM
        receives every message on these (mtype, subtype) pairs and discards the
        ones that do not match the current state.  For FSM trigger types this
        traffic is small; if a specific trigger is ever high-rate, register it
        with its match_tlvs to push that filter back to the router.

        Idempotent — only pairs not already active are registered, so it is safe
        to call at startup, on reconnect, and after a config reload.
        """
        desired: Dict[Tuple[int, int], None] = {}
        for state in self._states:
            for trans in state.transitions:
                for rcv in trans.rcv_msgs:
                    desired[(rcv.mtype, rcv.subtype)] = None

        for sig in desired:
            if sig in self._sub_by_sig:
                continue
            reg_id = self._client.register(
                mtype      = sig[0],
                subtype    = sig[1],
                callback   = self._on_message,
                match_tlvs = None,
                channel    = 0,
                dont_send_self = True,
            )
            self._sub_by_sig[sig] = reg_id
            self._reg_map[reg_id] = sig
            self.log_debug("Registered trigger mtype=%d subtype=%d reg=%d",
                           sig[0], sig[1], reg_id)

    # Dispatcher: choose the subscription strategy.  Called at startup, on
    # reconnect, and after a config reload.  Per-state mode re-syncs on every
    # transition (see _on_message); static mode registers once and never churns.
    def _register_state(self, state_tuple: tuple = None) -> None:
        if self._per_state_subs:
            self._register_state_dynamic(state_tuple
                                         if state_tuple is not None
                                         else self._current_tuple)
        else:
            self._register_triggers()

    def _register_state_dynamic(self, state_tuple: tuple) -> None:
        """Per-state subscription model (opt-in via SUBSCRIPTIONS per-state or
        --subscriptions per-state).

        Subscribe only to the triggers of the state(s) matching *state_tuple*,
        content-filtered at the router, and diff against the currently-active
        set so subscriptions shared between the old and new state are not
        churned.  Use this when a trigger is high-rate and you want the router
        (not the FSM) to filter it; the cost is register/unregister on each
        transition.  Dispatch still goes through _find_matching_transition, so
        keeping a subscription across a transition is safe.
        """
        desired: Dict[tuple, Tuple[int, int, Optional[list]]] = {}
        for state in self._states:
            if not state_matches(state_tuple, state.name):
                continue
            for trans in state.transitions:
                for rcv in trans.rcv_msgs:
                    sig = (rcv.mtype, rcv.subtype,
                           tuple((t.type_id, t.match, t.value)
                                 for t in rcv.tlvs))
                    if sig not in desired:
                        desired[sig] = (rcv.mtype, rcv.subtype,
                                        rcv.tlvs if rcv.tlvs else None)

        for sig in list(self._sub_by_sig):
            if sig not in desired:
                reg_id = self._sub_by_sig.pop(sig)
                self._client.unregister(reg_id)
                self._reg_map.pop(reg_id, None)

        for sig, (mtype, subtype, match_tlvs) in desired.items():
            if sig in self._sub_by_sig:
                continue
            reg_id = self._client.register(
                mtype      = mtype,
                subtype    = subtype,
                callback   = self._on_message,
                match_tlvs = match_tlvs,
                channel    = 0,
                dont_send_self = True,
            )
            self._sub_by_sig[sig] = reg_id
            self._reg_map[reg_id] = (mtype, subtype)

    def _unregister_state(self) -> None:
        """Unregister all current state subscriptions."""
        for reg_id in list(self._reg_map):
            self._client.unregister(reg_id)
            self.log_debug("Unregistered reg=%d", reg_id)
        self._reg_map.clear()
        self._sub_by_sig.clear()

    def _unregister_state_except_current(self) -> None:
        """No-op retained for compatibility.

        Removal of stale subscriptions is now handled inside _register_state(),
        which diffs the desired subscription set against the active one.  This
        method is kept so existing call sites remain valid.
        """
        self._prev_reg_ids.clear()

    def _register_all(self) -> None:
        """Register subscriptions for every RCV_MSG in every state/transition.

        Used only during restart (when current state is being reset).
        Normal operation uses _register_state / _unregister_state.
        """
        self._register_state(self._current_tuple)

        # Register command messages
        self._client.register(
            mtype    = MT_FSM,
            subtype  = ST_FSM_FORCE,
            callback = self._on_force_state,
            channel  = 0,   # ALL
        )
        self._client.register(
            mtype    = MT_FSM,
            subtype  = ST_FSM_RESTART,
            callback = self._on_restart,
            channel  = 0,   # ALL
        )
        self._client.register(
            mtype    = MT_FSM,
            subtype  = ST_FSM_STATUS,
            callback = self._on_status_request,
            channel  = 0,   # ALL
        )

    # ── message callbacks ─────────────────────────────────────────────────────

    def _find_matching_transition(self, rcv_mtype: int,
                                    rcv_subtype: int,
                                    msg: Optional['UMMMsg'] = None) -> Optional[Transition]:
        """
        Find the best matching transition for the current state and
        incoming mtype/subtype.

        Multi-dimensional matching:
          - Current state is a tuple e.g. (Idle, Running, BinsOK)
          - STATE patterns may contain * wildcards
          - More specific patterns (fewer wildcards) take priority
          - NEXT_STATE may contain SAME placeholders (resolved at transition time)
        """
        from umm.core.registry import registry as _registry
        from umm.core.tlv import decode_all as _decode_all

        # Pre-decode message TLVs for content matching
        msg_tlvs: list = []
        if msg is not None and msg.tdata and msg.tdata.value:
            try:
                msg_tlvs = list(_decode_all(msg.tdata.value))
            except Exception:
                pass

        best_trans:    Optional[Transition] = None
        best_wildcards: int                 = 999

        for state in self._states:
            # Check if this state pattern matches the current state
            if not state_matches(self._current_tuple, state.name):
                continue

            # Among matching states, prefer fewer wildcards
            wc = wildcard_count(state.name)
            if wc > best_wildcards:
                continue

            # Find a transition in this state that matches the message
            for trans in state.transitions:
                for rcv in trans.rcv_msgs:
                    if rcv.mtype != rcv_mtype or rcv.subtype != rcv_subtype:
                        continue
                    # Check content match TLVs if present
                    if rcv.tlvs and msg_tlvs:
                        content_ok = True
                        for sub_tlv in rcv.tlvs:
                            matched = any(
                                _registry.match(m_tlv, sub_tlv)
                                for m_tlv in msg_tlvs
                                if m_tlv.type_id == sub_tlv.type_id
                            )
                            if not matched:
                                content_ok = False
                                break
                        if not content_ok:
                            continue
                    if wc < best_wildcards:
                        best_wildcards = wc
                        best_trans     = trans
                    break

        return best_trans

    def _on_message(self, msg: UMMMsg) -> None:
        """Called for every matched subscription message."""
        # Deduplicate (same origin + msgId = duplicate from multiple subs)
        origin_key = (msg.origin.router, msg.origin.id)
        if origin_key == self._last_origin and msg.msg_id == self._last_msg_id:
            return
        self._last_origin = origin_key
        self._last_msg_id = msg.msg_id

        trans = self._find_matching_transition(msg.mtype, msg.subtype, msg)
        if trans is None:
            return

        # Send all SND_MSGs for this transition
        for snd in trans.snd_msgs:
            if snd.pass_through:
                self._send(
                    mtype   = snd.mtype,
                    subtype = snd.subtype,
                    tlvs    = [msg.tdata] if msg.tdata.type_id != TLV_TERM else None,
                )
            else:
                self._send(
                    mtype   = snd.mtype,
                    subtype = snd.subtype,
                    tlvs    = snd.tlvs if snd.tlvs else None,
                )

        # Apply state transition (resolve SAME placeholders)
        old_str = state_name_str(self._current_tuple)
        old_tuple = self._current_tuple
        self._current_tuple = apply_next_state(self._current_tuple,
                                               trans.next_state)
        new_str = state_name_str(self._current_tuple)
        self.log_debug("FSM: %s → %s", old_str, new_str)

        # Subscriptions are static by default (all triggers registered once),
        # so a state change needs no re-subscription — _find_matching_transition
        # gates on the current state.  In opt-in per-state mode, re-sync the
        # current state's subscriptions.
        if self._current_tuple != old_tuple:
            self.log_info("FSM state change: %s → %s", old_str, new_str)
            if self._per_state_subs:
                self._register_state_dynamic(self._current_tuple)

    def _on_status_request(self, msg: UMMMsg) -> None:
        """Respond to a GetState request (ST_FSM_STATUS) with the current state.

        Replies on (MT_FSM, ST_FSM_STATE_INFO) with:
            Int(state_index)  Char(state_name)  Int(state_count)
        Any agent — the GUI, the parser, another FSM — can query this to see
        where the machine currently is (e.g. to spot a state it is stuck in).
        """
        idx = -1
        for i, s in enumerate(self._states):
            if s.name == self._current_tuple or state_matches(self._current_tuple, s.name):
                idx = i
                break
        name = state_name_str(self._current_tuple)
        self.log_info("FSM state query → %s (index %d)", name, idx)
        name_bytes = name.encode('utf-8') + b'\x00'
        tlvs = [
            TLV(type_id=TLV_INT,    meta=INT_META_INDEX,       value=struct.pack('!i', idx)),
            TLV(type_id=TLV_STRING, meta=CHAR_META_IDENTIFIER, value=name_bytes),
            TLV(type_id=TLV_INT,    meta=INT_META_COUNT,       value=struct.pack('!i', len(self._states))),
        ]
        self._send(MT_FSM, ST_FSM_STATE_INFO, tlvs)

    def _on_force_state(self, msg: UMMMsg) -> None:
        """Force a state change via UMM message."""
        tlvs = decode_all(msg.tdata.value) if msg.tdata.value else []
        for tlv in tlvs:
            if tlv.type_id == TLV_INT:
                state_num = struct.unpack('!i', tlv.value)[0]
                if 0 <= state_num < len(self._states):
                    self._current = state_num
                    self._current_tuple = self._states[state_num].name
                    if self._per_state_subs:
                        self._register_state_dynamic(self._current_tuple)
                    self.log_info("FSM forced to state %d: %s",
                                state_num, self._states[state_num].name)
                break

    def _on_restart(self, msg: UMMMsg) -> None:
        """Reload config file, optionally starting at a new state."""
        new_start = 0
        tlvs = decode_all(msg.tdata.value) if msg.tdata.value else []
        for tlv in tlvs:
            if tlv.type_id == TLV_INT:
                new_start = struct.unpack('!i', tlv.value)[0]
        self.log_info("FSM restarting from config %s at state %d",
                    self.config_file, new_start)
        # On restart: unregister old first (no new state yet to protect),
        # then reload and register the initial state.
        self._unregister_state()
        self._states.clear()
        self._state_index.clear()
        self.load()
        self._current = max(0, min(new_start, len(self._states) - 1))
        if self._initial_name:
            self._current_tuple = self._initial_name
        else:
            self._current_tuple = self._states[self._current].name
        self._register_state(self._current_tuple)

    @property
    def current_state(self) -> str:
        """Name of the current FSM state as a display string."""
        return state_name_str(self._current_tuple)

    @property
    def current_state_tuple(self) -> tuple:
        """Current state as a tuple of dimension values."""
        return self._current_tuple


# ── CLI entry point ───────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    parser = argparse.ArgumentParser(description='UMM Finite State Machine')
    parser.add_argument('--version', action='store_true',
                   help='Show version and exit')
    parser.add_argument('--config',  required=True, help='FSM config file (.fsm)')
    parser.add_argument('--router',  default='localhost', dest='host')
    parser.add_argument('--port',    type=int, default=5000)
    parser.add_argument('--name',    default='FSM')
    parser.add_argument('--type',    type=int, default=None, dest='agent_type',
                        help='Override agent mtype for a project-scoped instance (default: 5)')
    parser.add_argument('--debug',     action='store_true')
    parser.add_argument('--permanent', action='store_true',
                        help='Attach with PERM_KEEP_CONN (set automatically by supervisor for C agents)')
    parser.add_argument('--subscriptions', choices=['all', 'per-state'], default='all',
                        help="Subscription strategy: 'all' (default) registers every "
                             "trigger once and filters by state in the FSM; 'per-state' "
                             "subscribes only to the current state's triggers (router-side "
                             "content filtering) and re-syncs on each transition. A "
                             "SUBSCRIPTIONS directive in the .fsm file overrides this.")
    args = parser.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    fsm = FSMModule(config_file=args.config, host=args.host,
                    port=args.port, process_name=args.name,
                    per_state_subs=(args.subscriptions == 'per-state'),
                    agent_type=args.agent_type)
    fsm._debug_flag = args.debug
    if args.permanent:
        fsm._client.attach_flags = AttachFlag.PERM_KEEP_CONN
        fsm._client.reconnect = True
    try:
        fsm.run()
    except KeyboardInterrupt:
        print("\nFSM stopped.")


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)