"""
umm.modules.timer
=================
Timer service — a UMM client that sends scheduled messages.

Clients send a timer request message (mtype=MT_TIMER, subtype=ST_REQUEST)
containing:
  - TLVUTime  start_time     (absolute Unix timestamp, or relative seconds
                               if < RELATIVE_TIME threshold)
  - TLVUTime  interval       (optional repeat interval, relative seconds)
  - TLVInt    count          (optional repeat count; 0 = continuous/forever)
  - TLVMsg    message_to_send (the nested UMMMsg to send when the timer fires)

The timer service responds with the timer reference number (Int) on
mtype=MT_TIMER, subtype=ST_CONFIRMED (103), or an error on subtype=ST_ERROR (104).

Cancel a timer by sending mtype=MT_TIMER, subtype=ST_CANCEL (102) with TLVInt
containing the reference number.

Run standalone::

    python -m umm.modules.timer --router localhost --port 5000

Or embed::

    from umm.modules.timer import TimerModule
    timer = TimerModule(host='localhost')
    timer.run()

Usage from a client::

    from umm import UMMAgent
    from umm.types.builtin import UTimeType, IntType
    from umm.core.tlv import TLV, TLVBuffer, TLV_MSG
    import time

    # Send a message every 60 seconds starting now
    client = UMMAgent(host='localhost')
    client.connect()

    utime  = UTimeType()
    int_t  = IntType()

    buf = TLVBuffer()
    buf.add(utime.make_tlv(60.0))          # interval: 60 seconds relative
    buf.add(int_t.make_tlv(0))              # count: 0 = continuous

    # The message to send when the timer fires
    # Inner format: mtype(4) subtype(4) channel(2) flags(2) [TLV payload]
    inner_header = struct.pack('!iiHH', 1001, 101, 1, 0)  # mtype, subtype, ch=APP, flags=0
    inner_payload = int_t.make_tlv(1).encode()
    buf.add(TLV(type_id=TLV_MSG, value=inner_header + inner_payload))

    client.send(mtype=2, subtype=101, tlvs=list(buf))
"""

from __future__ import annotations

import asyncio
import logging
import sys
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..agent import UMMAgent, UMMConnectionError
from ..capability import CapabilityMixin, TIMER_CAPABILITY
from ..core.tlv import TLV, TLVBuffer, decode_all, TLV_TERM, TLV_INT, TLV_MSG, TLV_STRING, TLV_MSGREF
from ..core.messages import MType, SType, UMMMsg, UTime, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag
from ..core.registry import registry
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin

logger = logging.getLogger(__name__)

# ── constants ─────────────────────────────────────────────────────────────────

MT_TIMER      = MType.TIMER
ST_REQUEST    = 101  # Client → Timer: request a timer
ST_CANCEL     = 102  # Client → Timer: cancel a timer
ST_CONFIRMED  = 103  # Timer → Client: timer created successfully  Int(ref) MsgRef(corr)
ST_ERROR      = 104  # Timer → Client: request failed             Char(msg) MsgRef(corr)
ST_FIRED      = -101 # Timer → Client: timer fired                Int(ref) Int(fire_count)

# Times below this threshold are treated as relative (seconds from now).
# Matches original C++ RELATIVE_TIME constant.
RELATIVE_TIME = 1_000_000_000   # ~ year 2001; anything before this = relative

MAX_TIMERS    = 256


# ── timer entry ───────────────────────────────────────────────────────────────

@dataclass
class TimerEntry:
    ref:          int
    next_fire:    float          # Unix timestamp
    interval:     float          # seconds; 0 = one-shot
    count:        int            # remaining fires; 0 = continuous forever
    msg_mtype:    int
    msg_subtype:  int
    msg_tlvs:     bytes          # pre-encoded TLV payload bytes
    msg_channel:  int = 1        # channel to fire the tick on
    msg_flags:    int = 0        # flags to set on the fired tick message
    req_msg_id:   int = 0        # original request msg_id for cancel-by-msgref
    req_origin_router: int = 0   # router id of the agent that requested the timer
    req_origin_id:     int = 0   # agent id of the agent that requested the timer


# ── timer module ──────────────────────────────────────────────────────────────

class TimerModule(CapabilityMixin, DebugMixin, VersionMixin, ShutdownMixin):

    CAPABILITY     = TIMER_CAPABILITY
    AGENT_VERSION  = "1.0.1"
    GROUP_VERSION  = "1.0.0"
    BUILD          = "dev"
    """
    UMM Timer service.

    Listens for timer requests on mtype=MT_TIMER, subtype=ST_REQUEST and
    fires the requested message at the scheduled time(s).
    """

    CAPABILITY = TIMER_CAPABILITY

    def __init__(self, host: str = 'localhost', port: int = DEFAULT_PORT,
                 process_name: str = 'Timer',
                 agent_type: int = None) -> None:
        self.host         = host
        self.port         = port
        self.process_name = process_name
        # Allow overriding the mtype (for dedicated named timer instances)
        global MT_TIMER
        if agent_type is not None:
            MT_TIMER = agent_type

        self._client  = UMMAgent(host=host, port=port,
                                  process_name=process_name,
                                  agent_mtype=MT_TIMER,
                                  flags=AttachFlag.NORMAL)
        self._timers: Dict[int, TimerEntry] = {}
        self._timers_lock = threading.Lock()   # guards _timers across threads
        self._next_ref = 1
        self._running  = False

    def run(self) -> None:
        """Connect and run the timer loop."""
        if not self._client.connect():
            print(f"\n  ERROR: Timer could not connect to router at {self.host}:{self.port}")
            print("  Is the router running?  Start it with: ./umm.sh start router")
            print("")
            return

        self._client.register(
            mtype    = MT_TIMER,
            subtype  = ST_REQUEST,
            callback = self._on_request,
            channel  = 0,   # ALL — accept requests from any channel
        )
        self._client.register(
            mtype    = MT_TIMER,
            subtype  = ST_CANCEL,
            callback = self._on_cancel,
            channel  = 0,   # ALL — accept cancels from any channel
        )
        # Register capability handler. If this instance uses a non-default
        # mtype (agent_type was overridden), patch the capability descriptor
        # so the content-match subscription uses the correct mtype.
        from dataclasses import replace as _replace
        cap = TIMER_CAPABILITY
        if MT_TIMER != MType.TIMER:
            cap = _replace(cap, mtype=MT_TIMER)
        self.CAPABILITY = cap
        self.register_capability_handler(self._client)
        self.register_debug_handler(self._client, MT_TIMER,
                                    debug=getattr(self, '_debug_flag', False))
        self.register_version_handler(self._client, MT_TIMER)
        self.register_shutdown_handler(self._client, MT_TIMER)
        self.log_info("Timer service running on %s:%d", self.host, self.port)
        self._running = True
        try:
            self._tick_loop()
        except KeyboardInterrupt:
            pass
        finally:
            self._running = False

    # ── request handling ──────────────────────────────────────────────────────

    def _on_request(self, msg: UMMMsg) -> None:
        """Parse a timer request and schedule the entry."""
        utime_handler = registry.get_by_name('UTime')
        int_handler   = registry.get_by_id(TLV_INT)

        now          = time.time()
        start_time   = 0.0
        interval     = 0.0
        count        = 1
        msg_mtype    = 0
        msg_subtype  = 0
        msg_channel  = msg.channel   # overridden by channel field in Msg TLV header
        msg_flags    = 0             # overridden by flags field in Msg TLV header
        msg_payload  = b''
        got_start    = False
        got_interval = False
        got_count    = False
        got_msg      = False

        if not msg.tdata.value:
            self._send_error("Empty timer request", msg)
            return

        tlvs = decode_all(msg.tdata.value)
        for tlv in tlvs:
            if utime_handler and tlv.type_id == utime_handler.TYPE_ID:
                ts = utime_handler.unpack(tlv.value)
                if ts < RELATIVE_TIME:
                    # Relative time
                    if not got_start:
                        interval  = ts
                        got_interval = True
                    else:
                        interval  = ts
                        got_interval = True
                else:
                    start_time = ts
                    got_start  = True

            elif int_handler and tlv.type_id == TLV_INT:
                count     = struct.unpack('!i', tlv.value)[0]
                got_count = True

            elif tlv.type_id == TLV_MSG:
                # Nested message spec: mtype(4) subtype(4) channel(2) flags(2) [TData]
                # Fixed 12-byte header; TLV payload follows.
                if len(tlv.value) >= 12:
                    msg_mtype, msg_subtype, msg_channel, msg_flags = \
                        struct.unpack('!iiHH', tlv.value[:12])
                    msg_payload = tlv.value[12:]
                    got_msg = True

        if not got_msg:
            self._send_error("Timer request has no message", msg)
            return
        if not got_start and not got_interval:
            self._send_error("Timer request has no time", msg)
            return
        if got_count and count < 0:
            self._send_error(f"Invalid count {count} - use 0 for continuous, positive integer for fixed repeat", msg)
            return

        # Convert relative start to absolute
        if not got_start:
            start_time = now + interval
        if got_interval and not got_count:
            count = 0    # repeat forever when interval but no count given
        if got_interval and got_start and not got_count:
            count = 1    # one-shot absolute

        with self._timers_lock:
            ref = self._next_ref
            self._next_ref += 1
            self._timers[ref] = TimerEntry(
                ref         = ref,
                next_fire   = start_time,
                interval    = interval,
                count       = count,
                msg_mtype   = msg_mtype,
                msg_subtype = msg_subtype,
                msg_tlvs    = msg_payload,
                msg_channel = msg_channel,
                msg_flags   = msg_flags,
                req_msg_id  = msg.msg_id,
                req_origin_router = msg.origin.router,
                req_origin_id     = msg.origin.id,
            )
        now = time.time()
        delay_s = max(0.0, start_time - now)
        count_str = '∞' if count <= 0 else str(count)
        self.log_info("Timer %d scheduled: fires in %.1fs, interval=%.1fs, count=%s, ch=%d flags=0x%x",
                      ref, delay_s, interval, count_str, msg_channel, msg_flags)

        # Send confirmation: subtype=ST_CONFIRMED, Int(ref), MsgRef(origin+msg_id)
        # MsgRef is globally unique — identifies the exact request message
        # across all agents/routers, not just within this agent's session.
        # Confirmation travels on ch1 (Confirm channel).
        int_t = registry.get_by_id(TLV_INT)
        if int_t:
            from ..types.builtin import MsgRefType as _MsgRef
            self._send(ST_CONFIRMED, tlvs=[
                int_t.make_tlv(ref),
                _MsgRef.make_tlv(
                    msg.origin.router,
                    msg.origin.id,
                    msg.msg_id,
                ),
            ], channel=2)

    def _on_cancel(self, msg: UMMMsg) -> None:
        """Cancel a scheduled timer.

        Accepts either TLV_INT(ref) or TLV_MSGREF(req_msg_id) to identify
        the timer.  TLV_MSGREF allows cancelling before the confirmation
        has been received (i.e. by the original request msg_id).
        """
        if not msg.tdata.value:
            self.log_warn("Cancel: no TLV data")
            return
        tlvs = decode_all(msg.tdata.value)
        ref = None
        req_msg_id = None
        for tlv in tlvs:
            if tlv.type_id == TLV_INT and ref is None:
                ref = struct.unpack('!i', tlv.value)[0]
            elif tlv.type_id == TLV_MSGREF and len(tlv.value) >= 12:
                req_msg_id = struct.unpack('!I', tlv.value[8:12])[0]
        with self._timers_lock:
            cancelled_ref   = None
            cancelled_entry = None
            if ref is not None and ref in self._timers:
                cancelled_entry = self._timers.pop(ref)
                cancelled_ref   = ref
            elif req_msg_id is not None:
                # Cancel by original request msg_id — useful before confirmation
                for r, entry in list(self._timers.items()):
                    if entry.req_msg_id == req_msg_id:
                        cancelled_entry = self._timers.pop(r)
                        cancelled_ref   = r
                        break
        if cancelled_ref is not None:
            # Cancellation across agents is allowed (e.g. an operator console
            # cancelling a runaway timer it did not create), but we flag it so
            # it is visible in the log and on the Confirm bus — useful when
            # tracking down "who cancelled my timer?" surprises with several
            # consoles or agents running at once.
            canceller = (msg.origin.router, msg.origin.id)
            requester = (cancelled_entry.req_origin_router,
                         cancelled_entry.req_origin_id)
            cross_agent = requester != (0, 0) and canceller != requester
            extra = None
            if cross_agent:
                self.log_warn(
                    "Timer %d cancelled by agent %d.%d but was requested by "
                    "agent %d.%d (cross-agent cancellation)",
                    cancelled_ref, canceller[0], canceller[1],
                    requester[0], requester[1])
                note = (f"Timer {cancelled_ref} cancelled by agent "
                        f"{canceller[0]}.{canceller[1]} "
                        f"(originally requested by agent "
                        f"{requester[0]}.{requester[1]})")
                # Machine-readable: a Bool(true) flag marks the cross-agent case,
                # and a MsgRef identifies the original requester.
                bool_t = registry.get_by_id(7)   # Bool
                from ..types.builtin import MsgRefType as _MsgRef
                extra = []
                if bool_t:
                    extra.append(bool_t.make_tlv(True))
                extra.append(_MsgRef.make_tlv(requester[0], requester[1], 0))
            else:
                self.log_info("Timer %d cancelled", cancelled_ref)
                note = f"Timer {cancelled_ref} cancelled"
            self._send_confirmed_msg(note, msg, extra_tlvs=extra)
        else:
            self.log_warn("Cancel: ref=%s req_msg_id=%s not found", ref, req_msg_id)
            self._send_error(f"No timer with ref={ref} or req_msg_id={req_msg_id}", msg)
        return

    # ── tick loop ─────────────────────────────────────────────────────────────

    def _tick_loop(self) -> None:
        """
        Main timer loop.  Checks every 50ms for timers that need to fire.
        Blocking — call from the main thread after register().

        _timers is shared with the event-loop thread (_on_request/_on_cancel),
        so every access is guarded by _timers_lock.  We take a snapshot of
        due entries under the lock, then fire them outside it so we don't
        hold the lock across a network send.
        """
        while self._running:
            now = time.time()
            due = []
            with self._timers_lock:
                for ref, entry in list(self._timers.items()):
                    if now >= entry.next_fire:
                        due.append(entry)
                        if entry.count == 1:
                            del self._timers[ref]
                            self.log_debug("Timer %d expired (one-shot)", ref)
                        elif entry.count > 1:
                            entry.count    -= 1
                            entry.next_fire = now + entry.interval
                        else:
                            # count == 0: repeat forever
                            entry.next_fire = now + entry.interval
            for entry in due:
                self._fire(entry)
            time.sleep(0.05)

    def _fire(self, entry: TimerEntry) -> None:
        """Schedule the timed message on the event loop — non-blocking.

        Using call_soon_threadsafe + create_task instead of the blocking
        self._client.send() avoids stalling the tick loop for up to 5 s
        on every pulse (send() calls fut.result(timeout=5) internally).
        At 120 ms pulse intervals with two belts this was enough to miss
        subsequent ticks and cause pulses to stall.
        """
        tlvs: Optional[List[TLV]] = None
        if entry.msg_tlvs:
            try:
                tlvs = decode_all(entry.msg_tlvs)
            except Exception:
                tlvs = None

        loop = self._client._loop
        if loop is None:
            self.log_error("_fire: no event loop — timer %d dropped", entry.ref)
            return

        mtype, subtype = entry.msg_mtype, entry.msg_subtype
        self.log_debug("Timer %d firing: mtype=%d subtype=%d ch=%d",
                      entry.ref, mtype, subtype, entry.msg_channel)

        async def _coro():
            try:
                await self._client._async_send(mtype, subtype, tlvs or [],
                                               entry.msg_flags,
                                               channel=entry.msg_channel)
            except Exception as exc:
                self.log_error("Timer %d fire failed: %s", entry.ref, exc)

        loop.call_soon_threadsafe(lambda: loop.create_task(_coro()))

    # ── helpers ───────────────────────────────────────────────────────────────

    def _send(self, subtype: int, tlvs=None, channel: int = 1) -> None:
        """
        Schedule a send on the agent's event loop without blocking.

        Callbacks run inside the agent's event loop thread. Calling
        self._client.send() directly (or from a new thread) deadlocks
        because send() calls fut.result() which waits for the same loop.

        The fix: use call_soon_threadsafe to schedule the coroutine
        directly on the loop, bypassing the blocking fut.result() path.
        """
        loop = self._client._loop
        if loop is None:
            self.log_error("_send: no event loop available")
            return

        async def _coro():
            try:
                await self._client._async_send(MT_TIMER, subtype, tlvs, 0,
                                               channel=channel)
                self.log_debug("_send: subtype=%d sent OK", subtype)
            except Exception as exc:
                self.log_error("_send: subtype=%d FAILED: %s", subtype, exc)

        loop.call_soon_threadsafe(
            lambda: loop.create_task(_coro())
        )

    def _send_error(self, message: str, msg: 'UMMMsg' = None) -> None:
        """
        Send an error response on subtype=ST_ERROR (104), channel=2 (Confirm).
        """
        tlvs = [self._str_tlv(message)]
        if msg is not None:
            from ..types.builtin import MsgRefType as _MsgRef
            tlvs.append(_MsgRef.make_tlv(
                msg.origin.router,
                msg.origin.id,
                msg.msg_id,
            ))
        self._send(ST_ERROR, tlvs=tlvs, channel=2)

    def _send_confirmed_msg(self, message: str, msg: 'UMMMsg' = None,
                            extra_tlvs: list = None) -> None:
        """
        Send a text confirmation on subtype=ST_CONFIRMED (103), channel=2 (Confirm).
        Used for cancel acknowledgement and other non-error confirmations.
        If msg is provided, includes a MsgRef correlation ID.
        Any TLVs in *extra_tlvs* are appended (e.g. a cross-agent-cancel flag).
        """
        tlvs = [self._str_tlv(message)]
        if msg is not None:
            from ..types.builtin import MsgRefType as _MsgRef
            tlvs.append(_MsgRef.make_tlv(
                msg.origin.router,
                msg.origin.id,
                msg.msg_id,
            ))
        if extra_tlvs:
            tlvs.extend(extra_tlvs)
        self._send(ST_CONFIRMED, tlvs=tlvs, channel=2)

    @staticmethod
    def _str_tlv(text: str) -> TLV:
        return TLV(type_id=TLV_STRING,
                   value=text.encode('utf-8') + b'\x00')


# ── CLI entry point ───────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    parser = argparse.ArgumentParser(description='UMM Timer service')
    parser.add_argument('--router', default='localhost', dest='host')
    parser.add_argument('--version', action='store_true',
                   help='Show version and exit')
    parser.add_argument('--port',   type=int, default=DEFAULT_PORT)
    parser.add_argument('--name',   default='Timer')
    parser.add_argument('--type',   type=int, default=None, dest='agent_type',
                        help='Override mtype this timer listens on (default: 2)')
    parser.add_argument('--debug',    action='store_true')
    parser.add_argument('--permanent', action='store_true',
                        help='Attach with PERM_KEEP_CONN (set automatically by supervisor for C agents)')
    args = parser.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    svc = TimerModule(host=args.host, port=args.port, process_name=args.name,
                      agent_type=args.agent_type)
    svc._debug_flag = args.debug
    if args.permanent:
        svc._client.attach_flags = AttachFlag.PERM_KEEP_CONN
        svc._client.reconnect = True   # picked up by register_debug_handler
    try:
        svc.run()
    except KeyboardInterrupt:
        print("\nTimer stopped.")


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)