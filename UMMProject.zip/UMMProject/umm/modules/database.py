"""
umm.modules.database
====================
Database agent — subscribes to UMM messages and writes rows to a relational
database.  Write-only for now; query support is a future addition.

Supports multiple backends via a simple adapter interface:
  - sqlite   (built-in, zero install — default for demos)
  - postgres  (requires psycopg2:  pip install psycopg2-binary)
  - mysql     (requires mysql-connector-python)

Configuration is read from a .ini file (default: database.conf).

Quick start::

    python -m umm.modules.database --config database.conf

Or embed::

    from umm.modules.database import DatabaseModule
    db = DatabaseModule(config_file='database.conf', host='localhost')
    db.run()

Config file format — see database.conf for full annotated example::

    [database]
    backend  = sqlite
    path     = umm_data.db        # sqlite only
    # host   = localhost
    # port   = 5432
    # name   = ummdb
    # user   = umm
    # password = secret

    [table.sensor_readings]
    mtype    = 100
    subtype  = 1
    columns =
        Float  -> value_celsius  REAL
        UShort -> alarm          INTEGER

    # Use mword to distinguish multiple TLVs of the same type.
    # mword values are arbitrary — the publisher and this config must agree.
    [table.events]
    mtype    = 200
    subtype  = 1
    columns =
        Char[0]  -> event_type  TEXT     # first Char TLV (mword=0)
        Char[1]  -> description TEXT     # second Char TLV (mword=1)
        Int      -> severity    INTEGER

Auto-columns added to every table:
    id           INTEGER  PRIMARY KEY AUTOINCREMENT (or serial/bigserial)
    received_at  DATETIME default current timestamp
    origin_site  INTEGER  router site portion of message origin
    origin_node  INTEGER  router node portion of message origin
    msg_id       INTEGER  message sequence number

TLV type names (case-insensitive):
    Raw, Int, UInt, Short, UShort, Float, Bool, Char, UTime,
    AttId, CoOrd, LogId, MsgRef, RouterId
    Plus any manufacturing types: Temperature, Pressure, ConveyorSpeed, …
    For types with multiple instances: TypeName[mword] e.g. Char[0], Char[2]
    Omitting [mword] matches the first TLV of that type found (any mword).
"""

from __future__ import annotations

import configparser
import datetime
import logging
import re
import struct
import sys
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ..agent import UMMAgent, UMMConnectionError
from ..capability import CapabilityMixin, make_capability, SubtypeSpec
from ..core.messages import MType, UMMMsg, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag
from ..core.registry import registry
from ..core.tlv import TLV, decode_all, TLV_INT, TLV_STRING, TLV_FLOAT, \
    TLV_BOOL, TLV_UINT, TLV_SHORT, TLV_USHORT, TLV_UTIME, TLV_COORD
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin

logger = logging.getLogger(__name__)

MT_DATABASE = MType.DATABASE   # 8

# Standard agent subtypes (GetCapability/GetVersion/SetDebug/Shutdown handled
# by mixins; we only declare application subtypes here).
ST_RECORD_SAVED  = 101   # DB → bus: published after a successful INSERT
ST_RECORD_ERROR  = 102   # DB → bus: published when an INSERT fails
ST_SET_NOTIFY    = 103   # bus → DB: Bool(enable) — turn record notifications on/off

# ── TLV type-name → type_id mapping ──────────────────────────────────────────

_NAME_TO_ID: Dict[str, int] = {
    'raw':          1,
    'int':          2,
    'uint':         3,
    'short':        4,
    'ushort':       5,
    'float':        6,
    'bool':         7,
    'char':         8,
    'utime':        9,
    'metadata':    10,
    'msg':         11,
    'attid':       12,
    'coord':       13,
    'fname':       14,
    'logid':       15,
    'msgref':      16,
    'routerid':    17,
    # manufacturing types loaded from registry at runtime (see _build_name_map)
}

_SENTINEL_MWORD = -1   # means "match first TLV of this type, any mword"


def _build_name_map() -> None:
    """Merge registry-known types into _NAME_TO_ID at startup."""
    for handler in registry:
        name = getattr(handler, 'TYPE_NAME', None)
        tid  = getattr(handler, 'TYPE_ID',   None)
        if name and tid:
            _NAME_TO_ID[name.lower()] = tid


# ── column spec ───────────────────────────────────────────────────────────────

@dataclass
class ColumnSpec:
    """One TLV → SQL column mapping parsed from the config file."""
    tlv_type_id: int          # TLV type_id to look for
    tlv_mword:   int          # mword to match; _SENTINEL_MWORD = any
    col_name:    str          # SQL column name
    sql_type:    str          # SQL type string (TEXT, INTEGER, REAL, …)

    def matches(self, tlv: TLV) -> bool:
        if tlv.type_id != self.tlv_type_id:
            return False
        if self.tlv_mword == _SENTINEL_MWORD:
            return True
        return tlv.match == self.tlv_mword


# ── table spec ────────────────────────────────────────────────────────────────

@dataclass
class TableSpec:
    """Everything needed to handle one (mtype, subtype) → table mapping."""
    table_name: str
    mtype:      int
    subtype:    int           # 0 = all subtypes
    columns:    List[ColumnSpec] = field(default_factory=list)


# ── config parser ─────────────────────────────────────────────────────────────

class DatabaseConfig:
    """Parses database.conf into backend settings and TableSpec objects."""

    def __init__(self, path: str) -> None:
        self.path     = path
        self.backend  = 'sqlite'
        self.db_path  = 'umm_data.db'   # sqlite
        self.host     = 'localhost'
        self.port     = 5432
        self.name     = 'ummdb'
        self.user     = ''
        self.password = ''
        self.tables:  List[TableSpec] = []
        self._parse()

    # ── TLV type spec parser ─────────────────────────────────────────────────
    #   Char[2]  -> col_name  SQL_TYPE
    #   Float    -> col_name  REAL
    _COL_RE = re.compile(
        r'^\s*'
        r'(?P<type>\w+)'            # type name
        r'(?:\[(?P<mword>\d+)\])?'  # optional [mword]
        r'\s*->\s*'
        r'(?P<col>\w+)'             # column name
        r'\s+'
        r'(?P<sql>\w+(?:\s+\w+)*)'  # SQL type (may be two words: NOT NULL etc.)
        r'\s*(?:#.*)?$'             # optional comment
    )

    def _parse_column(self, line: str) -> Optional[ColumnSpec]:
        m = self._COL_RE.match(line)
        if not m:
            return None
        type_name = m.group('type').lower()
        mword_str = m.group('mword')
        col_name  = m.group('col')
        sql_type  = m.group('sql').strip()

        type_id = _NAME_TO_ID.get(type_name)
        if type_id is None:
            # Try registry by exact name
            handler = registry.get_by_name(m.group('type'))
            if handler:
                type_id = handler.TYPE_ID
            else:
                logger.warning("Unknown TLV type name %r in config — column %r skipped",
                               m.group('type'), col_name)
                return None

        mword = int(mword_str) if mword_str is not None else _SENTINEL_MWORD
        return ColumnSpec(tlv_type_id=type_id, tlv_mword=mword,
                          col_name=col_name, sql_type=sql_type)

    def _parse(self) -> None:
        cfg = configparser.ConfigParser(
            allow_no_value=True,
            comment_prefixes=('#', ';'),
            inline_comment_prefixes=('#',),
        )
        cfg.read(self.path)

        if 'database' in cfg:
            db = cfg['database']
            self.backend  = db.get('backend',  'sqlite').lower().strip()
            self.db_path  = db.get('path',     'umm_data.db')
            self.host     = db.get('host',     'localhost')
            self.port     = db.getint('port',  5432)
            self.name     = db.get('name',     'ummdb')
            self.user     = db.get('user',     '')
            self.password = db.get('password', '')

        for section in cfg.sections():
            if not section.startswith('table.'):
                continue
            table_name = section[len('table.'):]
            sec = cfg[section]

            try:
                mtype   = int(sec.get('mtype',   '0'))
                subtype = int(sec.get('subtype', '0'))
            except ValueError as exc:
                logger.error("Config error in [%s]: %s", section, exc)
                continue

            # columns is a multi-line value; each non-blank line is one mapping
            raw_cols = sec.get('columns', '')
            columns: List[ColumnSpec] = []
            for line in raw_cols.splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                spec = self._parse_column(line)
                if spec:
                    columns.append(spec)

            if not columns:
                logger.warning("[%s] has no valid column mappings — skipped", section)
                continue

            self.tables.append(TableSpec(
                table_name=table_name,
                mtype=mtype,
                subtype=subtype,
                columns=columns,
            ))

        logger.info("Config loaded: backend=%s, %d table(s)", self.backend, len(self.tables))


# ── database backends ─────────────────────────────────────────────────────────

class _BackendBase:
    """Minimal interface all backends must implement."""

    def connect(self) -> None:
        raise NotImplementedError

    def ensure_table(self, spec: TableSpec) -> None:
        """CREATE TABLE IF NOT EXISTS with auto-columns + mapped columns."""
        raise NotImplementedError

    def insert(self, table_name: str,
               cols: List[str], values: List[Any]) -> None:
        raise NotImplementedError

    def close(self) -> None:
        pass


class _SQLiteBackend(_BackendBase):

    def __init__(self, path: str) -> None:
        self._path = path
        self._conn = None
        self._lock = threading.Lock()

    def connect(self) -> None:
        import sqlite3
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        logger.info("SQLite connected: %s", self._path)

    def ensure_table(self, spec: TableSpec) -> None:
        col_defs = [
            "id          INTEGER PRIMARY KEY AUTOINCREMENT",
            "received_at TEXT    NOT NULL",
            "origin_site INTEGER NOT NULL DEFAULT 0",
            "origin_node INTEGER NOT NULL DEFAULT 0",
            "msg_id      INTEGER NOT NULL DEFAULT 0",
        ]
        for c in spec.columns:
            col_defs.append(f"{c.col_name}  {c.sql_type}")
        ddl = (f"CREATE TABLE IF NOT EXISTS {spec.table_name} "
               f"({', '.join(col_defs)})")
        with self._lock:
            self._conn.execute(ddl)
            self._conn.commit()
        logger.info("Table ready: %s", spec.table_name)

    def insert(self, table_name: str,
               cols: List[str], values: List[Any]) -> None:
        placeholders = ', '.join('?' for _ in cols)
        sql = (f"INSERT INTO {table_name} ({', '.join(cols)}) "
               f"VALUES ({placeholders})")
        with self._lock:
            self._conn.execute(sql, values)
            self._conn.commit()

    def close(self) -> None:
        if self._conn:
            self._conn.close()


class _PostgresBackend(_BackendBase):

    def __init__(self, host: str, port: int, name: str,
                 user: str, password: str) -> None:
        self._host = host; self._port = port; self._name = name
        self._user = user; self._password = password
        self._conn = None
        self._lock = threading.Lock()

    def connect(self) -> None:
        try:
            import psycopg2
        except ImportError:
            raise RuntimeError(
                "psycopg2 is required for the postgres backend. "
                "Install it with:  pip install psycopg2-binary")
        self._conn = psycopg2.connect(
            host=self._host, port=self._port, dbname=self._name,
            user=self._user, password=self._password)
        self._conn.autocommit = False
        logger.info("PostgreSQL connected: %s@%s:%d/%s",
                    self._user, self._host, self._port, self._name)

    def ensure_table(self, spec: TableSpec) -> None:
        col_defs = [
            "id          BIGSERIAL PRIMARY KEY",
            "received_at TIMESTAMP NOT NULL",
            "origin_site INTEGER   NOT NULL DEFAULT 0",
            "origin_node INTEGER   NOT NULL DEFAULT 0",
            "msg_id      INTEGER   NOT NULL DEFAULT 0",
        ]
        for c in spec.columns:
            col_defs.append(f"{c.col_name}  {c.sql_type}")
        ddl = (f"CREATE TABLE IF NOT EXISTS {spec.table_name} "
               f"({', '.join(col_defs)})")
        with self._lock:
            cur = self._conn.cursor()
            cur.execute(ddl)
            self._conn.commit()
        logger.info("Table ready: %s", spec.table_name)

    def insert(self, table_name: str,
               cols: List[str], values: List[Any]) -> None:
        placeholders = ', '.join('%s' for _ in cols)
        sql = (f"INSERT INTO {table_name} ({', '.join(cols)}) "
               f"VALUES ({placeholders})")
        with self._lock:
            cur = self._conn.cursor()
            cur.execute(sql, values)
            self._conn.commit()

    def close(self) -> None:
        if self._conn:
            self._conn.close()


class _MySQLBackend(_BackendBase):

    def __init__(self, host: str, port: int, name: str,
                 user: str, password: str) -> None:
        self._host = host; self._port = port; self._name = name
        self._user = user; self._password = password
        self._conn = None
        self._lock = threading.Lock()

    def connect(self) -> None:
        try:
            import mysql.connector
        except ImportError:
            raise RuntimeError(
                "mysql-connector-python is required for the mysql backend. "
                "Install it with:  pip install mysql-connector-python")
        self._conn = mysql.connector.connect(
            host=self._host, port=self._port, database=self._name,
            user=self._user, password=self._password)
        logger.info("MySQL connected: %s@%s:%d/%s",
                    self._user, self._host, self._port, self._name)

    def ensure_table(self, spec: TableSpec) -> None:
        col_defs = [
            "id          BIGINT AUTO_INCREMENT PRIMARY KEY",
            "received_at DATETIME NOT NULL",
            "origin_site INT      NOT NULL DEFAULT 0",
            "origin_node INT      NOT NULL DEFAULT 0",
            "msg_id      INT      NOT NULL DEFAULT 0",
        ]
        for c in spec.columns:
            col_defs.append(f"`{c.col_name}`  {c.sql_type}")
        ddl = (f"CREATE TABLE IF NOT EXISTS `{spec.table_name}` "
               f"({', '.join(col_defs)})")
        with self._lock:
            cur = self._conn.cursor()
            cur.execute(ddl)
            self._conn.commit()
        logger.info("Table ready: %s", spec.table_name)

    def insert(self, table_name: str,
               cols: List[str], values: List[Any]) -> None:
        placeholders = ', '.join('%s' for _ in cols)
        col_list = ', '.join(f'`{c}`' for c in cols)
        sql = (f"INSERT INTO `{table_name}` ({col_list}) "
               f"VALUES ({placeholders})")
        with self._lock:
            cur = self._conn.cursor()
            cur.execute(sql, values)
            self._conn.commit()

    def close(self) -> None:
        if self._conn:
            self._conn.close()


def _make_backend(cfg: DatabaseConfig) -> _BackendBase:
    if cfg.backend == 'sqlite':
        return _SQLiteBackend(cfg.db_path)
    elif cfg.backend in ('postgres', 'postgresql'):
        return _PostgresBackend(cfg.host, cfg.port, cfg.name,
                                cfg.user, cfg.password)
    elif cfg.backend == 'mysql':
        return _MySQLBackend(cfg.host, cfg.port, cfg.name,
                             cfg.user, cfg.password)
    else:
        raise ValueError(f"Unknown database backend: {cfg.backend!r}. "
                         f"Supported: sqlite, postgres, mysql")


# ── TLV value extraction ──────────────────────────────────────────────────────

def _extract_value(tlv: TLV) -> Any:
    """
    Decode a TLV's raw bytes into a Python value suitable for SQL insertion.

    Falls back to the registry handler's unpack() if available, otherwise
    returns the raw bytes as a hex string so nothing is silently dropped.
    """
    tid = tlv.type_id
    val = tlv.value

    # Fast path for common built-in types
    try:
        if tid == 2:   return struct.unpack('!i', val)[0]          # Int
        if tid == 3:   return struct.unpack('!I', val)[0]          # UInt
        if tid == 4:   return struct.unpack('!h', val)[0]          # Short
        if tid == 5:   return struct.unpack('!H', val)[0]          # UShort
        if tid == 6:   return struct.unpack('!d', val)[0]          # Float
        if tid == 7:   return bool(struct.unpack('!I', val)[0])    # Bool
        if tid == 8:   return val.rstrip(b'\x00').decode('utf-8', errors='replace')  # Char
        if tid == 9:                                                # UTime
            if len(val) >= 8:
                secs, ms = struct.unpack_from('!II', val)
                ts = secs + ms / 1000.0
                return datetime.datetime.utcfromtimestamp(ts).isoformat()
    except struct.error:
        pass

    # Try registry handler
    handler = registry.get_by_id(tid)
    if handler:
        try:
            return handler.unpack(val)
        except Exception:
            pass

    # Last resort: hex string
    return val.hex()


# ── main module ───────────────────────────────────────────────────────────────

class DatabaseModule(DebugMixin, VersionMixin, ShutdownMixin, CapabilityMixin):
    """
    UMM Database agent.

    Subscribes to messages as configured, extracts TLV values, and inserts
    rows into the configured SQL database.
    """

    AGENT_VERSION = "1.0.0"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    CAPABILITY = make_capability(
        what        = 'Database',
        mtype       = MT_DATABASE,
        description = 'Subscribes to UMM messages and writes rows to a SQL database.',
        subtypes    = [
            SubtypeSpec(subtype=101, name='RecordSaved', direction='out',
                        description='Published after a successful INSERT. '
                                    'Char(table_name) Int(mtype) Int(subtype). '
                                    'Only sent when notifications enabled (--notify or ST_SET_NOTIFY).'),
            SubtypeSpec(subtype=102, name='RecordError', direction='out',
                        description='Published when an INSERT fails. '
                                    'Char(table_name) Char(error_message). '
                                    'Always sent regardless of notify flag.'),
            SubtypeSpec(subtype=103, name='SetNotify', direction='in',
                        description='Enable/disable RecordSaved notifications. '
                                    'Bool(1=enable, 0=disable). '
                                    'Persists until changed or agent restarts.'),
        ],
        author = 'Realtime Software Pty Ltd',
        notes  = 'Configure subscriptions and column mappings in database.conf.',
    )

    def __init__(self,
                 config_file: str = 'database.conf',
                 host:        str = 'localhost',
                 port:        int = DEFAULT_PORT,
                 process_name: str = 'Database',
                 create_tables: bool = False,
                 notify: bool = False,
                 agent_type: int = None) -> None:
        # Allow overriding the agent mtype for a project-scoped instance
        # (e.g. a tank-project database on 5008 instead of the default 8).
        global MT_DATABASE
        if agent_type is not None:
            MT_DATABASE = agent_type
        self.host          = host
        self.port          = port
        self.process_name  = process_name
        self.create_tables = create_tables
        self._notify       = notify   # publish RecordSaved/RecordError to bus

        _build_name_map()
        self._config  = DatabaseConfig(config_file)
        self._backend = _make_backend(self._config)
        self._client  = UMMAgent(host=host, port=port,
                                  process_name  = process_name,
                                  agent_mtype   = MT_DATABASE,
                                  flags         = AttachFlag.NORMAL)
        # Map table_name → TableSpec for quick lookup in callbacks
        self._table_map: Dict[str, TableSpec] = {}

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Connect to the router and start recording."""
        self._backend.connect()

        if not self._client.connect():
            raise RuntimeError("Database agent: could not connect to router")

        # Standard handlers (capability/version/debug/shutdown).
        # If this instance uses a non-default mtype (agent_type was
        # overridden, e.g. type=1008 in umm.conf), patch the capability
        # descriptor so the content-match subscription uses the correct
        # mtype — same treatment as timer.py.
        from dataclasses import replace as _replace
        cap = self.CAPABILITY
        if int(MT_DATABASE) != int(MType.DATABASE):
            cap = _replace(cap, mtype=int(MT_DATABASE))
        self.CAPABILITY = cap
        self.register_capability_handler(self._client,
                                         instance=self.process_name)
        self.register_version_handler(self._client, MT_DATABASE)
        self.register_debug_handler(self._client, MT_DATABASE,
                                    debug=getattr(self, '_debug_flag', False))
        self.register_shutdown_handler(self._client, MT_DATABASE)

        # SetNotify handler — allows runtime toggle of RecordSaved notifications
        self._client.register(
            mtype    = MT_DATABASE,
            subtype  = ST_SET_NOTIFY,
            callback = self._on_set_notify,
        )
        logger.info("Notifications %s (use --notify to enable at startup, "
                    "or send SetNotify(103) to toggle)",
                    "ON" if self._notify else "OFF")

        if not self._config.tables:
            logger.warning("No table mappings configured — agent will run but record nothing.")

        for spec in self._config.tables:
            self._table_map[spec.table_name] = spec

            if self.create_tables:
                try:
                    self._backend.ensure_table(spec)
                except Exception as exc:
                    logger.error("Failed to create table %s: %s", spec.table_name, exc)
                    # Non-fatal — table may already exist

            # Register the subscription for this (mtype, subtype)
            self._client.register(
                mtype    = spec.mtype,
                subtype  = spec.subtype if spec.subtype != 0 else 0,
                callback = self._make_handler(spec),
            )
            self.log_info("Subscribed: mtype=%d subtype=%d → table=%s (%d columns)",
                          spec.mtype, spec.subtype, spec.table_name, len(spec.columns))

        logger.info("Database agent running (backend=%s)", self._config.backend)
        self._client.run()

    def _on_reconnect(self) -> None:
        """Re-register all subscriptions after reconnecting to the router.

        The router has been queuing messages for us (PERM_KEEP_CONN) and will
        flush them once we send our final registration with LAST_REQUEST set.
        The agent framework handles LAST_REQUEST automatically on the last
        register() call — we just need to re-register everything.
        """
        logger.info("Database agent reconnected — re-registering %d subscription(s)",
                    len(self._config.tables))
        for spec in self._config.tables:
            self._client.register(
                mtype    = spec.mtype,
                subtype  = spec.subtype if spec.subtype != 0 else 0,
                callback = self._make_handler(spec),
            )
            logger.info("Re-subscribed: mtype=%d subtype=%d → table=%s",
                        spec.mtype, spec.subtype, spec.table_name)

    def _on_shutdown_request(self) -> None:
        """Flush and close DB connection before exiting."""
        logger.info("Database agent shutting down — closing connection")
        try:
            self._backend.close()
        except Exception:
            pass
        super()._on_shutdown_request()

    # ── notify toggle ─────────────────────────────────────────────────────────

    def _on_set_notify(self, msg: UMMMsg) -> None:
        """Handle SetNotify(103) — Bool(1=enable, 0=disable)."""
        enabled = False
        if msg.tdata and msg.tdata.value:
            try:
                tlvs = decode_all(msg.tdata.value)
                for tlv in tlvs:
                    if tlv.type_id == TLV_BOOL and len(tlv.value) >= 4:
                        enabled = bool(struct.unpack('!I', tlv.value[:4])[0])
                        break
                    # Also accept Int as convenience
                    if tlv.type_id == TLV_INT and len(tlv.value) >= 4:
                        enabled = bool(struct.unpack('!i', tlv.value[:4])[0])
                        break
            except Exception as exc:
                logger.warning("SetNotify: could not parse Bool TLV: %s", exc)
                return
        self._notify = enabled
        logger.info("Notifications %s via SetNotify message", "ON" if enabled else "OFF")
        self.log_info("Database notifications %s", "enabled" if enabled else "disabled")

    # ── message handler factory ───────────────────────────────────────────────

    def _make_handler(self, spec: TableSpec):
        """Return a callback closure bound to *spec*."""
        def _on_message(msg: UMMMsg) -> None:
            self._record(msg, spec)
        _on_message.__name__ = f'_on_{spec.table_name}'
        return _on_message

    # ── row builder ───────────────────────────────────────────────────────────

    def _record(self, msg: UMMMsg, spec: TableSpec) -> None:
        """Extract TLV values from *msg* and INSERT a row."""

        # Auto-columns
        now         = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds')
        origin_site = msg.origin.router if hasattr(msg, 'origin') else 0
        origin_node = msg.origin.id     if hasattr(msg, 'origin') else 0
        msg_id      = getattr(msg, 'msg_id', 0) or 0

        cols:   List[str] = ['received_at', 'origin_site', 'origin_node', 'msg_id']
        values: List[Any] = [now, origin_site, origin_node, msg_id]

        # Decode the TLV payload
        raw_tlvs: List[TLV] = []
        if msg.tdata and msg.tdata.value:
            try:
                raw_tlvs = decode_all(msg.tdata.value)
            except Exception as exc:
                logger.warning("TLV decode error for table %s: %s", spec.table_name, exc)

        # For each column spec, find the matching TLV.
        # TLVs with a sentinel mword are matched positionally against the
        # remaining unmatched TLVs of that type_id.
        # TLVs with an explicit mword are matched by (type_id, mword) exactly.
        used: set = set()   # indices of TLVs already consumed

        # First pass: exact mword matches (avoids stealing from positional)
        exact_matches: Dict[int, TLV] = {}   # col_index → tlv
        for ci, col in enumerate(spec.columns):
            if col.tlv_mword == _SENTINEL_MWORD:
                continue
            for ti, tlv in enumerate(raw_tlvs):
                if ti not in used and col.matches(tlv):
                    exact_matches[ci] = tlv
                    used.add(ti)
                    break

        # Second pass: positional matches for sentinel-mword columns
        positional_matches: Dict[int, TLV] = {}
        for ci, col in enumerate(spec.columns):
            if col.tlv_mword != _SENTINEL_MWORD:
                continue
            for ti, tlv in enumerate(raw_tlvs):
                if ti not in used and tlv.type_id == col.tlv_type_id:
                    positional_matches[ci] = tlv
                    used.add(ti)
                    break

        # Build the column/value lists in config order
        for ci, col in enumerate(spec.columns):
            tlv = exact_matches.get(ci) or positional_matches.get(ci)
            if tlv is not None:
                cols.append(col.col_name)
                values.append(_extract_value(tlv))
            else:
                # Column not present in this message — insert NULL
                cols.append(col.col_name)
                values.append(None)
                self.log_debug("No TLV for column %s.%s in mtype=%d subtype=%d",
                              spec.table_name, col.col_name, msg.mtype, msg.subtype)

        # Write to database
        insert_ok  = False
        insert_exc = None
        try:
            self._backend.insert(spec.table_name, cols, values)
            insert_ok = True
            self.log_debug("Saved row to %s (mtype=%d subtype=%d)",
                          spec.table_name, msg.mtype, msg.subtype)
        except Exception as exc:
            insert_exc = exc
            logger.error("Insert failed for table %s: %s", spec.table_name, exc)

        # Publish result outside the insert try/except, and fire-and-forget
        # (no .result() wait) — we are inside a callback running on the agent's
        # event loop thread, so blocking send() would deadlock.
        def _notify(subtype: int, tlvs: list) -> None:
            try:
                import asyncio as _asyncio
                loop = self._client._loop
                if loop and loop.is_running():
                    loop.call_soon_threadsafe(
                        lambda: loop.create_task(
                            self._client._async_send(MT_DATABASE, subtype, tlvs, 0)
                        )
                    )
            except Exception:
                pass

        if insert_ok:
            if self._notify:
                _notify(ST_RECORD_SAVED, [
                    TLV(type_id=TLV_STRING, value=spec.table_name.encode() + b'\x00'),
                    TLV(type_id=TLV_INT,    value=struct.pack('!i', msg.mtype)),
                    TLV(type_id=TLV_INT,    value=struct.pack('!i', msg.subtype)),
                ])
        else:
            # Errors always notify regardless of the flag — silent failures are worse
            _notify(ST_RECORD_ERROR, [
                TLV(type_id=TLV_STRING, value=spec.table_name.encode() + b'\x00'),
                TLV(type_id=TLV_STRING, value=str(insert_exc).encode() + b'\x00'),
            ])


# ── CLI entry point ───────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    p = argparse.ArgumentParser(description='UMM Database agent')
    p.add_argument('--config',  default='database.conf',
                   help='Config file (default: database.conf)')
    p.add_argument('--router',  default='localhost', dest='host')
    p.add_argument('--port',    type=int, default=DEFAULT_PORT)
    p.add_argument('--name',    default='Database')
    p.add_argument('--type',    type=int, default=None, dest='agent_type',
                   help='Override agent mtype for a project-scoped instance (default: 8)')
    p.add_argument('--create-tables', action='store_true', dest='create_tables',
                   help='CREATE TABLE IF NOT EXISTS on startup (safe for new installs)')
    p.add_argument('--notify', action='store_true', default=False,
                   help='Publish RecordSaved(101) to the bus after each successful INSERT. '
                        'Off by default — can also be toggled at runtime via SetNotify(103).')
    p.add_argument('--version', action='store_true',
                   help='Show version and exit')
    p.add_argument('--debug',     action='store_true')
    p.add_argument('--permanent', action='store_true',
                   help='Attach with PERM_KEEP_CONN (set automatically by supervisor for C agents)')
    args = p.parse_args()

    if args.version:
        print(UMM_VERSION_STR)
        return

    svc = DatabaseModule(
        config_file   = args.config,
        host          = args.host,
        port          = args.port,
        process_name  = args.name,
        create_tables = args.create_tables,
        notify        = args.notify,
        agent_type    = args.agent_type,
    )
    svc._debug_flag = args.debug
    if args.permanent:
        svc._client.attach_flags = AttachFlag.PERM_KEEP_CONN
        svc._client.reconnect    = True
        svc._client.on_reconnect = svc._on_reconnect
    try:
        svc.run()
    except KeyboardInterrupt:
        print("\nDatabase agent stopped.")


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)
    except (ValueError, RuntimeError) as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)