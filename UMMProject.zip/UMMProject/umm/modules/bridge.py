"""
umm.modules.bridge
==================
UMM Bridge — connects two UMM routers so that agents on either side
can subscribe to messages from the other side.

Pass-on-request model
---------------------
Subscriptions are local by default.  An agent that wants messages from
a remote router includes a RouterId TLV in its match criteria::

    from umm.types.builtin import RouterIdType

    agent.register(
        mtype      = 100,
        subtype    = 1,
        callback   = on_msg,
        match_tlvs = [RouterIdType.make_tlv(1, 3)],  # site=1, node=3
    )

The bridge subscribes to (UMM, REGISTER) and (UMM, UNREGISTER) on each
router — the same messages any other agent can subscribe to.  When a
Register message arrives with a RouterId TLV in its match criteria, the
bridge strips the RouterId TLV and mirrors the subscription on the
remote router.  Matching messages are forwarded back with loop detection.

The router requires no changes.

Loop detection
--------------
Before forwarding A→B the bridge checks whether the message's
attach_id.router has been seen arriving *from* B.  If so the message
originated on the B-side and has looped — drop it.  Router IDs age out
after LOOP_TTL seconds.

Running standalone::

    python -m umm.modules.bridge \\
        --router-a localhost:5300 \\
        --router-b 192.168.1.2:5300
"""

from __future__ import annotations

import logging
import struct
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple

from ..agent import UMMAgent
from ..capability import CapabilityMixin, make_capability, SubtypeSpec
from ..core.tlv import (
    TLV, TLVBuffer, decode_all,
    TLV_INT, TLV_STRING, TLV_JSON, TLV_MSG, TLV_SUBSPEC, TLV_ROUTER_ID,
)
from ..core.messages import MType, UMMSubType, UMMMsg, UMM_VERSION_STR, Channel
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin, HeartbeatMixin

logger = logging.getLogger(__name__)

# ── subtype constants (mtype = MType.BRIDGE = 11) ────────────────────────────

ST_FORWARD_REQ   = 101   # Agent→Bridge: request forwarding of (mtype, subtype) from far router
ST_FORWARD_ACK   = 102   # Bridge→Agent: ack with far router_id; forwarded msgs on channel=BRIDGE
ST_STATUS        = 103
ST_STATUS_REPLY  = 104
ST_HEARTBEAT     = 105   # Bridge heartbeat ping/pong for B-side liveness
ST_ROUTER_SEEN   = 106   # Bridge→*: newly observed remote router
ST_ROUTER_GONE   = 107   # Bridge→*: remote router timed out

LOOP_TTL = 60.0   # seconds before a router ID ages out of the loop table

HB_INTERVAL   = 10.0   # seconds between heartbeat pings to router B
HB_TIMEOUT    = 30.0   # seconds without a pong before treating B as dead

BRIDGE_CAPABILITY = make_capability(
    what        = 'Bridge',
    mtype       = MType.BRIDGE,
    description = 'Inter-router bridge. Forwards subscriptions to a remote router '
                  'and delivers matching messages back on channel=BRIDGE(7).',
    subtypes    = [
        SubtypeSpec(subtype=101, name='ForwardRequest', direction='in',
                    description='Request forwarding of messages from the far router. '
                                'Payload: Int(mtype) Int(subtype) — use 0,0 for all messages. '
                                'Bridge mirrors the subscription on the far router. '
                                'Matching messages forwarded back on channel=BRIDGE(7). '
                                'Subscribe locally to (mtype, subtype, channel=7) to receive.',
                    response_subtype=102),
        SubtypeSpec(subtype=102, name='ForwardAck',    direction='out',
                    description='Ack for ForwardRequest. Payload: Int(far_router_id).',
                    responds_to=101),
        SubtypeSpec(subtype=103, name='Status',        direction='in',
                    description='Request bridge status.',
                    response_subtype=104),
        SubtypeSpec(subtype=104, name='StatusReply',   direction='out',
                    description='Bridge status (JSON): router addresses, '
                                'sub counts, seen router IDs.',
                    responds_to=103),
        SubtypeSpec(subtype=106, name='RouterSeen',    direction='out',
                    description='Int(site) Int(node) Char(side) — '
                                'newly observed remote router.'),
        SubtypeSpec(subtype=105, name='Heartbeat',     direction='internal',
                    description='Bridge B-side liveness probe. '
                                'Bridge periodically pings router B; if no pong '
                                'arrives within the timeout the socket is closed '
                                'to force reconnect and subscription re-mirroring. '
                                f'Default interval={HB_INTERVAL}s, timeout={HB_TIMEOUT}s.'),
        SubtypeSpec(subtype=107, name='RouterGone',    direction='out',
                    description='Int(site) Int(node) — '
                                'remote router timed out of loop table.'),
        SubtypeSpec(subtype=110, name='RemoteSubscribe', direction='info',
                    description='ALTERNATIVE: RouterId TLV in subscription match_tlvs. '
                                'Include TLV type_id=17, value=site(2 NBO)+node(2 NBO). '
                                'Use (0,0) wildcard for any remote router. '
                                'Forwarded messages arrive on channel=BRIDGE(7). '
                                'Example: match_tlvs=[RouterIdType.make_tlv(site=1, node=2)]'),
    ],
    author = 'Realtime Software Pty Ltd',
)


# ── helpers ───────────────────────────────────────────────────────────────────

def strip_router_id_tlv(match_bytes: bytes) -> Tuple[Optional[Tuple[int, int]], bytes]:
    """
    Scan match_bytes for a TLV_ROUTER_ID TLV.

    Returns (router_id_tuple, stripped_bytes) where:
      - router_id_tuple is (site, node) if a RouterId TLV was found, else None
      - stripped_bytes is match_bytes with the RouterId TLV removed

    (0, 0) is a valid wildcard meaning "any remote router".
    """
    if not match_bytes:
        return None, match_bytes
    try:
        tlvs = decode_all(match_bytes)
    except Exception:
        return None, match_bytes

    router_id: Optional[Tuple[int, int]] = None
    kept: List[TLV] = []
    for tlv in tlvs:
        if tlv.type_id == TLV_ROUTER_ID and len(tlv.value) >= 4:
            site, node = struct.unpack_from('!HH', tlv.value)
            router_id = (site, node)
        else:
            kept.append(tlv)

    if router_id is None:
        return None, match_bytes

    if kept:
        buf = TLVBuffer()
        buf.add_all(kept)
        return router_id, buf.encode()
    return router_id, b''


def parse_register_msg(msg: UMMMsg) -> Optional[Tuple[int, int, int, int, bytes]]:
    """
    Extract (reg_id, mtype, subtype, channel, match_bytes) from a
    (UMM, REGISTER) message as published by the router.

    The TData contains a TLV_SUBSPEC whose value is:
        mtype(4) subtype(4) match_tlv_bytes

    The subscription channel comes from the message header (msg.channel).

    Returns None if the message cannot be parsed.
    """
    if not msg.tdata.value:
        return None
    try:
        for tlv in decode_all(msg.tdata.value):
            if tlv.type_id == TLV_SUBSPEC and len(tlv.value) >= 8:
                sub_mtype, sub_subtype = struct.unpack_from('!ii', tlv.value, 0)
                sub_channel = msg.channel  # ← from header
                match_bytes = tlv.value[8:]
                return msg.reg_id, sub_mtype, sub_subtype, sub_channel, match_bytes
    except Exception as exc:
        logger.warning("Bridge: could not parse Register message: %s", exc)
    return None


# ── B-side heartbeat ─────────────────────────────────────────────────────────

class BridgeHeartbeat:
    """
    Liveness probe for the bridge's B-side connection.

    Normally silent — no traffic is generated when messages are flowing
    across the bridge.  Only when the connection has been quiet for
    ``quiet_threshold`` seconds does the probe send a single ping.  If no
    pong (or any other B-side traffic) comes back within ``timeout`` seconds
    the B-side socket is closed, forcing the agent's reconnect loop to
    re-establish the connection.

    Call ``start(agent)`` after the B-side agent connects (and again on
    each reconnect via ``_on_side_b_connect``).
    Call ``note_activity()`` from any B-side message callback.
    Call ``stop()`` on bridge shutdown.
    """

    def __init__(self,
                 quiet_threshold: float = HB_INTERVAL,
                 timeout:         float = HB_TIMEOUT) -> None:
        self.quiet_threshold = quiet_threshold
        self.timeout         = timeout

        self._agent:         Optional[UMMAgent] = None
        self._seq:           int   = 0
        self._last_activity: float = 0.0   # monotonic; updated by any B-side traffic
        self._ping_sent_at:  float = 0.0   # when we sent the current outstanding ping
        self._waiting_pong:  bool  = False  # True while awaiting a pong
        self._running:       bool  = False
        self._thread:        Optional[threading.Thread] = None
        self._pong_reg:      Optional[int] = None

    # ── public API ────────────────────────────────────────────────────────────

    def start(self, agent: 'UMMAgent') -> None:
        """Attach to *agent*.  Safe to call again after a reconnect."""
        self._agent          = agent
        self._last_activity  = time.monotonic()
        self._waiting_pong   = False
        self._sub_pong()

        if not self._running:
            self._running = True
            self._thread  = threading.Thread(
                target=self._loop, name='bridge-heartbeat', daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._running = False

    def note_activity(self) -> None:
        """Call from any B-side message callback to record that B is alive."""
        self._last_activity = time.monotonic()
        self._waiting_pong  = False   # any traffic counts as proof of liveness

    # ── internals ─────────────────────────────────────────────────────────────

    def _sub_pong(self) -> None:
        from ..core.messages import HeartbeatSubType
        if not self._agent:
            return
        if self._pong_reg is not None:
            try:
                self._agent.unregister(self._pong_reg)
            except Exception:
                pass
        self._pong_reg = self._agent.register(
            mtype          = int(MType.UMM),
            subtype        = int(HeartbeatSubType.PONG),
            callback       = self._on_pong,
            channel        = int(Channel.HEARTBEAT),
            dont_send_self = False,
        )

    def _on_pong(self, msg: UMMMsg) -> None:
        logger.debug("Bridge heartbeat: pong received (seq=%d)", self._seq)
        self.note_activity()

    def _send_ping(self) -> None:
        from ..core.messages import HeartbeatSubType
        if not self._agent or not self._agent.is_attached:
            return
        self._seq = (self._seq + 1) & 0x7FFFFFFF
        try:
            self._agent.send(
                mtype   = int(MType.UMM),
                subtype = int(HeartbeatSubType.PING),
                tlvs    = [TLV(type_id=TLV_INT,
                               value=struct.pack('!i', self._seq))],
                channel = int(Channel.HEARTBEAT),
            )
            self._ping_sent_at = time.monotonic()
            self._waiting_pong = True
            logger.debug("Bridge heartbeat: ping sent (seq=%d) after %.0fs quiet",
                         self._seq, self._ping_sent_at - self._last_activity)
        except Exception as exc:
            logger.warning("Bridge heartbeat: ping send failed: %s", exc)

    def _force_reconnect(self) -> None:
        if not self._agent:
            return
        logger.warning("Bridge heartbeat: no response after %.0fs — forcing reconnect",
                       self.timeout)
        self._waiting_pong = False
        writer = self._agent._writer
        if writer:
            try:
                writer.close()
            except Exception:
                pass

    def _loop(self) -> None:
        """Monitor thread: check every second, ping only when quiet."""
        while self._running:
            time.sleep(1.0)
            if not self._running:
                break
            if not self._agent or not self._agent.is_attached:
                continue

            now   = time.monotonic()
            quiet = now - self._last_activity

            if self._waiting_pong:
                if now - self._ping_sent_at > self.timeout:
                    self._force_reconnect()
                    self._last_activity = time.monotonic()
            elif quiet > self.quiet_threshold:
                self._send_ping()


# ── per-side connection ───────────────────────────────────────────────────────

class RouterSide:
    """
    One connection in the bridge pair.

    Subscribes to (UMM, REGISTER) and (UMM, UNREGISTER) on its router.
    Tracks mirrored subscriptions and router IDs seen for loop detection.
    """

    def __init__(self,
                 label:      str,
                 host:       str,
                 port:       int,
                 mtype:      int,
                 on_sub_add: Callable[[int, int, int, int, bytes], None],
                 on_sub_rem: Callable[[int], None],
                 on_connect: Optional[Callable[[], None]] = None) -> None:
        self.label      = label
        self.host       = host
        self.port       = port
        self.mtype      = mtype
        self._on_add    = on_sub_add
        self._on_rem    = on_sub_rem
        self._on_connect = on_connect

        # remote_reg_id → (local_reg_id, mtype, subtype, match_bytes, channel, on_msg)
        self._mirrored: Dict[int, Tuple[int, int, int, bytes, int, Callable]] = {}

        # router_id → last_seen monotonic timestamp (loop detection)
        self._seen_routers: Dict[int, float] = {}

        self._agent = UMMAgent(
            host         = host,
            port         = port,
            process_name = f'UMMBridge-{label}',
            agent_mtype  = mtype,
            reconnect    = True,
            on_reconnect = on_connect,   # fires on every subsequent reconnect
        )

    def connect(self) -> bool:
        ok = self._agent.connect()
        if ok:
            # Subscribe to registration lifecycle events on this router
            self._agent.register(MType.UMM, UMMSubType.REGISTER,   self._on_register)
            self._agent.register(MType.UMM, UMMSubType.UNREGISTER, self._on_unregister)
            if self._on_connect:
                try:
                    self._on_connect()
                except Exception as exc:
                    logger.error("Bridge side %s on_connect failed: %s",
                                 self.label, exc, exc_info=True)
            logger.info("Bridge side %s connected to %s:%d", self.label, self.host, self.port)
        else:
            logger.warning("Bridge side %s could not connect to %s:%d",
                           self.label, self.host, self.port)
        return ok

    def run(self) -> None:
        self._agent.run()

    # ── registration event handlers ───────────────────────────────────────────

    def _on_register(self, msg: UMMMsg) -> None:
        parsed = parse_register_msg(msg)
        if parsed is None:
            return
        reg_id, sub_mtype, sub_subtype, sub_channel, match_bytes = parsed

        router_id_tuple, stripped = strip_router_id_tlv(match_bytes)
        if router_id_tuple is None:
            return   # local subscription — not our concern

        logger.info("Bridge %s: Register with RouterId %d.%d — "
                    "reg=%d mtype=%d subtype=%d",
                    self.label, router_id_tuple[0], router_id_tuple[1],
                    reg_id, sub_mtype, sub_subtype)
        self._on_add(reg_id, sub_mtype, sub_subtype, sub_channel, stripped)

    def _on_unregister(self, msg: UMMMsg) -> None:
        self._on_rem(msg.reg_id)

    # ── subscription mirroring ────────────────────────────────────────────────

    def mirror_sub(self, local_reg_id: int,
                   mtype: int, subtype: int,
                   match_bytes: bytes, channel: int,
                   on_msg: Callable[[UMMMsg], None]) -> Optional[int]:
        """Register mtype/subtype/match_bytes on this router; deliver to on_msg."""
        tlv_list: Optional[List[TLV]] = None
        if match_bytes:
            try:
                tlv_list = decode_all(match_bytes)
            except Exception as exc:
                logger.warning("Bridge %s: bad match bytes: %s", self.label, exc)
                return None

        remote_reg_id = self._agent.register(
            mtype      = mtype,
            subtype    = subtype,
            callback   = on_msg,
            match_tlvs = tlv_list,
            channel    = channel,
        )
        self._mirrored[remote_reg_id] = (local_reg_id, mtype, subtype, match_bytes, channel, on_msg)
        logger.info("Bridge %s: mirrored mtype=%d subtype=%d "
                    "local_reg=%d remote_reg=%d",
                    self.label, mtype, subtype, local_reg_id, remote_reg_id)
        return remote_reg_id

    def unmirror_sub(self, local_reg_id: int) -> None:
        for remote_reg_id, spec in list(self._mirrored.items()):
            if spec[0] == local_reg_id:
                self._agent.unregister(remote_reg_id)
                del self._mirrored[remote_reg_id]
                logger.info("Bridge %s: unmirrored local_reg=%d",
                            self.label, local_reg_id)
                return

    # ── message forwarding ────────────────────────────────────────────────────

    def forward(self, msg: UMMMsg) -> None:
        tlvs: Optional[List[TLV]] = None
        if msg.tdata.value:
            try:
                tlvs = decode_all(msg.tdata.value)
            except Exception:
                pass
        self._agent.send(
            mtype   = msg.mtype,
            subtype = msg.subtype,
            tlvs    = tlvs,
            channel = msg.channel,
        )

    # ── loop detection ────────────────────────────────────────────────────────

    def record_router(self, router_id: int) -> bool:
        """Record router_id seen from this side. Returns True if newly observed."""
        is_new = router_id not in self._seen_routers
        self._seen_routers[router_id] = time.monotonic()
        return is_new

    def has_router(self, router_id: int) -> bool:
        ts = self._seen_routers.get(router_id)
        if ts is None:
            return False
        if time.monotonic() - ts > LOOP_TTL:
            del self._seen_routers[router_id]
            return False
        return True

    def expire_routers(self) -> List[int]:
        now     = time.monotonic()
        expired = [rid for rid, ts in list(self._seen_routers.items())
                   if now - ts > LOOP_TTL]
        for rid in expired:
            del self._seen_routers[rid]
        return expired

    def sub_count(self) -> int:
        return len(self._mirrored)

    def seen_routers(self) -> Dict[int, float]:
        return dict(self._seen_routers)


# ── bridge module ─────────────────────────────────────────────────────────────

class BridgeModule(CapabilityMixin, DebugMixin, VersionMixin, ShutdownMixin, HeartbeatMixin):
    """
    UMM Bridge.

    Connects two routers symmetrically.  Subscribes to (UMM, REGISTER) and
    (UMM, UNREGISTER) on each router — no router changes required.  When a
    subscription with a RouterId TLV arrives, mirrors it on the far side and
    forwards matching messages back with loop detection.

    Responds to GetCapability, GetVersion, SetDebug, and Shutdown on both
    sides, just like any other standard UMM agent.
    """

    CAPABILITY = BRIDGE_CAPABILITY

    def __init__(self,
                 host_a:      str   = 'localhost', port_a:    int   = 5300,
                 host_b:      str   = 'localhost', port_b:    int   = 5301,
                 mtype_a:     int   = MType.BRIDGE,
                 mtype_b:     int   = 111,
                 debug:       bool  = False,
                 hb_interval: float = HB_INTERVAL,
                 hb_timeout:  float = HB_TIMEOUT) -> None:
        self.host_a  = host_a
        self.port_a  = port_a
        self.host_b  = host_b
        self.port_b  = port_b
        self.mtype_a = mtype_a
        self.mtype_b = mtype_b
        self._debug_startup = debug

        self._heartbeat = BridgeHeartbeat(quiet_threshold=hb_interval, timeout=hb_timeout)

        self._side_a = RouterSide('A', host_a, port_a, mtype=mtype_a,
                                   on_sub_add = self._sub_add_from_a,
                                   on_sub_rem = self._sub_rem_from_a)
        self._side_b = RouterSide('B', host_b, port_b, mtype=mtype_b,
                                   on_sub_add = self._sub_add_from_b,
                                   on_sub_rem = self._sub_rem_from_b,
                                   on_connect = self._on_side_b_connect)

    def run(self) -> None:
        # A-side must succeed — it's the local router
        if not self._side_a.connect():
            raise RuntimeError(
                f"Bridge: could not connect to Router A ({self.host_a}:{self.port_a})")

        # Register standard subtypes on A
        self._register_side_handlers(self._side_a)
        self.register_shutdown_handler(self._side_a._agent, self.mtype_a)

        logger.info("UMM Bridge running: %s:%d (mtype=%d) ↔ %s:%d (mtype=%d)",
                    self.host_a, self.port_a, self.mtype_a,
                    self.host_b, self.port_b, self.mtype_b)

        # B-side runs in its own thread with retry logic
        threading.Thread(target=self._expiry_loop, daemon=True).start()
        threading.Thread(target=self._run_side_b, name='bridge-b', daemon=True).start()
        self._side_a.run()   # blocks
        self._heartbeat.stop()

    def _on_side_b_connect(self) -> None:
        """
        Called each time side B (re)connects — initial connect or after a
        router-B outage.  Re-registers standard handlers, restarts the
        heartbeat, re-mirrors previously active subscriptions, then asks
        router A for its full subscription table to catch any registrations
        that arrived while the bridge was down.
        """
        self._register_side_handlers(self._side_b)

        # Restart the heartbeat with the fresh agent
        self._heartbeat.start(self._side_b._agent)
        logger.info("Bridge side B heartbeat started "
                    "(quiet_threshold=%.0fs timeout=%.0fs)",
                    self._heartbeat.quiet_threshold, self._heartbeat.timeout)

        # Re-mirror subscriptions that were active on B before the disconnect.
        stale_specs = list(self._side_b._mirrored.values())
        self._side_b._mirrored.clear()

        if stale_specs:
            logger.info("Bridge side B reconnected — re-mirroring %d subscription(s)",
                        len(stale_specs))
            for (local_reg_id, mtype, subtype,
                 match_bytes, channel, on_msg) in stale_specs:
                self._side_b.mirror_sub(
                    local_reg_id = local_reg_id,
                    mtype        = mtype,
                    subtype      = subtype,
                    match_bytes  = match_bytes,
                    channel      = channel,
                    on_msg       = on_msg,
                )

        # Ask router A for its full subscription table so we catch any
        # RouterId-bearing registrations that arrived while the bridge was down.
        threading.Thread(target=self._replay_subs_from_a,
                         name='bridge-replay', daemon=True).start()

    def _replay_subs_from_a(self) -> None:
        """
        Request the current subscription table from router A and mirror any
        RouterId-bearing subscriptions that aren't already mirrored.

        Runs in a short-lived thread so it doesn't block _on_side_b_connect.
        """
        import json as _json

        already_mirrored = {spec[0]  # local_reg_id
                            for spec in self._side_b._mirrored.values()}

        result: list = []
        ev = threading.Event()

        def on_response(msg: UMMMsg) -> None:
            if msg.tdata.value:
                try:
                    for tlv in decode_all(msg.tdata.value):
                        if tlv.type_id == TLV_JSON:
                            text = tlv.value.rstrip(b'\x00').decode('utf-8')
                            data = _json.loads(text)
                            result.extend(data.get('subscriptions', []))
                except Exception as exc:
                    logger.warning("Bridge: LIST_SUBS parse error: %s", exc)
            ev.set()

        reg_id = self._side_a._agent.register(
            mtype    = int(MType.UMM),
            subtype  = int(UMMSubType.LIST_SUBS_RESPONSE),
            callback = on_response,
        )
        self._side_a._agent.send(
            mtype   = int(MType.UMM),
            subtype = int(UMMSubType.LIST_SUBS),
        )
        ev.wait(timeout=5.0)
        self._side_a._agent.unregister(reg_id)

        if not result:
            logger.debug("Bridge: LIST_SUBS returned no subscriptions")
            return

        mirrored_count = 0
        for entry in result:
            local_reg_id = entry.get('reg_id', 0)
            if local_reg_id in already_mirrored:
                continue   # already re-mirrored from _mirrored dict above

            match_hex  = entry.get('match_hex', '')
            match_bytes = bytes.fromhex(match_hex) if match_hex else b''

            router_id_tuple, stripped = strip_router_id_tlv(match_bytes)
            if router_id_tuple is None:
                continue   # no RouterId TLV — local subscription, not our concern

            mtype   = entry.get('mtype',   0)
            subtype = entry.get('subtype', 0)
            channel = entry.get('channel', 1)

            logger.info("Bridge: replaying sub reg=%d mtype=%d subtype=%d "
                        "RouterId=%d.%d",
                        local_reg_id, mtype, subtype,
                        router_id_tuple[0], router_id_tuple[1])

            def on_msg(msg: UMMMsg) -> None:
                self._forward_b_to_a(msg)

            self._side_b.mirror_sub(
                local_reg_id = local_reg_id,
                mtype        = mtype,
                subtype      = subtype,
                match_bytes  = stripped,
                channel      = channel,
                on_msg       = on_msg,
            )
            mirrored_count += 1

        if mirrored_count:
            logger.info("Bridge: replayed %d subscription(s) from router A",
                        mirrored_count)


    def _run_side_b(self) -> None:
        """
        B-side thread: retry connection until successful, then run.
        Handles the case where B is unreachable at startup.
        Once connected, the agent's own reconnect loop handles subsequent drops.
        """
        while True:
            try:
                ok = self._side_b.connect()
                if ok:
                    self._side_b.run()   # blocks until B disconnects permanently
                    return
            except Exception as exc:
                logger.warning("Bridge side B connect failed, retrying in %ds: %s",
                               self._side_b._agent.reconnect_delay, exc)
            time.sleep(self._side_b._agent.reconnect_delay)

    def status(self) -> dict:
        hb = self._heartbeat
        quiet = time.monotonic() - hb._last_activity if hb._last_activity else None
        return {
            'router_a':      f"{self.host_a}:{self.port_a}",
            'mtype_a':       self.mtype_a,
            'router_b':      f"{self.host_b}:{self.port_b}",
            'mtype_b':       self.mtype_b,
            'a_to_b_subs':   self._side_b.sub_count(),
            'b_to_a_subs':   self._side_a.sub_count(),
            'seen_from_a':   {hex(k): round(v, 1)
                              for k, v in self._side_a.seen_routers().items()},
            'seen_from_b':   {hex(k): round(v, 1)
                              for k, v in self._side_b.seen_routers().items()},
            'heartbeat': {
                'quiet_threshold': hb.quiet_threshold,
                'timeout':         hb.timeout,
                'quiet_for':       round(quiet, 1) if quiet is not None else None,
                'waiting_pong':    hb._waiting_pong,
                'healthy':         not hb._waiting_pong or
                                   (quiet is not None and quiet < hb.timeout),
            },
        }

    # ── mixin registration ────────────────────────────────────────────────────

    def _register_side_handlers(self, side: 'RouterSide') -> None:
        """Register standard subtypes on one side, capturing the correct agent."""
        agent = side._agent
        mtype = side.mtype

        # Capability — pass the actual mtype so the response identifies correctly
        try:
            self.register_capability_handler(agent, mtype_override=mtype)
        except TypeError:
            # Older capability.py without mtype_override support
            self.register_capability_handler(agent)

        # Version — capture agent and mtype explicitly to avoid the mixin's
        # self._version_agent being overwritten by the second call
        def on_get_version(msg) -> None:
            import json, struct
            from umm.core.messages import MetaSubType, Channel
            from umm.core.registry import registry
            from umm.core.tlv import TLV
            int_type = registry.get_by_id(2)
            if int_type is None or not agent._loop:
                return
            version_data = {
                "system": UMM_VERSION_STR.split()[2] if ' ' in UMM_VERSION_STR else '?',
                "group":  getattr(self, 'GROUP_VERSION', '0.0.0'),
                "agent":  getattr(self, 'AGENT_VERSION', '0.0.0'),
                "build":  getattr(self, 'BUILD', 'dev'),
            }
            json_bytes = json.dumps(version_data).encode() + b'\x00'
            msgref_val = struct.pack('!III', 0, 0, getattr(msg, 'msg_id', 0))
            tlvs = [
                int_type.make_tlv(mtype),
                TLV(type_id=16, value=msgref_val),
                TLV(type_id=8,  value=json_bytes),
            ]
            async def _send():
                try:
                    await agent._async_send(
                        int(MType.UMM), int(MetaSubType.VERSION), tlvs, 0,
                        channel=int(Channel.META))
                except Exception as exc:
                    logger.warning("Bridge version response failed: %s", exc)
            agent._loop.call_soon_threadsafe(
                lambda: agent._loop.create_task(_send()))

        agent.register(mtype=mtype, subtype=2, callback=on_get_version,
                       dont_send_self=False)

        # Debug
        self.register_debug_handler(agent, mtype, debug=self._debug_startup)

        # Status
        agent.register(mtype=mtype, subtype=ST_STATUS,
                       callback=lambda msg, s=side: self._handle_status(msg, s),
                       dont_send_self=False)

        # ForwardRequest
        agent.register(mtype=mtype, subtype=ST_FORWARD_REQ,
                       callback=lambda msg, s=side: self._handle_forward_request(msg, s),
                       dont_send_self=False)

        # Heartbeat — B-side only: the bridge pings itself via router B so the
        # round-trip proves the connection is alive. A-side omits this because
        # if router A goes down the bridge process itself exits.
        if side is self._side_b:
            self.register_heartbeat_handler(agent, mtype)

    def _handle_status(self, msg: UMMMsg, side: 'RouterSide') -> None:
        """Respond to (BRIDGE, ST_STATUS) with a JSON status summary."""
        import json
        logger.info("Bridge status request from attach=%d on side %s",
                    msg.attach_id.id, side.label)
        payload = json.dumps(self.status(), indent=2).encode()
        buf = TLVBuffer()
        buf.add(TLV(TLV_STRING, value=payload + b'\x00'))
        side._agent.send(side.mtype, ST_STATUS_REPLY, tlvs=list(buf))
        logger.info("Bridge status reply sent on side %s mtype=%d",
                    side.label, side.mtype)

    def _handle_forward_request(self, msg: UMMMsg, side: 'RouterSide') -> None:
        """
        Handle a ForwardRequest from an agent on *side*.

        Payload: Int(mtype) Int(subtype) — the message type to forward.
        Use mtype=0, subtype=0 to forward all messages (wildcard).

        The bridge mirrors the subscription on the far side and forwards
        matching messages back on channel=BRIDGE(6).
        Responds with ForwardAck containing the far router's router_id.
        """
        # Parse mtype and subtype from payload TLVs
        req_mtype   = 0
        req_subtype = 0
        if msg.tdata.value:
            try:
                tlvs = decode_all(msg.tdata.value)
                ints = [struct.unpack_from('!i', t.value)[0]
                        for t in tlvs if t.type_id == TLV_INT and len(t.value) >= 4]
                if len(ints) >= 1: req_mtype   = ints[0]
                if len(ints) >= 2: req_subtype = ints[1]
            except Exception as exc:
                logger.warning("Bridge ForwardRequest parse error: %s", exc)
                return

        # Determine which side is "far"
        if side is self._side_a:
            far_side  = self._side_b
            near_side = self._side_a
        else:
            far_side  = self._side_a
            near_side = self._side_b

        logger.info("Bridge ForwardRequest from side %s: mtype=%d subtype=%d → mirror on side %s",
                    side.label, req_mtype, req_subtype, far_side.label)

        # Mirror the subscription on the far side, forwarding on channel=BRIDGE
        def on_forwarded(fwd_msg: UMMMsg) -> None:
            self._forward_with_channel(fwd_msg, near_side, int(Channel.BRIDGE))

        far_side.mirror_sub(
            local_reg_id = msg.reg_id,
            mtype        = req_mtype,
            subtype      = req_subtype,
            match_bytes  = b'',
            channel      = 1,
            on_msg       = on_forwarded,
        )

        # Send ForwardAck with the far router's router_id
        far_router_id = far_side._agent.attach_id.router if far_side._agent.attach_id else 0
        buf = TLVBuffer()
        buf.add(TLV(TLV_INT, value=struct.pack('!i', far_router_id)))
        side._agent.send(side.mtype, ST_FORWARD_ACK, tlvs=list(buf))

    def _forward_with_channel(self, msg: UMMMsg, side: 'RouterSide',
                               channel: int) -> None:
        """Forward msg onto side, overriding the channel."""
        tlvs = None
        if msg.tdata.value:
            try:
                tlvs = decode_all(msg.tdata.value)
            except Exception:
                pass
        side._agent.send(
            mtype   = msg.mtype,
            subtype = msg.subtype,
            tlvs    = tlvs,
            channel = channel,
        )

    # ── sub add/remove ────────────────────────────────────────────────────────

    def _sub_add_from_a(self, local_reg_id: int,
                         mtype: int, subtype: int,
                         channel: int, match_bytes: bytes) -> None:
        """Agent on A wants messages from B — mirror onto B."""
        def on_msg(msg: UMMMsg) -> None:
            self._forward_b_to_a(msg)
        self._side_b.mirror_sub(local_reg_id, mtype, subtype, match_bytes, channel, on_msg)

    def _sub_rem_from_a(self, local_reg_id: int) -> None:
        self._side_b.unmirror_sub(local_reg_id)

    def _sub_add_from_b(self, local_reg_id: int,
                         mtype: int, subtype: int,
                         channel: int, match_bytes: bytes) -> None:
        """Agent on B wants messages from A — mirror onto A."""
        def on_msg(msg: UMMMsg) -> None:
            self._forward_a_to_b(msg)
        self._side_a.mirror_sub(local_reg_id, mtype, subtype, match_bytes, channel, on_msg)

    def _sub_rem_from_b(self, local_reg_id: int) -> None:
        self._side_a.unmirror_sub(local_reg_id)

    # ── forwarding with loop detection ────────────────────────────────────────

    def _forward_b_to_a(self, msg: UMMMsg) -> None:
        self._heartbeat.note_activity()
        router_id = msg.attach_id.router
        if router_id:
            if self._side_a.has_router(router_id):
                logger.debug("Loop: 0x%08x from A, dropping B→A", router_id)
                return
            if self._side_b.record_router(router_id):
                self._publish_router_seen(router_id, 'B')
        self._side_a.forward(msg)

    def _forward_a_to_b(self, msg: UMMMsg) -> None:
        router_id = msg.attach_id.router
        if router_id:
            if self._side_b.has_router(router_id):
                logger.debug("Loop: 0x%08x from B, dropping A→B", router_id)
                return
            if self._side_a.record_router(router_id):
                self._publish_router_seen(router_id, 'A')
        self._side_b.forward(msg)

    # ── lifecycle events ──────────────────────────────────────────────────────

    def _publish_router_seen(self, router_id: int, side: str) -> None:
        site = (router_id >> 16) & 0xFFFF
        node =  router_id & 0xFFFF
        logger.info("Router seen: 0x%08x (%d.%d) via side %s", router_id, site, node, side)
        buf = TLVBuffer()
        buf.add(TLV(TLV_INT,    value=struct.pack('!i', site)))
        buf.add(TLV(TLV_INT,    value=struct.pack('!i', node)))
        buf.add(TLV(TLV_STRING, value=side.encode() + b'\x00'))
        try:
            self._side_a._agent.send(self.mtype_a, ST_ROUTER_SEEN, tlvs=list(buf))
        except Exception:
            pass

    def _publish_router_gone(self, router_id: int) -> None:
        site = (router_id >> 16) & 0xFFFF
        node =  router_id & 0xFFFF
        logger.info("Router gone (timeout): 0x%08x (%d.%d)", router_id, site, node)
        buf = TLVBuffer()
        buf.add(TLV(TLV_INT, value=struct.pack('!i', site)))
        buf.add(TLV(TLV_INT, value=struct.pack('!i', node)))
        try:
            self._side_a._agent.send(self.mtype_a, ST_ROUTER_GONE, tlvs=list(buf))
        except Exception:
            pass

    def _expiry_loop(self) -> None:
        while True:
            time.sleep(LOOP_TTL / 2)
            for side in (self._side_a, self._side_b):
                for rid in side.expire_routers():
                    self._publish_router_gone(rid)


# ── CLI ───────────────────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level  = logging.WARNING,
        format = '%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    ap = argparse.ArgumentParser(description='UMM Bridge — connects two UMM routers')
    ap.add_argument('--version',  action='store_true', help='Show version and exit')
    ap.add_argument('--router-a', default='localhost:5300', metavar='HOST:PORT',
                    help='Router A address (default: localhost:5300)')
    ap.add_argument('--router-b', required=True, metavar='HOST:PORT',
                    help='Router B address (required)')
    ap.add_argument('--mtype-a',  type=int, default=MType.BRIDGE, metavar='N',
                    help=f'mtype on Router A (default: {MType.BRIDGE})')
    ap.add_argument('--mtype-b',  type=int, default=111, metavar='N',
                    help='mtype on Router B (default: 111)')
    ap.add_argument('--name',        default='UMMBridge', metavar='NAME',
                    help='Process name (default: UMMBridge)')
    ap.add_argument('--hb-interval', type=float, default=HB_INTERVAL, metavar='SECS',
                    help=f'Heartbeat ping interval in seconds (default: {HB_INTERVAL})')
    ap.add_argument('--hb-timeout',  type=float, default=HB_TIMEOUT,  metavar='SECS',
                    help=f'Heartbeat timeout before forcing reconnect (default: {HB_TIMEOUT})')
    ap.add_argument('--debug',       action='store_true', help='Verbose logging')
    args = ap.parse_args()

    if args.version:
        print(UMM_VERSION_STR)
        return
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    def parse_addr(s: str) -> Tuple[str, int]:
        parts = s.rsplit(':', 1)
        return parts[0], int(parts[1]) if len(parts) > 1 else 5300

    host_a, port_a = parse_addr(args.router_a)
    host_b, port_b = parse_addr(args.router_b)

    bridge = BridgeModule(host_a=host_a, port_a=port_a,
                          host_b=host_b, port_b=port_b,
                          mtype_a=args.mtype_a,
                          mtype_b=args.mtype_b,
                          debug=args.debug,
                          hb_interval=args.hb_interval,
                          hb_timeout=args.hb_timeout)
    try:
        bridge.run()
    except KeyboardInterrupt:
        print("\nBridge stopped.")


if __name__ == '__main__':
    _main()
