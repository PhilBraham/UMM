"""
umm.modules.typedir
===================
Type Directory service — a UMM client that acts as the central registry
of all known TLV types on the network.

The directory is itself a UMM client: it publishes and subscribes just
like everything else.  This means:
  - Multiple directories can run (local plant + global company)
  - Any client can subscribe to be notified when new types are registered
  - The directory can be backed by a database (just another subscriber)

Supported queries (mtype=MT_TYPEDIR):

  ST_GET_NEXT_ID   → ST_NEXT_ID          returns next free type ID
  ST_REGISTER      → ST_REGISTERED       register a new type
  ST_QUERY_NAME    → ST_QUERY_RESULT     find type by name
  ST_QUERY_BASE    → ST_QUERY_RESULT     find types by base type
  ST_GET_ALL       → ST_ALL_TYPES        dump all known types
  ST_TYPE_ADDED    (published when a new type is successfully registered)

Run standalone::

    python -m umm.modules.typedir --router localhost --port 5000
"""

from __future__ import annotations

import json
import logging
import struct
import sys
from typing import Dict, List, Optional

from ..agent import UMMAgent, UMMConnectionError
from ..core.tlv import TLV, TLVBuffer, decode_all, TLV_TERM, TLV_INT, TLV_STRING
from ..core.messages import MType, SType, UMMMsg, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag
from ..core.registry import registry as _global_registry
from ..types._base import BaseUMMType
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin

logger = logging.getLogger(__name__)

# ── mtype/subtype constants ───────────────────────────────────────────────────

MT_TYPEDIR        = MType.TYPEDIR

ST_GET_NEXT_ID    = 101  # C→D  request next free type ID
ST_NEXT_ID        = 102  # D→C  response: next free ID (Int)
ST_REGISTER       = 103  # C→D  register a new type definition
ST_REGISTERED     = 104  # D→C  registration confirmed (Int=assigned ID)
ST_QUERY_NAME     = 105  # C→D  query by name (String)
ST_QUERY_BASE     = 106  # C→D  query by base type name (String)
ST_QUERY_RESULT   = 107  # D→C  query result (JSON as String TLV)
ST_GET_ALL        = 108  # C→D  request all types
ST_ALL_TYPES      = 109  # D→C  all types (JSON array as String TLV)
ST_TYPE_ADDED     = 110  # D→* published when a new type is registered


class TypeDirModule(DebugMixin, VersionMixin, ShutdownMixin):

    AGENT_VERSION = "1.0.0"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"
    """
    Type Directory service.

    Wraps the local TypeRegistry and exposes it over UMM so that any
    client on the network can discover and register types.
    """

    def __init__(self, host: str = 'localhost', port: int = 5000,
                 process_name: str = 'TypeDirectory',
                 min_user_id: int = 100) -> None:
        self.host         = host
        self.port         = port
        self.process_name = process_name
        self.min_user_id  = min_user_id

        self._client   = UMMAgent(host=host, port=port,
                                   process_name=process_name,
                                   agent_mtype=MT_TYPEDIR,
                                   flags=AttachFlag.NORMAL)
        self._registry = _global_registry

    def run(self) -> None:
        if not self._client.connect():
            raise RuntimeError("TypeDir: could not connect to router")

        self._client.register(MT_TYPEDIR, ST_GET_NEXT_ID, self._on_get_next_id, channel=0)
        self._client.register(MT_TYPEDIR, ST_REGISTER,    self._on_register,    channel=0)
        self._client.register(MT_TYPEDIR, ST_QUERY_NAME,  self._on_query_name,  channel=0)
        self._client.register(MT_TYPEDIR, ST_QUERY_BASE,  self._on_query_base,  channel=0)
        self._client.register(MT_TYPEDIR, ST_GET_ALL,     self._on_get_all,     channel=0)
        self.register_debug_handler(self._client, MT_TYPEDIR,
                                    debug=getattr(self, '_debug_flag', False))
        self.register_version_handler(self._client, MT_TYPEDIR)
        self.register_shutdown_handler(self._client, MT_TYPEDIR)
        self.log_info("Type directory running: %d types known", len(self._registry))
        self._client.run()

    # ── handlers ──────────────────────────────────────────────────────────────

    def _on_get_next_id(self, msg: UMMMsg) -> None:
        next_id = self._registry.next_free_id(self.min_user_id)
        self._client.send(MT_TYPEDIR, ST_NEXT_ID,
                          tlvs=[self._int_tlv(next_id)])

    def _on_register(self, msg: UMMMsg) -> None:
        """
        Register a new type from a remote client.

        Expected TLVs:
          String  type_name
          String  base_type  (optional)
          String  description (optional)
          String  unit        (optional)
          Int     requested_id (optional; -1 = auto-assign)
        """
        tlvs = decode_all(msg.tdata.value) if msg.tdata.value else []
        params: Dict[str, str] = {}
        requested_id = -1
        keys = ['name', 'base_type', 'description', 'unit']
        str_idx = 0
        for tlv in tlvs:
            if tlv.type_id == TLV_STRING and str_idx < len(keys):
                params[keys[str_idx]] = tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
                str_idx += 1
            elif tlv.type_id == TLV_INT:
                requested_id = struct.unpack('!i', tlv.value)[0]

        if 'name' not in params or not params['name']:
            self._client.send(MT_TYPEDIR, SType.ERROR,
                              tlvs=[self._str_tlv("Type registration requires a name")])
            return

        # Determine ID
        if requested_id > 0 and requested_id not in self._registry:
            type_id = requested_id
        else:
            type_id = self._registry.next_free_id(self.min_user_id)

        # Dynamically create a minimal BaseUMMType subclass
        new_cls = type(params['name'], (BaseUMMType,), {
            'TYPE_ID':     type_id,
            'TYPE_NAME':   params['name'],
            'BASE_TYPE':   params.get('base_type'),
            'DESCRIPTION': params.get('description', ''),
            'UNIT':        params.get('unit', ''),
            'MATCH_OPS':   {},
            'pack':        lambda self, v: str(v).encode() + b'\x00',
            'unpack':      lambda self, d: d.rstrip(b'\x00').decode('utf-8', errors='replace'),
        })
        self._registry.register_class(new_cls)

        self.log_info("Registered new type: id=%d name=%s base=%s",
                    type_id, params['name'], params.get('base_type'))

        # Confirm to requester
        self._client.send(MT_TYPEDIR, ST_REGISTERED,
                          tlvs=[self._int_tlv(type_id)])

        # Publish to all subscribers
        entry = self._registry.get_by_id(type_id)
        if entry:
            self._client.send(MT_TYPEDIR, ST_TYPE_ADDED,
                              tlvs=[self._str_tlv(json.dumps(entry.directory_entry()))])

    def _on_query_name(self, msg: UMMMsg) -> None:
        query = self._extract_string(msg)
        results = []
        if query:
            h = self._registry.get_by_name(query)
            if h:
                results = [h.directory_entry()]
        self._client.send(MT_TYPEDIR, ST_QUERY_RESULT,
                          tlvs=[self._str_tlv(json.dumps(results))])

    def _on_query_base(self, msg: UMMMsg) -> None:
        query   = self._extract_string(msg)
        results = [h.directory_entry()
                   for h in self._registry.query_by_base(query)] if query else []
        self._client.send(MT_TYPEDIR, ST_QUERY_RESULT,
                          tlvs=[self._str_tlv(json.dumps(results))])

    def _on_get_all(self, msg: UMMMsg) -> None:
        all_entries = self._registry.directory_entries()
        self._client.send(MT_TYPEDIR, ST_ALL_TYPES,
                          tlvs=[self._str_tlv(json.dumps(all_entries))])

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _int_tlv(value: int) -> TLV:
        return TLV(type_id=TLV_INT, value=struct.pack('!i', value))

    @staticmethod
    def _str_tlv(text: str) -> TLV:
        return TLV(type_id=TLV_STRING, value=text.encode('utf-8') + b'\x00')

    def _extract_string(self, msg: UMMMsg) -> str:
        if not msg.tdata.value:
            return ''
        for tlv in decode_all(msg.tdata.value):
            if tlv.type_id == TLV_STRING:
                return tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
        return ''


def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    parser = argparse.ArgumentParser(description='UMM Type Directory service')
    parser.add_argument('--version', action='store_true',
                   help='Show version and exit')
    parser.add_argument('--router',   default='localhost', dest='host')
    parser.add_argument('--port',     type=int, default=5000)
    parser.add_argument('--name',     default='TypeDirectory')
    parser.add_argument('--min-id',   type=int, default=100, dest='min_user_id')
    parser.add_argument('--typedir',  action='append', default=[],
                        help='Extra type plugin directories')
    parser.add_argument('--debug',    action='store_true')
    parser.add_argument('--permanent', action='store_true',
                        help='Attach with PERM_KEEP_CONN (set automatically by supervisor for C agents)')
    args = parser.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    for d in args.typedir:
        _global_registry.add_search_dir(d)

    svc = TypeDirModule(host=args.host, port=args.port,
                        process_name=args.name, min_user_id=args.min_user_id)
    svc._debug_flag = args.debug
    if args.permanent:
        svc._client.attach_flags = AttachFlag.PERM_KEEP_CONN
        svc._client.reconnect = True
    try:
        svc.run()
    except KeyboardInterrupt:
        print("\nType directory stopped.")


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)
