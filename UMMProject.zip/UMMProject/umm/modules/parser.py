"""
umm.modules.parser
==================
UMM Parser — monitors all traffic on the bus and displays it in real time.
Equivalent to the original C++ Parser/MsgParser application.

Channel model
-------------
Channel 0 is the subscription wildcard — it matches every channel.  Messages
are always sent on a named channel (1=APP, 2=Confirm, 3=Debug, 4=Meta, …,
128=Sim).  The parser subscribes on channel 0 by default so it sees all
traffic.  Use --channel to restrict to specific channels, or --exclude-channel
to subscribe to all channels but hide specific ones (e.g. --exclude-channel 128
to suppress simulation noise while still seeing everything else).

Features:
  - Subscribe to all messages (mtype=0, subtype=0, channel=0 wildcard)
  - Display each message with timestamp, mtype, subtype, TLV contents
  - Filter by mtype, subtype, or channel
  - Exclude noisy channels with --exclude-channel
  - Log to file in JSON-lines format for replay via umm.tools.send --replay

Run standalone::

    python -m umm.modules.parser --router localhost --port 5100

    # Filter: only show mtype=100
    python -m umm.modules.parser --router localhost --mtype 100

    # Show only the application bus (channel 1) — hide all infrastructure channels
    python -m umm.modules.parser --channel 1

    # See everything except simulation traffic
    python -m umm.modules.parser --exclude-channel 128

    # Record traffic to a JSON-lines file for later replay
    python -m umm.modules.parser --record session.json

    # Replay a recording via send:
    python3 -m umm.tools.send --replay session.json
"""

from __future__ import annotations

import datetime
import json
import logging
import os
import struct
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, TextIO

# On Windows, stdout defaults to the console code page which cannot represent
# the Unicode box-drawing and punctuation characters used in parser output.
if sys.platform == 'win32':
    import io
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    elif hasattr(sys.stdout, 'buffer'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8',
                                      errors='replace', line_buffering=True)
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8',
                                      errors='replace', line_buffering=True)


from ..agent import UMMAgent, UMMConnectionError
from ..core.tlv import TLV, TLVBuffer, decode_all, TLV_TERM, TLV_INT, TLV_STRING, TLV_MSG, TLV_SUBSPEC, TLV_JSON, MWORD_IGNORE_MATCH
from ..core.meta import meta_registry
from ..core.messages import MType, SType, UMMMsg, UMMSubType, UMM_VERSION_STR, DEFAULT_PORT
from ..core.registry import registry

logger = logging.getLogger(__name__)


# ── colour support (terminal only) ──────────────────────────────────────────
class _Ansi:
    RESET   = '\033[0m'
    BOLD    = '\033[1m'
    GREY    = '\033[90m'   # bright-black = light grey
    RED     = '\033[31m'
    GREEN   = '\033[32m'
    YELLOW  = '\033[33m'
    BLUE    = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN    = '\033[36m'


def _stdout_is_tty() -> bool:
    try:
        return bool(sys.stdout.isatty())
    except Exception:
        return False


def _color_default() -> bool:
    """Auto-detect: colour on only for an interactive terminal with NO_COLOR unset."""
    if os.environ.get('NO_COLOR'):
        return False
    return _stdout_is_tty()


# Colour names accepted in parser.conf.  Foreground colours + attributes; combine
# freely, e.g. "bold green", "dim grey".  "none"/"default" clears colour.
_FG_COLORS = {
    'black': 30, 'red': 31, 'green': 32, 'yellow': 33, 'blue': 34,
    'magenta': 35, 'cyan': 36, 'white': 37, 'grey': 90, 'gray': 90,
    'bright_black': 90, 'bright_red': 91, 'bright_green': 92, 'bright_yellow': 93,
    'bright_blue': 94, 'bright_magenta': 95, 'bright_cyan': 96, 'bright_white': 97,
}
_ATTRS = {'bold': 1, 'dim': 2, 'underline': 4, 'reverse': 7}


def _parse_color(spec: str) -> Optional[str]:
    """'bold green' → '\\033[1;32m'; 'none'/'default'/'' → ''; unknown token → None."""
    spec = spec.strip().lower()
    if spec in ('', 'none', 'default', 'reset'):
        return ''
    codes: List[int] = []
    for tok in spec.replace(',', ' ').split():
        if tok in _ATTRS:
            codes.append(_ATTRS[tok])
        elif tok in _FG_COLORS:
            codes.append(_FG_COLORS[tok])
        else:
            return None
    if not codes:
        return None
    return '\033[' + ';'.join(str(c) for c in codes) + 'm'


def _empty_color_rules() -> dict:
    """The colour-rule structure consulted by MessageFormatter._line_color."""
    return {'mtype_subtype': {}, 'mtype': {}, 'channel': {}, 'subtype': {},
            'category': {}}


# Category keywords in parser.conf → internal rule keys.  These override the
# colour the built-in semantic rules use (e.g. recolour agentsResponse).
_COLOR_CATEGORIES = {
    'agentsresponse': 'agentsResponse', 'control': 'control', 'debug': 'debug',
    'confirm': 'confirm', 'meta': 'meta', 'low-subtype': 'low_subtype',
    'low_subtype': 'low_subtype', 'default': 'default',
    'header': 'header', 'banner': 'header',
}


def load_parser_config(path, rules: Optional[dict] = None):
    """Parse a parser.conf into a colour-rule dict.  Returns (rules, warnings).

    Format (whitespace-delimited, '#' comments, [section] headers)::

        [colors]
        mtype 5001         blue           # pump messages
        mtype 5000         green          # tankLevel messages
        mtype 5000 102     bright_green   # a specific (mtype, subtype)
        channel 3          dim grey       # by channel
        subtype 13         magenta        # by subtype (any mtype)
        agentsResponse     grey           # recolour a built-in category
        default            none

    Unknown sections are ignored (reserved for future use, e.g. [display]).
    Unparseable lines are collected as warnings and skipped — never fatal.
    """
    rules = rules if rules is not None else _empty_color_rules()
    warnings: List[str] = []
    section: Optional[str] = None

    for lineno, raw in enumerate(Path(path).read_text().splitlines(), 1):
        line = raw.split('#')[0].strip()
        if not line:
            continue
        if line.startswith('[') and line.endswith(']'):
            section = line[1:-1].strip().lower()
            continue
        if section != 'colors':
            continue   # only [colors] is consumed today
        toks = line.split()
        key = toks[0].lower()
        try:
            if key == 'mtype':
                m = int(toks[1])
                if len(toks) >= 3 and toks[2].lstrip('-').isdigit():
                    col = _parse_color(' '.join(toks[3:]))
                    if col is None:
                        raise ValueError
                    rules['mtype_subtype'][(m, int(toks[2]))] = col
                else:
                    col = _parse_color(' '.join(toks[2:]))
                    if col is None:
                        raise ValueError
                    rules['mtype'][m] = col
            elif key == 'channel':
                col = _parse_color(' '.join(toks[2:]))
                if col is None:
                    raise ValueError
                rules['channel'][int(toks[1])] = col
            elif key == 'subtype':
                col = _parse_color(' '.join(toks[2:]))
                if col is None:
                    raise ValueError
                rules['subtype'][int(toks[1])] = col
            elif key in _COLOR_CATEGORIES:
                col = _parse_color(' '.join(toks[1:]))
                if col is None:
                    raise ValueError
                rules['category'][_COLOR_CATEGORIES[key]] = col
            else:
                warnings.append(f"{path}:{lineno}: unknown selector '{toks[0]}'")
        except (ValueError, IndexError):
            warnings.append(f"{path}:{lineno}: could not parse '{line}'")
    return rules, warnings


# ── message formatter ─────────────────────────────────────────────────────────

class MessageFormatter:
    """
    Formats a UMMMsg as human-readable text.

    Uses NameRegistry for mtype/subtype names — extensible via:
      - umm.capability  (auto-loaded)
      - umm_names.conf  (auto-loaded from current directory)
      - formatter.names.load_file(path)  (explicit load)
      - formatter.names.add_mtype(mtype, name)  (programmatic)

    Example output::

        Mon Apr 18 14:31:48  1.2  Conveyor(1002),CmdC1(1)  reg=1  Bool true
    """

    # Width of the "src (id(name))" column.  Senders longer than this are
    # truncated (with an ellipsis inside the name) so columns stay aligned.
    SRC_WIDTH = 24

    @staticmethod
    def _fit_src(rid: int, aid: int, name: str, width: int) -> str:
        """Build the src field 'rid.aid(name)', truncating to *width*.

        Truncation happens inside the name (keeping the id and parentheses):
        'TankLevelAgent' under a tight width becomes e.g. '131.6(TankLevel…)'.
        Falls back to truncating the whole string if even the id won't fit.
        """
        base = f"{rid}.{aid}"
        if name:
            prefix, suffix = base + "(", ")"
            avail = width - len(prefix) - len(suffix)
            if avail >= 2 and len(name) > avail:
                name = name[:avail - 1] + "…"
            s = prefix + name + suffix
        else:
            s = base
        if len(s) > width:
            s = s[:width - 1] + "…"
        return s

    def __init__(self) -> None:
        from ..names import NameRegistry
        self.names = NameRegistry()
        self.names.load_capabilities()
        # Auto-load umm_names.conf from current directory
        from pathlib import Path
        for candidate in ['umm_names.conf', 'names.conf']:
            if Path(candidate).exists():
                self.names.load_file(candidate)
                break
        # Make names accessible to _format_one for Msg TLV decoding
        self._names_ref = self.names
        # Agent name map injected by ParserModule: attach_id → name
        self.agent_names: dict = {}
        # Display options configured by ParserModule.  Defaults are safe for
        # standalone/library use (no colour, no truncation).
        self.use_color: bool = False
        self.truncate:  bool = False
        # Colour rules from parser.conf (empty = built-in defaults only).
        self.color_rules: dict = _empty_color_rules()

    def format(self, msg: UMMMsg, show_hex: bool = False,
               raw_mode: bool = False, show_flags: bool = False,
               show_channel: bool = False, show_json: bool = False,
               show_reg: bool = False) -> str:
        """Format a UMMMsg as a display string."""
        ts      = datetime.datetime.now().strftime('%a %b %d %H:%M:%S')
        # sender: show name if known, otherwise router_id.attach_id —
        # truncated to a fixed width so columns stay aligned.
        aid     = msg.origin.id
        rid     = msg.origin.router
        aname   = self.agent_names.get(aid, '')
        sender  = self._fit_src(rid, aid, aname, self.SRC_WIDTH)

        if raw_mode:
            type_str = f"{msg.mtype},{msg.subtype}"
        else:
            if msg.channel > 1:
                from umm.core.messages import Channel as _CH
                ch_names = {2:'Confirm', 3:'Debug', 4:'Meta', 5:'Heartbeat',
                            6:'Supervisor', 7:'Bridge'}
                ch_label = ch_names.get(msg.channel, f'ch{msg.channel}')
                sub_name = self.names.full_name(msg.mtype, msg.subtype,
                                                channel=msg.channel)
                type_str = f"{ch_label}/{sub_name}"
            else:
                type_str = self.names.full_name(msg.mtype, msg.subtype)

        tlv_str = self._format_tlvs(msg.tdata, show_hex, show_json, raw_mode)

        parts = [f'"{ts}"', f'{sender:{self.SRC_WIDTH}s}', f'{type_str:32s}']
        if show_reg:
            parts.append(f'reg={msg.reg_id}')
        if show_channel or msg.channel != 1:
            parts.append(f'ch={msg.channel}')
        if show_flags and msg.flags:
            parts.append(self._format_flags(msg.flags))
        if tlv_str:
            parts.append(tlv_str)
        line = '  '.join(parts)

        # Truncate to the terminal width so a single bulky message (e.g. the
        # agentsResponse JSON) can't wrap over many lines and push the header
        # off-screen.  Done on the plain text, before colour, so the escape
        # codes are never counted in the width.
        if self.truncate:
            width = shutil.get_terminal_size((100, 24)).columns
            if len(line) > width:
                line = line[:width - 1] + '…'

        # Colourise the whole line by message kind (terminal only).
        if self.use_color:
            c = self._line_color(msg)
            if c:
                line = c + line + _Ansi.RESET
        return line

    def _line_color(self, msg: UMMMsg) -> str:
        """Pick a line colour by message kind.

        Most-specific selector wins.  At each tier a parser.conf rule is checked
        first, then the built-in default; configuring a category recolours its
        built-in rule.  An absent/empty parser.conf reproduces the built-ins:
        agentsResponse → grey, mtype=1 → cyan, ch3 → grey, ch2 → green,
        ch4 → magenta, subtype < 20 → yellow, otherwise none.
        """
        a = _Ansi
        r = self.color_rules
        cat = r['category']
        key = (msg.mtype, msg.subtype)
        if key in r['mtype_subtype']:
            return r['mtype_subtype'][key]
        if msg.mtype == 1 and msg.subtype == int(UMMSubType.LIST_AGENTS_RESPONSE):
            return cat.get('agentsResponse', a.GREY)
        if msg.mtype in r['mtype']:
            return r['mtype'][msg.mtype]
        if msg.mtype == 1:
            return cat.get('control', a.CYAN)
        if msg.channel in r['channel']:
            return r['channel'][msg.channel]
        if msg.channel == 3:
            return cat.get('debug', a.GREY)
        if msg.channel == 2:
            return cat.get('confirm', a.GREEN)
        if msg.channel == 4:
            return cat.get('meta', a.MAGENTA)
        if msg.subtype in r['subtype']:
            return r['subtype'][msg.subtype]
        if msg.subtype < 20:
            return cat.get('low_subtype', a.YELLOW)
        return cat.get('default', '')

    def header_color(self) -> str:
        """Colour for the banner / column heading (config 'header', else bold)."""
        return self.color_rules['category'].get('header', _Ansi.BOLD)

    @staticmethod
    def _format_flags(flags: int) -> str:
        """Return a compact human-readable flag string, e.g. 'flags[RTR,RCV]'."""
        from umm.core.messages import MsgFlag as _F
        names = []
        if flags & _F.CONFIRM_RTR:  names.append('RTR')
        if flags & _F.CONFIRM_RCV:  names.append('RCV')
        if flags & _F.CONFIRM_APP:  names.append('APP')
        unknown = flags & ~(_F.CONFIRM_RTR | _F.CONFIRM_RCV | _F.CONFIRM_APP)
        if unknown:
            names.append(f'0x{unknown:x}')
        return f'flags[{",".join(names)}]'

    @staticmethod
    def heading(show_reg: bool = False) -> str:
        """Return a column heading line matching format() output."""
        ts_col    = f'{"timestamp":24s}'
        src_col   = f'{"src (id(name))":{MessageFormatter.SRC_WIDTH}s}'
        type_col  = f'{"mtype,subtype":30s}'
        if show_reg:
            return f'  {ts_col}  {src_col}  {type_col}  reg  tlv data'
        return f'  {ts_col}  {src_col}  {type_col}  tlv data'

    @staticmethod
    def separator() -> str:
        return '-' * 100

    def _format_tlvs(self, tdata: TLV, show_hex: bool, show_json: bool = False, raw_mode: bool = False) -> str:
        """Format TLV payload as readable text."""
        if not tdata.value:
            return ''
        try:
            tlvs = decode_all(tdata.value)
        except Exception:
            return f'<corrupt TLV: {tdata.value.hex()}>'

        parts = []
        for tlv in tlvs:
            parts.append(self._format_one(tlv, show_hex, show_json, raw_mode))
        return '  '.join(parts)

    def _format_one(self, tlv: TLV, show_hex: bool, show_json: bool = False, raw_mode: bool = False) -> str:
        """Format a single TLV."""
        handler = registry.get_by_id(tlv.type_id)
        type_name = handler.TYPE_NAME if handler else f'Type{tlv.type_id}'

        # Meta annotation: show name if registered, otherwise show number
        meta_str = ''
        if tlv.meta != 0:
            meta_name = meta_registry.name(tlv.type_id, tlv.meta)
            meta_str = f'[{meta_name}]' if meta_name else f'[{tlv.meta}]'

        # Match-word annotation
        mword_str = ''
        if tlv.match != 0:
            if tlv.match == MWORD_IGNORE_MATCH:
                mword_str = '{ignore}'
            elif handler and hasattr(handler, 'OP_TEXT'):
                # Reverse lookup operator symbol
                op_text = {v: k for k, v in handler.OP_TEXT.items()}
                sym = op_text.get(tlv.match, str(tlv.match))
                mword_str = f'{{{sym}}}'
            else:
                mword_str = f'{{{tlv.match}}}'

        if not tlv.value:
            return f'{type_name}{meta_str}{mword_str}'

        # Nested TLVs (TLV_MSG)
        if tlv.type_id == TLV_MSG:
            try:
                val = tlv.value
                # Inner message spec: mtype(4) subtype(4) channel(2) flags(2) [TLV payload]
                if len(val) >= 12:
                    import struct as _s
                    inner_mtype, inner_sub, inner_ch, inner_flags = \
                        _s.unpack_from('!iiHH', val)
                    inner_name = f'{inner_mtype},{inner_sub}' if raw_mode else \
                        (self._names_ref.full_name(
                         inner_mtype, inner_sub) if self._names_ref else \
                         f'{inner_mtype},{inner_sub}')
                    ch_str = f' ch={inner_ch}' if inner_ch != 1 else ''
                    fl_str = f' flags=0x{inner_flags:x}' if inner_flags else ''
                    remainder = val[12:]
                    if remainder:
                        try:
                            inner_tlvs = decode_all(remainder)
                            tlv_str = ' '.join(
                                self._format_one(t, show_hex, raw_mode=raw_mode)
                                for t in inner_tlvs)
                            return f'Msg{{{inner_name}{ch_str}{fl_str}  {tlv_str}}}'
                        except Exception:
                            pass
                    return f'Msg{{{inner_name}{ch_str}{fl_str}}}'
                else:
                    inner = decode_all(val)
                    inner_str = ' '.join(
                        self._format_one(t, show_hex, show_json, raw_mode) for t in inner)
                    return f'Msg{{{inner_str}}}'
            except Exception:
                pass

        if tlv.type_id == TLV_SUBSPEC:
            try:
                val = tlv.value
                # Subscription spec: mtype(4) subtype(4) match_bytes
                if len(val) >= 8:
                    import struct as _s
                    s_mtype, s_sub = _s.unpack_from('!ii', val)
                    s_name = f'{s_mtype},{s_sub}' if raw_mode else \
                        (self._names_ref.full_name(s_mtype, s_sub) \
                         if self._names_ref else f'{s_mtype},{s_sub}')
                    match_bytes = val[8:]
                    if match_bytes:
                        try:
                            match_tlvs = decode_all(match_bytes)
                            m_str = ' '.join(self._format_one(t, show_hex, show_json, raw_mode)
                                             for t in match_tlvs)
                            return f'SubSpec{{{s_name}  {m_str}}}'
                        except Exception:
                            pass
                    return f'SubSpec{{{s_name}}}'
            except Exception:
                pass

        if handler:
            try:
                value = handler.unpack(tlv.value)
                # For JSON type, only expand if --json-decode is set
                if tlv.type_id == TLV_JSON and not show_json:
                    text = handler.to_text(value)  # shows as quoted string
                else:
                    text = handler.to_text(value)
                return f'{type_name}{meta_str}{mword_str} {text}'
            except Exception:
                pass

        if show_hex:
            return f'{type_name}{meta_str}{mword_str} 0x{tlv.value.hex()}'
        # Try UTF-8 text
        try:
            s = tlv.value.rstrip(b'\x00').decode('utf-8')
            return f'{type_name}{meta_str}{mword_str} "{s}"'
        except Exception:
            return f'{type_name}{meta_str}{mword_str} ({len(tlv.value)}b)'


# ── log file format ───────────────────────────────────────────────────────────

class MessageLog:
    """
    JSON-lines recording of bus traffic for later replay via umm.tools.send.

    Each line is a JSON object with fields:
        ts_secs   : int   — UTime seconds (from message header, not wall clock)
        ts_ms     : int   — UTime milliseconds
        channel   : int   — logical channel (Channel enum value)
        mtype     : int   — message type
        subtype   : int   — message sub-type
        flags     : int   — message flags
        tlvs_hex  : str   — hex-encoded raw TLV payload bytes (authoritative for replay)
        tlvs_meta : list  — optional human-readable meta names/values (informational)

    Use umm.tools.send --replay <file> to replay.
    The tlvs_hex field carries the complete wire bytes including match and meta
    words, so meta is preserved exactly through record/replay without any
    special handling.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._file: Optional[TextIO] = None

    def open_write(self) -> None:
        self._file = open(self._path, 'w', encoding='utf-8')
        # Write a header comment so the file is self-describing
        header = {'_umm_recording': True, '_version': 1,
                  '_recorded': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        self._file.write(json.dumps(header) + '\n')
        self._file.flush()

    def write(self, msg: UMMMsg) -> None:
        """Record one message. Timestamp comes from the message header, not wall clock."""
        if not self._file:
            return
        # Build a human-readable meta summary for the record so recordings
        # are inspectable.  tlvs_hex is the authoritative round-trip source.
        meta_summary = []
        if msg.tdata.value:
            try:
                for tlv in decode_all(msg.tdata.value):
                    if tlv.meta:
                        name = meta_registry.name(tlv.type_id, tlv.meta)
                        meta_summary.append(name or tlv.meta)
            except Exception:
                pass
        record = {
            'ts_secs':  msg.tm.secs,
            'ts_ms':    msg.tm.ms,
            'channel':  msg.channel,
            'mtype':    msg.mtype,
            'subtype':  msg.subtype,
            'flags':    msg.flags,
            'tlvs_hex': msg.tdata.value.hex() if msg.tdata.value else '',
        }
        if meta_summary:
            record['tlvs_meta'] = meta_summary   # informational only; replay uses tlvs_hex
        self._file.write(json.dumps(record) + '\n')
        self._file.flush()

    def close(self) -> None:
        if self._file:
            self._file.close()
            self._file = None


# ── parser module ─────────────────────────────────────────────────────────────

class ParserModule:
    """
    UMM bus monitor.

    Connects to a router and displays every message passing through it
    (by registering a wildcard subscription mtype=0, subtype=0, channel=0).

    Parameters
    ----------
    host : str
        Router hostname.
    port : int
        Router port.
    filter_mtypes : list of int or None
        Only show messages with these mtypes.  Empty list = all (wildcard).
        Negative values are valid (e.g. -2 for the debug channel).
    filter_subtype : int
        Only show messages with this subtype (0 = all).
    filter_channels : list of int or None
        Subscribe on specific channels only.  Empty list = channel 0 (ALL
        wildcard).  e.g. [1] for app bus only, [3] for debug channel only.
    exclude_channels : list of int or None
        Subscribe on ALL channels (wildcard) but suppress these channels in
        output.  e.g. [128] to hide simulation traffic.
        Ignored when filter_channels is non-empty.
    log_file : str or None
        If given, log all messages to this file.
    show_hex : bool
        Show unknown TLV values as hex.
    raw_mode : bool
        Show mtype/subtype as raw numbers instead of names.
    show_flags : bool
        Show message flags (RTR/RCV/APP confirm) when non-zero.
    show_channel : bool
        Always show ch= on every output line (auto-enabled when
        filter_channels is set).
    show_control : bool
        Show UMM control messages (ATTACH, REGISTER etc.).
    on_message : callable or None
        Optional callback for programmatic use (receives formatted string).
    """

    def __init__(self,
                 host:             str   = 'localhost',
                 port:             int   = DEFAULT_PORT,
                 name:             str   = 'Parser',
                 filter_mtypes:    Optional[List[int]] = None,
                 filter_subtype:   int   = 0,
                 filter_channels:  Optional[List[int]] = None,
                 exclude_channels: Optional[List[int]] = None,
                 record_file:      Optional[str] = None,
                 show_hex:         bool  = False,
                 raw_mode:         bool  = False,
                 show_flags:       bool  = False,
                 show_channel:     bool  = False,
                 show_control:     bool  = False,
                 show_json:        bool  = False,
                 show_reg:         bool  = False,
                 truncate:         bool  = True,
                 color:            Optional[bool] = None,
                 config_file:      Optional[str] = None,
                 on_message:       Optional[Callable[[str, UMMMsg], None]] = None,
                 ) -> None:

        self.host             = host
        self.port             = port
        self.name             = name
        self.filter_mtypes    = list(filter_mtypes) if filter_mtypes else []
        self.filter_subtype   = filter_subtype
        # filter_channels: explicit channels to subscribe on.
        # Empty = subscribe with channel=0 (ALL wildcard — every channel).
        self.filter_channels  = list(filter_channels) if filter_channels else []
        # exclude_channels: subscribe ALL, suppress these in output display.
        # Has no effect when filter_channels is non-empty.
        self.exclude_channels = list(exclude_channels) if exclude_channels else []
        self.show_hex         = show_hex
        self.raw_mode         = raw_mode
        self.show_flags       = show_flags
        self.show_channel     = show_channel or bool(filter_channels)
        self.show_control     = show_control
        self.show_json        = show_json
        self.show_reg         = show_reg
        self.on_message       = on_message

        self._client    = UMMAgent(host=host, port=port, process_name=self.name)
        self._formatter = MessageFormatter()
        # Colour: explicit override, else auto (terminal + NO_COLOR unset).
        # Truncation: user flag, but only meaningful on a terminal — when output
        # is piped to a log file we keep full lines.
        is_tty                    = _stdout_is_tty()
        self.use_color            = _color_default() if color is None else bool(color)
        self._formatter.use_color = self.use_color
        self._formatter.truncate  = bool(truncate) and is_tty

        # Colour rules from a single config file: an explicit --config-file, or
        # else parser.conf in the working directory.  Absent default => built-in
        # defaults (silent).  An explicitly-named file that's missing warns.
        # Bad lines are collected and reported, never fatal.
        self._config_warnings: List[str] = []
        explicit = config_file is not None
        cfg_path = config_file or 'parser.conf'
        if Path(cfg_path).exists():
            _, w = load_parser_config(cfg_path, self._formatter.color_rules)
            self._config_warnings += w
        elif explicit:
            self._config_warnings.append(f"config file not found: {cfg_path}")
        self._record: Optional[MessageLog] = None
        self._msg_count = 0
        # Live subscription map: attach_id → {reg_id → (mtype, subtype, channel, name)}
        self._sub_map: dict = {}
        # Agent name map: attach_id → name (shared with formatter for display)
        # id=0 is always the router itself
        self._agent_names: dict = {0: 'Router'}
        self._formatter.agent_names = self._agent_names  # shared reference

        if record_file:
            self._record = MessageLog(record_file)

    def run(self) -> None:
        """Connect and start monitoring."""
        if not self._client.connect():
            print(f"\n  ERROR: Parser could not connect to router at {self.host}:{self.port}")
            print("  Is the router running?  Start it with: ./umm.sh start router")
            print("")
            return

        if self._record:
            self._record.open_write()
            print(f"  [recording to {self._record._path}]")

        # Build the set of (mtype, channel) pairs to subscribe on.
        # channel=0 is the ALL wildcard — receives messages on every channel.
        # mtype=0 is the ALL wildcard — receives messages of every mtype.
        sub_channels = self.filter_channels if self.filter_channels else [0]
        sub_mtypes   = self.filter_mtypes   if self.filter_mtypes   else [0]

        for ch in sub_channels:
            for mt in sub_mtypes:
                self._client.register(
                    mtype          = mt,
                    subtype        = self.filter_subtype,
                    channel        = ch,
                    callback       = self._on_msg,
                    dont_send_self = True,
                )

        # Subscribe to agent lifecycle events to auto-load capability names.
        self._client.register(
            mtype          = 1,   # MType.UMM
            subtype        = int(UMMSubType.AGENT_ATTACHED),
            callback       = self._on_agent_attached,
            dont_send_self = True,
        )

        # Auto-discovery: broadcast capability query to all currently-attached
        # agents so the parser knows their names without needing umm_names.conf.
        # Responses arrive on channel=META (3).
        from ..core.messages import Channel as _CH
        self._client.register(
            mtype          = 1,   # MType.UMM
            subtype        = int(UMMSubType.CAPABILITY_RESPONSE),
            channel        = int(_CH.META),
            callback       = self._on_cap_response,
            dont_send_self = True,
        )
        # Agent-name resolution: ask the router for the authoritative
        # attach_id → name list (same source as `runumm agents`) so the src
        # column shows names for agents that were already attached before the
        # parser started.  New attaches are picked up via _on_agent_attached,
        # which re-queries this list.
        self._client.register(
            mtype          = 1,   # MType.UMM
            subtype        = int(UMMSubType.LIST_AGENTS_RESPONSE),
            callback       = self._on_list_agents_names,
            dont_send_self = True,
        )
        self._client.send(mtype=1, subtype=int(UMMSubType.LIST_AGENTS))

        # Broadcast: no payload = all agents respond.
        # We track this send so the startup capability responses are not shown
        # in the display output (they are still processed by _on_cap_response).
        self._startup_cap_done = False
        self._client.send(mtype=1, subtype=int(UMMSubType.CAPABILITY_QUERY))

        # Subscribe to mtype=1 (APP channel) to track ATTACH/REGISTER/DETACH
        # control messages.  We track them for the subs/who commands.
        # When show_control is set, display them too.
        if self.show_control:
            self._client.register(
                mtype          = 1,
                subtype        = 0,
                channel        = 1,   # APP — router control bus
                callback       = self._on_control_and_display,
                dont_send_self = True,
            )
            print("  [showing UMM control messages]")
        else:
            self._client.register(
                mtype          = 1,
                subtype        = 0,
                channel        = 1,   # APP only — don't intercept META/DEBUG
                callback       = self._on_control_msg,
                dont_send_self = True,
            )

        mtype_str = ', '.join(str(m) for m in self.filter_mtypes) \
                    if self.filter_mtypes else 'ALL'
        sub_str   = str(self.filter_subtype) if self.filter_subtype else 'ALL'
        if self.filter_channels:
            ch_str = 'ch=' + ', '.join(str(c) for c in self.filter_channels)
        elif self.exclude_channels:
            ch_str = 'ALL excl=' + ', '.join(str(c) for c in self.exclude_channels)
        else:
            ch_str = 'ALL'
        banner = (f"UMM Parser — {self.host}:{self.port}  "
                  f"mtype={mtype_str}  subtype={sub_str}  channel={ch_str}")
        if self.use_color:
            banner = self._formatter.header_color() + banner + _Ansi.RESET
        print(banner)
        print("-" * 70)
        for w in self._config_warnings:
            print(f"  [parser.conf] {w}")

        try:
            self._client.run()
        finally:
            if self._record:
                self._record.close()
            print(f"\n{self._msg_count} messages received.")

    def stop(self) -> None:
        """Stop a running parser: disconnect the client so the blocking run()
        returns.  Safe to call from another thread (e.g. the keyboard 'q'
        handler) — disconnect() schedules the shutdown on the event loop."""
        try:
            self._client.disconnect()
        except Exception:
            pass

    def _on_msg(self, msg: UMMMsg) -> None:
        """Called for every received message."""
        from ..core.messages import Channel as _CH, UMMSubType as _ST
        # Suppress router control messages (mtype=1, subtypes 1–9) unless
        # --show-control is set.  REGISTER messages travel on the subscription
        # channel (not always channel=1), so match on mtype+subtype only.
        # Exception: debug output is also (mtype=1, subtype=1) but rides the
        # DEBUG channel — never treat it as control, or --channel 3 shows nothing.
        if (msg.mtype == 1 and 1 <= msg.subtype <= 9
                and msg.channel != int(_CH.DEBUG)):
            if not self.show_control:
                return
        # Suppress mtype=1 capability responses on the META channel from display.
        # These are processed internally by _on_cap_response; showing them on
        # startup floods the screen with JSON blobs.
        if (msg.mtype == 1 and msg.channel == int(_CH.META)
                and msg.subtype == int(_ST.CAPABILITY_RESPONSE)):
            if not self._startup_cap_done:
                return
        # Exclude-channel filter: skip channels the user wants hidden.
        if self.exclude_channels and msg.channel in self.exclude_channels:
            return
        self._msg_count += 1
        text = self._formatter.format(msg, self.show_hex, self.raw_mode,
                                      self.show_flags,
                                      show_channel=self.show_channel,
                                      show_json=self.show_json,
                                      show_reg=self.show_reg)
        print(text)

        if self._record:
            self._record.write(msg)

        if self.on_message:
            self.on_message(text, msg)

    def _on_control_and_display(self, msg: UMMMsg) -> None:
        """Track AND display control messages (when --show-control is set)."""
        self._on_control_msg(msg)
        self._on_msg(msg)

    def _on_control_msg(self, msg: UMMMsg) -> None:
        """Track REGISTER/UNREGISTER/ATTACH/DETACH to build the sub/agent maps."""
        import struct as _struct
        st        = msg.subtype
        origin_id = msg.origin.id

        try:
            if st == int(UMMSubType.ATTACH):
                # Extract process name from LogId TLV (type_id=15)
                if msg.tdata.value:
                    for tlv in decode_all(msg.tdata.value):
                        if tlv.type_id == 15 and tlv.value:
                            name = tlv.value.split(b'\x00')[0].decode('utf-8',
                                                                        errors='replace')
                            self._agent_names[origin_id] = name
                            break

            elif st == int(UMMSubType.REGISTER):
                # UMMReg payload: mtype(4) subtype(4) [match_tlvs…]
                # Channel comes from the message header.
                if msg.tdata.value:
                    for tlv in decode_all(msg.tdata.value):
                        if tlv.type_id == 11 and tlv.value and len(tlv.value) >= 8:
                            reg_mtype, reg_sub = _struct.unpack_from('!ii',
                                                                      tlv.value, 0)
                            reg_ch = msg.channel
                            self._sub_map.setdefault(origin_id, {})[msg.reg_id] = (
                                reg_mtype, reg_sub, reg_ch,
                                self._formatter.names.full_name(reg_mtype, reg_sub))
                            break

            elif st == int(UMMSubType.UNREGISTER):
                self._sub_map.get(origin_id, {}).pop(msg.reg_id, None)

            elif st == int(UMMSubType.DETACH):
                self._sub_map.pop(origin_id, None)
                self._agent_names.pop(origin_id, None)

        except Exception as exc:
            logger.debug("_on_control_msg error: %s", exc)

    def _on_list_agents_names(self, msg: UMMMsg) -> None:
        """Populate attach_id → name from the router's ListAgents response.

        Authoritative source (same one `runumm agents` uses), so it names
        every attached agent, including ones that attached before us.
        """
        if not msg.tdata.value:
            return
        try:
            import json as _json
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == TLV_STRING:
                    text = tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
                    try:
                        data = _json.loads(text)
                    except Exception:
                        return
                    for a in data.get('agents', []):
                        aid  = a.get('attach_id')
                        name = a.get('name')
                        if aid is not None and name:
                            self._agent_names[aid] = name
                    return
        except Exception as exc:
            logger.debug("Parser: _on_list_agents_names error: %s", exc)

    def _on_cap_response(self, msg: UMMMsg) -> None:
        """
        Handle a capability response (UMM, 11) arriving from any agent.
        Extracts the JSON capability descriptor and loads names into the registry.
        Used both for the initial broadcast and for responses to targeted queries.
        """
        if not msg.tdata.value:
            return
        try:
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == TLV_STRING:
                    text = tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
                    try:
                        from ..capability import AgentCapability
                        cap = AgentCapability.from_json(text)
                        if cap and cap.mtype > 0:
                            self._formatter.names.register_capability(cap)
                            logger.info("Parser: loaded capability names for mtype=%d (%s)",
                                        cap.mtype, cap.what)
                    except Exception as exc:
                        logger.debug("Parser: capability parse error: %s", exc)
                    return
        except Exception as exc:
            logger.debug("Parser: _on_cap_response error: %s", exc)

    def _on_agent_attached(self, msg: UMMMsg) -> None:
        """
        Called when a new agent attaches to the router.
        Extracts the agent's mtype and sends a targeted capability query if
        we don't already have names for it.
        """
        import struct as _struct
        if not msg.tdata.value:
            return
        # A new agent attached — refresh the authoritative name list so the
        # src column can show its name on the very next message.
        try:
            self._client.send(mtype=1, subtype=int(UMMSubType.LIST_AGENTS))
        except Exception:
            pass
        try:
            agent_mtype = 0
            agent_name  = ""
            for tlv in decode_all(msg.tdata.value):
                if tlv.type_id == 2 and len(tlv.value) == 4:   # Int = mtype
                    agent_mtype = _struct.unpack('!i', tlv.value)[0]
                elif tlv.type_id == TLV_STRING:
                    agent_name = tlv.value.rstrip(b'\x00').decode('utf-8',
                                                                    errors='replace')
            if agent_mtype <= 0:
                return

            # Check if we already know this mtype
            if self._formatter.names.subtype_name(agent_mtype, 0) is not None:
                return   # already have names for this mtype

            logger.debug("Parser: new agent mtype=%d name=%s — querying capabilities",
                         agent_mtype, agent_name)

            # Send targeted capability query — response arrives on the
            # standing (UMM, 11) subscription and is handled by _on_cap_response.
            int_handler = None
            try:
                from ..core.registry import registry as _reg
                int_handler = _reg.get_by_id(2)
            except Exception:
                pass
            if int_handler:
                self._client.send(
                    mtype=1, subtype=int(UMMSubType.CAPABILITY_QUERY),
                    tlvs=[int_handler.make_tlv(agent_mtype)])

        except Exception as exc:
            logger.debug("Parser: lifecycle handler error: %s", exc)


    def send(self, mtype: int, subtype: int,
             tlv_text: str) -> None:
        """
        Send an ad-hoc message from text description.
        Format: 'TypeName value  TypeName value ...'
        Example: 'Int 42  Char "hello"'
        """
        tlvs = self._parse_tlv_text(tlv_text)
        self._client.send(mtype=mtype, subtype=subtype, tlvs=tlvs or None)

    @staticmethod
    def _parse_tlv_text(text: str) -> List[TLV]:
        """Parse 'TypeName value TypeName value ...' into TLV list."""
        import re
        tlvs: List[TLV] = []
        text = text.strip()
        while text:
            m = re.match(r'^(\w+)\s*(.*)', text)
            if not m:
                break
            type_name = m.group(1)
            rest      = m.group(2).strip()
            handler   = registry.get_by_name(type_name)
            if not handler:
                break
            # Quoted string?
            if rest.startswith('"'):
                end = rest.find('"', 1)
                val_str = rest[1:end] if end != -1 else rest[1:]
                text    = rest[end+1:].strip() if end != -1 else ''
            else:
                tok = re.match(r'^(\S+)(.*)', rest)
                if tok:
                    val_str = tok.group(1)
                    text    = tok.group(2).strip()
                else:
                    val_str = rest
                    text    = ''
            try:
                val_bytes = handler.pack(handler.from_text(val_str))
                tlvs.append(TLV(type_id=handler.TYPE_ID, value=val_bytes))
            except Exception as exc:
                logger.warning("Could not parse '%s %s': %s", type_name, val_str, exc)
        return tlvs


# ── CLI entry point ───────────────────────────────────────────────────────────

def _handle_parser_cmd(parser: 'ParserModule', cmd: str) -> None:
    """Handle an interactive query command typed while parser is running."""
    parts = cmd.lower().split()
    if not parts:
        return

    if parts[0] == 'subs':
        # subs          — all subscriptions
        # subs <mtype>  — who subscribes to this mtype
        filter_mtype = int(parts[1]) if len(parts) > 1 else None
        names = parser._formatter.names
        print()
        print("  ── Subscriptions ──────────────────────────────────────")
        if not parser._sub_map and not parser._agent_names:
            print("  No subscription data yet.")
            print("  Tip: use --show-control to track REGISTER messages.")
        else:
            for aid in sorted(set(list(parser._sub_map.keys()) +
                                  list(parser._agent_names.keys()))):
                agent_name = parser._agent_names.get(aid, f'agent{aid}')
                subs = parser._sub_map.get(aid, {})
                if filter_mtype is not None:
                    subs = {r: v for r, v in subs.items()
                            if v[0] == filter_mtype}
                if filter_mtype is not None and not subs:
                    continue
                print(f"  {aid:3d}  {agent_name}")
                if subs:
                    for reg_id, (mt, st, ch, full) in sorted(subs.items()):
                        _CH_NAMES = {0: 'ALL', 1: 'APP', 2: 'Confirm',
                                     3: 'Debug', 4: 'Meta', 128: 'Sim'}
                        ch_str = f'  ch={ch}({_CH_NAMES.get(ch, str(ch))})'
                        print(f"       reg={reg_id:3d}  {full}{ch_str}")
                else:
                    print(f"       (no subscriptions" +
                          (f" for mtype={filter_mtype})" if filter_mtype
                           else ")"))
        print()

    elif parts[0] == 'who':
        # who <mtype> <subtype>  — who would receive this message
        if len(parts) < 3:
            print("  Usage: who <mtype> <subtype>")
            return
        try:
            mt = int(parts[1])
            st = int(parts[2])
        except ValueError:
            print("  ERROR: mtype and subtype must be integers")
            return
        names  = parser._formatter.names
        full   = names.full_name(mt, st)
        print()
        print(f"  ── Who receives {full} ────────────────────────────")
        receivers = []
        for aid, subs in parser._sub_map.items():
            for reg_id, (reg_mt, reg_st, reg_ch, _) in subs.items():
                # Wildcard: 0,0 = all; mtype,0 = all subtypes of mtype
                mt_match = reg_mt == 0 or reg_mt == mt
                st_match = reg_st == 0 or reg_st == st
                if mt_match and st_match:
                    aname = parser._agent_names.get(aid, f'agent{aid}')
                    receivers.append((aid, aname, reg_id, reg_mt, reg_st, reg_ch))
        if receivers:
            for aid, aname, reg_id, reg_mt, reg_st, reg_ch in receivers:
                sub_desc = (f"mtype={reg_mt},subtype={reg_st}" if reg_mt else
                            "wildcard all")
                ch_desc = f"  ch={reg_ch}" if reg_ch else ""
                print(f"  {aid:3d}  {aname:<20} reg={reg_id}  "
                      f"(subscribed as {sub_desc}{ch_desc})")
        else:
            print(f"  Nobody — no agent has subscribed to {full}")
            print("  (data may be incomplete without --show-control)")
        print()

    elif parts[0] == 'agents':
        print()
        print("  ── Known agents ──────────────────────────────────────")
        if not parser._agent_names:
            print("  No agent data yet. Use --show-control to see ATTACH messages.")
        for aid, name in sorted(parser._agent_names.items()):
            nsubs = len(parser._sub_map.get(aid, {}))
            print(f"  {aid:3d}  {name:<20}  {nsubs} subscriptions")
        print()

    else:
        print("  Parser commands:  subs | subs <mtype> | who <mtype> <subtype> "
              "| agents | q")


def _main() -> None:
    import argparse
    logging.basicConfig(
        level=logging.WARNING,   # quiet by default; parser output is the display
        format='%(levelname)s %(name)s: %(message)s',
    )
    p = argparse.ArgumentParser(description='UMM Parser / Bus Monitor')
    p.add_argument('--version', action='store_true',
                   help='Show version and exit')
    p.add_argument('--router',   default='localhost', dest='host')
    p.add_argument('--port',     type=int, default=DEFAULT_PORT)
    p.add_argument('--name',     default='Parser',
                   help='Process name shown in the agents list (default: Parser)')
    p.add_argument('--mtype',    type=int, default=[], action='append',
                   dest='mtypes',
                   help='Filter: only show this mtype (repeat for multiple; '
                        'negative values supported e.g. --mtype -2 for debug). '
                        'Omit for all mtypes.')
    p.add_argument('--subtype',  type=int, default=0,
                   help='Filter: only show this subtype (0=all)')
    p.add_argument('--channel',  type=int, default=[], action='append',
                   dest='channels', metavar='N',
                   help='Subscribe on channel N only (repeat for multiple). '
                        'e.g. --channel 1 for app bus, --channel 3 for debug. '
                        'Omit to subscribe on all channels (channel=0 wildcard).')
    p.add_argument('--exclude-channel', type=int, default=[], action='append',
                   dest='exclude_channels', metavar='N',
                   help='Subscribe on all channels but hide channel N in output '
                        '(repeat for multiple). '
                        'e.g. --exclude-channel 128 to suppress simulation traffic. '
                        'Ignored when --channel is specified.')
    p.add_argument('--show-channel', action='store_true', default=False,
                   help='Always show the channel number on every message '
                        '(auto-enabled when --channel is specified)')
    p.add_argument('--record',   default=None, metavar='FILE',
                   help='Record all messages to a JSON-lines file for later replay '
                        'via: python3 -m umm.tools.send --replay FILE')
    p.add_argument('--hex',      action='store_true', dest='show_hex',
                   help='Show unknown TLV values as hex')
    p.add_argument('--flags',    action='store_true', dest='show_flags',
                   help='Show message flags (RTR/RCV/APP confirm) when non-zero')
    p.add_argument('--raw',      action='store_true', dest='raw_mode',
                   help='Show mtype/subtype as raw numbers instead of names')
    p.add_argument('--names',    default=None, metavar='FILE',
                   help='Load mtype/subtype names from config file '
                        '(default: auto-load umm_names.conf if present)')
    p.add_argument('--heading',  action='store_true',
                   help='Print column headings before message stream')
    p.add_argument('--show-control', action='store_true',
                   help='Show UMM control messages (ATTACH, REGISTER etc.) '
                        'normally handled internally by the router')
    p.add_argument('--show-reg', action='store_true', dest='show_reg',
                   help='Show the receiving subscription reg id (reg=N) on each '
                        'line (off by default — rarely relevant)')
    p.add_argument('--json-decode', action='store_true', dest='show_json',
                   help='Expand JSON TLV values inline (default: show as quoted string)')
    p.add_argument('--typedir',  action='append', default=[],
                   help='Extra type plugin directories')
    p.add_argument('--dont-truncate', action='store_false', dest='truncate',
                   default=True,
                   help='Do not truncate long lines to the terminal width '
                        '(default: truncate with … so the header stays visible)')
    p.add_argument('--no-color', '--no-colour', '--no-colors', '--no-colours',
                   action='store_const', const=False, default=None, dest='color',
                   help='Disable colour even on a terminal. All other formatting '
                        '(truncation, column layout) is kept — only the colours '
                        'are dropped. Colour is otherwise auto-enabled when stdout '
                        'is a terminal and NO_COLOR is unset.')
    p.add_argument('--config-file', '--config', default=None, metavar='FILE',
                   dest='config_file',
                   help='Parser config file (colours etc.). Default: parser.conf '
                        'in the working directory. Use a different file per '
                        'project or per user.')
    p.add_argument('--project', default=None, action='append', metavar='FILE',
                   help='Consolidated project file defining all message types for '
                        'a project in one place: [names] (mtype/subtype names), '
                        '[meta] (meta-word names) and [colors] (parser colours). '
                        'The top-level project.conf (next to umm.conf) is always '
                        'loaded first for installation-wide defaults; --project '
                        'adds more files on top and may be repeated (e.g. '
                        '--project examples/sorting/sorting.conf). The last file '
                        'loaded wins on any overlap.')
    p.add_argument('--debug',    action='store_true')
    args = p.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    for d in args.typedir:
        registry.add_search_dir(d)

    parser = ParserModule(
        host             = args.host,
        port             = args.port,
        name             = args.name,
        filter_mtypes    = args.mtypes,
        filter_subtype   = args.subtype,
        filter_channels  = args.channels,
        exclude_channels = args.exclude_channels,
        record_file      = args.record,
        show_hex         = args.show_hex,
        show_flags       = args.show_flags,
        raw_mode         = args.raw_mode,
        show_channel     = args.show_channel,
        show_control     = args.show_control,
        show_json        = args.show_json,
        show_reg         = args.show_reg,
        truncate         = args.truncate,
        color            = args.color,
        config_file      = args.config_file,
    )
    if args.names:
        parser._formatter.names.load_file(args.names)
    # Project files. The top-level project.conf (alongside umm.conf at the
    # project root) is ALWAYS loaded first, so installation-wide defaults —
    # heading/router/confirm colours and the like — live in one place. Then any
    # --project files are layered on top, in order. Last file loaded wins on
    # overlap.
    from pathlib import Path as _Path
    from umm.project import load_project
    _proj_files = []
    _default_pc = _Path(__file__).resolve().parents[2] / 'project.conf'
    if _default_pc.exists():
        _proj_files.append(str(_default_pc))
    for _pf in (args.project or []):
        _proj_files.append(_pf)
    for _pf in _proj_files:
        _, _, _warns = load_project(_pf, parser._formatter.names,
                                    parser._formatter.color_rules)
        for _w in _warns:
            logger.warning("project: %s", _w)
    if args.heading:
        h = parser._formatter.heading(args.show_reg)
        if parser.use_color:
            h = parser._formatter.header_color() + h + _Ansi.RESET
        print(h)
        print(parser._formatter.separator())

    # Start subscription query thread (reads keyboard while parser runs)
    import threading as _threading
    stop_evt = _threading.Event()

    def query_thread():
        try:
            import sys as _sys
            # Check if stdin is a real terminal — if not (e.g. backgrounded
            # by umm_ctl), skip the query thread entirely
            if not _sys.stdin or not _sys.stdin.isatty():
                return
        except Exception:
            return
        print("  Commands while running:  subs  |  subs <mtype>  |  "
              "who <mtype> <subtype>  |  q")
        while not stop_evt.is_set():
            try:
                cmd = input().strip()
            except (EOFError, KeyboardInterrupt, OSError):
                break
            if not cmd:
                continue
            if cmd in ('q', 'quit', 'exit'):
                stop_evt.set()
                parser.stop()      # actually unblock parser.run()
                break
            _handle_parser_cmd(parser, cmd)

    t = _threading.Thread(target=query_thread, daemon=True,
                          name='parser-query')
    t.start()
    try:
        parser.run()
    except KeyboardInterrupt:
        pass
    except RuntimeError as exc:
        print(f"\n  ERROR: {exc}")
        print("  Is the router running?  Start it with: ./umm.sh start router")
    finally:
        stop_evt.set()


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)