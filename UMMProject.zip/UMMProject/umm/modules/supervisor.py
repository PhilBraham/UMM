"""
umm.modules.supervisor
======================
UMM Supervisor — process management and liveness monitoring.

The supervisor is a UMM agent (mtype=12) that starts immediately after the
router.  It reads ``supervisor.conf``, starts all configured agents, monitors
their liveness, and restarts them according to their configured policy.

It replaces the watchdog module and takes over process management from
``umm_ctl``.  ``umm_ctl`` remains fully functional — implementations that
prefer manual control can continue to use it.

supervisor.conf format
----------------------
One directive per line.  Lines beginning with ``#`` are comments.
Blank lines are ignored.

Start directives::

    Start "python3 -m umm.modules.timer --name timer"  C
    Start "python3 -m umm.modules.typedir --name typedir"  E
    Start "python3 -m umm.demo.conveyor --name conveyor"  E  H 10
    Start "python3 -m umm.tools.send --file init.conf --router {router} --port {port}"

Flags (space-separated, after the quoted command):

    C            CRITICAL  — attach with PERM_KEEP_CONN; router stores
                             messages while agent is down; supervisor
                             restarts on detach.  Mutually exclusive with E.
    E            ESSENTIAL — router does not store messages; supervisor
                             restarts on detach.  Mutually exclusive with C.
    H <secs>     HEARTBEAT — supervisor pings every <secs> seconds;
                             agent must respond; combinable with C or E.
    O            ONESHOT   — runs once and exits (e.g. an init sender);
                             reported as idle (not crashed) when not running.

Restart policy
--------------
Exponential backoff: 2 s, 4 s, 8 s … capped at 60 s.
After ``max_restarts`` failed attempts (default 5): declare agent dead,
publish ``(12, -103)`` AgentFailed, stop retrying.
Before each restart: SIGKILL the old PID in case the process is hung.

Heartbeat
---------
Subtype ``ReservedSubType.HEARTBEAT = 5``.
Supervisor sends ``(agent_mtype, 5)`` with ``Int(seq)``.
Agent responds with the same subtype and same ``Int(seq)``.
Two consecutive missed responses → Shutdown + restart.

Messages published by the supervisor
-------------------------------------
    (12, -101)  AgentStarted  Char(name) Int(pid)
    (12, -102)  AgentStopped  Char(name) Int(pid) Int(exit_code)
    (12, -103)  AgentFailed   Char(name) Int(attempt_count)  — give-up

Messages accepted by the supervisor
-------------------------------------
    (12, 101)  StartAgent   Char(command) [Int(flags)]
    (12, 102)  StopAgent    Char(name)
    (12, 103)  RestartAgent Char(name)
    (12, 104)  AgentStatus  — response on (-3, ?) future; logs for now
    (any, 4)   Shutdown     — stops all managed agents then exits

Run standalone::

    python3 -m umm.modules.supervisor \\
        --router localhost --port 5100 \\
        --config supervisor.conf

Or programmatically::

    from umm.modules.supervisor import SupervisorModule
    sup = SupervisorModule(host='localhost', port=5100,
                           config='supervisor.conf')
    sup.run()
"""

from __future__ import annotations

import logging
import os
import re
import shlex
import signal
import struct
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from enum import IntFlag
from pathlib import Path
from typing import Dict, List, Optional

from ..agent import UMMAgent, UMMConnectionError
from ..core.messages import (
    MType, UMMSubType, AttachFlag, ReservedSubType, HeartbeatSubType, Channel,
    UMM_VERSION_STR, DEFAULT_PORT,
)
from ..core.tlv import TLV, decode_all, TLV_INT, TLV_STRING, TLV_JSON
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin
from ..capability import CapabilityMixin, make_capability, SubtypeSpec, TLVSpec

logger = logging.getLogger(__name__)

# ── constants ─────────────────────────────────────────────────────────────────

MT_SUPERVISOR = int(MType.SUPERVISOR)   # 12

ST_START_AGENT   = 101   # C→Sup: Char(command) [Int(flags)]
ST_STOP_AGENT    = 102   # C→Sup: Char(name)
ST_RESTART_AGENT = 103   # C→Sup: Char(name)
ST_AGENT_STATUS  = 104   # C→Sup: request status
ST_AGENT_STATUS_RESPONSE = 105  # Sup→C: JSON(agent_list) response to ST_AGENT_STATUS

ST_AGENT_STARTED = -101  # Sup→*: Char(name) Int(pid)
ST_AGENT_STOPPED = -102  # Sup→*: Char(name) Int(pid) Int(exit_code)
ST_AGENT_FAILED  = -103  # Sup→*: Char(name) Int(attempt_count)

# Heartbeat uses channel=HEARTBEAT (4) with mtype=UMM, not negative mtype=-4
CH_HEARTBEAT     = int(Channel.HEARTBEAT)         # channel 4
MT_HEARTBEAT     = int(MType.UMM)                 # mtype 1 on channel 4
HB_PING          = int(HeartbeatSubType.PING)     #  1  supervisor → agent
HB_PONG          = int(HeartbeatSubType.PONG)     #  2  agent → supervisor

RESTART_BASE_DELAY = 2.0    # seconds — doubled on each attempt
RESTART_MAX_DELAY  = 60.0   # cap
DEFAULT_MAX_RESTARTS = 5


# ── agent flags ───────────────────────────────────────────────────────────────

class AgentPolicy(IntFlag):
    NONE      = 0x00
    CRITICAL  = 0x01   # C — PERM_KEEP_CONN + restart on detach
    ESSENTIAL = 0x02   # E — restart on detach (no message storage)
    HEARTBEAT = 0x04   # H — active liveness via ping/pong
    ONESHOT   = 0x08   # O — runs once and exits; not-running is normal


# ── managed agent record ──────────────────────────────────────────────────────

@dataclass
class ManagedAgent:
    """Runtime state for one supervised agent."""
    name:            str              # display name (derived from command)
    command:         str              # full shell command to launch
    policy:          AgentPolicy      # C / E / H flags
    heartbeat_secs:  float            = 0.0    # 0 = no heartbeat
    mtype:           int              = 0      # detected from AGENT_ATTACHED
    pid:             int              = 0      # current OS pid (0 = not running)
    attach_id:       int              = 0      # router attach_id (0 = not attached)
    restart_count:   int              = 0
    last_attach:     float            = 0.0
    last_heartbeat_sent: float        = 0.0
    last_heartbeat_ack:  float        = 0.0
    heartbeat_seq:   int              = 0
    missed_heartbeats: int            = 0
    given_up:        bool             = False  # True after max restarts exhausted
    _lock:           threading.Lock   = field(default_factory=threading.Lock,
                                              repr=False)

    @property
    def is_running(self) -> bool:
        return self.pid > 0 and self._pid_alive()

    @property
    def restart_policy(self) -> bool:
        return bool(self.policy & (AgentPolicy.CRITICAL | AgentPolicy.ESSENTIAL))

    @property
    def oneshot(self) -> bool:
        """True for run-once tools (e.g. send --file init.conf): they exit
        after doing their job, so 'not running' is normal, not a failure."""
        return bool(self.policy & AgentPolicy.ONESHOT)

    def _pid_alive(self) -> bool:
        if self.pid <= 0:
            return False
        if sys.platform == 'win32':
            # CRITICAL: do NOT use os.kill(pid, 0) on Windows.  signal 0 is
            # CTRL_C_EVENT there, so os.kill(pid, 0) calls
            # GenerateConsoleCtrlEvent(CTRL_C_EVENT, pid) — it sends a console
            # Ctrl-C to the process group rather than probing liveness, which
            # can take down the router and other agents sharing the console.
            # Query the process handle instead.
            import ctypes
            SYNCHRONIZE  = 0x00100000
            WAIT_TIMEOUT = 0x00000102   # still running (not signalled)
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, self.pid)
            if not handle:
                return False            # no such process (or fully exited)
            try:
                return kernel32.WaitForSingleObject(handle, 0) == WAIT_TIMEOUT
            finally:
                kernel32.CloseHandle(handle)
        try:
            os.kill(self.pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False

    def restart_delay(self) -> float:
        """Exponential backoff capped at RESTART_MAX_DELAY."""
        delay = RESTART_BASE_DELAY * (2 ** (self.restart_count - 1))
        return min(delay, RESTART_MAX_DELAY)


# ── config parser ─────────────────────────────────────────────────────────────

def parse_supervisor_conf(path: str) -> List[ManagedAgent]:
    """
    Parse ``supervisor.conf`` and return a list of ManagedAgent records.

    Format::

        Start "command [args...]"  [C] [E] [H <secs>]
        # comment
    """
    agents: List[ManagedAgent] = []
    lineno = 0

    try:
        with open(path) as fh:
            lines = fh.readlines()
    except FileNotFoundError:
        raise FileNotFoundError(f"supervisor.conf not found: {path}")

    for raw in lines:
        lineno += 1
        line = raw.strip()
        if not line or line.startswith('#'):
            continue

        parts = line.split(None, 1)
        keyword = parts[0].upper()

        if keyword != 'START':
            logger.warning("supervisor.conf line %d: unknown directive %r — ignored",
                           lineno, parts[0])
            continue

        if len(parts) < 2:
            logger.warning("supervisor.conf line %d: Start with no command — ignored",
                           lineno)
            continue

        rest = parts[1].strip()

        # Extract quoted command
        m = re.match(r'^"([^"]+)"\s*(.*)', rest)
        if not m:
            # Try single-quoted
            m = re.match(r"^'([^']+)'\s*(.*)", rest)
        if not m:
            logger.warning("supervisor.conf line %d: command must be quoted — ignored",
                           lineno)
            continue

        command   = m.group(1).strip()
        flags_str = m.group(2).strip().upper()

        # Derive a display name from the command (last non-flag token before --)
        name = _derive_name(command)

        # Parse flags
        policy         = AgentPolicy.NONE
        heartbeat_secs = 0.0
        flag_tokens    = flags_str.split()
        i = 0
        while i < len(flag_tokens):
            tok = flag_tokens[i]
            if tok == 'C':
                if policy & AgentPolicy.ESSENTIAL:
                    logger.warning("supervisor.conf line %d: C and E are mutually "
                                   "exclusive — E ignored", lineno)
                    policy &= ~AgentPolicy.ESSENTIAL
                policy |= AgentPolicy.CRITICAL
            elif tok == 'E':
                if policy & AgentPolicy.CRITICAL:
                    logger.warning("supervisor.conf line %d: C and E are mutually "
                                   "exclusive — E ignored", lineno)
                else:
                    policy |= AgentPolicy.ESSENTIAL
            elif tok == 'H':
                i += 1
                if i >= len(flag_tokens):
                    logger.warning("supervisor.conf line %d: H requires a value in "
                                   "seconds — ignored", lineno)
                else:
                    try:
                        heartbeat_secs = float(flag_tokens[i])
                        policy |= AgentPolicy.HEARTBEAT
                    except ValueError:
                        logger.warning("supervisor.conf line %d: H value %r is not "
                                       "a number — ignored", lineno, flag_tokens[i])
            elif tok == 'O':
                policy |= AgentPolicy.ONESHOT
            else:
                logger.warning("supervisor.conf line %d: unknown flag %r — ignored",
                               lineno, tok)
            i += 1

        agents.append(ManagedAgent(
            name           = name,
            command        = command,
            policy         = policy,
            heartbeat_secs = heartbeat_secs,
        ))
        logger.debug("supervisor.conf: loaded agent %r  policy=%s  hb=%.0fs",
                     name, policy, heartbeat_secs)

    return agents


def _derive_name(command: str) -> str:
    """Extract a short display name from a command string."""
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()

    # Look for --name arg
    for i, tok in enumerate(tokens):
        if tok == '--name' and i + 1 < len(tokens):
            return tokens[i + 1]
        if tok.startswith('--name='):
            return tok.split('=', 1)[1]

    # Fall back to last path component of first arg that looks like a module/script
    for tok in tokens:
        if tok.startswith('-'):
            continue
        # python3 -m umm.modules.timer  → "timer"
        # python3 umm_initiator.py      → "umm_initiator"
        name = tok.replace('-', '_').rstrip('.py')
        if '.' in name:
            name = name.rsplit('.', 1)[-1]
        if name and name not in ('python', 'python3', 'python3.11', 'python3.14',
                                 'm', 'c'):
            return name

    return command[:30]


# ── supervisor module ─────────────────────────────────────────────────────────

class SupervisorModule(DebugMixin, VersionMixin, ShutdownMixin, CapabilityMixin):
    """
    UMM Supervisor agent.

    Reads ``supervisor.conf``, starts all configured agents, monitors
    liveness, and restarts failed agents according to their policy.

    Parameters
    ----------
    host, port   : router connection (default localhost:5100)
    config       : path to supervisor.conf
    max_restarts : give-up threshold per agent (default 5)
    name         : process name shown on the bus
    """

    AGENT_VERSION = "1.0.0"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    from ..capability import SUPERVISOR_CAPABILITY as CAPABILITY

    def __init__(self,
                 host:         str   = 'localhost',
                 port:         int   = DEFAULT_PORT,
                 config:       str   = 'supervisor.conf',
                 max_restarts: int   = DEFAULT_MAX_RESTARTS,
                 name:         str   = 'Supervisor') -> None:
        self.host         = host
        self.port         = port
        self.config_path  = config
        self.max_restarts = max_restarts

        self._client = UMMAgent(host=host, port=port,
                                process_name=name,
                                agent_mtype=MT_SUPERVISOR)

        # name → ManagedAgent
        self._agents: Dict[str, ManagedAgent] = {}
        # mtype → ManagedAgent  (populated when AGENT_ATTACHED arrives)
        self._by_mtype: Dict[int, ManagedAgent] = {}
        # attach_id → ManagedAgent
        self._by_attach: Dict[int, ManagedAgent] = {}

        self._running  = False
        self._hb_thread: Optional[threading.Thread] = None

    # ── public API ────────────────────────────────────────────────────────────

    def run(self) -> None:
        """Load config, connect, start all agents, enter monitoring loop."""
        # Load config
        try:
            agent_list = parse_supervisor_conf(self.config_path)
        except FileNotFoundError as exc:
            print(f"\n  ERROR: {exc}")
            return
        except Exception as exc:
            print(f"\n  ERROR: Failed to parse {self.config_path}: {exc}")
            return

        for a in agent_list:
            self._agents[a.name] = a

        # Connect to router
        try:
            self._client.connect()
        except UMMConnectionError as exc:
            print(f"\n  ERROR: Supervisor could not connect to router: {exc}")
            return

        # Register standard handlers
        self.register_capability_handler(self._client)
        self.register_debug_handler(self._client, MT_SUPERVISOR,
                                    debug=getattr(self, '_debug_flag', False))
        self.register_version_handler(self._client, MT_SUPERVISOR)
        self.register_shutdown_handler(self._client, MT_SUPERVISOR)

        # Register control message handlers
        self._client.register(MT_SUPERVISOR, ST_START_AGENT,
                              self._on_start_agent,
            channel=0)   # ALL — accept from any channel
        self._client.register(MT_SUPERVISOR, ST_STOP_AGENT,
                              self._on_stop_agent,
            channel=0)   # ALL — accept from any channel
        self._client.register(MT_SUPERVISOR, ST_RESTART_AGENT,
                              self._on_restart_agent,
            channel=0)   # ALL — accept from any channel
        self._client.register(MT_SUPERVISOR, ST_AGENT_STATUS,
                              self._on_status_request,
            channel=0)   # ALL — accept from any channel

        # Subscribe to heartbeat pong responses on channel=HEARTBEAT
        # The subtype on the response tells us it's a pong;
        # attach_id in the message tells us which agent sent it.
        self._client.register(MT_HEARTBEAT, HB_PONG,
                              self._on_heartbeat_response,
                              channel=CH_HEARTBEAT,
                              dont_send_self=True)

        # Subscribe to lifecycle notifications
        self._client.register(int(MType.UMM), int(UMMSubType.AGENT_ATTACHED),
                              self._on_agent_attached,
                              dont_send_self=True)
        self._client.register(int(MType.UMM), int(UMMSubType.AGENT_DETACHED),
                              self._on_agent_detached,
                              dont_send_self=True)

        logger.info("Supervisor connected — starting %d agents from %s",
                    len(self._agents), self.config_path)
        print(f"[Supervisor] Starting {len(self._agents)} agents from "
              f"{self.config_path}")

        # Start all configured agents
        self._running = True
        for agent in list(self._agents.values()):
            self._launch(agent)

        # Start heartbeat thread
        self._hb_thread = threading.Thread(
            target=self._heartbeat_loop,
            name='supervisor-heartbeat',
            daemon=True,
        )
        self._hb_thread.start()

        # Enter UMM event loop (blocks until disconnect or shutdown)
        try:
            self._client.run()
        except KeyboardInterrupt:
            pass
        finally:
            self._running = False
            self._stop_all()

    # ── agent lifecycle ───────────────────────────────────────────────────────

    def _launch(self, agent: ManagedAgent, is_restart: bool = False) -> None:
        """Start an agent process."""
        # Substitute {router} and {port} placeholders with actual values
        command = (agent.command
                   .replace('{router}', self.host)
                   .replace('{port}',   str(self.port)))

        # Inject --permanent for CRITICAL agents if not already present
        if (agent.policy & AgentPolicy.CRITICAL and
                '--permanent' not in command):
            command = command + ' --permanent'

        label = "Restarting" if is_restart else "Starting"
        logger.info("%s: %s  command=%r", label, agent.name, command)
        print(f"[Supervisor] {label}: {agent.name}")

        # Working directory = directory containing supervisor.conf so that
        # relative paths in the config (e.g. "umm_gui/server.py") resolve
        # correctly regardless of where the supervisor itself was launched from.
        work_dir = str(Path(self.config_path).parent.resolve())

        # Log output to a per-agent file in the working directory
        log_path = Path(work_dir) / 'logs' / f'{agent.name}.log'
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_fh = open(log_path, 'a', encoding='utf-8', errors='replace')

        # Detach the managed agent from the console so a Ctrl-C in some other
        # window (e.g. a foreground parser sharing the console) is not
        # delivered to it.  start_new_session (setsid) does this on POSIX; its
        # Windows equivalent is CREATE_NEW_PROCESS_GROUP, which start_new_session
        # silently does NOT provide (it is a no-op on Windows).
        popen_kw = {}
        if sys.platform == 'win32':
            popen_kw['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            popen_kw['start_new_session'] = True

        try:
            proc = subprocess.Popen(
                shlex.split(command),
                stdout=log_fh,
                stderr=log_fh,
                cwd=work_dir,
                **popen_kw,
            )
            with agent._lock:
                agent.pid           = proc.pid
                agent.last_attach   = time.time()
                agent.missed_heartbeats = 0

            logger.info("Started %s  pid=%d", agent.name, proc.pid)

            self._publish(ST_AGENT_STARTED,
                          _str_tlv(agent.name),
                          _int_tlv(proc.pid))
        except Exception as exc:
            logger.error("Failed to start %s: %s", agent.name, exc)
            if agent.restart_policy:
                self._schedule_restart(agent)

    def _kill(self, agent: ManagedAgent) -> None:
        """SIGKILL a potentially hung process."""
        pid = agent.pid
        if pid <= 0:
            return
        try:
            if sys.platform == 'win32':
                # signal.SIGKILL does not exist on Windows; os.kill with
                # SIGTERM maps to TerminateProcess, a forceful kill.  (Avoid
                # signal 0/1 here — those are console Ctrl-C/Ctrl-Break events.)
                os.kill(pid, signal.SIGTERM)
            else:
                os.kill(pid, signal.SIGKILL)
            logger.info("Force-killed %s pid=%d", agent.name, pid)
        except ProcessLookupError:
            pass   # already gone
        except Exception as exc:
            logger.warning("Could not kill %s pid=%d: %s", agent.name, pid, exc)
        with agent._lock:
            agent.pid = 0

    def _schedule_restart(self, agent: ManagedAgent) -> None:
        """Schedule a restart with exponential backoff in a daemon thread."""
        if agent.given_up:
            return

        with agent._lock:
            agent.restart_count += 1
            count = agent.restart_count

        if count > self.max_restarts:
            # CRITICAL agents never give up — they keep restarting indefinitely
            # (delay capped at RESTART_MAX_DELAY). Only ESSENTIAL and unmonitored
            # agents are subject to the give-up limit.
            if agent.policy & AgentPolicy.CRITICAL:
                logger.warning("CRITICAL agent %s has restarted %d times — "
                               "continuing to restart (C agents never give up)",
                               agent.name, count)
                # Reset count so delay doesn't grow beyond max
                with agent._lock:
                    agent.restart_count = self.max_restarts
            else:
                agent.given_up = True
                logger.error("GIVE UP: %s failed to restart after %d attempts",
                             agent.name, self.max_restarts)
                print(f"[Supervisor] GIVE UP: {agent.name} — "
                      f"exceeded {self.max_restarts} restart attempts")
                self._publish(ST_AGENT_FAILED,
                              _str_tlv(agent.name),
                              _int_tlv(count))
                return

        delay = agent.restart_delay()
        logger.info("Will restart %s in %.0fs (attempt %d/%d)",
                    agent.name, delay, count, self.max_restarts)

        def _do_restart():
            time.sleep(delay)
            if not self._running:
                return
            self._kill(agent)   # ensure old process is dead
            self._launch(agent, is_restart=True)

        t = threading.Thread(target=_do_restart,
                             name=f'sup-restart-{agent.name}',
                             daemon=True)
        t.start()

    def _stop_agent_by_name(self, name: str) -> bool:
        """Send Shutdown to an agent, then SIGKILL if it doesn't die."""
        agent = self._agents.get(name)
        if not agent:
            return False

        # Send graceful Shutdown message
        if agent.mtype > 0:
            try:
                self._client.send(agent.mtype,
                                  int(ReservedSubType.SHUTDOWN))
            except Exception:
                pass

        # Give it 3 seconds then SIGKILL
        def _enforce():
            time.sleep(3.0)
            if agent.is_running:
                self._kill(agent)

        threading.Thread(target=_enforce, daemon=True).start()
        return True

    def _stop_all(self) -> None:
        """Gracefully stop all managed agents on supervisor shutdown."""
        logger.info("Supervisor stopping all managed agents")
        for agent in list(self._agents.values()):
            self._stop_agent_by_name(agent.name)
        time.sleep(1.0)   # brief grace period

    # ── heartbeat ─────────────────────────────────────────────────────────────

    def _heartbeat_loop(self) -> None:
        """Background thread: send heartbeats and detect missed responses."""
        while self._running:
            time.sleep(1.0)
            now = time.time()
            for agent in list(self._agents.values()):
                if not (agent.policy & AgentPolicy.HEARTBEAT):
                    continue
                if agent.mtype <= 0 or agent.attach_id == 0:
                    continue   # not yet attached
                if agent.given_up:
                    continue

                interval = agent.heartbeat_secs
                # Time to send a new heartbeat?
                if now - agent.last_heartbeat_sent >= interval:
                    with agent._lock:
                        agent.heartbeat_seq  = (agent.heartbeat_seq + 1) & 0x7FFFFFFF
                        seq                  = agent.heartbeat_seq
                        agent.last_heartbeat_sent = now

                    try:
                        # Ping on channel=HEARTBEAT with mtype=UMM, subtype=HB_PING
                        self._client.send(MT_HEARTBEAT, HB_PING,
                                          tlvs=[_int_tlv(seq)],
                                          channel=CH_HEARTBEAT)
                        logger.debug("Heartbeat ping → %s seq=%d", agent.name, seq)
                    except Exception as exc:
                        logger.warning("Heartbeat send failed for %s: %s",
                                       agent.name, exc)

                # Check for missed response (waited > 2× interval)
                if (agent.last_heartbeat_sent > 0 and
                        agent.last_heartbeat_ack < agent.last_heartbeat_sent and
                        now - agent.last_heartbeat_sent > interval * 2):
                    with agent._lock:
                        agent.missed_heartbeats += 1
                        missed = agent.missed_heartbeats
                        # Reset so we don't count this miss again
                        agent.last_heartbeat_sent = now

                    logger.warning("Missed heartbeat from %s (miss #%d)",
                                   agent.name, missed)

                    if missed >= 2:
                        logger.error("Two missed heartbeats from %s — restarting",
                                     agent.name)
                        agent.missed_heartbeats = 0
                        self._stop_agent_by_name(agent.name)
                        if agent.restart_policy:
                            self._schedule_restart(agent)

    def _on_heartbeat_response(self, msg) -> None:
        """Handle heartbeat response from any agent."""
        agent = self._by_attach.get(msg.attach_id.id)
        if not agent:
            return
        now = time.time()
        with agent._lock:
            agent.last_heartbeat_ack  = now
            agent.missed_heartbeats   = 0
        logger.debug("Heartbeat ack from %s", agent.name)

    # ── lifecycle handlers ────────────────────────────────────────────────────

    def _on_agent_attached(self, msg) -> None:
        """Router notified us an agent joined the bus."""
        mtype, attach_id, proc_name = _parse_lifecycle(msg)
        if mtype <= 0:
            return

        # Find a managed agent matching by name or mtype
        agent = self._find_agent(mtype, proc_name)
        if not agent:
            return

        with agent._lock:
            agent.mtype       = mtype
            agent.attach_id   = attach_id
            agent.last_attach = time.time()
            agent.restart_count = 0   # successful attach resets backoff
            agent.missed_heartbeats = 0
            agent.given_up    = False  # can try again if it crashes later

        self._by_mtype[mtype]     = agent
        self._by_attach[attach_id] = agent

        logger.info("Agent attached: %s  mtype=%d  attach_id=%d",
                    agent.name, mtype, attach_id)

    def _on_agent_detached(self, msg) -> None:
        """Router notified us an agent left the bus."""
        mtype, attach_id, proc_name = _parse_lifecycle(msg)
        if mtype <= 0:
            return

        agent = self._by_mtype.get(mtype) or self._by_attach.get(attach_id)
        if not agent:
            return

        with agent._lock:
            agent.attach_id = 0

        self._by_mtype.pop(mtype, None)
        self._by_attach.pop(attach_id, None)

        elapsed = time.time() - agent.last_attach
        logger.info("Agent detached: %s  mtype=%d  (was up %.0fs)",
                    agent.name, mtype, elapsed)

        exit_code = 0   # not available from detach message; 0 = clean
        self._publish(ST_AGENT_STOPPED,
                      _str_tlv(agent.name),
                      _int_tlv(agent.pid),
                      _int_tlv(exit_code))

        if agent.restart_policy and not agent.given_up:
            self._schedule_restart(agent)

    # ── control message handlers ──────────────────────────────────────────────

    def _on_start_agent(self, msg) -> None:
        """Dynamic StartAgent message: Char(command) [Int(flags)]."""
        command, flags_int = _parse_start_msg(msg)
        if not command:
            logger.warning("StartAgent: empty command — ignored")
            return

        policy = AgentPolicy(flags_int & 0x07)
        name   = _derive_name(command)

        if name in self._agents:
            logger.warning("StartAgent: %r already managed — ignored", name)
            return

        agent = ManagedAgent(name=name, command=command, policy=policy)
        self._agents[name] = agent
        self._launch(agent)

    def _on_stop_agent(self, msg) -> None:
        """StopAgent message: Char(name)."""
        name = _first_string(msg)
        if not name:
            return
        if not self._stop_agent_by_name(name):
            logger.warning("StopAgent: %r not found", name)

    def _on_restart_agent(self, msg) -> None:
        """RestartAgent message: Char(name)."""
        name = _first_string(msg)
        if not name:
            return
        agent = self._agents.get(name)
        if not agent:
            logger.warning("RestartAgent: %r not found", name)
            return
        agent.given_up = False
        self._stop_agent_by_name(name)
        self._schedule_restart(agent)

    def _on_status_request(self, msg) -> None:
        """Log status of all managed agents and send a structured JSON response."""
        import json
        logger.info("=== Supervisor status ===")
        agent_list = []
        for a in self._agents.values():
            status = ("running"  if a.is_running else
                      "given_up" if a.given_up   else
                      # One-shot tool (e.g. send --file init.conf): it runs
                      # once and exits, so "not running" is normal, not a crash.
                      "idle"     if a.oneshot    else
                      "stopped")
            policy_str = (
                "C" if a.policy & AgentPolicy.CRITICAL  else
                "E" if a.policy & AgentPolicy.ESSENTIAL else
                "-"
            ) + ("H" if a.policy & AgentPolicy.HEARTBEAT else "")
            logger.info("  %-20s  mtype=%-5d  pid=%-6d  restarts=%-3d  %s",
                        a.name, a.mtype, a.pid, a.restart_count, status)
            agent_list.append({
                "name":          a.name,
                "status":        status,
                "pid":           a.pid,
                "mtype":         a.mtype,
                "policy":        policy_str,
                "restarts":      a.restart_count,
                "given_up":      a.given_up,
            })

        payload = json.dumps({"agents": agent_list}).encode() + b'\x00'
        # Fire-and-forget: this runs inside a callback on the agent's event
        # loop thread, so blocking send() would deadlock (same pattern as
        # database RecordSaved). Schedule the send without waiting.
        try:
            loop = self._client._loop
            if loop and loop.is_running():
                loop.call_soon_threadsafe(
                    lambda: loop.create_task(
                        self._client._async_send(
                            MT_SUPERVISOR,
                            ST_AGENT_STATUS_RESPONSE,
                            [TLV(type_id=TLV_JSON, value=payload)],
                            0,
                        )
                    )
                )
        except Exception as exc:
            logger.warning("Status response send failed: %s", exc)

    # ── ShutdownMixin override ─────────────────────────────────────────────────

    def _on_shutdown_request(self) -> None:
        """Override: stop all agents before exiting."""
        logger.info("Supervisor shutdown requested — stopping all agents")
        print("[Supervisor] Shutdown — stopping all agents")
        self._running = False
        self._stop_all()
        super()._on_shutdown_request()

    # ── helpers ───────────────────────────────────────────────────────────────

    def _find_agent(self, mtype: int,
                    proc_name: str) -> Optional[ManagedAgent]:
        """Find a managed agent by mtype or process name."""
        # Already known by mtype
        a = self._by_mtype.get(mtype)
        if a:
            return a
        # Match by process name (--name arg extracted from command)
        if proc_name:
            for a in self._agents.values():
                if a.name == proc_name:
                    return a
        return None

    def _publish(self, subtype: int, *tlvs: TLV) -> None:
        """Publish a supervisor lifecycle message."""
        try:
            self._client.send(MT_SUPERVISOR, subtype, tlvs=list(tlvs))
        except Exception as exc:
            logger.warning("Supervisor publish failed (subtype=%d): %s",
                           subtype, exc)


# ── TLV helpers ───────────────────────────────────────────────────────────────

def _int_tlv(value: int) -> TLV:
    return TLV(type_id=TLV_INT, value=struct.pack('!i', value))


def _str_tlv(text: str) -> TLV:
    return TLV(type_id=TLV_STRING, value=text.encode() + b'\x00')


def _first_string(msg) -> str:
    """Extract the first TLV_STRING from a message."""
    if not msg.tdata.value:
        return ''
    try:
        for tlv in decode_all(msg.tdata.value):
            if tlv.type_id == TLV_STRING:
                return tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
    except Exception:
        pass
    return ''


def _parse_start_msg(msg) -> tuple[str, int]:
    """Extract (command, flags_int) from a StartAgent message."""
    command = ''
    flags   = 0
    if not msg.tdata.value:
        return command, flags
    try:
        for tlv in decode_all(msg.tdata.value):
            if tlv.type_id == TLV_STRING and not command:
                command = tlv.value.rstrip(b'\x00').decode('utf-8',
                                                            errors='replace')
            elif tlv.type_id == TLV_INT:
                flags = struct.unpack('!i', tlv.value)[0]
    except Exception:
        pass
    return command, flags


def _parse_lifecycle(msg) -> tuple[int, int, str]:
    """Extract (mtype, attach_id, process_name) from a lifecycle message."""
    mtype = 0; attach_id = 0; name = ''
    if not msg.tdata.value:
        return mtype, attach_id, name
    try:
        int_count = 0
        for tlv in decode_all(msg.tdata.value):
            if tlv.type_id == 12 and len(tlv.value) >= 8:
                # AttachId: router(4) + id(4)
                attach_id = struct.unpack_from('!I', tlv.value, 4)[0]
            elif tlv.type_id == TLV_INT and len(tlv.value) == 4:
                val = struct.unpack('!i', tlv.value)[0]
                if int_count == 0:
                    mtype = val
                int_count += 1
            elif tlv.type_id == TLV_STRING:
                name = tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
    except Exception:
        pass
    return mtype, attach_id, name


# ── CLI ───────────────────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level  = logging.WARNING,
        format = '%(asctime)s %(levelname)-7s [%(name)s] %(message)s',
    )
    p = argparse.ArgumentParser(description='UMM Supervisor')
    p.add_argument('--version', action='store_true',
                   help='Show version and exit')
    p.add_argument('--router',       default='localhost', dest='host',
                   help='Router hostname (default: localhost)')
    p.add_argument('--port',         type=int, default=DEFAULT_PORT,
                   help=f'Router port (default: {DEFAULT_PORT})')
    p.add_argument('--config',       default='supervisor.conf',
                   help='Path to supervisor.conf (default: supervisor.conf)')
    p.add_argument('--max-restarts', type=int, default=DEFAULT_MAX_RESTARTS,
                   dest='max_restarts',
                   help=f'Max restart attempts per agent '
                        f'(default: {DEFAULT_MAX_RESTARTS})')
    p.add_argument('--name',         default='Supervisor',
                   help='Agent name on the bus')
    p.add_argument('--debug',        action='store_true')
    args = p.parse_args()

    if args.version:
        print(UMM_VERSION_STR)
        return

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    sup = SupervisorModule(
        host         = args.host,
        port         = args.port,
        config       = args.config,
        max_restarts = args.max_restarts,
        name         = args.name,
    )
    sup._debug_flag = args.debug

    try:
        sup.run()
    except KeyboardInterrupt:
        print('\nSupervisor stopped.')


if __name__ == '__main__':
    _main()
