"""
umm.modules.watchdog
====================
Watchdog agent — monitors critical agent liveness.

Subscribes to agent lifecycle notifications (mtype=1, subtype=AGENT_DETACHED).
When a watched agent disconnects unexpectedly:
  - Attempts to restart it (if restart_cmd configured)
  - Sends an operator alert message
  - Logs the event

Configuration
-------------
A watched agent is defined by its mtype and optional process name.
The watchdog ignores expected detaches (clean shutdown via DETACH message)
— it only triggers on unexpected drops (TCP disconnect without DETACH).

Usage::

    python3 -m umm.modules.watchdog \\
        --router localhost --port 5100 \\
        --watch 1002 "python3 examples/sorting/sorting_demo.py" \\
        --watch 1004 \\
        --alert-mtype 400 --alert-subtype 1

Or programmatically::

    from umm.modules.watchdog import WatchdogModule

    watcher = WatchdogModule(host='localhost', port=5100)
    watcher.watch(mtype=1002,
                  name="ConveyorAgent",
                  restart_cmd="./umm.sh conveyor",
                  critical=True)
    watcher.run()
"""

from __future__ import annotations

import logging
import os
import struct
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from ..agent import UMMAgent, UMMConnectionError
from ..core.messages import MType, UMMSubType, UMM_VERSION_STR, DEFAULT_PORT, AttachFlag
from ..core.tlv import TLV, TLVBuffer, decode_all, TLV_INT, TLV_STRING
from ..capability import CapabilityMixin, query_capability
from ..mixins import DebugMixin, VersionMixin, ShutdownMixin

logger = logging.getLogger(__name__)


# ── watched agent config ──────────────────────────────────────────────────────

@dataclass
class WatchedAgent:
    """Configuration for one watched agent."""
    mtype:        int
    name:         str        = ""          # display name
    restart_cmd:  str        = ""          # shell command to restart, "" = no restart
    critical:     bool       = False       # if True, alert even without restart
    restart_delay: float     = 3.0        # seconds before attempting restart
    max_restarts: int        = 3           # -1 = unlimited
    restart_count: int       = 0          # current restart count
    last_seen:    float      = 0.0        # timestamp of last attach
    on_detach:    Optional[Callable] = None  # custom callback


# ── watchdog module ───────────────────────────────────────────────────────────

class WatchdogModule(DebugMixin, VersionMixin, ShutdownMixin):
    """
    Monitors critical agent liveness.

    Subscribes to:
        mtype=1, subtype=AGENT_ATTACHED  — records agent as alive
        mtype=1, subtype=AGENT_DETACHED  — triggers watchdog logic

    Parameters
    ----------
    host, port      : router connection
    alert_mtype     : mtype to publish alerts on (default 0 = don't alert)
    alert_subtype   : subtype for alert messages
    name            : process name shown on the bus
    """

    AGENT_VERSION = "1.0.0"
    GROUP_VERSION = "1.0.0"
    BUILD         = "dev"

    def __init__(self,
                 host:          str = 'localhost',
                 port:          int = 5000,
                 alert_mtype:   int = 0,
                 alert_subtype: int = 1,
                 name:          str = 'Watchdog') -> None:
        self.host          = host
        self.port          = port
        self.alert_mtype   = alert_mtype
        self.alert_subtype = alert_subtype
        self._client       = UMMAgent(host=host, port=port,
                                      process_name=name,
                                      flags=AttachFlag.NORMAL)
        self._watched:    Dict[int, WatchedAgent] = {}
        self._active:     Dict[int, int]          = {}  # mtype → attach_id

    def watch(self, mtype: int,
              name:          str   = "",
              restart_cmd:   str   = "",
              critical:      bool  = True,
              restart_delay: float = 3.0,
              max_restarts:  int   = 3,
              on_detach:     Optional[Callable] = None) -> None:
        """
        Register an agent to watch.

        Parameters
        ----------
        mtype         : agent's primary mtype
        name          : human-readable name for alerts
        restart_cmd   : shell command to restart the agent (empty = no restart)
        critical      : if True, send operator alert on disconnect
        restart_delay : seconds to wait before restarting
        max_restarts  : maximum restart attempts (-1 = unlimited)
        on_detach     : optional custom callback(mtype, name, attach_id)
        """
        self._watched[mtype] = WatchedAgent(
            mtype         = mtype,
            name          = name or f"mtype={mtype}",
            restart_cmd   = restart_cmd,
            critical      = critical,
            restart_delay = restart_delay,
            max_restarts  = max_restarts,
            on_detach     = on_detach,
        )

    def run(self) -> None:
        """Connect and start monitoring."""
        if not self._client.connect():
            print(f"\n  ERROR: Watchdog could not connect to router at {self.host}:{self.port}")
            print("  Is the router running?  Start it with: ./umm.sh start router")
            print("")
            return

        # Subscribe to lifecycle notifications
        self._client.register(
            mtype    = int(MType.UMM),
            subtype  = int(UMMSubType.AGENT_ATTACHED),
            callback = self._on_attached,
            dont_send_self = True,
        )
        self._client.register(
            mtype    = int(MType.UMM),
            subtype  = int(UMMSubType.AGENT_DETACHED),
            callback = self._on_detached,
            dont_send_self = True,
        )

        watched_names = ', '.join(
            f"{w.name}(mtype={w.mtype})" for w in self._watched.values()
        )
        # Watchdog has mtype=0 — use 0 as source_mtype in debug envelope
        self.register_debug_handler(self._client, 0,
                                    debug=getattr(self, '_debug_flag', False))
        self.register_version_handler(self._client, 0)
        self.register_shutdown_handler(self._client, 0)
        self.log_info("Watchdog running — watching: %s", watched_names)
        print(f"Watchdog monitoring: {watched_names}")

        self._client.run()

    # ── lifecycle handlers ────────────────────────────────────────────────────

    def _on_attached(self, msg) -> None:
        """Record agent as alive when it attaches."""
        mtype, attach_id, name = self._parse_lifecycle(msg)
        if mtype <= 0:
            return

        w = self._watched.get(mtype)
        if w:
            w.last_seen = time.time()
            w.restart_count = 0   # reset on successful attach
            self._active[mtype] = attach_id
            self.log_info("Watchdog: %s (mtype=%d) attached as id=%d",
                        w.name, mtype, attach_id)

    def _on_detached(self, msg) -> None:
        """Handle agent disconnect."""
        mtype, attach_id, name = self._parse_lifecycle(msg)
        if mtype <= 0:
            return

        w = self._watched.get(mtype)
        if not w:
            return

        self._active.pop(mtype, None)

        elapsed = time.time() - w.last_seen if w.last_seen else 0
        self.log_warn("Watchdog: %s (mtype=%d) DISCONNECTED (was up %.0fs)",
                       w.name, mtype, elapsed)

        # Call custom callback if provided
        if w.on_detach:
            try:
                w.on_detach(mtype, w.name, attach_id)
            except Exception as exc:
                self.log_warn("Watchdog: on_detach callback error: %s", exc)

        # Send operator alert
        if w.critical and self.alert_mtype:
            self._send_alert(
                f"AGENT DISCONNECTED: {w.name} (mtype={mtype})"
            )

        # Attempt restart in background
        if w.restart_cmd:
            threading.Thread(
                target=self._restart, args=(w,),
                daemon=True, name=f"watchdog-restart-{mtype}"
            ).start()
        elif w.critical:
            print(f"  [WATCHDOG] {w.name} disconnected — no restart configured")

    def _restart(self, w: WatchedAgent) -> None:
        """Attempt to restart a disconnected agent."""
        if w.max_restarts >= 0 and w.restart_count >= w.max_restarts:
            msg = (f"RESTART LIMIT REACHED for {w.name} "
                   f"({w.max_restarts} attempts)")
            self.log_error("Watchdog: %s", msg)
            if self.alert_mtype:
                self._send_alert(msg)
            return

        w.restart_count += 1
        self.log_info("Watchdog: restarting %s in %.1fs (attempt %d/%s)...",
                    w.name, w.restart_delay, w.restart_count,
                    w.max_restarts if w.max_restarts >= 0 else '∞')
        time.sleep(w.restart_delay)

        try:
            result = subprocess.run(
                w.restart_cmd, shell=True,
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                self.log_info("Watchdog: restart command launched for %s",
                            w.name)
            else:
                err_msg = (f"RESTART FAILED for {w.name}: "
                           f"{result.stderr.strip()[:100]}")
                self.log_error("Watchdog: %s", err_msg)
                if self.alert_mtype:
                    self._send_alert(err_msg)
        except subprocess.TimeoutExpired:
            self.log_error("Watchdog: restart command timed out for %s", w.name)
        except Exception as exc:
            self.log_error("Watchdog: restart error for %s: %s", w.name, exc)

    def _send_alert(self, text: str) -> None:
        """Send an operator alert message."""
        if not self.alert_mtype:
            return
        try:
            self._client.send(
                mtype   = self.alert_mtype,
                subtype = self.alert_subtype,
                tlvs    = [TLV(type_id=TLV_STRING,
                               value=text.encode() + b'\x00')],
            )
            self.log_info("Watchdog alert: %s", text)
        except Exception as exc:
            self.log_warn("Watchdog: alert send failed: %s", exc)

    @staticmethod
    def _parse_lifecycle(msg) -> tuple:
        """Extract (mtype, attach_id, process_name) from lifecycle TLVs."""
        mtype = 0; attach_id = 0; name = ""
        if not msg.tdata.value:
            return mtype, attach_id, name
        try:
            tlvs = decode_all(msg.tdata.value)
            int_count = 0
            for tlv in tlvs:
                if tlv.type_id == 12 and len(tlv.value) >= 8:
                    # AttachId: router(4) + id(4)
                    attach_id = struct.unpack_from('!I', tlv.value, 4)[0]
                elif tlv.type_id == TLV_INT and len(tlv.value) == 4:
                    val = struct.unpack('!i', tlv.value)[0]
                    if int_count == 0:
                        mtype = val
                    int_count += 1
                elif tlv.type_id == TLV_STRING:
                    name = tlv.value.rstrip(b'\x00').decode('utf-8',
                                                             errors='replace')
        except Exception:
            pass
        return mtype, attach_id, name


# ── CLI ───────────────────────────────────────────────────────────────────────

def _main() -> None:
    import argparse
    logging.basicConfig(
        level  = logging.WARNING,
        format = '%(asctime)s %(levelname)-7s %(name)s: %(message)s',
    )
    p = argparse.ArgumentParser(
        description='UMM Watchdog — monitors critical agent liveness')
    p.add_argument('--version', action='store_true',
                   help='Show version and exit')
    p.add_argument('--router',        default='localhost', dest='host')
    p.add_argument('--port',          type=int, default=5000)
    p.add_argument('--name',          default='Watchdog',
                   help='Agent process name')
    p.add_argument('--watch',         action='append', nargs='+',
                   metavar=('MTYPE', 'RESTART_CMD'),
                   help='Watch mtype [restart_cmd]. '
                        'E.g. --watch 1002 "./umm.sh conveyor"')
    p.add_argument('--alert-mtype',   type=int, default=0,
                   help='mtype to send alert messages on (0=disabled)')
    p.add_argument('--alert-subtype', type=int, default=199,
                   help='subtype for alert messages (default 199=OperatorMessage)')
    p.add_argument('--debug',         action='store_true')
    p.add_argument('--permanent',     action='store_true',
                   help='Attach with PERM_KEEP_CONN (set automatically by supervisor for C agents)')
    args = p.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return

    watcher = WatchdogModule(
        host          = args.host,
        port          = args.port,
        alert_mtype   = args.alert_mtype,
        alert_subtype = args.alert_subtype,
        name          = args.name,
    )
    watcher._debug_flag = args.debug
    if args.permanent:
        watcher._client.attach_flags = AttachFlag.PERM_KEEP_CONN
        watcher._client.reconnect = True

    if args.watch:
        for spec in args.watch:
            mtype       = int(spec[0])
            restart_cmd = spec[1] if len(spec) > 1 else ""
            watcher.watch(mtype=mtype, restart_cmd=restart_cmd, critical=True)
    else:
        # Default: watch all standard agents
        for mtype, name in [(2,'Timer'),(5,'FSM'),(10,'TypeDir'),(11,'Bridge')]:
            watcher.watch(mtype=mtype, name=name, critical=False)

    try:
        watcher.run()
    except KeyboardInterrupt:
        print("\nWatchdog stopped.")


if __name__ == '__main__':
    try:
        _main()
    except UMMConnectionError as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        sys.exit(1)
