"""
umm.core.tlv
============
TLV (Type / Match / Meta / Length / Value) wire-format encode and decode.

Wire layout of a single TLV
----------------------------
Offset  Size  Field
     0     4  Type   – unsigned 32-bit, network byte order
     4     4  Match  – unsigned 32-bit, network byte order
               In subscription TLVs: comparison-operator index (EQ/GT/LT …)
               In published messages: passed through by the router unchanged.
               Agents may use it as a sub-qualifier (e.g. to distinguish
               current/max/min readings of the same type).
               Special value 0xFFFFFFFF (MWORD_IGNORE_MATCH): subscription only
               — skip this positional slot entirely, always passes.
     8     4  Meta   – unsigned 32-bit, network byte order
               Semantic qualifier for the type.  Optional; 0 means absent.
               Meaning is type-dependent: for Float, meta=1 might mean
               "temperature"; for Char, meta=1 might mean "filename".
               Router matching rule: if either side has meta=0 the meta
               field always passes; otherwise both values must be equal.
               The meta registry (umm.core.meta) maps (type_id, meta) → name.
    12     4  Length – unsigned 32-bit, network byte order
               length is the byte-count of Value only
    16  Length  Value  – raw bytes
    16+Length  0-3  Padding – zero bytes to align next TLV to a 4-byte boundary

TLVs may be nested: the Value of one TLV can contain one or more TLVs.

Type IDs
--------
IDs 0-49   : reserved for core UMM types (see types/ directory)
IDs 50-99  : manufacturing types
IDs 100+   : user / application types
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Iterator, List, Optional

# ── constants ────────────────────────────────────────────────────────────────

HEADER_SIZE   = 16          # Type(4) + Match(4) + Meta(4) + Length(4)
ALIGN         = 4
# Wire order: TYPE | MATCH | META | LENGTH
_HEADER_FMT   = "!IIII"     # network byte-order: uint32 × 4  (type, match, meta, length)

# Core type IDs – authoritative list lives in types/_base.py;
# duplicated here so tlv.py has zero imports from the rest of the package.
TLV_TERM      =  0
TLV_RAW       =  1
TLV_INT       =  2
TLV_UINT      =  3
TLV_SHORT     =  4
TLV_USHORT    =  5
TLV_FLOAT     =  6
TLV_BOOL      =  7
TLV_STRING    =  8
TLV_UTIME     =  9
TLV_METADATA  = 10
TLV_MSG       = 11
TLV_ATTID     = 12
TLV_COORD     = 13
TLV_FNAME     = 14
TLV_LOGID     = 15
TLV_MSGREF    = 16    # MsgRef: router_id(4) + attach_id(4) + msg_id(4)
TLV_TEST      = 16
TLV_ROUTER_ID = 17   # RouterId: site(2, NBO) + node(2, NBO)  — inter-router addressing
TLV_JSON      = 18   # JSON: null-terminated UTF-8 JSON string — wire-identical to Char
TLV_SUBSPEC   = 19   # Subscription spec: mtype(4,NBO) + subtype(4,NBO) + match_bytes

# Default match-word (no operator) and meta-word (absent) values
MWORD_NONE         = 0
META_NONE          = 0            # meta absent — always matches
MWORD_IGNORE_MATCH = 0xFFFFFFFF   # subscription TLV only — skip this positional slot, always passes


# ── padding helper ───────────────────────────────────────────────────────────

def _padded_len(length: int) -> int:
    """Return length rounded up to the next 4-byte boundary."""
    return (length + ALIGN - 1) & ~(ALIGN - 1)


def _padding(length: int) -> bytes:
    """Return zero-padding bytes needed after *length* value bytes."""
    pad = _padded_len(length) - length
    return b"\x00" * pad


# ── TLV dataclass ─────────────────────────────────────────────────────────────

@dataclass
class TLV:
    """
    A single TLV unit.

    Parameters
    ----------
    type_id : int
        TLV type identifier.
    value : bytes
        Raw value bytes (before padding).
    match : int
        Match-word.  In subscriptions: operator index (EQ/GT/LT …).
        In published messages: passed through unchanged; agents may use
        as a sub-qualifier.  Default is 0 (MWORD_NONE).
    meta : int
        Meta-word.  Semantic qualifier for the type (0 = absent).
        Default is 0 (META_NONE).
    children : list[TLV]
        If this TLV contains nested TLVs, store them here.
        When encoding, *children* are serialised into *value* automatically
        if *value* is empty.
    """
    type_id:  int
    value:    bytes          = b""
    match:    int            = MWORD_NONE
    meta:     int            = META_NONE
    children: List["TLV"]   = field(default_factory=list)

    # ── encoding ─────────────────────────────────────────────────────────────

    def encode(self) -> bytes:
        """
        Serialise this TLV (and any children) to wire bytes.

        If *children* is non-empty and *value* is empty, the children are
        first encoded and concatenated to form the value.
        """
        payload = self.value
        if self.children and not payload:
            payload = b"".join(c.encode() for c in self.children)

        # Wire order: TYPE | MATCH | META | LENGTH
        header = struct.pack(_HEADER_FMT, self.type_id, self.match, self.meta, len(payload))
        return header + payload + _padding(len(payload))

    # ── convenience constructors ──────────────────────────────────────────────

    @classmethod
    def terminator(cls) -> "TLV":
        """Return a TLV_TERM (empty, closes a TLV buffer)."""
        return cls(type_id=TLV_TERM, value=b"", match=0, meta=0)

    @classmethod
    def from_children(cls, type_id: int, children: List["TLV"],
                      match: int = MWORD_NONE,
                      meta: int = META_NONE) -> "TLV":
        """Build a container TLV whose value is the encoding of *children*."""
        return cls(type_id=type_id, children=children, match=match, meta=meta)

    # ── representation ────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        meta_str = f", meta={self.meta}" if self.meta else ""
        if self.children:
            return (f"TLV(type={self.type_id}, match={self.match}{meta_str}, "
                    f"children=[{', '.join(repr(c) for c in self.children)}])")
        return (f"TLV(type={self.type_id}, match={self.match}{meta_str}, "
                f"len={len(self.value)}, value={self.value!r})")


# ── decoding ─────────────────────────────────────────────────────────────────

def decode_one(buf: bytes, offset: int = 0) -> tuple[TLV, int]:
    """
    Decode a single TLV from *buf* starting at *offset*.

    Returns
    -------
    (tlv, next_offset)
        *next_offset* points to the first byte after this TLV (including
        any alignment padding), ready for the next call.

    Raises
    ------
    ValueError
        If there are not enough bytes to read the header or value.
    """
    if len(buf) - offset < HEADER_SIZE:
        raise ValueError(
            f"Need {HEADER_SIZE} bytes for TLV header, "
            f"only {len(buf) - offset} available at offset {offset}"
        )

    # Wire order: TYPE | MATCH | META | LENGTH
    type_id, match, meta, length = struct.unpack_from(_HEADER_FMT, buf, offset)
    offset += HEADER_SIZE

    if len(buf) - offset < length:
        raise ValueError(
            f"TLV type={type_id} declares length={length} but only "
            f"{len(buf) - offset} bytes remain"
        )

    value = buf[offset: offset + length]
    offset += _padded_len(length)   # skip value + padding in one step

    return TLV(type_id=type_id, value=value, match=match, meta=meta), offset


def decode_all(buf: bytes, offset: int = 0) -> List[TLV]:
    """
    Decode every TLV in *buf* (from *offset* onwards) and return them as a
    list.  Stops at a TLV_TERM or end-of-buffer.
    """
    tlvs: List[TLV] = []
    end = len(buf)
    while offset < end:
        if end - offset < HEADER_SIZE:
            break
        tlv, offset = decode_one(buf, offset)
        if tlv.type_id == TLV_TERM:
            break
        tlvs.append(tlv)
    return tlvs


def decode_nested(buf: bytes) -> List[TLV]:
    """
    Decode the *value* bytes of a container TLV as a list of child TLVs.
    Equivalent to ``decode_all(buf)``.
    """
    return decode_all(buf)


def iter_tlvs(buf: bytes, offset: int = 0) -> Iterator[TLV]:
    """
    Iterate over TLVs in *buf* one at a time.  More memory-efficient than
    ``decode_all`` when the buffer is large.
    """
    end = len(buf)
    while offset < end:
        if end - offset < HEADER_SIZE:
            break
        tlv, offset = decode_one(buf, offset)
        if tlv.type_id == TLV_TERM:
            break
        yield tlv


# ── buffer builder ────────────────────────────────────────────────────────────

class TLVBuffer:
    """
    Mutable accumulator for building a sequence of TLVs.

    Usage::

        buf = TLVBuffer()
        buf.add(TLV(TLV_INT,   value=struct.pack('!i', 42)))
        buf.add(TLV(TLV_STRING, value=b'hello'))
        wire_bytes = buf.encode()
    """

    def __init__(self) -> None:
        self._tlvs: List[TLV] = []

    def add(self, tlv: TLV) -> "TLVBuffer":
        """Append a TLV and return self for chaining."""
        self._tlvs.append(tlv)
        return self

    def add_all(self, tlvs: List[TLV]) -> "TLVBuffer":
        self._tlvs.extend(tlvs)
        return self

    def encode(self, terminate: bool = False) -> bytes:
        """
        Encode all accumulated TLVs to bytes.

        Parameters
        ----------
        terminate : bool
            If True, append a TLV_TERM after all TLVs.
        """
        parts = [t.encode() for t in self._tlvs]
        if terminate:
            parts.append(TLV.terminator().encode())
        return b"".join(parts)

    def find(self, type_id: int) -> Optional[TLV]:
        """Return the first TLV with *type_id*, or None."""
        for t in self._tlvs:
            if t.type_id == type_id:
                return t
        return None

    def find_all(self, type_id: int) -> List[TLV]:
        """Return all TLVs with *type_id*."""
        return [t for t in self._tlvs if t.type_id == type_id]

    def __len__(self) -> int:
        return len(self._tlvs)

    def __iter__(self) -> Iterator[TLV]:
        return iter(self._tlvs)

    def __repr__(self) -> str:
        return f"TLVBuffer({self._tlvs!r})"


# ── wire-level find helper ────────────────────────────────────────────────────

def find_in_bytes(buf: bytes, type_id: int,
                  offset: int = 0) -> Optional[TLV]:
    """
    Scan *buf* for the first TLV whose type matches *type_id*.
    Returns the TLV or None.  Does not recurse into children.
    """
    for tlv in iter_tlvs(buf, offset):
        if tlv.type_id == type_id:
            return tlv
    return None


# ── total encoded size helper ─────────────────────────────────────────────────

def encoded_size(value_len: int) -> int:
    """Total bytes occupied by a TLV with *value_len* value bytes."""
    return HEADER_SIZE + _padded_len(value_len)