"""
umm.core.registry
=================
Type plugin registry.

The registry is the single source of truth for all known TLV types.
It is populated at startup from:
  1. The built-in types in umm/types/builtin.py
  2. Any .py files found in configured type search directories
     (e.g. umm/types/manufacturing/, user application directories)

Auto-discovery
--------------
Any Python file dropped into a search directory that contains a class
subclassing BaseUMMType will be automatically loaded.  No imports or
explicit registration are needed.

Usage
-----
    from umm.core.registry import TypeRegistry
    registry = TypeRegistry()          # auto-loads all built-ins
    registry.add_search_dir("myapp/types")

    # Look up by ID (used by the router during matching)
    handler = registry.get_by_id(TLV_INT)

    # Look up by name (used by parser / config files)
    handler = registry.get_by_name("Temperature")

    # Ask the registry what comes next
    next_id = registry.next_free_id()
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Type

from .tlv import TLV_TERM, MWORD_IGNORE_MATCH, META_NONE
from ..types._base import BaseUMMType

logger = logging.getLogger(__name__)


class TypeRegistry:
    """
    Central registry of all TLV type handlers.

    Thread-safety: register operations are not thread-safe.  All types
    should be registered before the router starts accepting connections.
    """

    def __init__(self) -> None:
        self._by_id:   Dict[int, BaseUMMType] = {}
        self._by_name: Dict[str, BaseUMMType] = {}
        self._search_dirs: List[Path] = []

        # Load built-in types automatically
        self._load_builtins()

    # ── built-in loading ──────────────────────────────────────────────────────

    def _load_builtins(self) -> None:
        from ..types.builtin import BUILTIN_TYPES
        for cls in BUILTIN_TYPES:
            self._register_class(cls)

    # ── public API ────────────────────────────────────────────────────────────

    def register(self, handler: BaseUMMType) -> None:
        """Register a type handler instance."""
        cls = type(handler)
        cls.validate()
        self._by_id[handler.TYPE_ID]     = handler
        self._by_name[handler.TYPE_NAME] = handler
        logger.debug("Registered type %s (id=%d)", handler.TYPE_NAME, handler.TYPE_ID)

    def register_class(self, cls: Type[BaseUMMType]) -> None:
        """Instantiate *cls* and register it."""
        self._register_class(cls)

    def _register_class(self, cls: Type[BaseUMMType]) -> None:
        try:
            cls.validate()
            instance = cls()
            self._by_id[cls.TYPE_ID]     = instance
            self._by_name[cls.TYPE_NAME] = instance
            logger.debug("Registered type %s (id=%d)", cls.TYPE_NAME, cls.TYPE_ID)
        except Exception as exc:
            logger.warning("Could not register type %s: %s", cls.__name__, exc)

    def get_by_id(self, type_id: int) -> Optional[BaseUMMType]:
        """Return the handler for *type_id*, or None if unknown."""
        return self._by_id.get(type_id)

    def get_by_name(self, name: str) -> Optional[BaseUMMType]:
        """Return the handler whose TYPE_NAME matches *name* (case-insensitive)."""
        handler = self._by_name.get(name)
        if handler:
            return handler
        # Case-insensitive fallback
        name_lower = name.lower()
        for k, v in self._by_name.items():
            if k.lower() == name_lower:
                return v
        return None

    def all_types(self) -> List[BaseUMMType]:
        """Return all registered type handlers sorted by TYPE_ID."""
        return sorted(self._by_id.values(), key=lambda h: h.TYPE_ID)

    def all_names(self) -> List[str]:
        """Return all registered TYPE_NAME strings, sorted alphabetically."""
        return sorted(self._by_name.keys())

    def next_free_id(self, min_id: int = 100) -> int:
        """
        Return the lowest type ID >= *min_id* that is not yet registered.
        Used by the type directory service when a client requests a new ID.
        """
        candidate = min_id
        while candidate in self._by_id:
            candidate += 1
        return candidate

    def query_by_base(self, base_name: str) -> List[BaseUMMType]:
        """
        Return all types whose BASE_TYPE matches *base_name*.
        E.g. query_by_base("Float") returns Temperature, Pressure …
        """
        base_lower = base_name.lower()
        return [h for h in self._by_id.values()
                if h.BASE_TYPE and h.BASE_TYPE.lower() == base_lower]

    # ── directory search ──────────────────────────────────────────────────────

    def add_search_dir(self, path: str | Path) -> None:
        """
        Add *path* to the type search directories and immediately scan it
        for BaseUMMType subclasses.
        """
        p = Path(path).expanduser().resolve()
        if not p.is_dir():
            logger.warning("Type search dir not found: %s", p)
            return
        self._search_dirs.append(p)
        self._scan_dir(p)

    def _scan_dir(self, directory: Path) -> None:
        """Import every .py file in *directory* and register discovered types."""
        for py_file in sorted(directory.glob("*.py")):
            if py_file.name.startswith('_'):
                continue
            self._load_file(py_file)
        # Recurse into sub-directories
        for sub in sorted(directory.iterdir()):
            if sub.is_dir() and not sub.name.startswith('_'):
                self._scan_dir(sub)

    def _load_file(self, py_file: Path) -> None:
        """Load *py_file* as a module and register any BaseUMMType subclasses."""
        module_name = f"umm_plugin_{py_file.stem}_{id(py_file)}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, py_file)
            if spec is None or spec.loader is None:
                return
            mod = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = mod
            spec.loader.exec_module(mod)
        except Exception as exc:
            logger.warning("Failed to load type plugin %s: %s", py_file, exc)
            return

        found = 0
        for attr_name in dir(mod):
            attr = getattr(mod, attr_name)
            if (isinstance(attr, type) and
                    issubclass(attr, BaseUMMType) and
                    attr is not BaseUMMType and
                    attr.TYPE_ID >= 0):
                self._register_class(attr)
                found += 1

        if found:
            logger.info("Loaded %d type(s) from %s", found, py_file)

    # ── matching interface ────────────────────────────────────────────────────

    def match(self, msg_tlv, sub_tlv) -> bool:
        """
        Dispatch a match check to the appropriate type handler.

        Parameters
        ----------
        msg_tlv : TLV
            TLV from the incoming (published) message.
        sub_tlv : TLV
            TLV from the stored subscription (carries match-word operator and
            optional meta qualifier).

        Returns True if the message TLV satisfies the subscription criterion.

        Matching order
        --------------
        1. MWORD_IGNORE_MATCH on subscription → always pass (positional wildcard)
        2. type_id must match
        3. Meta check: if either side has meta=0 → pass; else must be equal
        4. Value/operator check delegated to the type handler
        """
        # MWORD_IGNORE_MATCH in a subscription TLV means "skip this positional
        # slot" — passes regardless of message TLV type, meta, or value.
        if sub_tlv.match == MWORD_IGNORE_MATCH:
            return True

        if msg_tlv.type_id != sub_tlv.type_id:
            return False

        # Meta check: 0 on either side means "absent/wildcard" → always passes.
        # Otherwise both sides must carry the same non-zero meta value.
        if (msg_tlv.meta != META_NONE and sub_tlv.meta != META_NONE
                and msg_tlv.meta != sub_tlv.meta):
            return False

        handler = self.get_by_id(msg_tlv.type_id)
        if handler is None:
            logger.warning("No handler for type_id=%d – skipping match", msg_tlv.type_id)
            return False

        return handler.match(msg_tlv, sub_tlv)

    # ── type directory entry list ─────────────────────────────────────────────

    def directory_entries(self) -> List[dict]:
        """Return directory metadata for all registered types."""
        return [h.directory_entry() for h in self.all_types()]

    # ── iteration ─────────────────────────────────────────────────────────────

    def __iter__(self) -> Iterator[BaseUMMType]:
        return iter(self.all_types())

    def __len__(self) -> int:
        return len(self._by_id)

    def __contains__(self, type_id: int) -> bool:
        return type_id in self._by_id

    def __repr__(self) -> str:
        return f"TypeRegistry({len(self._by_id)} types)"


# ── module-level singleton ────────────────────────────────────────────────────
# The router and all modules share this instance.
# Client code can import it directly:
#   from umm.core.registry import registry

registry = TypeRegistry()
