"""
umm.core.messages
=================
UMMMsg wire-format struct, all flag enumerations, and mtype/subtype constants.

Wire layout of UMMMsg
---------------------
Field         Size  Notes
VersionId        4  ummIdent(1) msgVersion(1) major(1) minor(1)
AttachId         8  router_id(4, NBO) + id(4, NBO)
Origin           8  router_id(4, NBO) + id(4, NBO)
UTime           12  secs(4,NBO) + ms(2,NBO) + timezone(2,NBO) + dst(2,NBO) + pad(2)
Flags            4  NBO  – ETMsgFlags / ETAttachFlags / ETRequestFlags
RegId            4  NBO  – registration id (0 for router messages)
MsgId            4  NBO  – message sequence id
Mtype            4  NBO  – message type (see MType enum)
SubType          4  NBO  – message sub-type
Channel          1        – logical channel (0=all channels wildcard, 1=app, 2=confirm, 3=debug, 4=meta,
                            4=heartbeat, 5=supervisor, 6=bridge; 11–255 user)
Reserved         3        – must be zero on send; ignored on receive
TData           12+ TLV header + value (Type=TLV_TERM, Length=0 if no data)

Total fixed header = 4+8+8+12+4+4+4+4+4+1+3 = 56 bytes
TData adds at least 12 bytes (empty TLV header).

Reserved channels
-----------------
0   Application bus — all current application traffic
1   Confirm — error responses and delivery confirmations
2   Debug   — runtime debug output from agents
3   Meta    — capability and version responses
4   Heartbeat — supervisor liveness ping/pong
5   Supervisor control
6   Bridge protocol
7–10  Reserved for future system use
11–127  User-defined
128–255  Simulation / test scaffolding (convention: invisible on ch0 views)
"""

from __future__ import annotations

import os
import struct
import time
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from pathlib import Path
from typing import Optional

from .tlv import TLV, TLVBuffer, TLV_TERM, MWORD_NONE, HEADER_SIZE


# ── version ───────────────────────────────────────────────────────────────────

VERSION_IDENT   = ord('U')   # 'U' for UMM
VERSION_MSG     = ord('C')   # 'C' for client message
VERSION_MAJOR   = 1
VERSION_MINOR   = 4

# Human-readable version string — shown by --version flag
UMM_VERSION     = f"{VERSION_MAJOR}.{VERSION_MINOR}"
UMM_VERSION_STR = (f"UMM Python v{UMM_VERSION}  "
                   f"(multi-dim FSM, capability system, lifecycle events, channels)")

MAX_ATTACHES      = 1024
MAX_REGISTRATIONS =   64
MAX_BUFF_SIZE     = 32 * 1024

_FALLBACK_PORT = 5300   # used only if no config and no env var found


def _resolve_default_port() -> int:
    """Return the default router port, resolved in priority order:

    1. ``UMM_ROUTER`` environment variable  (``host:port`` or ``:port``)
    2. ``umm.conf`` ``[settings] port =`` — searched upward from this file
    3. Hard-coded fallback (``_FALLBACK_PORT``)

    This is evaluated once at import time so that ``UMMAgent()`` with no
    explicit ``port=`` argument picks up the project's configured port.
    """
    # ── 1. UMM_ROUTER env var ─────────────────────────────────────────────────
    env = os.environ.get('UMM_ROUTER', '').strip()
    if env and ':' in env:
        port_str = env.rpartition(':')[2].strip()
        try:
            return int(port_str)
        except ValueError:
            pass  # malformed — fall through

    # ── 2. umm.conf — walk up from the project root ───────────────────────────
    # This file lives at  <project>/umm/core/messages.py, so the project root
    # is two directories up.
    here = Path(__file__).resolve()
    candidates = [
        here.parent.parent.parent / 'umm.conf',   # <project>/umm.conf  (typical)
        here.parent.parent.parent.parent / 'umm.conf',  # one level higher
        Path('umm.conf'),                           # current working directory
    ]
    for conf_path in candidates:
        if conf_path.is_file():
            try:
                import configparser as _cp
                parser = _cp.ConfigParser(
                    allow_no_value=True,
                    inline_comment_prefixes=('#',),
                )
                parser.read(str(conf_path))
                if parser.has_option('settings', 'port'):
                    return int(parser.get('settings', 'port'))
            except Exception:
                pass  # malformed config — fall through
            break  # found the file; don't keep searching even if parse failed

    # ── 3. Hard-coded fallback ────────────────────────────────────────────────
    return _FALLBACK_PORT


# Resolved once at import time.  All modules that do ``from .core.messages
# import DEFAULT_PORT`` automatically get the project-configured value.
DEFAULT_PORT: int = _resolve_default_port()


# ── struct formats (network byte order) ───────────────────────────────────────
#
#  VersionId : 4B  BBbb  (ummIdent, msgVersion, major, minor)
#  AttachId  : 8B  !II   (router_id, id)
#  UTime     : 12B !IHhhH  (secs, ms, tz, dst, pad[2]) → use 'xx' for pad
#  scalar    : 4B  !I or !i

_FMT_VERSION = "!BBBB"          # 4 bytes
_FMT_ATTACHID = "!II"           # 8 bytes  (router_id, id)
_FMT_UTIME   = "!IHhhxx"        # 12 bytes (secs, ms, tz, dst, 2×pad)
_FMT_SCALARS = "!iiii"          # 16 bytes (flags, regId, msgId implicit in pack)

# Complete fixed-header layout (without TData):
#   VersionId(4) AttachId(8) Origin(8) UTime(12) Flags(4) RegId(4) MsgId(4)
#   Mtype(4) SubType(4)  = 52 bytes
_FMT_HEADER = "!BBBBIIIIHHXX" + "I" * 7   # approximate; use pack/unpack below

FIXED_HEADER_SIZE = 56   # bytes before TData (52 + 1 channel + 3 reserved)


# ── channel constants ─────────────────────────────────────────────────────────

class Channel(IntEnum):
    """Logical channel numbers embedded in the fixed message header.

    Channel 0 is reserved as the subscription wildcard (matches any channel).
    It must not be used as a message send channel.  The application bus is
    channel 1 (APP).
    """
    ALL        = 0   # Subscription wildcard — matches any channel; never used to send
    APP        = 1   # Application bus — all ordinary traffic
    CONFIRM    = 2   # Delivery confirmations and error responses
    DEBUG      = 3   # Runtime debug output from agents
    META       = 4   # Capability and version responses
    HEARTBEAT  = 5   # Supervisor liveness ping/pong
    SUPERVISOR = 6   # Supervisor control messages
    BRIDGE     = 7   # Inter-router bridge protocol
    # 8–10 reserved for future system use
    # 11–127 user-defined
    # 128–255 simulation / test scaffolding (recommended convention)
    SIM        = 128  # Default channel for simulation-only traffic
    # Use SIM+N for named simulation sub-channels, e.g. SIM+1=belt encoders


# ── enumerations ──────────────────────────────────────────────────────────────

class MType(IntEnum):
    """Message types (mtype field)."""

    # ── Negative mtypes — infrastructure channels ─────────────────────────────
    # These are convention, not enforcement. The router delivers them like any
    # other message. Non-compliant agents are unaffected.
    #
    # See DESIGN_NOTES.md section 10 for full protocol specification.
    CONFIRM     = -1   # Confirmations and error responses
    DEBUG       = -2   # Runtime debug output from any agent
    META        = -3   # Agent metadata (capability, version responses)
    HEARTBEAT   = -4   # Supervisor liveness ping/pong

    # ── Positive mtypes — services and applications ───────────────────────────
    NULL        =  0
    UMM         =  1   # Router control – RESERVED
    TIMER       =  2   # Timer service
    COMMAND     =  3   # Command processor
    METADATA    =  4   # Metadata service
    FSM         =  5   # Finite State Machine
    FILESEND    =  6   # File send
    FILERECV    =  7   # File receive
    DATABASE    =  8   # Database bridge
    MICROBILL   =  9   # Microbilling
    TYPEDIR     = 10   # Type directory service
    BRIDGE      = 11   # UMM Bridge (inter-router)
    SUPERVISOR  = 12   # Supervisor — process management and watchdog
    GUI         = 13   # GUI console server
    FEED        = 14   # Feed agent — lifecycle events (source added/removed/error)
    FEED_ITEM   = 15   # Feed agent — one message per new RSS/Atom item
    # 16–19 reserved for future system use
    UTILITY     = 20   # Miscellaneous utility / information messages

    # Manufacturing block
    SENSOR      = 100
    ACTUATOR    = 101
    ALARM       = 102
    PROCESS     = 103
    CONSOLE     = 104

    # User-defined start point
    USER_START  = 1000


class SType(IntEnum):
    """Common sub-types (stype / subType field)."""
    INFO    = 1001
    WARN    = 1002
    ERROR   = 1003
    STATUS  = 1004
    CONF    = 1005


class ReservedSubType(IntEnum):
    """
    Reserved subtypes 1–99, common to ALL positive mtypes by convention.

    Subtype range summary:
        1–4    System-wide standard  (capability, version, debug control, shutdown)
        5–20   System-wide reserved  (future standard additions)
        21–99  Domain/group reserved (families of agents, by convention)
        100+   Application-defined  (agent-specific commands and events)

    These subtypes are a convention layer on top of the UMM protocol.
    The router does not enforce them. An agent that uses subtype 1 for
    an application-specific purpose will work correctly — it simply will
    not respond to the standard GetCapability query.
    See DESIGN_NOTES.md section 10.
    """
    GET_CAPABILITY  = 1   # Query agent capability  → response on (META, ST_META_CAPABILITY)
    GET_VERSION     = 2   # Query agent version     → response on (META, ST_META_VERSION)
    SET_DEBUG       = 3   # Enable/disable debug    → Bool(enable); agent publishes to DEBUG
    SHUTDOWN        = 4   # Request graceful shutdown → no payload; agent disconnects and exits
    # 5–11 overlap the router (mtype=1) control protocol — do not use for new reserved controls
    SET_LOG_LEVEL   = 12  # Set logging verbosity   → Int(DebugLevel 0-3); per-agent, by mtype
    DEBUG_MSG       = 13  # Debug output message     → Int(source_mtype) Int(level) Char(text)
                          #   published on channel=DEBUG using the issuing agent's OWN mtype.
                          #   NOT a router-control subtype, so it is dispatched, never intercepted.
    # 14–20 system-wide reserved
    # 21–99 domain/group reserved


class ConfirmSubType(IntEnum):
    """
    Subtypes for mtype=MType.CONFIRM (-1).

    Envelope (all subtypes):
        Int(source_mtype)   — primary filter for content-match subscriptions
        MsgRef(msg_id)      — correlates response to the original request
        <payload>           — subtype-specific (see below)
    """
    ERROR           = 1   # Error response: Int(source_mtype) MsgRef(msg_id) Int(error_code) Char(description)
    ROUTER_CONFIRM  = 2   # MsgFlag.CONFIRM_RTR: Int(source_mtype) MsgRef(msg_id) Int(receiver_count)
    RECEIVER_ACK    = 3   # MsgFlag.CONFIRM_RCV: Int(source_mtype) MsgRef(msg_id)
    APP_ACK         = 4   # MsgFlag.CONFIRM_APP: Int(source_mtype) MsgRef(msg_id)


class ConfirmError(IntEnum):
    """
    Error codes for ConfirmSubType.ERROR messages on mtype=MType.CONFIRM (-1).
    """
    MALFORMED       = 1   # Message did not parse correctly
    MISSING_TLV     = 2   # Required TLV absent
    WRONG_TYPE      = 3   # TLV present but wrong type id
    UNKNOWN_SUBTYPE = 4   # Subtype not recognised by this agent
    NOT_SUPPORTED   = 5   # Subtype recognised but not implemented


class DebugLevel(IntEnum):
    """
    Debug levels for mtype=MType.DEBUG (-2).

    All debug messages use subtype=1 with envelope:
        Int(source_mtype)   — primary filter (which agent)
        Int(level)          — secondary filter (severity)
        Char(text)          — human-readable message

    Example subscriptions:
        (-2, 1) match Int(source_mtype)==1002           # one agent, all levels
        (-2, 1) match Int(level)>=WARN                  # all agents, warnings+
        (-2, 1) match Int(source_mtype)==1002, Int(level)==ERROR  # specific
    """
    DEBUG   = 0
    INFO    = 1
    WARN    = 2
    ERROR   = 3


class MetaSubType(IntEnum):
    """
    Subtypes for mtype=MType.META (-3).

    Envelope (all subtypes):
        Int(source_mtype)   — primary filter for content-match subscriptions
        MsgRef(msg_id)      — correlates response to the original request
        <payload>           — subtype-specific (see below)
    """
    CAPABILITY  = 1   # Response to GET_CAPABILITY: Int(source_mtype) MsgRef(msg_id) Char(json)
    VERSION     = 2   # Response to GET_VERSION:    Int(source_mtype) MsgRef(msg_id) Char(version)


class HeartbeatSubType(IntEnum):
    """
    Subtypes for mtype=MType.HEARTBEAT (-4).

    The subtype is the agent's own mtype — this lets the supervisor
    identify which agent is responding without additional TLVs.

    Envelope::

        (-4, agent_mtype)  Int(seq)

    The supervisor sends (-4, agent_mtype) with Int(seq).
    The agent echoes (-4, agent_mtype) with the same Int(seq).
    Two consecutive missed responses → Shutdown + restart.

    Using a dedicated negative mtype keeps heartbeat traffic completely
    off the application bus.  Agents that do not participate in heartbeat
    monitoring simply never subscribe to mtype=-4.
    """
    PING = 1   # Supervisor → Agent: Int(seq)
    PONG = 2   # Agent → Supervisor: Int(seq)  (same seq echoed back)


class UMMSubType(IntEnum):
    """
    Sub-types for mtype=MType.UMM (the UMM system layer).

    The namespace is split into three zones:

    Subtypes 1–50   ROUTER WIRE PROTOCOL — consumed privately by the router.
                    These messages drive the router's own machinery
                    (attach, register, shutdown…) and are also dispatched
                    normally through the subscription system so monitors
                    can observe them.

    Subtypes 51–99  ROUTER QUERY SERVICES — request/response services provided
                    by the router (capability, version, status, match query,
                    system shutdown).  Also intercepted by the router and
                    also dispatched to subscribers.

    Subtypes 100+   SYSTEM MESSAGES — pure pub/sub, not consumed by the
                    router.  Any agent may publish or subscribe.  Used for
                    system-level services: error reporting, agent directory,
                    type registry, diagnostics.  The router delivers them
                    exactly like application messages.
    """

    # ── Router wire protocol (subtypes 1–50) ──────────────────────────────────
    VERSION             = -1   # C→R  legacy: request router version string
    INIT                =  0   # R→C  acknowledge connection (pre-attach)
    ATTACH              =  1   # C→R  attach with flags/login
    ATTACH_CONFIRM      =  2   # R→C  attach confirmed
    DETACH              =  3   # C→R  detach
    REGISTER            =  4   # C→R  register a subscription
    UNREGISTER          =  5   # C→R  unregister a subscription
    SHUTDOWN            =  6   # C→R  initiate router/agent shutdown
    AGENT_ATTACHED      =  7   # R→*  lifecycle: agent joined the bus
    AGENT_DETACHED      =  8   # R→*  lifecycle: agent left the bus
    AGENT_REATTACHED    =  9   # R→*  lifecycle: agent reconnected

    # Reserved for future wire-protocol: 10–50

    # ── Router query services (subtypes 51–99) ────────────────────────────────

    # Capability (51–52)
    CAPABILITY_QUERY    = 51   # C→*  Int(mtype) targeted, or no payload for broadcast
    CAPABILITY_RESPONSE = 52   # *→C  Int(mtype)  Char(json)

    # Version (53–54)
    VERSION_REQUEST     = 53   # C→R  request router/agent version (no payload needed)
    VERSION_RESPONSE    = 54   # R→C  Int(mtype) Char(json)

    # Status / subscription table (55–56)
    STATUS_REQUEST      = 55   # C→R  request subscription table
    STATUS_RESPONSE     = 56   # R→C  Char(json) subscription table

    # Match query — dry-run delivery (57–58)
    MATCH_QUERY         = 57   # C→R  hypothetical message; returns who would receive it
    MATCH_RESULT        = 58   # R→C  Char(json) list of matching subscriptions

    # System shutdown (59) — trusted agents only
    SYSTEM_SHUTDOWN     = 59   # C→R  Int(delay_secs) [Char(message)]
                                #      Router broadcasts to all agents then exits.
                                #      Requires AttachFlag.TRUSTED.

    # Reserved for future query services: 60–99

    # ── System messages (subtypes 100+) ───────────────────────────────────────
    # Pure pub/sub — router delivers these like any other message.
    # Any agent may publish or subscribe.

    # Error / info / permission reporting (subtypes 100–109)
    SYS_ERROR           = 100  # R→C  Char(message)  — router error to one client
    SYS_INFO            = 101  # R→C  Char(message)  — router info to one client
    SYS_WARN            = 102  # R→*  Char(message)  — broadcast warning
    SYS_DENIED          = 103  # R→C  Char(message)  — request denied (e.g. not trusted)

    # Agent directory (subtypes 110–111)
    LIST_AGENTS         = 110  # C→R  request list of all attached agents
    LIST_AGENTS_RESPONSE = 111  # R→C  Char(json) list of attached agents

    # Type registry (subtypes 112–113)
    LIST_TYPES          = 112  # C→R  request all registered TLV types
    LIST_TYPES_RESPONSE = 113  # R→C  Char(json) type list with match operators

    # Subscription table (subtypes 114–115)
    LIST_SUBS           = 114  # C→R  request all current subscriptions
    LIST_SUBS_RESPONSE  = 115  # R→C  Char(json) subscription list


class AttachFlag(IntFlag):
    """Flags for the Attach message (flags field when mtype=UMM)."""
    NORMAL           = 0x00000
    PERM_KEEP_CONN   = 0x00001  # Critical process – queue msgs if offline
    TRANS_KEEP_CONN  = 0x00002  # May disconnect temporarily
    MONITOR          = 0x00004  # Non-intrusive monitor
    TRUSTED          = 0x00008  # Privileged agent – may issue system-wide commands
    MULTI_REG        = 0x00010  # Send multiple times if multi-match


class DetachFlag(IntFlag):
    NORMAL  = 0x00100
    FORCED  = 0x00200


class AttachConfFlag(IntFlag):
    NORMAL      = 0x01000
    PERM_NEW    = 0x02000
    PERM_REATT  = 0x04000
    PERM_DUP    = 0x08000


class RequestFlag(IntFlag):
    DONT_SEND_SELF = 0x80000  # Don't echo back to sender if self-match
    LAST_REQUEST   = 0x40000  # Final registration – flush queued msgs


class MsgFlag(IntFlag):
    SEND_RCVS    = 0x00001  # Router sends back receiver count
    CONFIRM_RTR  = 0x00002  # Router confirms receipt + forward
    CONFIRM_RCV  = 0x00004  # Receiver sends confirmation
    CONFIRM_APP  = 0x00008  # Application sends confirmation
    SERIES       = 0x00010  # Message is part of a series
    SERIES_START = 0x00020  # First of a series (OR with SERIES)
    SERIES_END   = 0x00040  # Last of a series  (OR with SERIES)


class AccountTrans(IntEnum):
    GET           = 0
    RESET         = 1
    GET_AND_RESET = 2


# ── AttachId ──────────────────────────────────────────────────────────────────

@dataclass
class AttachId:
    router: int = 0
    id:     int = 0

    def pack(self) -> bytes:
        return struct.pack(_FMT_ATTACHID, self.router, self.id)

    @classmethod
    def unpack(cls, buf: bytes, offset: int = 0) -> "AttachId":
        router, id_ = struct.unpack_from(_FMT_ATTACHID, buf, offset)
        return cls(router=router, id=id_)

    SIZE = struct.calcsize(_FMT_ATTACHID)   # 8


# ── UTime ─────────────────────────────────────────────────────────────────────

@dataclass
class UTime:
    secs:     int = 0
    ms:       int = 0
    timezone: int = 0
    dst:      int = 0

    def pack(self) -> bytes:
        return struct.pack(_FMT_UTIME, self.secs, self.ms, self.timezone, self.dst)

    @classmethod
    def unpack(cls, buf: bytes, offset: int = 0) -> "UTime":
        secs, ms, tz, dst = struct.unpack_from(_FMT_UTIME, buf, offset)
        return cls(secs=secs, ms=ms, timezone=tz, dst=dst)

    @classmethod
    def now(cls) -> "UTime":
        t = time.time()
        secs = int(t)
        ms   = int((t - secs) * 1000)
        return cls(secs=secs, ms=ms)

    SIZE = struct.calcsize(_FMT_UTIME)   # 12


# ── VersionId ─────────────────────────────────────────────────────────────────

@dataclass
class VersionId:
    umm_ident:   int = VERSION_IDENT
    msg_version: int = VERSION_MSG
    major:       int = VERSION_MAJOR
    minor:       int = VERSION_MINOR

    def pack(self) -> bytes:
        return struct.pack(_FMT_VERSION,
                           self.umm_ident, self.msg_version,
                           self.major, self.minor)

    @classmethod
    def unpack(cls, buf: bytes, offset: int = 0) -> "VersionId":
        a, b, c, d = struct.unpack_from(_FMT_VERSION, buf, offset)
        return cls(umm_ident=a, msg_version=b, major=c, minor=d)

    def is_valid(self) -> bool:
        return (self.umm_ident == VERSION_IDENT and
                self.msg_version == VERSION_MSG)

    SIZE = struct.calcsize(_FMT_VERSION)   # 4


# ── LogId ─────────────────────────────────────────────────────────────────────

MAX_NAME_LEN = 64

@dataclass
class LogId:
    process_name: str = ""
    login_name:   str = ""
    password:     str = ""

    def pack(self) -> bytes:
        """Encode as three null-terminated strings."""
        return (self.process_name.encode() + b'\x00' +
                self.login_name.encode()   + b'\x00' +
                self.password.encode()     + b'\x00')

    @classmethod
    def unpack(cls, buf: bytes, offset: int = 0) -> "LogId":
        parts = buf[offset:].split(b'\x00', 3)
        return cls(
            process_name=parts[0].decode(errors='replace') if len(parts) > 0 else "",
            login_name  =parts[1].decode(errors='replace') if len(parts) > 1 else "",
            password    =parts[2].decode(errors='replace') if len(parts) > 2 else "",
        )


# ── UMMMsg ────────────────────────────────────────────────────────────────────

@dataclass
class UMMMsg:
    """
    The UMM message structure.

    All integer fields are stored in Python native int; they are converted
    to/from network byte order on encode/decode.
    """
    version:   VersionId = field(default_factory=VersionId)
    attach_id: AttachId  = field(default_factory=AttachId)
    origin:    AttachId  = field(default_factory=AttachId)
    tm:        UTime     = field(default_factory=UTime.now)
    flags:     int       = 0
    reg_id:    int       = 0
    msg_id:    int       = 0
    mtype:     int       = 0
    subtype:   int       = 0
    channel:   int       = 1   # logical channel (Channel enum); 1 = application bus (APP)
    tdata:     TLV       = field(default_factory=lambda: TLV(TLV_TERM))

    # ── encode ────────────────────────────────────────────────────────────────

    def encode(self) -> bytes:
        """Serialise the complete message to wire bytes."""
        parts = [
            self.version.pack(),
            self.attach_id.pack(),
            self.origin.pack(),
            self.tm.pack(),
            struct.pack("!iiii",
                        self.flags, self.reg_id, self.msg_id, self.mtype),
            struct.pack("!i", self.subtype),
            struct.pack("!BBBx", self.channel & 0xFF, 0, 0),  # channel(1) + reserved(3)
            self.tdata.encode(),
        ]
        return b"".join(parts)

    # ── decode ────────────────────────────────────────────────────────────────

    @classmethod
    def decode(cls, buf: bytes, offset: int = 0) -> "UMMMsg":
        """
        Deserialise the UMMMsg fixed header only (56 bytes).
        TData is NOT parsed here — caller must read and attach it.
        See UMMAgent._read_one() for the full read sequence.
        """
        o = offset

        version   = VersionId.unpack(buf, o);  o += VersionId.SIZE
        attach_id = AttachId.unpack(buf, o);   o += AttachId.SIZE
        origin    = AttachId.unpack(buf, o);   o += AttachId.SIZE
        tm        = UTime.unpack(buf, o);      o += UTime.SIZE

        flags, reg_id, msg_id, mtype = struct.unpack_from("!iiii", buf, o)
        o += 16
        (subtype,) = struct.unpack_from("!i", buf, o)
        o += 4
        # channel byte + 3 reserved (ignored on receive)
        channel = struct.unpack_from("!B", buf, o)[0]

        return cls(
            version=version,
            attach_id=attach_id,
            origin=origin,
            tm=tm,
            flags=flags,
            reg_id=reg_id,
            msg_id=msg_id,
            mtype=mtype,
            subtype=subtype,
            channel=channel,
            tdata=TLV(TLV_TERM),   # caller reads and attaches TData
        )

    # ── helpers ───────────────────────────────────────────────────────────────

    @property
    def total_size(self) -> int:
        return len(self.encode())

    def is_umm_control(self) -> bool:
        return self.mtype == MType.UMM

    def __repr__(self) -> str:
        return (f"UMMMsg(mtype={self.mtype}, subtype={self.subtype}, "
                f"ch={self.channel}, "
                f"attach={self.attach_id.id}, reg={self.reg_id}, "
                f"flags=0x{self.flags:x})")


# ── factory helpers ───────────────────────────────────────────────────────────

def make_msg(mtype: int, subtype: int,
             tlvs: Optional[TLVBuffer] = None,
             flags: int = 0,
             reg_id: int = 0,
             msg_id: int = 0,
             channel: int = 1,
             attach_id: Optional[AttachId] = None,
             origin: Optional[AttachId] = None) -> UMMMsg:
    """
    Convenience constructor for building outgoing messages.

    Parameters
    ----------
    mtype, subtype : int
        Message type and sub-type.
    tlvs : TLVBuffer, optional
        Payload TLVs.  If None, an empty TLV_TERM is used.
    flags : int
        Message flags (MsgFlag / AttachFlag etc.).
    reg_id : int
        Registration ID.
    msg_id : int
        Message sequence ID.
    channel : int
        Logical channel (Channel enum); default 1 = application bus (Channel.APP).
    attach_id, origin : AttachId, optional
        Overrides for attach/origin IDs (set by router normally).
    """
    if tlvs is not None:
        payload_bytes = tlvs.encode()
        # Wrap in a container TLV so the message has a single TData TLV
        # whose value contains all the packed sub-TLVs.
        from .tlv import TLV_MSG
        tdata = TLV(type_id=TLV_MSG, value=payload_bytes)
    else:
        tdata = TLV(type_id=TLV_TERM)

    return UMMMsg(
        version   = VersionId(),
        attach_id = attach_id or AttachId(),
        origin    = origin or AttachId(),
        tm        = UTime.now(),
        flags     = flags,
        reg_id    = reg_id,
        msg_id    = msg_id,
        mtype     = mtype,
        subtype   = subtype,
        channel   = channel,
        tdata     = tdata,
    )


def msg_size(msg: UMMMsg) -> int:
    """Return the total encoded byte-length of *msg*."""
    return msg.total_size