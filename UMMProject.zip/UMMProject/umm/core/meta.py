"""
umm.core.meta
=============
Metadata registry — maps (type_id, meta_value) → human-readable name.

The meta field in a TLV header is a 32-bit semantic qualifier that narrows
the meaning of the base type without creating a new type.  Its meaning is
type-dependent: meta=1 on a Float might mean "temperature", while meta=1 on a
Char might mean "filename".

Registration
------------
Built-in metadata is pre-registered below.  Application code can add entries
at startup via ``meta_registry.register(type_id, meta_value, name)``.

Lookup
------
``meta_registry.name(type_id, meta_value)`` returns the registered name or
None if unknown.

Wire rule
---------
The router's match rule for meta is intentionally simple:
  - meta == 0 on either side → always passes (meta absent / wildcard)
  - otherwise both sides must have the same non-zero meta value

No partial matching, no hierarchy — exact equality or wildcard only.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from typing import Dict, Optional, Tuple


# ── standard meta values for built-in types ───────────────────────────────────
#
# Values are per-type: the same integer can mean different things for different
# base types.  This mirrors the design intent — meta is a type-scoped qualifier.
#
# Reservations:
#   0          always means "absent" — do not register
#   1–99       reserved for UMM built-in use (defined here)
#   100–999    reserved for manufacturing / industrial use
#   1000+      free for application use

# Meta values for Char (type_id = 8) — string semantics
CHAR_META_FILENAME   = 1   # a filesystem filename or path
CHAR_META_URL        = 2   # a URL or URI
CHAR_META_EMAIL      = 3   # an email address
CHAR_META_HOSTNAME   = 4   # a hostname or FQDN
CHAR_META_JSON       = 5   # a JSON-encoded string (informational; use TLV_JSON for typed matching)
CHAR_META_MIME_TYPE  = 6   # a MIME type string (e.g. "image/png")
CHAR_META_COMMAND    = 7   # a shell or system command string
CHAR_META_IDENTIFIER = 8   # a generic identifier / key

# Meta values for Float (type_id = 6) — physical measurement semantics
FLOAT_META_TEMPERATURE  = 1   # temperature (°C unless otherwise agreed)
FLOAT_META_PRESSURE     = 2   # pressure (Pa unless otherwise agreed)
FLOAT_META_HUMIDITY     = 3   # relative humidity (%)
FLOAT_META_SPEED        = 4   # speed (m/s unless otherwise agreed)
FLOAT_META_VOLTAGE      = 5   # electrical voltage (V)
FLOAT_META_CURRENT      = 6   # electrical current (A)
FLOAT_META_POWER        = 7   # power (W)
FLOAT_META_DISTANCE     = 8   # distance / length (m)
FLOAT_META_MASS         = 9   # mass (kg)
FLOAT_META_FREQUENCY    = 10  # frequency (Hz)
FLOAT_META_ANGLE        = 11  # angle (degrees)
FLOAT_META_FLOW_RATE    = 12  # flow rate (m³/s unless otherwise agreed)
FLOAT_META_LUMINANCE    = 13  # luminance / brightness (lux)
FLOAT_META_CONCENTRATION = 14 # concentration (application-defined units)

# Float meta — industrial / process measurements (100–999 range)
FLOAT_META_LEVEL        = 100 # fill level / percentage (e.g. tank level 0–100%)

# Meta values for Int / UInt (type_id = 2, 3) — categorical / status semantics
INT_META_STATUS      = 1   # a status or state code
INT_META_ERROR_CODE  = 2   # an error or fault code
INT_META_COUNT       = 3   # a count or quantity
INT_META_INDEX       = 4   # a 0-based index or position
INT_META_PRIORITY    = 5   # a priority level
INT_META_VERSION     = 6   # a version number
INT_META_FLAGS       = 7   # a bitmask of flags

# Meta values for Bool (type_id = 7)
BOOL_META_ENABLED    = 1   # enabled/disabled flag
BOOL_META_ALARM      = 2   # alarm active/inactive
BOOL_META_CONNECTED  = 3   # connection state
BOOL_META_RUNNING    = 4   # process/machine running state


# Meta value ranges (by convention)
# ---------------------------------
#   1–49    built-in per-type words (above) — the same low number means
#           different things for different types (e.g. meta=1 is "filename" on
#           Char, "temperature" on Float, "status" on Int).
#   50–99   cross-type semantic words — one number + one name reused across the
#           encodings a concept may arrive in, registered with
#           register_semantic() or a comma-separated [meta] line.  Each type
#           still matches on its own terms; a subscriber registers one
#           subscription per type and the router ORs across them.
#   100+    application-specific words (e.g. the sorting demo's sort-code=100).


# ── registry class ────────────────────────────────────────────────────────────

class MetaRegistry:
    """
    Registry mapping (type_id, meta_value) → name string.

    Thread-safety: register() is not thread-safe.  All registrations should
    happen before the router starts accepting connections.
    """

    def __init__(self) -> None:
        self._table: Dict[Tuple[int, int], str] = {}
        self._load_builtins()

    def _load_builtins(self) -> None:
        from ..core.tlv import TLV_STRING, TLV_FLOAT, TLV_INT, TLV_UINT, TLV_BOOL

        # Char meta
        self.register(TLV_STRING, CHAR_META_FILENAME,    "filename")
        self.register(TLV_STRING, CHAR_META_URL,         "url")
        self.register(TLV_STRING, CHAR_META_EMAIL,       "email")
        self.register(TLV_STRING, CHAR_META_HOSTNAME,    "hostname")
        self.register(TLV_STRING, CHAR_META_JSON,        "json-string")
        self.register(TLV_STRING, CHAR_META_MIME_TYPE,   "mime-type")
        self.register(TLV_STRING, CHAR_META_COMMAND,     "command")
        self.register(TLV_STRING, CHAR_META_IDENTIFIER,  "identifier")

        # Float meta
        self.register(TLV_FLOAT, FLOAT_META_TEMPERATURE,   "temperature")
        self.register(TLV_FLOAT, FLOAT_META_PRESSURE,      "pressure")
        self.register(TLV_FLOAT, FLOAT_META_HUMIDITY,      "humidity")
        self.register(TLV_FLOAT, FLOAT_META_SPEED,         "speed")
        self.register(TLV_FLOAT, FLOAT_META_VOLTAGE,       "voltage")
        self.register(TLV_FLOAT, FLOAT_META_CURRENT,       "current")
        self.register(TLV_FLOAT, FLOAT_META_POWER,         "power")
        self.register(TLV_FLOAT, FLOAT_META_DISTANCE,      "distance")
        self.register(TLV_FLOAT, FLOAT_META_MASS,          "mass")
        self.register(TLV_FLOAT, FLOAT_META_FREQUENCY,     "frequency")
        self.register(TLV_FLOAT, FLOAT_META_ANGLE,         "angle")
        self.register(TLV_FLOAT, FLOAT_META_FLOW_RATE,     "flow-rate")
        self.register(TLV_FLOAT, FLOAT_META_LUMINANCE,     "luminance")
        self.register(TLV_FLOAT, FLOAT_META_CONCENTRATION, "concentration")
        self.register(TLV_FLOAT, FLOAT_META_LEVEL,         "level")

        # Int / UInt meta
        for tid in (TLV_INT, TLV_UINT):
            self.register(tid, INT_META_STATUS,     "status")
            self.register(tid, INT_META_ERROR_CODE, "error-code")
            self.register(tid, INT_META_COUNT,      "count")
            self.register(tid, INT_META_INDEX,      "index")
            self.register(tid, INT_META_PRIORITY,   "priority")
            self.register(tid, INT_META_VERSION,    "version")
            self.register(tid, INT_META_FLAGS,      "flags")

        # Bool meta
        self.register(TLV_BOOL, BOOL_META_ENABLED,   "enabled")
        self.register(TLV_BOOL, BOOL_META_ALARM,     "alarm")
        self.register(TLV_BOOL, BOOL_META_CONNECTED, "connected")
        self.register(TLV_BOOL, BOOL_META_RUNNING,   "running")

    def register(self, type_id: int, meta_value: int, name: str) -> None:
        """Register a (type_id, meta_value) → name mapping."""
        if meta_value == 0:
            raise ValueError("meta_value 0 is reserved for 'absent' — cannot register")
        self._table[(type_id, meta_value)] = name

    def register_semantic(self, meta_value: int, name: str, type_ids) -> None:
        """
        Register one meta value under one name for several types at once.

        This is the "middle way" for a cross-type semantic meta word: the same
        number and name are reused across the encodings a concept may arrive in,
        so an agent can subscribe to e.g. ``temperature`` whether it is sent as
        an Int, a Float or a Char.  Each type keeps its own matching semantics —
        a subscriber registers one subscription per type and the router ORs the
        results across them (conditions *within* one subscription are ANDed).

        ``type_ids`` is an iterable of TLV type ids (e.g. TLV_INT, TLV_FLOAT) or
        registered type names (e.g. 'Int', 'Float', 'Char').

        By convention, cross-type semantic meta values use the reserved band
        50–99 (the built-in per-type words occupy the low numbers, and 100+ is
        the application range).
        """
        for tid in type_ids:
            rid = tid if isinstance(tid, int) else self._resolve_type_token(str(tid))
            if rid is None:
                logger.warning("MetaRegistry.register_semantic: unknown type %r", tid)
                continue
            self.register(rid, meta_value, name)

    @staticmethod
    def _resolve_type_token(token: str):
        """Resolve a TYPE token (numeric id or registered name) → type id, or None."""
        if token.lstrip('-').isdigit():
            return int(token)
        try:
            from .registry import registry            # lazy — avoids import cycle
        except Exception:
            return None
        h = registry.get_by_name(token)
        if h is None:
            for nm in registry.all_names():
                if nm.lower() == token.lower():
                    h = registry.get_by_name(nm)
                    break
        return h.TYPE_ID if h is not None else None

    def name(self, type_id: int, meta_value: int) -> Optional[str]:
        """Return the registered name for (type_id, meta_value), or None."""
        if meta_value == 0:
            return None
        return self._table.get((type_id, meta_value))

    def all_entries(self) -> list:
        """Return all registered entries as list of (type_id, meta_value, name) tuples."""
        return [(t, m, n) for (t, m), n in sorted(self._table.items())]

    def entries_for_type(self, type_id: int) -> list:
        """Return all registered entries for a given type_id as (meta_value, name) tuples."""
        return [(m, n) for (t, m), n in sorted(self._table.items()) if t == type_id]

    def load_file(self, path) -> int:
        """
        Load meta-word names from the ``[meta]`` section of a config/project file.

        Section line format (whitespace-delimited, ``#`` comments)::

            [meta]
            # TYPE          META  NAME
            Int             100   sort-code
            6               1     temperature   # TYPE may be a numeric type id
            Int,Float,Char  50    temperature   # one cross-type semantic word

        ``TYPE`` is a registered type name (case-insensitive: Int, Float, Char …)
        or a numeric TLV type id; a comma-separated list registers the same meta
        value and name for each type at once (the "middle way" for a cross-type
        semantic meta — see ``register_semantic``).  By convention such words use
        the reserved band 50–99.  Only the ``[meta]`` section is read; all other
        sections are ignored.  Returns the number of (type, meta) entries loaded.
        """
        from pathlib import Path
        p = Path(path)
        if not p.exists():
            return 0

        count = 0
        section = None                               # require an explicit [meta]
        for lineno, raw in enumerate(p.read_text().splitlines(), 1):
            line = raw.split('#')[0].strip()
            if not line:
                continue
            if line.startswith('[') and line.endswith(']'):
                section = line[1:-1].strip().lower()
                continue
            if section != 'meta':
                continue
            parts = line.split()
            if len(parts) < 3:
                logger.warning("MetaRegistry: bad [meta] line %d in %s: %r",
                               lineno, path, raw)
                continue
            type_tok, meta_tok, name = parts[0], parts[1], parts[2]

            try:
                meta_val = int(meta_tok)
            except ValueError:
                logger.warning("MetaRegistry: bad meta value %r (line %d in %s)",
                               meta_tok, lineno, path)
                continue

            # TYPE may be a single type or a comma-separated list.
            resolved = False
            for tok in type_tok.split(','):
                tok = tok.strip()
                if not tok:
                    continue
                type_id = self._resolve_type_token(tok)
                if type_id is None:
                    logger.warning("MetaRegistry: unknown type %r (line %d in %s)",
                                   tok, lineno, path)
                    continue
                try:
                    self.register(type_id, meta_val, name)
                    count += 1
                    resolved = True
                except ValueError as exc:    # meta_value 0 is reserved
                    logger.warning("MetaRegistry: %s (line %d in %s)", exc, lineno, path)
            if not resolved:
                logger.warning("MetaRegistry: no usable type on line %d in %s: %r",
                               lineno, path, raw)

        if count:
            logger.info("MetaRegistry: loaded %d meta names from %s", count, path)
        return count

    def __repr__(self) -> str:
        return f"MetaRegistry({len(self._table)} entries)"


# ── module-level singleton ────────────────────────────────────────────────────

meta_registry = MetaRegistry()
