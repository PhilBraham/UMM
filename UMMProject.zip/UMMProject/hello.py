from umm.agent import UMMAgent

# 1004 = Barcode mtype in the sorting demo
MT_BARCODE      = 1004
ST_SCAN_SUCCESS = 102

def on_scan(msg):
    print(f'Barcode scan result received: mtype={msg.mtype} subtype={msg.subtype}')

agent = UMMAgent(host='localhost', port=5300, process_name='HelloUMM')
agent.connect()
agent.register(mtype=MT_BARCODE, subtype=ST_SCAN_SUCCESS, callback=on_scan)
agent.run()   # blocks until interrupted
