# Universal Message Manager (UMM)

UMM is a typed publish/subscribe middleware. Agents attach to a central **router**
and register subscriptions; the router dispatches messages to matching subscribers
based on channel, message type (`mtype`), subtype, and optional **content matching**
on the TLV‑encoded payload. It ships with a service stack (timer, type directory,
supervisor, parser, database, feed, inter‑router bridge), a web console, two worked
demos (a parcel‑sorting machine and a tank‑level controller), and a wire‑compatible
C implementation of the router and client library.

Full documentation is in the three Word volumes that accompany this project:

- **Volume 1 — Introduction & Concepts** — start here.
- **Volume 2 — The UMM System (Reference)** — architecture, wire format, type system, matching rules, services.
- **Volume 3 — Building UMM Agents (Developer Guide)** — writing agents, capabilities, custom types, FSMs, the C library.

---

## Requirements

- **Python 3.7 or later.** Developed and tested on 3.11/3.12, and verified to run
  on Python 3.7 (e.g. Raspberry Pi OS). The code avoids syntax and standard-library
  features newer than 3.7, so an older deployment target works without changes.
- The core router, agents, and command‑line tools use **only the Python standard
  library** — no third‑party packages are needed to run the router and send/receive
  messages.

A few optional features need extra packages; see [Optional dependencies](#optional-dependencies)
below. The two you are most likely to want are `websockets` (for the web console and the
demo GUIs) and `feedparser` (only if you use the RSS/Atom feed agent).

---

## Getting started

### 1. Unpack the project

If you received the project as a zip, unpack it first. On macOS/Linux:

```bash
unzip UMMProject.zip
```

On Windows, right‑click the zip and choose **Extract All**. Everything lives under a
single `UMMProject/` directory.

### 2. Open a terminal in the project directory

```bash
cd UMMProject
```

All commands below are run from this directory unless stated otherwise.

### 3. Start the system

If the first time you may need:
```bash
chmod +x ./runumm
```
Add the UMMProject path to $PATH (eg: "export PATH="/path/to/UMMProject:$PATH") or prefix runnumm with ./ to execute it locally. 

```bash
runumm start
```

`runumm` is a thin wrapper around `umm_ctl.py` (the service manager). `runumm start`
brings up the **core stack**: the router (port **5300**) and the supervisor, which in
turn launches the timer, the type directory, the web console server (port **8765**), and
the two built‑in match plugins (string and coordinate matching).

Then open the web console in a browser:

```
http://localhost:8765
```

To stop everything:

```bash
runumm stop
```

> **`runumm: command not found`?** The `runumm` script lives in the project directory,
> which is normally not on your `PATH`. Either call it with a leading `./` (see below),
> or add it to your `PATH` (also below).

---

## Running `runumm`

### macOS / Linux

`runumm` is a bash script. If the project directory is not on your `PATH`, run it with a
leading `./` from inside `UMMProject`:

```bash
./runumm start
./runumm status
./runumm stop
```

### Windows

Use the `runumm.cmd` batch file. From a Command Prompt or PowerShell opened in
`UMMProject`:

```
runumm start
runumm status
runumm stop
```

(`cmd`/PowerShell will find `runumm.cmd` in the current directory.) To run it from
anywhere, add the project directory to your **System Properties → Environment Variables →
Path**, or copy/symlink `runumm.cmd` into a directory already on your `Path`.

**Stopping a terminal agent with Ctrl-C.** When you stop a foreground agent (e.g. the
parser) that was started via `runumm.cmd`, Windows shows `Terminate batch job (Y/N)?`.
This is normal: the prompt comes from `cmd.exe` (a batch file can't hand the console
straight to Python the way the Unix script does), and by the time you see it the agent
has *already* shut down cleanly — answer either Y or N. To skip the prompt entirely for
agents you interrupt often, install the package once (`pip install -e .` from the project
directory) and run that agent through its console script, which is a real executable
rather than a batch file:

```
umm-parser --heading --channel 1 --channel 128
```

Ctrl-C then returns you straight to the prompt. Keep using `runumm` for starting and stopping the system; the direct console scripts (`umm-parser`, `umm-send`, …) are just more convenient for a long-running monitor.

---

## Optional dependencies

The core system needs nothing beyond the standard library. Install these only if you use the corresponding feature. The relevant tools also print the exact install command if a package is missing.

| Package | Needed for | Install |
|---|---|---|
| `websockets` | The web console and all browser GUIs (console, conveyor, tank, feed browser). Without it the router and CLI tools still work, but no web UI. | `python3 -m pip install websockets` |
| `feedparser` | The RSS/Atom **feed agent** (`umm.modules.feed`) only. | `python3 -m pip install feedparser` |
| `psycopg2-binary` | The **database agent** with the PostgreSQL backend. SQLite (the default) needs nothing — it is built into Python. | `python3 -m pip install psycopg2-binary` |
| `mysql-connector-python` | The database agent with the MySQL backend. | `python3 -m pip install mysql-connector-python` |

**macOS / Homebrew note:** on a Homebrew‑managed Python you may hit an "externally‑managed‑environment" error. Two options:

```bash
# Option A: per‑user install
python3 -m pip install --user websockets feedparser

# Option B: override the protection (simplest for a dev machine)
python3 -m pip install websockets feedparser --break-system-packages
```

Also note `feedparser` is **not** a Homebrew formula — `brew install feedparser` will not work. Always install it with `pip`.

If you use a **virtual environment**, activate it first, then `pip install` normally:

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install websockets feedparser
```

Verify an install with, e.g.:

```bash
python3 -c "import websockets; print(websockets.__version__)"
```

**`websockets` versions — any recent one works.** The browser GUIs serve their
HTML page and the live WebSocket on a single port, and the server adapts at
runtime to whichever `websockets` API is installed: the *legacy* server (used by
`websockets` 8–13, which is what Python 3.7 installs — e.g. on a Raspberry Pi)
and the *new asyncio* server (`websockets` 14+ on Python 3.8+). It detects the
calling convention per request, so no specific version is required — whatever
`pip install websockets` selects for your Python will work. The GUI prints the
version it loaded in its startup banner if you ever need to check.

---

## Common commands

`runumm` (i.e. `umm_ctl.py`) supports:

| Command | What it does |
|---|---|
| `runumm start` | Start the core stack (router + supervisor + managed agents). |
| `runumm start <group>` | Start a named group as well (e.g. `tank`, `sorting`). |
| `runumm stop` | Stop everything started by `runumm`. |
| `runumm restart` | Stop then start. |
| `runumm status` | Show running processes, the router address/port, and GUI port. |
| `runumm agents` | Query the live router/supervisor for every attached agent (including plugins). |
| `runumm logs` | Show recent log output. |
| `runumm show` | Show the parsed configuration (agents, groups, bridges). |
| `runumm validate` | Check `umm.conf` for problems without starting anything. |
| `runumm killall` | Force‑kill any stray UMM processes (use if something is stuck). |
| `runumm cleanstart` | `killall` then `start` — a clean restart. |
| `runumm help [agent]` | Show help; `runumm help parser` shows the parser's own options. |

To pass arguments straight through to an agent, use `--`:

```bash
runumm start parser -- --channel 1        # parser, app‑bus channel only
```

### Monitoring traffic

The **parser** prints messages on the bus — invaluable while developing:

```bash
runumm start parser            # see all traffic
runumm start parser -- --channel 1   # application bus only (hide infrastructure)
```

### Sending messages by hand

The **send** tool publishes one‑off messages or replays a script:

```bash
runumm start send -- 100,1 Float 25.3            # publish one message, then exit
runumm start send                                 # interactive REPL
```

---

## Running the demos

Two worked examples are included. Both are started as groups and have their own browser GUI served by the console server on port 8765.
The project had a database (umm.data.db) pre-loaded with the tables for the tank and parcel sorting demos.

**Sorting machine** (parcel sorter with conveyor, barcode scanner, diverter, and bins):

```bash
runumm start sorting-database-setup  # only if you want to recreate the database tables 
runumm start                         # core stack first
# then start the demo agents + FSM (see Volume 3, Appendix, for the exact commands)
# open http://localhost:8765/conveyor.html  → click CONN, then START
```

**Tank level** (simulated tank with a pump controller driven by an FSM):

```bash
runumm start tank-database-setup     # only if you want to recreate the database tables 
runumm start tank                    # starts the tank group
# open http://localhost:8765/tank_gui.html
```

The exact agent/FSM launch commands and configuration for each demo are documented in
**Volume 3** (developer guide).

---

## Connecting from another machine

By default the router binds to all network interfaces, so agents on other machines can
connect to it. On the **agent** machine, point it at the router's address with an
environment variable (no code or config change needed):

```bash
export UMM_ROUTER=192.168.1.31:5300        # host:port of the router
```

This is read by all UMM tools and agents. See Volume 1 §5 and Volume 2 §2 for details.

---

## Project layout

```
UMMProject/
├── runumm, runumm.cmd        Service‑manager wrapper (Unix / Windows)
├── umm_ctl.py                The service manager itself (start/stop/status/…)
├── umm.conf                  Service configuration (port 5300, GUI 8765, agents, groups)
├── supervisor.conf           What the supervisor launches and how it monitors them
├── init.conf                 Startup message script (run once by the supervisor)
├── umm/
│   ├── router.py             The message router (asyncio TCP)
│   ├── agent.py              UMMAgent — the synchronous client API
│   ├── mixins.py             Debug / Version / Heartbeat / Shutdown / Resequence mixins
│   ├── capability.py         Capability descriptors and query handlers
│   ├── core/                 Wire format: messages, tlv, registry, meta
│   ├── types/                Built‑in and manufacturing TLV types
│   ├── modules/              Services: timer, fsm, typedir, watchdog, parser,
│   │                         supervisor, database, feed, bridge
│   ├── plugins/              External match plugins: string_match, coord_match
│   └── tools/                send (publish/REPL/replay)
├── umm_gui/                  Web console + demo GUIs (server.py + *.html)
├── examples/
│   ├── sorting/              Parcel‑sorting demo
│   └── tankLevel/            Tank‑level demo
└── umm-c/                    C router + client library (wire‑compatible with Python)
```

---

## Where to read next

- **New to UMM?** Read **Volume 1**, then try the Getting Started walkthrough in it.
- **Writing an agent?** **Volume 3**.
- **Need the wire format / matching rules / service reference?** **Volume 2**.
