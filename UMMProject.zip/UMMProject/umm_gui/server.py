"""
umm_gui/server.py
=================
GUI server — serves gui.html and bridges the browser to the UMM router.

The browser connects via WebSocket and sends/receives JSON.
This server translates JSON commands to UMM calls via UMMAgent.

Run::
    python3 umm_gui/server.py --router localhost --port 5100 --gui-port 8765
    Open http://localhost:8765
"""
from __future__ import annotations

import asyncio
import json
import logging
import struct
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional, Set

if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

try:
    import websockets
except ImportError:
    print("ERROR: websockets module not found.")
    print(f"       Python executable: {sys.executable}")
    print( "       Install with:  pip install websockets")
    print( "       Make sure you are using the same Python that runs this script.")
    print( "       On Windows:    py -m pip install websockets")
    print( "       On macOS/Linux with multiple Pythons:")
    print(f"       {sys.executable} -m pip install websockets")
    sys.exit(1)

sys.path.insert(0, str(Path(__file__).parent.parent))

from umm.agent import UMMAgent
from umm.core.tlv import TLV, TLVBuffer, decode_all, TLV_TERM, TLV_INT, TLV_MSG, TLV_STRING
from umm.core.meta import meta_registry
from umm.core.messages import MType, Channel, UMM_VERSION_STR, DEFAULT_PORT
from umm.core.registry import registry
from umm.types.builtin import BUILTIN_TYPES       # Bool, Int, Char, UTime etc.
from umm.types.manufacturing import MANUFACTURING_TYPES
from umm.modules.timer import ST_REQUEST as _ST_TIMER_REQUEST

for _cls in BUILTIN_TYPES:
    registry.register_class(_cls)

logger = logging.getLogger(__name__)

for _cls in MANUFACTURING_TYPES:
    registry.register_class(_cls)

from umm.names import NameRegistry as _NameRegistry
_names = _NameRegistry()
_names.load_capabilities()
# Site-specific names — auto-load umm_names.conf from the working directory,
# exactly like the parser does, so custom mtype/subtype names appear in the GUI.
for _names_cand in ('umm_names.conf', 'names.conf'):
    if Path(_names_cand).exists():
        _names.load_file(_names_cand)
        break
# The top-level project.conf (next to umm.conf at the project root) is always
# loaded, exactly like the parser: [names] and [meta] apply to the GUI's
# message display ([colors] is parser-only and ignored here).
_default_project = Path(__file__).resolve().parents[1] / 'project.conf'
if _default_project.exists():
    from umm.project import load_project as _load_project
    _load_project(_default_project, names=_names)

def _mtype_name(mtype: int) -> str:
    return _names.mtype_name(mtype)

def _subtype_name(mtype: int, subtype: int, channel: int = 0) -> str:
    # Channel-specific subtype names take priority to avoid collisions
    # e.g. subtype=2 on channel=3 is VersionResponse, not AttachConfirm
    _CH_SN = {
        2: {1:'Error', 2:'RouterConfirm', 3:'ReceiverConfirm', 4:'AppConfirm'},
        3: {1:'DebugMsg'},
        4: {1:'CapabilityResponse', 2:'VersionResponse', 11:'CapabilityResponse'},
        5: {1:'Ping', 2:'Pong'},
        6: {1:'Ping', 2:'Pong'},
    }
    if channel > 1:
        ch_name = _CH_SN.get(channel, {}).get(subtype)
        if ch_name:
            return ch_name
    n = _names.subtype_name(mtype, subtype)
    return n if n is not None else str(subtype)

def format_tlv(tlv: TLV) -> Dict[str, Any]:
    handler   = registry.get_by_id(tlv.type_id)
    type_name = handler.TYPE_NAME if handler else f"Type{tlv.type_id}"
    op_text   = ""
    if tlv.match != 0 and handler:
        op_map  = getattr(handler, 'OP_TEXT', {})
        # Only store a named symbol; leave empty for raw numbers so the
        # GUI can render them as {n} using the match integer directly.
        _rev = {v: k for k, v in op_map.items()}
        op_text = _rev.get(tlv.match, '')
    meta_val  = tlv.meta
    meta_name = meta_registry.name(tlv.type_id, meta_val) if meta_val else ""
    value_text = ""
    if tlv.value:
        if tlv.type_id == TLV_MSG:
            try:
                val = tlv.value
                # UMMReg format: mtype(4) + subtype(4) + TLV payload
                # Try to decode as mtype/subtype + TLVs first
                if len(val) >= 8:
                    import struct as _s
                    inner_mtype, inner_sub = _s.unpack_from('!ii', val)
                    remainder = val[8:]
                    children = []
                    if remainder:
                        try:
                            children = [format_tlv(c) for c in decode_all(remainder)]
                        except Exception:
                            pass
                    # Format mtype/subtype as readable name
                    inner_name = _names.full_name(inner_mtype, inner_sub)
                    return {"type_id":tlv.type_id,"type_name":"Msg","match":tlv.match,"meta":meta_val,"meta_name":meta_name,
                            "op":op_text,
                            "value":inner_name,
                            "children":children}
                else:
                    # Short Msg — try plain TLV decode
                    children = [format_tlv(c) for c in decode_all(val)]
                    return {"type_id":tlv.type_id,"type_name":"Msg","match":tlv.match,"meta":meta_val,"meta_name":meta_name,
                            "op":op_text,"value":"","children":children}
            except Exception:
                pass
        if handler:
            try:
                value_text = handler.to_text(handler.unpack(tlv.value))
            except Exception:
                value_text = tlv.value.hex()
        else:
            try:
                value_text = tlv.value.rstrip(b'\x00').decode('utf-8')
            except Exception:
                value_text = tlv.value.hex()
    return {"type_id":tlv.type_id,"type_name":type_name,"match":tlv.match,"meta":meta_val,"meta_name":meta_name,
            "op":op_text,"value":value_text,"children":[]}

def format_msg(msg) -> Dict[str, Any]:
    tlvs = []
    if msg.tdata.value:
        try:
            tlvs = [format_tlv(t) for t in decode_all(msg.tdata.value)]
        except Exception:
            pass
    return {
        "ts":           time.strftime("%H:%M:%S"),
        "ts_ms":        int(time.time() * 1000),
        "mtype":        msg.mtype,
        "subtype":      msg.subtype,
        "channel":      msg.channel,
        "mtype_name":   _mtype_name(msg.mtype),
        "subtype_name": _subtype_name(msg.mtype, msg.subtype, msg.channel),
        "attach_id":    f"{msg.attach_id.router}.{msg.attach_id.id}",
        "origin":       f"{msg.origin.router}.{msg.origin.id}",
        "reg_id":       msg.reg_id,
        "msg_id":       msg.msg_id,
        "flags":        msg.flags,
        "tlvs":         tlvs,
    }

def build_tlvs(specs: list) -> bytes:
    buf = TLVBuffer()
    for spec in specs:
        type_id  = int(spec["type_id"])
        match    = int(spec.get("match", spec.get("mword", 0)))  # accept legacy mword key
        meta     = int(spec.get("meta", 0))
        val_text = str(spec.get("value", ""))
        handler  = registry.get_by_id(type_id)
        if handler and val_text:
            try:
                value_bytes = handler.pack(handler.from_text(val_text))
            except Exception:
                value_bytes = val_text.encode() + b'\x00'
        elif val_text:
            value_bytes = val_text.encode() + b'\x00'
        else:
            value_bytes = b''
        buf.add(TLV(type_id=type_id, value=value_bytes, match=match, meta=meta))
    return buf.encode()

class ClientSession:
    """Per-WebSocket UMM session.

    Each browser tab gets its **own** UMMAgent — its own attach_id and TCP
    connection to the router — so it is a fully independent UMM agent, exactly
    like a native client (see umm/proxy.py).  This is what allows several GUI
    consoles, the conveyor GUI and the tank GUI to run at the same time without
    the router's per-attach subscription de-duplication collapsing their
    identical subscriptions into one.

    All per-client state (the agent, its subscriptions, pending one-shot query
    state) lives here rather than on the shared server.
    """

    def __init__(self, server: 'GUIServer', ws, name: str) -> None:
        self.server = server
        self.ws     = ws
        self.name   = name
        self.agent: Optional[UMMAgent] = None
        self.regs:  Dict[int, Dict]    = {}     # reg_id → registration info
        self.msg_count = 0
        # Transient one-shot query reg_ids — tracked so we can unregister before
        # re-registering (avoids router dedup silently ignoring the new reg_id).
        self._query_regs: Dict[str, int] = {}
        # Pending capability requests: msg_id → (target_mtype, Event, result[])
        self._cap_pending: Dict[Any, tuple] = {}
        self._list_agents_pending: Optional[tuple] = None
        self._list_types_pending:  Optional[tuple] = None

    @property
    def connected(self) -> bool:
        return self.agent is not None and self.agent._attached

    # ── response handlers (per-session) ───────────────────────────────────────
    def _on_capability_response(self, msg) -> None:
        import struct as _struct
        corr_msg_id = None
        json_str    = None
        if msg.tdata.value:
            try:
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == 16 and len(tlv.value) >= 12:
                        # MsgRef: router(4) agent(4) msg_id(4)
                        _, _, corr_msg_id = _struct.unpack_from('!III', tlv.value, 0)
                    elif tlv.type_id == TLV_STRING:
                        json_str = tlv.value.rstrip(b'\x00').decode('utf-8')
            except Exception as exc:
                logger.warning("_on_capability_response parse error: %s", exc)
        key = None if corr_msg_id is None else corr_msg_id
        pending = self._cap_pending.get(key)
        if pending is not None:
            _mtype, evt, result = pending
            result[0] = json_str
            evt.set()

    def _on_list_agents_response(self, msg) -> None:
        if self._list_agents_pending is None:
            return
        evt, result = self._list_agents_pending
        if msg.tdata.value:
            try:
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == TLV_STRING:
                        result[0] = tlv.value.rstrip(b'\x00').decode('utf-8')
                        break
            except Exception as exc:
                logger.warning("list_agents parse error: %s", exc)
        evt.set()

    def _on_list_types_response(self, msg) -> None:
        if self._list_types_pending is None:
            return
        evt, result = self._list_types_pending
        if msg.tdata.value:
            try:
                for tlv in decode_all(msg.tdata.value):
                    if tlv.type_id == TLV_STRING:
                        result[0] = tlv.value.rstrip(b'\x00').decode('utf-8')
                        break
            except Exception as exc:
                logger.warning("list_types parse error: %s", exc)
        evt.set()

    # ── message delivery callback ─────────────────────────────────────────────
    def make_message_callback(self) -> Any:
        """Return a UMM callback that delivers messages to *this* client's ws."""
        srv = self.server
        ws  = self.ws

        def _on_msg(msg) -> None:
            if ws not in srv._clients:
                return   # client already gone — drop silently
            self.msg_count += 1
            data = format_msg(msg)
            if srv._loop and srv._loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    srv._send_to(ws, {"type": "message", "data": data,
                                      "count": self.msg_count}),
                    srv._loop)

        return _on_msg

    # ── agent lifecycle ───────────────────────────────────────────────────────
    def connect_agent(self) -> bool:
        """Connect this session's own UMMAgent to the router (synchronous)."""
        srv = self.server
        if self.agent:
            try:
                self.agent.disconnect()
            except Exception:
                pass

        def _on_reconnect():
            """Tell this one client to re-register after its agent reconnects."""
            if srv._loop and srv._loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    srv._send_to(self.ws, {
                        "type":      "status",
                        "connected": True,
                        "router":    f"{srv.umm_host}:{srv.umm_port}",
                        "attach_id": str(self.agent.attach_id.id) if self.agent else "—",
                        "types":     registry.directory_entries(),
                        "registrations": [],
                        "msg_count": 0,
                    }),
                    srv._loop)

        self.agent = UMMAgent(
            host=srv.umm_host, port=srv.umm_port,
            process_name=self.name,
            agent_mtype=int(MType.GUI),
            reconnect=True,
            on_reconnect=_on_reconnect)
        ok = self.agent.connect()
        if ok:
            logger.info("Session %s attached as %d", self.name, self.agent.attach_id.id)
            self._register_capability()   # mixin handlers only — no deadlock risk
        return ok

    def _register_capability(self) -> None:
        """Register capability/version/debug/shutdown mixin handlers on this agent."""
        from umm.capability import make_capability, register_capability_handler
        from umm.mixins import DebugMixin, VersionMixin, ShutdownMixin

        cap = make_capability(
            what        = 'UMMGui',
            mtype       = int(MType.GUI),
            description = 'UMM GUI console server — WebSocket bridge and HTTP file server.',
            version     = '1.0.0',
            author      = 'Realtime Software Pty Ltd',
            subtypes    = [],
        )
        register_capability_handler(self.agent, cap)

        dbg = DebugMixin()
        dbg.register_debug_handler(self.agent, int(MType.GUI))

        ver = VersionMixin()
        ver.AGENT_VERSION = '1.0.0'
        ver.GROUP_VERSION = '1.0.0'
        ver.register_version_handler(self.agent, int(MType.GUI))

        sdn = ShutdownMixin()
        sdn.register_shutdown_handler(self.agent, int(MType.GUI))

    async def register_permanent_subs(self) -> None:
        """Register this session's capability/list/version response handlers.

        _async_register must run on the agent's own event loop (the agent's
        StreamWriter belongs to that loop), so each registration is scheduled
        there and awaited.
        """
        from umm.core.messages import UMMSubType as _ST

        agent_loop = self.agent._loop
        if not agent_loop or not agent_loop.is_running():
            logger.error("register_permanent_subs: agent loop not running")
            return

        def _reg_sync(mtype, subtype, callback, channel=1):
            fut = asyncio.run_coroutine_threadsafe(
                self.agent._async_register(
                    mtype, subtype, callback, None, 0, channel=channel),
                agent_loop)
            try:
                reg_id = fut.result(timeout=5.0)
                logger.info("Permanent sub registered: (%d,%d) ch=%d reg_id=%d",
                            mtype, subtype, channel, reg_id)
            except Exception as exc:
                logger.error("Failed permanent sub (%d,%d): %s", mtype, subtype, exc)

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: (
            _reg_sync(int(MType.UMM), int(_ST.CAPABILITY_RESPONSE),
                      self._on_capability_response, channel=4),
            _reg_sync(int(MType.UMM), int(_ST.LIST_AGENTS_RESPONSE),
                      self._on_list_agents_response),
            _reg_sync(int(MType.UMM), int(_ST.LIST_TYPES_RESPONSE),
                      self._on_list_types_response),
        ))

    def disconnect_agent(self) -> None:
        if self.agent:
            try:
                self.agent.disconnect()
            except Exception:
                pass
            self.agent = None


class GUIServer:
    def __init__(self, umm_host: str, umm_port: int, gui_port: int) -> None:
        self.umm_host  = umm_host
        self.umm_port  = umm_port
        self.gui_port  = gui_port
        # One ClientSession per connected WebSocket.
        self._clients: Dict[Any, ClientSession] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._session_counter = 0

    async def _send_to(self, ws, data: dict) -> None:
        """Send a JSON message to a single WebSocket, ignoring send errors."""
        try:
            await ws.send(json.dumps(data))
        except Exception:
            pass

    async def handle_ws(self, ws, path=None) -> None:
        # `path` is passed positionally by legacy websockets (<=10.x, Python 3.7)
        # and omitted by modern websockets (>=11); accept and ignore it so the
        # handler works on both.
        self._session_counter += 1
        session = ClientSession(self, ws, name=f"UMMGui#{self._session_counter}")
        self._clients[ws] = session

        # Each client connects its own agent to the router.
        ok = await asyncio.get_event_loop().run_in_executor(
            None, session.connect_agent)
        if ok:
            await session.register_permanent_subs()

        await ws.send(json.dumps({
            "type":          "status",
            "connected":     session.connected,
            "router":        f"{self.umm_host}:{self.umm_port}",
            "attach_id":     str(session.agent.attach_id.id) if session.connected else "—",
            "types":         registry.directory_entries(),
            "registrations": [],
            "msg_count":     0,
        }))
        try:
            async for raw in ws:
                try:
                    await self.handle_cmd(json.loads(raw), session)
                except Exception as exc:
                    logger.exception("Command error: %s", exc)
        except Exception:
            pass
        finally:
            self._clients.pop(ws, None)
            # Tearing down the agent unregisters every subscription this client
            # owned, at the router, in one step.
            session.disconnect_agent()
            logger.info("Session %s closed (%d subscription(s))",
                        session.name, len(session.regs))

    async def handle_cmd(self, cmd: dict, session: 'ClientSession') -> None:
        action = cmd.get("action")
        logger.info("handle_cmd[%s]: action=%s", session.name, action)
        ws    = session.ws
        agent = session.agent

        if action == "connect":
            host = cmd.get("host", self.umm_host)
            port = int(cmd.get("port", self.umm_port))
            self.umm_host = host
            self.umm_port = port
            ok = await asyncio.get_event_loop().run_in_executor(
                None, session.connect_agent)
            session.regs = {}
            session.msg_count = 0
            session._query_regs = {}
            session._cap_pending = {}
            session._list_agents_pending = None
            session._list_types_pending  = None
            if ok:
                await session.register_permanent_subs()
            await self._send_to(ws, {
                "type": "status", "connected": ok,
                "router": f"{host}:{port}",
                "attach_id": str(session.agent.attach_id.id) if ok else "—",
                "types": registry.directory_entries(),
                "registrations": [], "msg_count": 0,
            })

        elif action == "disconnect":
            session.disconnect_agent()
            session.regs = {}
            session.msg_count = 0
            await self._send_to(ws, {
                "type": "status",
                "router": f"{self.umm_host}:{self.umm_port}",
                "attach_id": "—", "types": [], "registrations": [], "msg_count": 0,
            })

        elif action == "send":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            mtype    = int(cmd["mtype"])
            subtype  = int(cmd["subtype"])
            channel  = int(cmd.get("channel", -1))   # -1 → agent default (app bus)
            flags    = int(cmd.get("flags", 0))      # MsgFlag bits, e.g. 2 = CONFIRM_RTR
            tlvs_enc = build_tlvs(cmd.get("tlvs", []))
            tlv_list = None
            if tlvs_enc:
                try:
                    tlv_list = list(decode_all(tlvs_enc))
                except Exception:
                    pass
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: agent.send(mtype=mtype, subtype=subtype, tlvs=tlv_list,
                                         flags=flags, channel=channel))
            await ws.send(json.dumps({"type":"sent","mtype":mtype,"subtype":subtype}))

        elif action == "register":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            mtype       = int(cmd["mtype"])
            subtype     = int(cmd["subtype"])
            channel     = int(cmd.get("channel", 0))  # 0 = ALL channels wildcard
            match_specs = cmd.get("match_tlvs", [])
            match_enc   = build_tlvs(match_specs)
            match_list  = None
            if match_enc:
                try:
                    match_list = list(decode_all(match_enc))
                except Exception:
                    pass
            desc = cmd.get("desc", f"{mtype},{subtype}")
            dont_send_self = bool(cmd.get('dont_send_self', True))

            reg_id = await asyncio.get_event_loop().run_in_executor(
                None, lambda: agent.register(
                    mtype=mtype, subtype=subtype,
                    callback=session.make_message_callback(),
                    match_tlvs=match_list,
                    channel=channel,
                    dont_send_self=dont_send_self,
                ))
            session.regs[reg_id] = {
                "reg_id":reg_id,"mtype":mtype,"subtype":subtype,
                "channel":channel,
                "desc":desc,"match_tlvs":match_specs,
            }
            await ws.send(json.dumps({
                "type":"registered","reg_id":reg_id,
                "registration":session.regs[reg_id],
            }))

        elif action == "unregister":
            reg_id = int(cmd["reg_id"])
            if reg_id not in session.regs:
                await ws.send(json.dumps({"type":"error","msg":"Cannot unregister: not owned by this client"}))
                return
            if agent:
                agent.unregister(reg_id)
            session.regs.pop(reg_id, None)
            await ws.send(json.dumps({"type":"unregistered","reg_id":reg_id}))

        elif action == "timer":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            import math as _math

            def _f(v, d):
                try: r=float(v); return r if _math.isfinite(r) else d
                except: return d
            def _i(v, d):
                try: return int(v)
                except: return d

            interval       = _f(cmd.get("interval"),      5.0)
            count          = _i(cmd.get("count"),          0)
            delay          = _f(cmd.get("delay"),          0.0)
            target_mtype   = _i(cmd.get("target_mtype"),  100)
            target_subtype = _i(cmd.get("target_subtype"), 1)
            timer_mtype    = _i(cmd.get("timer_mtype"),   int(MType.TIMER))
            if interval <= 0: interval = 5.0
            if count < 0: count = 0

            def _send_timer():
                import struct as _s
                from umm.core.tlv import TLV, TLVBuffer, TLV_INT, TLV_MSG
                tlvs_enc = build_tlvs(cmd.get("tlvs", []))
                inner = _s.pack('!iiHH', target_mtype, target_subtype, 1, 0) + tlvs_enc
                buf = TLVBuffer()
                buf.add(TLV(type_id=9,     value=_s.pack('!IHhhxx', int(interval), int((interval%1)*1000), 0, 0)))
                buf.add(TLV(type_id=TLV_INT, value=_s.pack('!i', count)))
                if delay > 0:
                    buf.add(TLV(type_id=9, value=_s.pack('!IHhhxx', int(delay), int((delay%1)*1000), 0, 0)))
                buf.add(TLV(type_id=TLV_MSG, value=inner))
                from umm.core.tlv import decode_all as _da
                tlvs = list(_da(buf.encode()))
                agent.send(mtype=timer_mtype, subtype=101, tlvs=tlvs)

            await asyncio.get_event_loop().run_in_executor(None, _send_timer)
            await ws.send(json.dumps({"type":"sent","mtype":timer_mtype,"subtype":101,
                "msg":f"Timer: every {interval}s → {target_mtype},{target_subtype}"}))

        elif action == "list_agents":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return

            import threading as _threading
            from umm.core.messages import UMMSubType as _ST
            from umm.core.tlv import TLV_JSON as _TLV_JSON

            MT_SUPERVISOR            = 12
            ST_AGENT_STATUS          = 104
            ST_AGENT_STATUS_RESPONSE = 105

            got_agents    = _threading.Event()
            got_sup       = _threading.Event()
            result_agents = [None]
            result_sup    = [None]

            session._list_agents_pending = (got_agents, result_agents)

            _sup_reg_id = [None]
            def _on_sup_status(msg):
                try:
                    for tlv in decode_all(msg.tdata.value):
                        if tlv.type_id == _TLV_JSON:
                            result_sup[0] = tlv.value.rstrip(b'\x00').decode()
                            break
                except Exception:
                    pass
                finally:
                    if _sup_reg_id[0] is not None:
                        try: agent.unregister(_sup_reg_id[0])
                        except Exception: pass
                    got_sup.set()

            try:
                _sup_reg_id[0] = agent.register(
                    MT_SUPERVISOR, ST_AGENT_STATUS_RESPONSE, _on_sup_status)
                agent.send(mtype=MT_SUPERVISOR, subtype=ST_AGENT_STATUS, tlvs=[])
            except Exception:
                got_sup.set()   # don't block if supervisor isn't running

            agent.send(mtype=MType.UMM, subtype=_ST.LIST_AGENTS)

            def wait_and_reply():
                triggered = got_agents.wait(timeout=3.0)
                session._list_agents_pending = None
                if not triggered:
                    logger.warning("list_agents: timed out waiting for response")
                got_sup.wait(timeout=2.0)
                fut = asyncio.run_coroutine_threadsafe(
                    ws.send(json.dumps({
                        "type": "list_agents_response",
                        "data": result_agents[0],
                        "supervisor": result_sup[0],
                    })),
                    self._loop,
                )
                try:
                    fut.result(timeout=5.0)
                except Exception as exc:
                    logger.warning("list_agents ws.send failed: %s", exc)
            _threading.Thread(target=wait_and_reply, daemon=True).start()

        elif action == "list_types":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return

            import threading as _threading
            from umm.core.messages import UMMSubType as _ST

            got    = _threading.Event()
            result = [None]
            session._list_types_pending = (got, result)

            agent.send(mtype=MType.UMM, subtype=_ST.LIST_TYPES)

            def wait_and_reply():
                triggered = got.wait(timeout=3.0)
                session._list_types_pending = None
                if not triggered:
                    logger.warning("list_types: timed out waiting for response")
                fut = asyncio.run_coroutine_threadsafe(
                    ws.send(json.dumps({
                        "type": "list_types_response",
                        "data": result[0],
                    })),
                    self._loop,
                )
                try:
                    fut.result(timeout=5.0)
                except Exception as exc:
                    logger.warning("list_types ws.send failed: %s", exc)
            _threading.Thread(target=wait_and_reply, daemon=True).start()

        elif action == "get_capability":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            target_mtype = int(cmd.get("mtype", 0))
            if target_mtype <= 0:
                await ws.send(json.dumps({"type":"error","msg":"Invalid mtype"}))
                return

            import threading as _threading
            from umm.capability import ST_CAPABILITY_QUERY
            from umm.core.registry import registry as _reg

            got    = _threading.Event()
            result = [None]

            int_type = _reg.get_by_id(2)
            query_msg_id = agent._next_msg_id()
            key = None if target_mtype == int(MType.UMM) else query_msg_id

            session._cap_pending[key] = (target_mtype, got, result)

            query_tlvs = [int_type.make_tlv(target_mtype)] if int_type else []
            await agent._async_send(
                int(MType.UMM), ST_CAPABILITY_QUERY, query_tlvs, 0,
                msg_id=query_msg_id, channel=1)

            def wait_and_reply():
                triggered = got.wait(timeout=3.0)
                session._cap_pending.pop(key, None)
                payload = json.dumps({
                    "type": "capability_response",
                    "mtype": target_mtype,
                    "data": result[0],
                })
                logger.info("capability: triggered=%s result=%s",
                            triggered, result[0] is not None)
                try:
                    fut = asyncio.run_coroutine_threadsafe(
                        ws.send(payload), self._loop)
                    fut.result(timeout=5.0)
                except Exception as exc:
                    logger.warning("capability ws.send failed: %s", exc)
            _threading.Thread(target=wait_and_reply, daemon=True).start()

        elif action == "get_version":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            target_mtype = int(cmd.get("mtype", int(MType.UMM)))

            import threading as _threading
            from umm.core.messages import UMMSubType as _UMMSubType

            got    = _threading.Event()
            result = [None]

            def on_version(msg):
                from umm.core.tlv import decode_all, TLV_INT, TLV_STRING
                tlvs = list(decode_all(msg.tdata.value))
                resp_mtype = None
                version_json = None
                for tlv in tlvs:
                    if tlv.type_id == TLV_INT and resp_mtype is None:
                        import struct as _st
                        resp_mtype = _st.unpack('!i', tlv.value)[0]
                    elif tlv.type_id == TLV_STRING and version_json is None:
                        version_json = tlv.value.rstrip(b'\x00').decode('utf-8', errors='replace')
                if resp_mtype == target_mtype:
                    result[0] = version_json
                    got.set()

            stale = session._query_regs.pop('get_version', None)
            if stale and agent:
                try:
                    await asyncio.get_event_loop().run_in_executor(
                        None, lambda: agent.unregister(stale))
                except Exception:
                    pass

            ver_reg_id = await asyncio.get_event_loop().run_in_executor(
                None, lambda: agent.register(
                    mtype=int(MType.UMM), subtype=int(_UMMSubType.VERSION_RESPONSE),
                    callback=on_version, match_tlvs=[], flags=0,
                    channel=int(Channel.APP)))
            session._query_regs['get_version'] = ver_reg_id

            await asyncio.get_event_loop().run_in_executor(
                None, lambda: agent.send(
                    mtype=int(MType.UMM), subtype=int(_UMMSubType.VERSION_REQUEST),
                    tlvs=[], flags=0, channel=int(Channel.APP)))

            def wait_and_reply():
                triggered = got.wait(timeout=3.0)
                session._query_regs.pop('get_version', None)
                try:
                    agent.unregister(ver_reg_id)
                except Exception:
                    pass
                payload = json.dumps({
                    "type":    "version_result",
                    "mtype":   target_mtype,
                    "version": result[0] if triggered else None,
                    "timeout": not triggered,
                })
                try:
                    fut = asyncio.run_coroutine_threadsafe(ws.send(payload), self._loop)
                    fut.result(timeout=5.0)
                except Exception as exc:
                    logger.warning("version ws.send failed: %s", exc)
            _threading.Thread(target=wait_and_reply, daemon=True).start()

        elif action == "system_shutdown":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            from umm.core.messages import UMMSubType as _UMMSubType
            from umm.core.tlv import TLV as _TLV, TLV_INT, TLV_STRING
            import struct as _struct
            delay   = max(0, int(cmd.get("delay", 0)))
            message = str(cmd.get("message", "")).strip()
            tlvs = [_TLV(type_id=TLV_INT, value=_struct.pack('!i', delay))]
            if message:
                tlvs.append(_TLV(type_id=TLV_STRING,
                                 value=message.encode('utf-8') + b'\x00'))
            await agent._async_send(
                int(MType.UMM), int(_UMMSubType.SYSTEM_SHUTDOWN),
                tlvs, 0, channel=int(Channel.APP))

        elif action == "subscribe_debug":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            source_mtype = int(cmd.get("source_mtype", 0))  # 0 = all agents

            from umm.core.registry import registry as _reg
            from umm.types._base import MatchOp as _MatchOp

            int_type = _reg.get_by_id(2)

            match_tlvs = None
            if source_mtype > 0 and int_type:
                match_tlvs = [int_type.make_subscription_tlv(source_mtype, _MatchOp.EQ)]

            reg_id = await asyncio.get_event_loop().run_in_executor(
                None, lambda: agent.register(
                    mtype=int(MType.UMM), subtype=1,
                    callback=session.make_message_callback(),
                    match_tlvs=match_tlvs, flags=0,
                    channel=int(Channel.DEBUG)))
            session.regs[reg_id] = {
                "reg_id": reg_id, "mtype": int(MType.UMM), "subtype": 1,
                "channel": int(Channel.DEBUG),
                "desc": f"Debug ch3({'mtype='+str(source_mtype) if source_mtype else 'all'})",
                "match_tlvs": [],
            }
            await ws.send(json.dumps({"type":"registered","reg_id":reg_id,
                                       "registration":session.regs[reg_id]}))
            await ws.send(json.dumps({"type":"debug_subscribed",
                                      "reg_id":reg_id,
                                      "source_mtype":source_mtype}))

        elif action == "set_debug":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            target_mtype = int(cmd.get("mtype", 0))
            enable       = bool(cmd.get("enable", True))
            if target_mtype <= 0:
                await ws.send(json.dumps({"type":"error","msg":"Invalid mtype"}))
                return
            from umm.core.registry import registry as _reg
            from umm.core.messages import ReservedSubType as _RST
            bool_type = _reg.get_by_id(7)
            if bool_type is None:
                logger.error("set_debug: Bool type not in registry")
                await ws.send(json.dumps({"type":"error","msg":"Bool type not registered"}))
                return
            tlv = bool_type.make_tlv(enable)
            subtype_val = int(_RST.SET_DEBUG)
            logger.info("set_debug: sending mtype=%d subtype=%d enable=%s",
                        target_mtype, subtype_val, enable)
            def _do_send():
                try:
                    agent.send(mtype=target_mtype, subtype=subtype_val, tlvs=[tlv])
                    logger.info("set_debug: sent OK")
                except Exception as exc:
                    logger.error("set_debug: send failed: %s", exc)
            await asyncio.get_event_loop().run_in_executor(None, _do_send)
            await ws.send(json.dumps({"type":"debug_set","mtype":target_mtype,"enable":enable}))

        elif action == "set_log_level":
            if not session.connected:
                await ws.send(json.dumps({"type":"error","msg":"Not connected"}))
                return
            target_mtype = int(cmd.get("mtype", 0))
            level        = int(cmd.get("level", 2))   # 0=DEBUG 1=INFO 2=WARN 3=ERROR
            if target_mtype <= 0:
                await ws.send(json.dumps({"type":"error","msg":"Invalid mtype"}))
                return
            level = max(0, min(3, level))
            from umm.core.registry import registry as _reg
            from umm.core.messages import ReservedSubType as _RST
            int_type = _reg.get_by_id(2)
            if int_type is None:
                await ws.send(json.dumps({"type":"error","msg":"Int type not registered"}))
                return
            tlv = int_type.make_tlv(level)
            subtype_val = int(_RST.SET_LOG_LEVEL)
            logger.info("set_log_level: mtype=%d subtype=%d level=%d",
                        target_mtype, subtype_val, level)
            def _do_send_level():
                try:
                    agent.send(mtype=target_mtype, subtype=subtype_val, tlvs=[tlv])
                except Exception as exc:
                    logger.error("set_log_level: send failed: %s", exc)
            await asyncio.get_event_loop().run_in_executor(None, _do_send_level)
            await ws.send(json.dumps({"type":"log_level_set","mtype":target_mtype,"level":level}))

        elif action == "clear_log":
            session.msg_count = 0
            await self._send_to(ws, {"type": "cleared"})

    async def serve(self) -> None:
        self._loop = asyncio.get_event_loop()

        html_path        = Path(__file__).parent / 'gui.html'
        fb_path          = Path(__file__).parent / 'feed_browser.html'
        conv_path        = Path(__file__).parent / 'conveyor.html'
        tank_path        = Path(__file__).parent / 'tank_gui.html'
        chess_path       = Path(__file__).parent / 'chess.html'
        cap_viewer_path  = Path(__file__).parent / 'capability_viewer.html'
        from umm.capability import BUILTIN_CAPABILITIES

        # ── websockets API compatibility ──────────────────────────────────────
        # The HTTP-serving hook differs across websockets versions, and crucially
        # the *reply type* must match the calling convention used for THIS call:
        #   • legacy server (websockets.legacy — what websockets.serve uses up to
        #     v13, and the only line that supports Python 3.7, e.g. a Pi running
        #     websockets 11.x) calls  process_request(path, request_headers):
        #     request_headers IS a Headers object, and the reply is an
        #     (HTTPStatus, headers, body) tuple, unpacked via AbortHandshake(*reply).
        #   • new asyncio server (websockets.serve in v14+, e.g. the dev Mac) calls
        #     process_request(connection, request): use request.path / .headers,
        #     and the reply is a websockets.http11.Response.
        # Note: websockets.http11.Response EXISTS in v11/12 too, so we must NOT
        # decide the reply type from imports — only from how this call was made.
        from http import HTTPStatus as _HTTPStatus

        async def process_request(*args):
            """Serve plain HTTP GETs; return None to let a WebSocket upgrade proceed."""
            # Modern call passes a Request object (has .path and .headers);
            # legacy call passes (path_str, Headers).
            req = args[1] if len(args) >= 2 else None
            modern = req is not None and hasattr(req, 'headers') and hasattr(req, 'path')
            if modern:
                headers  = req.headers
                raw_path = req.path
            else:
                raw_path = args[0]
                headers  = args[1]

            if (headers.get('Upgrade', '') or '').lower() == 'websocket':
                return None

            path = raw_path.split('?')[0]

            def respond(content: bytes, status: int = 200,
                        content_type: str = 'text/html; charset=utf-8'):
                hdrs = [
                    ('Content-Type',   content_type),
                    ('Content-Length', str(len(content))),
                    ('Cache-Control',  'no-store, no-cache, must-revalidate'),
                ]
                if modern:
                    from websockets.http11 import Response
                    from websockets.datastructures import Headers
                    return Response(status, _HTTPStatus(status).phrase,
                                    Headers(hdrs), content)
                return (_HTTPStatus(status), hdrs, content)   # legacy tuple form

            def html_response(content: bytes, status: int = 200):
                return respond(content, status, 'text/html; charset=utf-8')

            def json_response(content: bytes):
                return respond(content, 200, 'application/json')

            if path in ('/', '/index.html', '/gui.html'):
                if html_path.exists():
                    return html_response(html_path.read_bytes())
                return html_response(b'<h1>gui.html not found</h1>', 404)

            elif path in ('/feed', '/feed_browser.html', '/feeds'):
                if fb_path.exists():
                    return html_response(fb_path.read_bytes())
                return html_response(b'<h1>feed_browser.html not found</h1>', 404)

            elif path in ('/conveyor.html', '/conveyor'):
                if conv_path.exists():
                    return html_response(conv_path.read_bytes())
                return html_response(b'<h1>conveyor.html not found</h1>', 404)

            elif path in ('/tank_gui.html', '/tank'):
                if tank_path.exists():
                    return html_response(tank_path.read_bytes())
                return html_response(b'<h1>tank_gui.html not found</h1>', 404)

            elif path in ('/chess.html', '/chess'):
                if chess_path.exists():
                    return html_response(chess_path.read_bytes())
                return html_response(b'<h1>chess.html not found</h1>', 404)

            elif path in ('/capabilities', '/capability_viewer.html'):
                if cap_viewer_path.exists():
                    return html_response(cap_viewer_path.read_bytes())
                return html_response(b'<h1>capability_viewer.html not found</h1>', 404)

            elif path.startswith('/capability/'):
                try:
                    mtype = int(path.split('/')[-1])
                    cap   = BUILTIN_CAPABILITIES.get(mtype)
                    if cap:
                        body = cap.to_json().encode()
                        return json_response(body)
                except (ValueError, AttributeError):
                    pass
                return html_response(b'<h1>Not found</h1>', 404)

            # Generic fallback: serve any other *.html that exists in the GUI
            # directory, so a new GUI page works without needing its own route.
            # Any non-WebSocket GET that matches nothing gets a clean 404 — it
            # must NOT fall through to the WebSocket handler, which rejects a
            # plain browser GET with the confusing "invalid Connection header:
            # keep-alive" error.
            gui_dir = Path(__file__).parent.resolve()
            if path.endswith('.html'):
                candidate = (gui_dir / path.lstrip('/')).resolve()
                if candidate.parent == gui_dir and candidate.exists():
                    return html_response(candidate.read_bytes())
            return html_response(b'<h1>404 Not Found</h1>', 404)

        print(f"\nUMM GUI ready  ->  http://localhost:{self.gui_port}"
              f"   (websockets {getattr(websockets, '__version__', '?')})")
        print(f"UMM Router     ->  {self.umm_host}:{self.umm_port}")
        print("Each browser tab connects as its own UMM agent.\n")

        async with websockets.serve(self.handle_ws, "", self.gui_port,
                                    process_request=process_request,
                                    reuse_address=True):
            await asyncio.Future()


def main() -> None:
    import argparse
    logging.basicConfig(level=logging.WARNING,
                        format='%(levelname)s %(name)s: %(message)s')
    p = argparse.ArgumentParser(description='UMM GUI Server')
    p.add_argument('--router',   default='localhost', dest='umm_host')
    p.add_argument('--port',     type=int, default=DEFAULT_PORT, dest='umm_port')
    p.add_argument('--version', action='store_true',
                   help='Show version and exit')
    p.add_argument('--gui-port', type=int, default=8765)
    p.add_argument('--names',    default=None,
                   help='Extra names file to load (in addition to umm_names.conf)')
    p.add_argument('--project',  default=None, action='append', metavar='FILE',
                   help='Consolidated project file: [names] and [meta] apply '
                        'to the GUI message display (project.conf at the '
                        'project root is always loaded first; last file wins). '
                        'e.g. --project examples/chess/chess.conf')
    p.add_argument('--debug',    action='store_true')
    args = p.parse_args()
    if args.version:
        print(UMM_VERSION_STR)
        return
    if args.names:
        _names.load_file(args.names)
    if args.project:
        from umm.project import load_project
        for pf in args.project:
            _, _, warns = load_project(pf, names=_names)
            for w in warns:
                logger.warning('project %s: %s', pf, w)
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    server = GUIServer(args.umm_host, args.umm_port, args.gui_port)
    try:
        asyncio.run(server.serve())
    except KeyboardInterrupt:
        print("\nGUI server stopped.")


if __name__ == '__main__':
    main()
