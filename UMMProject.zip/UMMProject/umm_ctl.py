#!/usr/bin/env python3
"""
umm_ctl.py — UMM Service Manager
==================================
Reads a configuration file and manages UMM agent processes.

Usage::
    runumm [--config umm.conf] <command> [target]

Commands::
    start [target]      Start all auto agents, a named group, or a named agent
    stop  [target]      Stop all, a group, or a named agent
    restart [target]    Stop then start
    status [target]     Show process status
    validate            Check config for errors and type conflicts
    show                Display parsed configuration

Target::
    (none)              All non-manual agents
    core                All agents in 'core' group
    sorting             All agents in 'sorting' group (the sorting demo)
    router              Named agent
    all                 All agents including manual

Examples::
    runumm start              # start core agents
    runumm start sorting      # start sorting demo group
    runumm stop  sorting
    runumm start ConveyorTimer
    runumm status
    runumm validate

Config file format (INI-style)::

    [settings]
    router  = localhost
    port    = 5100

    [agent.router]
    module   = umm.router      # python module to run with -m
    group    = core            # group membership (space-separated for multiple)
    after    = -               # dependency: -, manual, or agent-name
    required = true            # abort startup if this fails
    singleton = true           # only one instance allowed
    restart  = always          # always / on-failure / never
    restart_delay = 3          # seconds before restart attempt
    type     = 1050            # agent primary mtype (--type argument)
    name     = ConveyorTimer   # process name (--name argument)
    options  = --debug         # extra CLI options
    binary   = false           # true → module is an executable path, not a python -m module

    # Example binary agent (compiled C router or custom agent):
    [agent.c-router]
    module   = build/umm_router_bin   # path to executable (relative to umm.conf dir)
    binary   = true
    router   = true                   # pass --port/--id/--host instead of --router/--port
    group    = core
    after    = -
    restart  = always

    after values:
        -           no dependency, start immediately
        manual      never auto-start, must be named explicitly
        <name>      start after agent <name> is running
"""

from __future__ import annotations

import argparse
import configparser
import json
import os
import re
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

# On Windows, stdout defaults to the console code page which cannot represent
# the Unicode characters used in status and log output.
if sys.platform == 'win32' and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass


# ── colours ───────────────────────────────────────────────────────────────────
# Enable ANSI escape codes on Windows (no-op on macOS/Linux).
# os.system('') triggers the Windows console to enter VT processing mode.
if sys.platform == 'win32':
    os.system('')

RED    = '\033[0;31m'
GREEN  = '\033[0;32m'
YELLOW = '\033[0;33m'
CYAN   = '\033[0;36m'
BOLD   = '\033[1m'
RESET  = '\033[0m'

# ── cross-platform process utilities ─────────────────────────────────────────
# Windows does not support os.kill(pid, 0) for existence checks, has no
# SIGKILL, and pgrep/ps are unavailable. These helpers work on both platforms.

def _proc_is_running(pid: int) -> bool:
    """Return True if a process with this PID exists and is running."""
    if sys.platform == 'win32':
        import ctypes
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        SYNCHRONIZE                       = 0x00100000
        WAIT_OBJECT_0                     = 0x00000000
        WAIT_TIMEOUT                      = 0x00000102
        handle = ctypes.windll.kernel32.OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, pid)
        if not handle:
            return False
        try:
            # WaitForSingleObject with timeout=0: returns WAIT_OBJECT_0 if the
            # process has exited (handle is signaled), WAIT_TIMEOUT if still running.
            # This is more reliable than GetExitCodeProcess because exit code 259
            # (STILL_ACTIVE) is also a valid application exit code.
            result = ctypes.windll.kernel32.WaitForSingleObject(handle, 0)
            return result == WAIT_TIMEOUT   # WAIT_TIMEOUT means still running
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    else:
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, OSError):
            return False

def _proc_terminate(pid: int) -> None:
    """Send SIGTERM (Unix) or TerminateProcess (Windows)."""
    if sys.platform == 'win32':
        import ctypes
        PROCESS_TERMINATE = 0x0001
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
        if handle:
            ctypes.windll.kernel32.TerminateProcess(handle, 1)
            ctypes.windll.kernel32.CloseHandle(handle)
    else:
        os.kill(pid, signal.SIGTERM)

def _proc_kill(pid: int) -> None:
    """Force-kill (SIGKILL on Unix; TerminateProcess is already forceful on Windows)."""
    if sys.platform == 'win32':
        _proc_terminate(pid)
    else:
        os.kill(pid, signal.SIGKILL)

def _get_ppid(pid: int) -> int:
    """Return the parent PID of the given process, or 0 on failure."""
    try:
        if sys.platform == 'win32':
            import subprocess
            # Try wmic first (available on Windows 10 and earlier)
            r = subprocess.run(
                ['wmic', 'process', 'where', f'ProcessId={pid}',
                 'get', 'ParentProcessId', '/value'],
                capture_output=True, text=True)
            for line in r.stdout.splitlines():
                if line.startswith('ParentProcessId='):
                    val = line.split('=')[1].strip()
                    if val.isdigit():
                        return int(val)
            # Fallback: PowerShell (available everywhere on Windows 11+)
            r = subprocess.run(
                ['powershell', '-NoProfile', '-Command',
                 f'(Get-Process -Id {pid}).Parent.Id'],
                capture_output=True, text=True)
            val = r.stdout.strip()
            if val.isdigit():
                return int(val)
            return 0
        else:
            import subprocess
            r = subprocess.run(['ps', '-p', str(pid), '-o', 'ppid='],
                               capture_output=True, text=True)
            return int(r.stdout.strip()) if r.stdout.strip() else 0
    except Exception:
        return 0

def _is_launcher_process(pid: int) -> bool:
    """Return True if the process looks like a umm_ctl launcher wrapper."""
    try:
        if sys.platform == 'win32':
            import subprocess
            cmd = ''
            # Try wmic first
            r = subprocess.run(
                ['wmic', 'process', 'where', f'ProcessId={pid}',
                 'get', 'CommandLine', '/value'],
                capture_output=True, text=True)
            for line in r.stdout.splitlines():
                if line.startswith('CommandLine='):
                    cmd = line.split('=', 1)[1]
                    break
            if not cmd:
                # Fallback: PowerShell
                r = subprocess.run(
                    ['powershell', '-NoProfile', '-Command',
                     f'(Get-Process -Id {pid}).CommandLine'],
                    capture_output=True, text=True)
                cmd = r.stdout
        else:
            import subprocess
            r = subprocess.run(['ps', '-p', str(pid), '-o', 'command='],
                               capture_output=True, text=True)
            cmd = r.stdout
        return 'import subprocess, sys, os' in cmd and 'pid_file' in cmd
    except Exception:
        return False

# ── output helpers ────────────────────────────────────────────────────────────

def ok(msg):    print(f"{GREEN}[OK]  {RESET} {msg}")
def err(msg):   print(f"{RED}[ERR] {RESET} {msg}")
def warn(msg):  print(f"{YELLOW}[WARN]{RESET} {msg}")
def info(msg):  print(f"{CYAN}[UMM] {RESET} {msg}")
def head(msg):  print(f"\n{BOLD}{msg}{RESET}")


# ── mtype range table (for validation) ───────────────────────────────────────

MTYPE_RANGES = [
    (1,   1,   "UMM router control",    False),  # reserved
    (2,   2,   "Timer",                 True),   # standard, ok for single instance
    (3,   3,   "Command",               True),
    (4,   4,   "Metadata",              True),
    (5,   5,   "FSM",                   True),
    (6,   7,   "File transfer",         True),
    (8,   8,   "Database",              True),
    (9,   9,   "Microbilling",          True),
    (10,  10,  "Type directory",        True),
    (11,  11,  "Bridge",                True),
    (12,  99,  "Reserved",              False),
    (100, 199, "Sensor family",         True),
    (200, 299, "Actuator family",       True),
    (300, 399, "Alarm family",          True),
    (400, 499, "Process control",       True),
    (500, 999, "Reserved",              False),
]

def mtype_info(mtype: int):
    for lo, hi, desc, ok_for_app in MTYPE_RANGES:
        if lo <= mtype <= hi:
            return desc, ok_for_app
    if mtype >= 1000:
        return "Application range", True
    return "Unknown", True


# ── agent definition ──────────────────────────────────────────────────────────

@dataclass
class AgentDef:
    """Definition of one agent from the config file."""
    name:          str           # config key e.g. "conveyor-timer"
    module:        str           # python module e.g. "umm.modules.timer"
    display_name:  str           # --name argument e.g. "ConveyorTimer"
    groups:        List[str]     # group memberships
    after:         str           # dependency: '-', 'manual', or agent name
    required:      bool          # abort startup if fails
    singleton:     bool          # only one instance
    restart:       str           # always / on-failure / never
    restart_delay: float         # seconds before restart
    agent_type:    Optional[int] # --type mtype argument
    options:       List[str]     # extra CLI arguments
    foreground:    bool          = False  # run in terminal, not background
    binary:        bool          = False  # True → run as a compiled binary, not python3 -m
    is_router:     bool          = False  # True → this agent IS the router (gets --port/--id/--host instead of --router/--port)
    bridge_env:    dict          = field(default_factory=dict)  # parsed UMM_BRIDGE_* env
    # Runtime state
    pid:           Optional[int] = None
    pid_file:      Optional[Path] = None

    @property
    def is_manual(self) -> bool:
        return self.after == 'manual'

    @property
    def dependency(self) -> Optional[str]:
        """Agent name this depends on, or None."""
        if self.after in ('-', 'manual', ''):
            return None
        return self.after

    def status(self) -> str:
        """Return 'running', 'stopped', or 'unknown'."""
        if self.pid_file and self.pid_file.exists():
            try:
                pid = int(self.pid_file.read_text().strip())
                if _proc_is_running(pid):
                    self.pid = pid
                    return 'running'
                else:
                    self.pid_file.unlink() if self.pid_file.exists() else None
            except ValueError:
                self.pid_file.unlink() if self.pid_file.exists() else None


@dataclass
class StartupMessage:
    """One line to execute when a group finishes starting.
    Uses the same syntax as the Send tool's interactive mode."""
    raw_line: str


@dataclass
class GroupDef:
    """Per-group configuration, from [group.<name>] sections."""
    name:             str
    startup_messages: List[StartupMessage] = field(default_factory=list)
    startup_delay:    float = 0.5   # seconds to wait after agents start before sending


# ── config parser ─────────────────────────────────────────────────────────────

@dataclass
class Config:
    """Parsed configuration."""
    router:        str           = 'localhost'   # address clients use to connect
    bind:          str           = ''            # address router binds to (from config only)
    port:          int           = 5100
    router_id:     str           = '1.1'      # site.node format
    log_dir:       Path          = Path('logs')
    gui_port:      int           = 8765
    python:        str           = 'python3'
    router_b:      str           = ''         # remote router for bridge (empty = not configured)
    port_b:        int           = 5300
    agents:        Dict[str, AgentDef] = field(default_factory=dict)
    groups:        Dict[str, GroupDef] = field(default_factory=dict)
    pid_dir:       Path          = Path('.pids')
    log_file:      Optional[Path] = None

    def get_group(self, group: str) -> List[AgentDef]:
        """Return agents in a group, in dependency order."""
        members = [a for a in self.agents.values()
                   if group in a.groups]
        return self._order(members)

    def get_auto(self) -> List[AgentDef]:
        """Return non-manual agents in dependency order."""
        auto = [a for a in self.agents.values() if not a.is_manual]
        return self._order(auto)

    def _order(self, agents: List[AgentDef]) -> List[AgentDef]:
        """Topological sort by 'after' dependencies."""
        result = []
        remaining = list(agents)
        started: Set[str] = set()
        max_iter = len(remaining) + 1
        i = 0
        while remaining and i < max_iter:
            i += 1
            for agent in list(remaining):
                dep = agent.dependency
                if dep is None or dep in started:
                    result.append(agent)
                    started.add(agent.name)
                    remaining.remove(agent)
        # Append any with unresolved deps at the end
        result.extend(remaining)
        return result

    def validate(self) -> List[str]:
        """Return list of error/warning strings. Empty = valid."""
        issues = []

        # Check dependencies exist
        for agent in self.agents.values():
            dep = agent.dependency
            if dep and dep not in self.agents:
                issues.append(
                    f"ERROR  [{agent.name}] after={dep!r} — "
                    f"no such agent in config")

        # Check mtype conflicts
        mtype_owners: Dict[int, str] = {}
        for agent in self.agents.values():
            if agent.agent_type is not None:
                mt = agent.agent_type
                desc, ok_range = mtype_info(mt)
                if not ok_range:
                    issues.append(
                        f"WARN   [{agent.name}] type={mt} is in "
                        f"reserved range '{desc}'")
                if mt in mtype_owners:
                    issues.append(
                        f"ERROR  [{agent.name}] type={mt} conflicts with "
                        f"[{mtype_owners[mt]}] — both claim mtype {mt}")
                else:
                    mtype_owners[mt] = agent.name

        # Warn about standard range mtypes used for named instances
        for agent in self.agents.values():
            if agent.agent_type is not None:
                mt = agent.agent_type
                desc, _ = mtype_info(mt)
                if 2 <= mt <= 99 and agent.display_name:
                    issues.append(
                        f"WARN   [{agent.name}] type={mt} ({desc}) is a "
                        f"standard range — consider using 1000+ for named instances")

        # Check binary agents: executable must exist and be executable
        import os as _os
        for agent in self.agents.values():
            if not agent.binary:
                continue
            exe = Path(agent.module)
            if not exe.is_absolute():
                exe = Path(__file__).parent / exe
            if not exe.exists():
                issues.append(
                    f"ERROR  [{agent.name}] binary={agent.module!r} — "
                    f"file not found (resolved: {exe})")
            elif not _os.access(exe, _os.X_OK):
                issues.append(
                    f"WARN   [{agent.name}] binary={agent.module!r} — "
                    f"file exists but is not executable (chmod +x {exe})")

        return issues


def _primary_ip() -> Optional[str]:
    """Return the primary non-loopback IP address of this machine."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def _auto_router_id() -> str:
    """
    Derive router_id from the primary IP address.
    192.168.0.31 → '0.31'  (last two octets as site.node)
    Falls back to '1.1' if IP cannot be determined.
    """
    ip = _primary_ip()
    if ip:
        parts = ip.split('.')
        if len(parts) == 4:
            return f"{parts[2]}.{parts[3]}"
    return '1.1'


def _auto_bind() -> str:
    """Return the primary IP for binding, or '' (all interfaces) if not determinable."""
    return _primary_ip() or ''


def parse_config(path: Path) -> Config:
    """Parse a umm.conf file and return a Config object."""
    cfg_parser = configparser.ConfigParser(
        allow_no_value=True,
        inline_comment_prefixes=('#',),
    )
    cfg_parser.read(str(path))

    cfg = Config()
    cfg.pid_dir   = path.parent / '.pids'
    cfg.log_dir   = path.parent / 'logs'
    cfg.router_id = _auto_router_id()   # auto from IP; overridden by config/env
    cfg.bind      = _primary_ip() or '' # auto from IP; overridden by config

    if cfg_parser.has_section('settings'):
        s = cfg_parser['settings']
        cfg.router    = s.get('router',    'localhost')
        cfg.bind      = s.get('router',    cfg.bind)
        cfg.port      = int(s.get('port',  '5300'))
        cfg.router_id = s.get('router_id', cfg.router_id)
        cfg.gui_port  = int(s.get('gui_port', '8765'))
        cfg.python    = s.get('python',   'python3')
        cfg.router_b  = s.get('router_b', '').strip()
        cfg.port_b    = int(s.get('port_b', '5300'))
        log = s.get('log_dir', 'logs')
        cfg.log_dir  = path.parent / log

    # UMM_ROUTER env var overrides umm.conf — format: host:port or host
    env_router = os.environ.get('UMM_ROUTER', '').strip()
    if env_router:
        if ':' in env_router:
            env_host, _, env_port_str = env_router.rpartition(':')
            try:
                cfg.router = env_host.strip()
                cfg.port   = int(env_port_str.strip())
            except ValueError:
                print(f"[WARN] UMM_ROUTER={env_router!r} — port is not an integer, ignoring")
        else:
            cfg.router = env_router   # host only, keep port from config

    # UMM_ROUTER_ID env var overrides umm.conf — format: site.node or integer
    env_id = os.environ.get('UMM_ROUTER_ID', '').strip()
    if env_id:
        cfg.router_id = env_id

    for section in cfg_parser.sections():
        if not section.startswith('agent.'):
            continue
        aname = section[6:]   # strip "agent."
        s     = cfg_parser[section]

        module       = s.get('module', '').strip()
        display_name = s.get('name',   aname).strip()
        groups_str   = s.get('group',  '').strip()
        groups       = groups_str.split() if groups_str else []
        after        = s.get('after',  '').strip() or '-'
        required     = s.get('required',  'false').lower() in ('true','1','yes')
        singleton    = s.get('singleton', 'false').lower() in ('true','1','yes')
        restart      = s.get('restart',   'never').strip()
        restart_delay= float(s.get('restart_delay', '3'))
        type_str     = s.get('type', '').strip()
        agent_type   = int(type_str) if type_str else None
        options_str  = s.get('options', '').strip()
        options      = options_str.split() if options_str else []
        foreground   = s.get('foreground', 'false').lower() in ('true','1','yes')
        binary       = s.get('binary',     'false').lower() in ('true','1','yes')
        # is_router: explicit in config, or auto-detected for the built-in Python router
        is_router    = s.get('router',     'false').lower() in ('true','1','yes')
        if module == 'umm.router':
            is_router = True

        pid_file = cfg.pid_dir / f"{aname}.pid"

        agent = AgentDef(
            name          = aname,
            module        = module,
            display_name  = display_name,
            groups        = groups,
            after         = after,
            required      = required,
            singleton     = singleton,
            restart        = restart,
            restart_delay  = restart_delay,
            agent_type    = agent_type,
            options       = options,
            foreground    = foreground,
            binary        = binary,
            is_router     = is_router,
            pid_file      = pid_file,
        )
        cfg.agents[aname] = agent

    # Parse [group.<name>] sections — per-group config (startup messages etc.)
    for section in cfg_parser.sections():
        if not section.startswith('group.'):
            continue
        gname = section[6:]   # strip "group."
        s     = cfg_parser[section]
        gdef  = GroupDef(name=gname)
        gdef.startup_delay = float(s.get('startup_delay', '0.5'))

        # startup_msg lines — same syntax as the Send tool interactive mode:
        #   mtype subtype [TLV spec]
        #   timer interval [repeat N] -> mtype subtype [TLVs]
        #   wait seconds
        # Keys: startup_msg, startup_msg_2, startup_msg_3, ... (any suffix)
        for key, value in s.items():
            if key == 'startup_msg' or key.startswith('startup_msg_'):
                if not value:
                    continue
                gdef.startup_messages.append(StartupMessage(raw_line=value.strip()))
        cfg.groups[gname] = gdef

    # Scan UMM_BRIDGE_<NAME> environment variables.
    # Formats: "host:port"  or  "host:port,mtype_b=N"  or  "host:port,mtype_a=N,mtype_b=N"
    # If a matching [agent.bridge-<name>] section exists, attach the env to it.
    # If not, auto-create a bridge agent entry from the env var alone.
    for key, value in os.environ.items():
        if not key.startswith('UMM_BRIDGE_'):
            continue
        suffix       = key[len('UMM_BRIDGE_'):]
        agent_suffix = suffix.lower().replace('_', '-')
        agent_name   = f'bridge-{agent_suffix}'
        parsed = _parse_bridge_env(key, value)
        if parsed is None:
            continue
        if agent_name not in cfg.agents:
            # Auto-create agent entry from env var
            display = ''.join(w.capitalize() for w in agent_suffix.split('-'))
            agent = AgentDef(
                name          = agent_name,
                module        = 'umm.modules.bridge',
                display_name  = f'Bridge{display}',
                groups        = ['bridge'],
                after         = 'manual',
                restart       = 'always',
                restart_delay = 5,
            )
            agent.bridge_env = parsed
            cfg.agents[agent_name] = agent
        else:
            cfg.agents[agent_name].bridge_env = parsed
    return cfg


def _parse_bridge_env(key: str, value: str) -> Optional[dict]:
    """
    Parse a UMM_BRIDGE_<NAME> environment variable value.

    Formats accepted:
      host:port                             — defaults: mtype_a=11, mtype_b=11
      host:port,mtype_b=N                   — custom mtype on Router B
      host:port,mtype_a=N,mtype_b=N         — custom mtype on both routers
      router_b=host:port,mtype_b=N          — explicit key=value form

    mtype_a = mtype this bridge uses on Router A (local)
    mtype_b = mtype this bridge uses on Router B (remote)

    Returns a dict with keys: router_b, port_b, and optionally mtype_a, mtype_b.
    Returns None on parse error.
    """
    value = value.strip()
    result: dict = {}

    # Detect bare address form: first token has no '='
    # e.g. '192.168.64.3:5300' or '192.168.64.3:5300,mtype_b=11'
    parts = [p.strip() for p in value.split(',')]
    first = parts[0]
    if '=' not in first:
        # First token is bare host:port
        if ':' in first:
            host, _, port_str = first.rpartition(':')
            try:
                result['router_b'] = host.strip()
                result['port_b']   = int(port_str.strip())
            except ValueError:
                print(f"[WARN] {key}: port is not an integer in {first!r}")
                return None
        else:
            result['router_b'] = first
            result['port_b']   = 5300
        parts = parts[1:]   # remaining parts are key=value
    
    # Parse remaining key=value pairs
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if '=' not in part:
            print(f"[WARN] {key}: unexpected token {part!r} — expected key=value")
            return None
        k, _, v = part.partition('=')
        k, v = k.strip(), v.strip()
        if k == 'router_b':
            if ':' in v:
                host, _, port_str = v.rpartition(':')
                try:
                    result['router_b'] = host.strip()
                    result['port_b']   = int(port_str.strip())
                except ValueError:
                    print(f"[WARN] {key}: port not integer in {v!r}")
                    return None
            else:
                result['router_b'] = v
                result['port_b']   = 5300
        elif k in ('mtype_a', 'mtype_b'):
            try:
                result[k] = int(v)
            except ValueError:
                print(f"[WARN] {key}: {k} is not an integer in {v!r}")
                return None
        else:
            print(f"[WARN] {key}: unknown key {k!r} — expected router_b, mtype_a, mtype_b")
            return None

    if 'router_b' not in result:
        print(f"[WARN] {key}: no router address found — expected host:port")
        return None
    return result


# ── process management ────────────────────────────────────────────────────────

class ProcessManager:
    """Starts and stops agent processes."""

    def __init__(self, cfg: Config, debug: bool = False) -> None:
        self.cfg   = cfg
        self.debug = debug   # if True, appends --debug to every agent command
        cfg.pid_dir.mkdir(parents=True, exist_ok=True)
        cfg.log_dir.mkdir(parents=True, exist_ok=True)
        self._log_file = self._get_log_file()
        # Log version at startup
        try:
            sys.path.insert(0, str(Path(__file__).parent))
            from umm.core.messages import UMM_VERSION_STR
            self._log('umm_ctl', f"UMM Service Manager starting — {UMM_VERSION_STR}")
            self._log('umm_ctl', f"Config: {cfg.__class__.__module__}")
        except ImportError:
            self._log('umm_ctl', "UMM Service Manager starting")
        if debug:
            self._log('umm_ctl', "Debug mode ON — all agents will receive --debug")

    def _get_log_file(self) -> Path:
        """Get or create the log file for this session.

        A fresh timestamped file is created only when no 'current' pointer
        exists yet — i.e. the very first `start` of a new session.  Subsequent
        `start sorting`, `start ConveyorTimer` etc. append to the same file so
        that all agent output appears in one place.

        Use `logs reset` to explicitly rotate to a new file mid-session.
        The 'current' pointer is always written as an absolute path so it
        works correctly regardless of the working directory the caller used.
        """
        link = self.cfg.log_dir / 'current'
        if link.exists():
            try:
                existing = Path(link.read_text().strip())
                # Only reuse if the file exists AND lives inside our log_dir.
                # A stale pointer from a different installation (different
                # base directory) is discarded so we don't inherit another
                # project's log file.
                log_dir_resolved = self.cfg.log_dir.resolve()
                if (existing.exists() and
                        existing.resolve().parent == log_dir_resolved):
                    return existing
            except Exception:
                pass
        # No valid current log — create a fresh one
        ts  = time.strftime('%Y%m%d_%H%M%S')
        log = (self.cfg.log_dir / f"umm_{ts}.log").resolve()
        log.touch()
        link.write_text(str(log))
        return log

    def reset_log(self) -> Path:
        """Start a new log file immediately and return its path.

        Used by `./runumm logs reset` — lets operators open a clean log
        mid-session without restarting any agents.
        """
        self._log_file = self._get_log_file()
        self._log('umm_ctl', "Log reset by operator request")
        return self._log_file

    def _log(self, agent_name: str, message: str) -> None:
        ts = time.strftime('%Y-%m-%d %H:%M:%S')
        with open(self._log_file, 'a') as f:
            f.write(f"{ts}  [{agent_name:<14}]  {message}\n")

    # Modules that are file paths (scripts), not python -m modules
    SCRIPT_MODULES = {
        'umm_gui.server',
    }

    # Modules that do NOT accept --name argument
    NO_NAME_ARG = {
        'umm_gui.server',
    }

    # Modules that do NOT accept --router / --port
    NO_ROUTER_ARG = {
        'umm.router',
        'umm_gui.server',   # uses --router and --port but different flag names
    }

    def build_command(self, agent: AgentDef,
                      extra_args: Optional[List[str]] = None) -> List[str]:
        """Build the command list for an agent."""
        cfg = self.cfg
        mod = agent.module

        # ── Binary agent: module field is the executable path ──────────────
        # Resolve relative paths relative to the umm.conf directory.
        # If is_router=true, pass --port/--id/--host (same as the Python router).
        # Otherwise pass --router/--port/--name like any other agent.
        if agent.binary:
            exe = Path(mod)
            if not exe.is_absolute():
                exe = Path(__file__).parent / exe
            cmd = [str(exe)]
            if agent.is_router:
                cmd += ['--port', str(cfg.port),
                        '--id',   cfg.router_id]
                if cfg.bind and cfg.bind not in ('localhost', '127.0.0.1'):
                    cmd += ['--host', cfg.bind]
            else:
                cmd += ['--router', cfg.router, '--port', str(cfg.port)]
                cmd += ['--name', agent.display_name]
                if agent.agent_type is not None:
                    cmd += ['--type', str(agent.agent_type)]
            cmd += agent.options
            if self.debug and '--debug' not in cmd:
                cmd += ['--debug']
            if extra_args:
                cmd += extra_args
            return cmd

        # GUI server is a script, not a -m module
        if mod == 'umm_gui.server':
            script = Path(__file__).parent / 'umm_gui' / 'server.py'
            cmd = [cfg.python, str(script)]
            cmd += ['--router', cfg.router,
                    '--port',   str(cfg.port)]
            # Only add --gui-port if not already in agent options
            if '--gui-port' not in agent.options:
                cmd += ['--gui-port', str(cfg.gui_port)]
            cmd += agent.options
            if extra_args:
                cmd += extra_args
            return cmd

        # Standard: python3 -m module
        cmd = [cfg.python, '-m', mod]

        # Router gets --port, --id, and optionally --host
        if agent.is_router:
            cmd += ['--port', str(cfg.port),
                    '--id',   cfg.router_id]
            if cfg.bind and cfg.bind not in ('localhost', '127.0.0.1'):
                cmd += ['--host', cfg.bind]
        elif mod == 'umm.modules.bridge':
            # Bridge takes --router-a/--router-b instead of --router/--port.
            # Values come from three sources in increasing priority:
            #   1. [settings] router_b / port_b
            #   2. UMM_BRIDGE_<NAME> env var (attached to agent.bridge_env)
            #   3. options in [agent.bridge-*] (--mtype-b etc.) — highest priority

            # Start with config-file defaults
            b_router = cfg.router_b
            b_port   = cfg.port_b
            b_mtype_a: Optional[int] = None   # defaults to MType.BRIDGE (11) in bridge.py
            b_mtype_b: Optional[int] = None   # defaults to 111 in bridge.py

            # Layer env var values on top
            env = agent.bridge_env
            if env:
                b_router  = env.get('router_b', b_router)
                b_port    = env.get('port_b',   b_port)
                b_mtype_a = env.get('mtype_a',  b_mtype_a)
                b_mtype_b = env.get('mtype_b',  b_mtype_b)

            # Parse agent.options to find explicit overrides (highest priority)
            remaining_opts: List[str] = []
            opts = list(agent.options)
            i = 0
            while i < len(opts):
                o = opts[i]
                if o == '--router-b' and i + 1 < len(opts):
                    addr = opts[i + 1]
                    if ':' in addr:
                        h, _, p = addr.rpartition(':')
                        b_router, b_port = h, int(p)
                    else:
                        b_router = addr
                    i += 2
                elif o == '--mtype-a' and i + 1 < len(opts):
                    b_mtype_a = int(opts[i + 1]); i += 2
                elif o == '--mtype-b' and i + 1 < len(opts):
                    b_mtype_b = int(opts[i + 1]); i += 2
                else:
                    remaining_opts.append(o); i += 1

            env_key = ('UMM_BRIDGE_' +
                       agent.name[len('bridge-'):].upper().replace('-', '_')
                       if agent.name.startswith('bridge-')
                       else agent.name.upper().replace('-', '_'))
            if not b_router:
                raise RuntimeError(
                    f"Bridge [{agent.name}]: router_b not set — "
                    f"add to [settings], set {env_key}=host:port, "
                    f"or add --router-b to options")

            router_a = f"{cfg.router}:{cfg.port}"
            router_b = f"{b_router}:{b_port}"
            cmd += ['--router-a', router_a, '--router-b', router_b]
            if b_mtype_a is not None:
                cmd += ['--mtype-a', str(b_mtype_a)]
            if b_mtype_b is not None:
                cmd += ['--mtype-b', str(b_mtype_b)]
            cmd += remaining_opts
            if self.debug and '--debug' not in cmd:
                cmd += ['--debug']
            if extra_args:
                cmd += extra_args
            return cmd
        elif mod == 'umm.modules.supervisor':
            cmd += ['--router', cfg.router, '--port', str(cfg.port)]
            # Resolve --config path relative to umm.conf directory
            for i, opt in enumerate(agent.options):
                if opt == '--config' and i + 1 < len(agent.options):
                    conf_path = Path(agent.options[i + 1])
                    if not conf_path.is_absolute():
                        conf_path = Path(__file__).parent / conf_path
                    cmd += ['--config', str(conf_path)]
                    cmd += agent.options[i + 2:]
                    break
            else:
                cmd += agent.options
            if '--name' not in cmd:
                cmd += ['--name', agent.display_name]
            if extra_args:
                cmd += extra_args
            return cmd
        else:
            cmd += ['--router', cfg.router, '--port', str(cfg.port)]

        # --name (most modules accept this)
        if mod not in self.NO_NAME_ARG:
            cmd += ['--name', agent.display_name]

        # --type (agent primary mtype) — only for modules that accept it
        TYPE_MODULES = {'umm.modules.timer', 'umm.modules.fsm',
                        'umm.modules.database'}
        if agent.agent_type is not None and mod in TYPE_MODULES:
            cmd += ['--type', str(agent.agent_type)]

        # Extra options from config
        cmd += agent.options

        # --debug: inject if global debug mode is on and not already present
        if self.debug and '--debug' not in cmd:
            cmd += ['--debug']

        # Extra args from the command line (passed after the agent name)
        if extra_args:
            cmd += extra_args

        return cmd

    def start_foreground(self, agent: AgentDef,
                         extra_args: Optional[List[str]] = None) -> None:
        """
        Start an agent in the foreground (replaces current process on Unix,
        runs as a child process on Windows since os.execvp is unreliable there).
        This never returns.
        """
        cmd = self.build_command(agent, extra_args=extra_args)
        self._log(agent.display_name, f"Starting foreground: {' '.join(cmd)}")
        info(f"Starting {agent.display_name} in foreground...")
        info(f"Command: {' '.join(cmd)}")
        print()
        if sys.platform == 'win32':
            import subprocess as _sp
            proc = _sp.Popen(cmd)
            try:
                result = proc.wait()
            except KeyboardInterrupt:
                # Ctrl-C reaches both us and the child (shared console group).
                # Let the child run its own clean shutdown, then exit quietly
                # instead of dumping a KeyboardInterrupt traceback here.
                try:
                    result = proc.wait(timeout=10)
                except Exception:
                    result = 0
            sys.exit(result)
        else:
            os.execvp(cmd[0], cmd)

    def start(self, agent: AgentDef, wait: float = 1.0,
              extra_args: Optional[List[str]] = None) -> bool:
        """
        Start an agent as a background process.
        Returns True if started successfully.
        """
        if agent.status() == 'running':
            warn(f"{agent.display_name} is already running (PID {agent.pid})")
            return True

        cmd = self.build_command(agent, extra_args=extra_args)
        self._log(agent.display_name, f"Starting: {' '.join(cmd)}")

        log_file = self._log_file
        name     = agent.display_name

        # Python launcher: starts real process, writes its PID, pipes output
        launcher = [
            self.cfg.python, '-c',
            f'''
import subprocess, sys, os
pid_file = sys.argv[1]
args     = sys.argv[2:]
proc     = subprocess.Popen(args, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
with open(pid_file, "w") as f:
    f.write(str(proc.pid))
import time
for line in proc.stdout:
    text = line.decode("utf-8", errors="replace").rstrip()
    ts   = time.strftime("%Y-%m-%d %H:%M:%S")
    with open({str(log_file)!r}, "a", encoding="utf-8", errors="replace") as lf:
        lf.write(f"{{ts}}  [{name:<14}]  {{text}}\\n")
proc.wait()
''',
            str(agent.pid_file),
        ] + cmd

        # Detach the background agent from the console process group on Windows
        # so a later Ctrl-C in a foreground tool sharing the console does not
        # take it down.  (POSIX detaches background agents elsewhere.)
        popen_kw = {}
        if sys.platform == 'win32':
            popen_kw['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP

        proc = subprocess.Popen(
            launcher,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            **popen_kw,
        )

        # Wait for pid file
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if agent.pid_file.exists() and agent.pid_file.stat().st_size > 0:
                break
            time.sleep(0.1)

        if not agent.pid_file.exists():
            err(f"{agent.display_name} failed to start — check log: {log_file}")
            return False

        time.sleep(wait)

        if agent.status() == 'running':
            ok(f"{agent.display_name} started (PID {agent.pid})")
            self._log(agent.display_name, f"Started OK (PID {agent.pid})")
            return True
        else:
            err(f"{agent.display_name} exited immediately — check log: {log_file}")
            self._log(agent.display_name, "Exited immediately after start")
            return False

    def stop(self, agent: AgentDef) -> bool:
        """Stop a running agent. Returns True if stopped."""
        if agent.status() != 'running':
            warn(f"{agent.display_name} is not running")
            return True

        pid = agent.pid
        try:
            # Also kill the launcher wrapper (the -c "import subprocess..." parent
            # process that tails the log). Its PID is the child's PPID.
            # We verify it is actually a launcher before killing it.
            launcher_pid = _get_ppid(pid)

            _proc_terminate(pid)
            # Wait for clean exit
            deadline = time.time() + 5.0
            while time.time() < deadline:
                if not _proc_is_running(pid):
                    break
                time.sleep(0.2)
            else:
                # Force kill
                _proc_kill(pid)

            # Kill launcher if it is still alive and looks like our wrapper
            if launcher_pid and launcher_pid > 1 and _proc_is_running(launcher_pid):
                if _is_launcher_process(launcher_pid):
                    _proc_terminate(launcher_pid)

            agent.pid_file.unlink() if agent.pid_file.exists() else None
            self._log(agent.display_name, f"Stopped (PID {pid})")
            ok(f"{agent.display_name} stopped (PID {pid})")
            return True

        except Exception as exc:
            err(f"Failed to stop {agent.display_name}: {exc}")
            return False

    def check_router(self) -> bool:
        """Return True if router port is reachable."""
        import socket
        for family, addr in [
            (socket.AF_INET,  (self.cfg.router, self.cfg.port)),
            (socket.AF_INET6, (self.cfg.router, self.cfg.port, 0, 0)),
        ]:
            try:
                s = socket.socket(family)
                s.settimeout(1)
                s.connect(addr)
                s.close()
                return True
            except Exception:
                pass
        return False


# ── commands ──────────────────────────────────────────────────────────────────

def resolve_target(cfg: Config, target: Optional[str]) -> List[AgentDef]:
    """
    Resolve a target string to a list of agents.

    target=None   → all non-manual agents
    target='all'  → all agents including manual
    target='core' → agents in 'core' group
    target='ConveyorTimer' or 'conveyor-timer' → that specific agent
    """
    if target is None:
        return cfg.get_auto()

    if target == 'all':
        return cfg._order(list(cfg.agents.values()))

    # Group name?
    agents_in_group = cfg.get_group(target)
    if agents_in_group:
        return agents_in_group

    # Agent name (config key or display name)?
    for agent in cfg.agents.values():
        if (agent.name == target or
                agent.display_name.lower() == target.lower()):
            return [agent]

    err(f"Unknown target: {target!r}")
    info(f"Known agents:  {', '.join(cfg.agents.keys())}")
    info(f"Known groups:  "
         f"{', '.join(sorted({g for a in cfg.agents.values() for g in a.groups}))}")
    return []


def _roll_logs(cfg: Config) -> None:
    """Move existing log files into logs/backup/ before starting fresh."""
    log_dir    = cfg.log_dir
    backup_dir = log_dir / 'backup'
    if not log_dir.exists():
        return
    logs = list(log_dir.glob('umm_*.log'))
    if not logs:
        return
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = time.strftime('%Y%m%d_%H%M%S')
    for log in logs:
        dest = backup_dir / f"{log.stem}_{ts}{log.suffix}"
        try:
            log.rename(dest)
        except Exception as exc:
            print(f"[WARN] Could not roll log {log.name}: {exc}")
    # Remove the 'current' symlink so a fresh one is created on next start
    link = log_dir / 'current'
    if link.is_symlink():
        link.unlink()


def _send_startup_messages(cfg: Config, group_name: str) -> None:
    """Send any startup_msg entries defined in [group.<group_name>].

    Each startup_msg value is a line in the same syntax as the Send tool's
    interactive mode:

        mtype subtype [TLV spec]          — plain message
        timer interval -> mtype subtype   — schedule a timer
        wait 2.0                          — pause between messages

    Examples in umm.conf::

        [group.tank]
        startup_delay = 1.0
        startup_msg   = 5001,101 Bool false
        startup_msg_2 = timer 10.0 -> 5000 201 Float 50.0
        startup_msg_3 = wait 0.5
        startup_msg_4 = 5000,202 Int 42
    """
    gdef = cfg.groups.get(group_name)
    if not gdef or not gdef.startup_messages:
        return

    try:
        from umm.agent import UMMAgent, UMMConnectionError
        from umm.tools.send import _handle_line
    except ImportError as exc:
        warn(f"Cannot send startup messages — UMM not importable: {exc}")
        return

    if gdef.startup_delay > 0:
        time.sleep(gdef.startup_delay)

    try:
        agent = UMMAgent(host=cfg.router, port=cfg.port,
                         process_name='umm_ctl-startup')
        if not agent.connect():
            warn(f"Could not connect to router — startup messages for "
                 f"group '{group_name}' not sent")
            return
    except UMMConnectionError as exc:
        warn(f"Could not connect to router: {exc} — startup messages not sent")
        return

    for smsg in gdef.startup_messages:
        try:
            _handle_line(agent, smsg.raw_line)
            info(f"Startup: {smsg.raw_line}")
        except Exception as exc:
            warn(f"Startup message failed ({smsg.raw_line!r}): {exc}")

    agent.disconnect()


def cmd_start(cfg: Config, target: Optional[str], pm: ProcessManager,
              extra_args: Optional[List[str]] = None) -> None:
    agents = resolve_target(cfg, target)
    if not agents:
        return

    # Full stack start (no specific target): kill stale processes and roll logs
    if target is None:
        cmd_killall(cfg, quiet=True)
        _roll_logs(cfg)
        time.sleep(0.5)

    # Extra args only make sense for a single named agent
    if extra_args and len(agents) > 1:
        warn(f"Extra arguments {extra_args} ignored when starting a group — "
             f"target a single agent to pass extra arguments")
        extra_args = None

    head(f"Starting {target or 'default stack'}")
    print()

    for agent in agents:
        if agent.is_manual and target is None:
            continue   # skip manual agents unless explicitly targeted

        # Check dependency
        dep = agent.dependency
        if dep and dep in cfg.agents:
            dep_agent = cfg.agents[dep]
            if dep_agent.status() != 'running':
                # Try to start the dependency first
                info(f"{agent.display_name} depends on {dep_agent.display_name} — starting dependency first")
                if not pm.start(dep_agent):
                    if agent.required:
                        err(f"Required dependency {dep} failed — aborting")
                        return
                    warn(f"Dependency {dep} failed — skipping {agent.display_name}")
                    continue

        # Special delay after router
        wait = 1.0 if agent.module == 'umm.router' else 0.5

        # Foreground agents run in the terminal — only when targeting
        # a specific agent, not during bulk start
        if agent.foreground and target is not None:
            pm.start_foreground(agent, extra_args=extra_args)   # exec — never returns
            return

        success = pm.start(agent, wait=wait, extra_args=extra_args)
        if not success and agent.required:
            err(f"Required agent {agent.display_name} failed — aborting startup")
            return

    # Send any startup messages defined for this group
    if target and target in cfg.groups:
        _send_startup_messages(cfg, target)

    print()
    info(f"Log: {pm._log_file}")
    info("Status:  runumm status")
    info("Logs:    runumm logs")
    info("Stop:    runumm stop")
    print()


def cmd_stop(cfg: Config, target: Optional[str], pm: ProcessManager) -> None:
    agents = resolve_target(cfg, target)
    if not agents:
        return

    head(f"Stopping {target or 'all agents'}")
    print()

    # When stopping everything, stop the supervisor first so it cannot
    # restart agents that we are about to stop.
    if target is None:
        supervisor = cfg.agents.get('supervisor')
        if supervisor and supervisor.status() == 'running':
            pm.stop(supervisor)

    # Stop remaining agents in reverse dependency order
    for agent in reversed(agents):
        if agent.display_name == 'supervisor':
            continue   # already handled above
        if agent.status() == 'running':
            pm.stop(agent)

    # If stopping everything, also kill any UMM processes that were spawned
    # by the supervisor (timer, typedir, plugins, GUI server, demo agents)
    # and are therefore not tracked by PID files.
    if target is None:
        cmd_killall(cfg, quiet=True)
        link = cfg.log_dir / 'current'
        if link.exists():
            link.unlink()

    print()


def cmd_restart(cfg: Config, target: Optional[str], pm: ProcessManager) -> None:
    cmd_stop(cfg, target, pm)
    time.sleep(1)
    cmd_start(cfg, target, pm)


def cmd_status(cfg: Config, target: Optional[str]) -> None:
    agents = resolve_target(cfg, target) if target else list(cfg.agents.values())
    if not agents:
        return

    head("UMM Agent Status")
    try:
        from umm.core.messages import UMM_VERSION_STR
        print(f"  {CYAN}{UMM_VERSION_STR}{RESET}")
    except ImportError:
        pass
    print()

    # System summary line
    router_agent = cfg.agents.get('router')
    router_st = router_agent.status() if router_agent else 'stopped'
    router_col = GREEN if router_st == 'running' else RED
    print(f"  Router:   {router_col}{cfg.router}:{cfg.port}{RESET}   "
          f"GUI: {cfg.gui_port}   "
          f"ID: {cfg.router_id}")

    # Bridge summary
    bridge_agents = [a for a in cfg.agents.values()
                     if a.module == 'umm.modules.bridge']
    if bridge_agents:
        for b in bridge_agents:
            bst  = b.status()
            bcol = GREEN if bst == 'running' else RED
            env  = b.bridge_env
            if env:
                rb = f"{env.get('router_b','?')}:{env.get('port_b','?')}"
            elif cfg.router_b:
                rb = f"{cfg.router_b}:{cfg.port_b}"
            else:
                rb = f"{YELLOW}router_b not set{RESET}"
            print(f"  Bridge:   {bcol}{b.display_name}{RESET}  →  {rb}  "
                  f"[{bcol}{bst}{RESET}]")
    print()

    # Group by group membership for display
    shown: Set[str] = set()
    groups: Dict[str, List[AgentDef]] = {}
    ungrouped: List[AgentDef] = []

    for agent in agents:
        if agent.groups:
            for g in agent.groups:
                groups.setdefault(g, []).append(agent)
        else:
            ungrouped.append(agent)

    def show_agent(agent: AgentDef) -> None:
        if agent.name in shown:
            return
        shown.add(agent.name)
        st = agent.status()
        pid_str = f"PID {agent.pid}" if st == 'running' else '       '
        st_str  = f"{GREEN}running{RESET}" if st == 'running' else f"{RED}stopped{RESET}"
        mt_str  = f"  mtype={agent.agent_type}" if agent.agent_type else ''
        manual  = "  [manual]" if agent.is_manual else ''
        print(f"  {agent.display_name:<22} {st_str}  {pid_str}  {agent.module}{mt_str}{manual}")

    for group_name, group_agents in sorted(groups.items()):
        print(f"  {CYAN}── {group_name} ──{RESET}")
        for agent in group_agents:
            show_agent(agent)
        print()

    if ungrouped:
        print(f"  {CYAN}── ungrouped ──{RESET}")
        for agent in ungrouped:
            show_agent(agent)
        print()


def cmd_agents(cfg: Config) -> None:
    """Query the live router and supervisor for all running agents and plugins."""
    import json, threading

    head("UMM Live Agents")
    print()

    # Check router is reachable first
    router_agent = cfg.agents.get('router')
    if not router_agent or router_agent.status() != 'running':
        err("Router is not running — cannot query live agents")
        return

    try:
        from umm.agent import UMMAgent, UMMConnectionError
        from umm.core.tlv import decode_all, TLV_STRING, TLV_JSON
        from umm.core.messages import MType, UMMSubType
    except ImportError as e:
        err(f"Cannot import UMM: {e}")
        return

    router_data  = {}   # from ListAgents (1,111)
    sup_data     = {}   # from supervisor status (12,105)
    got_router   = threading.Event()
    got_sup      = threading.Event()

    def _on_list_agents(msg):
        try:
            tlvs = decode_all(msg.tdata.value) if msg.tdata and msg.tdata.value else []
            for t in tlvs:
                if t.type_id == TLV_STRING:
                    text = t.value.rstrip(b'\x00').decode('utf-8', errors='replace')
                    try:
                        router_data.update(json.loads(text))
                    except Exception:
                        pass
                    break
        finally:
            got_router.set()

    def _on_sup_status(msg):
        try:
            tlvs = decode_all(msg.tdata.value) if msg.tdata and msg.tdata.value else []
            for t in tlvs:
                if t.type_id == TLV_JSON or t.type_id == TLV_STRING:
                    text = t.value.rstrip(b'\x00').decode('utf-8', errors='replace')
                    try:
                        data = json.loads(text)
                        for a in data.get('agents', []):
                            sup_data[a['name']] = a
                    except Exception:
                        pass
                    break
        finally:
            got_sup.set()

    client = UMMAgent(
        host=cfg.router,
        port=cfg.port,
        process_name='ummctl-agents',
    )
    try:
        if not client.connect():
            err(f"Cannot connect to router at {cfg.router}:{cfg.port}")
            return

        client.register(mtype=int(MType.UMM), subtype=int(UMMSubType.LIST_AGENTS_RESPONSE),
                        callback=_on_list_agents, dont_send_self=False)
        client.register(mtype=12, subtype=105,
                        callback=_on_sup_status, dont_send_self=False)

        client.send(mtype=int(MType.UMM), subtype=int(UMMSubType.LIST_AGENTS))
        client.send(mtype=12, subtype=104)   # supervisor ST_AGENT_STATUS

        got_router.wait(timeout=3.0)
        got_sup.wait(timeout=3.0)

    except Exception as e:
        err(f"Query failed: {e}")
        return
    finally:
        try:
            client.disconnect()
        except Exception:
            pass

    agents = router_data.get('agents', [])

    # Known plugin process names
    PLUGIN_NAMES = {'string-match', 'coord-match', 'StringMatch', 'CoordMatch',
                    'string_match', 'coord_match'}

    print(f"  Router: {GREEN}{cfg.router}:{cfg.port}{RESET}  "
          f"(ID {router_data.get('router_id','?')}  "
          f"name: {router_data.get('router_name','?')})")
    print()

    # Header
    print(f"  {CYAN}{'Name':<22} {'mtype':>6}  {'attach':>7}  {'pid':>7}  "
          f"{'policy':<6}  {'restarts':>8}  {'kind'}{RESET}")
    print(f"  {'-'*22} {'-'*6}  {'-'*7}  {'-'*7}  {'-'*6}  {'-'*8}  {'-'*8}")

    for a in agents:
        name      = a.get('name', '?')
        mtype     = a.get('mtype', 0)
        attach_id = a.get('attach_id', '-')
        sup       = sup_data.get(name, {})
        pid       = sup.get('pid', '-')
        policy    = sup.get('policy', '-')
        restarts  = sup.get('restarts', '-')
        status    = sup.get('status', 'running')

        if name in PLUGIN_NAMES or 'match' in name.lower():
            kind = 'plugin'
        elif mtype == int(MType.UMM):
            kind = 'router'
        elif mtype == 12:
            kind = 'supervisor'
        elif sup:
            kind = 'supervised'
        else:
            kind = 'agent'

        col = GREEN if status == 'running' else RED
        print(f"  {col}{name:<22}{RESET} {mtype:>6}  {str(attach_id):>7}  "
              f"{str(pid):>7}  {str(policy):<6}  {str(restarts):>8}  {kind}")

    if not agents:
        warn("No agents returned from router — is ListAgents supported?")

    if not got_router.is_set():
        warn("Router did not respond to ListAgents within 3s")
    if not got_sup.is_set():
        info("Supervisor did not respond (may not be running)")

    print()


def cmd_validate(cfg: Config) -> None:
    head("Validating configuration")
    print()

    issues = cfg.validate()
    errors   = [i for i in issues if i.startswith('ERROR')]
    warnings = [i for i in issues if i.startswith('WARN')]

    # Show all agents
    print(f"  {'Agent':<22} {'Module':<35} {'Groups':<15} {'After':<15} {'Type'}")
    print(f"  {'-'*22} {'-'*35} {'-'*15} {'-'*15} {'-'*10}")
    for agent in cfg.agents.values():
        groups  = ' '.join(agent.groups) or '-'
        mt      = str(agent.agent_type) if agent.agent_type else '-'
        manual  = '[manual]' if agent.is_manual else (agent.after or '-')
        print(f"  {agent.display_name:<22} {agent.module:<35} {groups:<15} {manual:<15} {mt}")
    print()

    if not issues:
        ok("Configuration is valid")
    else:
        for w in warnings:
            warn(w[7:].strip())
        for e in errors:
            err(e[7:].strip())
        if errors:
            err(f"{len(errors)} error(s) found — fix before starting")
        else:
            ok(f"No errors ({len(warnings)} warning(s))")
    print()


def cmd_show(cfg: Config) -> None:
    head("UMM Configuration")
    print()
    print(f"  Router:    {cfg.router}:{cfg.port}  (ID: {cfg.router_id})")
    print(f"  GUI port:  {cfg.gui_port}")
    print(f"  Log dir:   {cfg.log_dir}")
    print(f"  PID dir:   {cfg.pid_dir}")

    # Bridge config
    bridge_agents = [a for a in cfg.agents.values()
                     if a.module == 'umm.modules.bridge']
    if bridge_agents:
        print()
        print(f"  {CYAN}── Bridges ──{RESET}")
        for b in bridge_agents:
            # Derive env var name from agent name
            if b.name.startswith('bridge-'):
                env_key = 'UMM_BRIDGE_' + b.name[len('bridge-'):].upper().replace('-', '_')
            else:
                env_key = None
            env    = b.bridge_env
            rb_host = env.get('router_b') or cfg.router_b or None
            rb_port = env.get('port_b',   cfg.port_b)
            rb_str  = f"{rb_host}:{rb_port}" if rb_host else f"{YELLOW}not set{RESET}"
            # Effective mtype_a / mtype_b — options win over env
            ma = str(env.get('mtype_a', '')) if env else ''
            mb = str(env.get('mtype_b', '')) if env else ''
            opts = b.options
            for i, o in enumerate(opts):
                if o == '--mtype-a' and i + 1 < len(opts): ma = opts[i + 1]
                if o == '--mtype-b' and i + 1 < len(opts): mb = opts[i + 1]
            mtype_str  = (f"  mtype_a={ma}" if ma else '') + (f"  mtype_b={mb}" if mb else '')
            if env:
                env_str = f"  {CYAN}(env: {env_key}){RESET}"
            elif env_key:
                env_str = f"  {YELLOW}(env: {env_key} not set){RESET}"
            else:
                env_str = ''
            print(f"    {b.display_name:<24} → {rb_str}{mtype_str}{env_str}")
    elif cfg.router_b:
        print(f"  Router B:  {cfg.router_b}:{cfg.port_b}  (no bridge agent configured)")

    print()
    groups: Set[str] = {g for a in cfg.agents.values() for g in a.groups}
    print(f"  Groups: {', '.join(sorted(groups)) or '(none)'}")
    print(f"  Agents: {len(cfg.agents)}")
    print()

    for agent in cfg.agents.values():
        st      = agent.status()
        st_col  = f"{GREEN}▶{RESET}" if st == 'running' else '○'
        mt      = f"  mtype={agent.agent_type}" if agent.agent_type else ''
        restart = f"  restart={agent.restart}" if agent.restart != 'never' else ''
        groups_str = f"  [{', '.join(agent.groups)}]" if agent.groups else ''
        after   = f"  after={agent.after}" if agent.after not in ('-', '') else ''
        manual  = f"  {YELLOW}[manual]{RESET}" if agent.is_manual else ''
        binary  = f"  {YELLOW}[binary]{RESET}" if agent.binary else ''
        is_rtr  = f"  {YELLOW}[router]{RESET}" if agent.is_router and agent.binary else ''
        print(f"  {st_col} {agent.display_name:<22} {agent.module}{mt}{restart}{groups_str}{after}{manual}{binary}{is_rtr}")
    print()


def cmd_killall(cfg: Config, quiet: bool = False) -> None:
    """Kill all UMM-related Python processes by pattern, regardless of PID files."""
    import subprocess as _sp

    if not quiet:
        head("Killing all UMM processes")
        print()

    patterns = [
        'umm.router', 'umm.modules.', 'umm.plugins.',
        'umm_gui/server', 'umm_gui.server',
        'umm_start.py', 'examples.',
    ]

    killed = []
    my_pid = os.getpid()

    if sys.platform == 'win32':
        # Try wmic first; fall back to PowerShell (wmic removed in Windows 11)
        py_pids = []
        try:
            result = _sp.run(
                ['wmic', 'process', 'where', 'name like "%python%"',
                 'get', 'ProcessId,CommandLine', '/format:csv'],
                capture_output=True, text=True)
            for line in result.stdout.splitlines():
                parts = line.strip().split(',', 2)
                if len(parts) < 3:
                    continue
                cmd_line = parts[1].strip()
                pid_str  = parts[2].strip()
                if pid_str.isdigit():
                    py_pids.append((int(pid_str), cmd_line))
        except Exception:
            pass

        if not py_pids:
            try:
                result = _sp.run(
                    ['powershell', '-NoProfile', '-Command',
                     'Get-Process python*,py* | Select-Object Id,CommandLine | '
                     'ConvertTo-Csv -NoTypeInformation'],
                    capture_output=True, text=True)
                for line in result.stdout.splitlines()[1:]:
                    parts = line.strip().strip('"').split('","', 1)
                    if len(parts) == 2 and parts[0].isdigit():
                        py_pids.append((int(parts[0]), parts[1]))
            except Exception:
                pass

        for pid, cmd_line in py_pids:
            if pid == my_pid:
                continue
            if any(pat in cmd_line for pat in patterns):
                try:
                    _proc_terminate(pid)
                    killed.append((pid, cmd_line.split()[-1] if cmd_line else '?'))
                except Exception:
                    pass

    else:
        # Unix: use pgrep + ps
        # Run multiple pgrep passes to catch all UMM-related processes:
        # - 'umm' catches umm.router, umm.modules.*, umm.plugins.*, umm_gui.*
        # - 'examples.' catches demo agents (examples.tankLevel.*, examples.sorting.*)
        # - The project directory path catches any process launched from it
        pids: set = set()
        project_dir = str(Path(__file__).parent)
        for pattern in ['umm', 'examples.tankLevel', 'examples.sorting',
                        project_dir]:
            try:
                result = _sp.run(['pgrep', '-f', pattern],
                                 capture_output=True, text=True)
                for p in result.stdout.split():
                    if p.strip():
                        pids.add(int(p))
            except Exception:
                pass
        pids = list(pids)

        for pid in pids:
            if pid == my_pid:
                continue
            try:
                cmd_result = _sp.run(['ps', '-p', str(pid), '-o', 'command='],
                                     capture_output=True, text=True)
                cmd_line = cmd_result.stdout.strip()
                if any(pat in cmd_line for pat in patterns):
                    # Also kill the launcher parent if there is one
                    ppid = _get_ppid(pid)
                    if ppid and ppid > 1 and _is_launcher_process(ppid):
                        try:
                            _proc_terminate(ppid)
                        except Exception:
                            pass
                    _proc_terminate(pid)
                    killed.append((pid, cmd_line.split()[-1] if cmd_line else '?'))
            except (ProcessLookupError, PermissionError):
                pass

    if killed:
        for pid, name in killed:
            ok(f"Killed PID {pid}  ({name})")
        # Wait for all killed processes to actually exit (up to 5s),
        # then force-kill any that are still alive.
        deadline = time.time() + 5.0
        while time.time() < deadline:
            still_alive = [pid for pid, _ in killed if _proc_is_running(pid)]
            if not still_alive:
                break
            time.sleep(0.2)
        else:
            for pid, name in [(p, n) for p, n in killed if _proc_is_running(p)]:
                try:
                    _proc_kill(pid)
                    warn(f"Force-killed PID {pid} ({name})")
                except Exception:
                    pass
        time.sleep(0.3)  # brief pause for OS to release ports/resources
    else:
        info("No UMM processes found")

    # Also clean up all PID files
    for pid_file in cfg.pid_dir.glob('*.pid'):
        pid_file.unlink() if pid_file.exists() else None
    print()


def cmd_cleanstart(cfg: Config, target: Optional[str],
                   pm: ProcessManager,
                   extra_args: Optional[List[str]] = None) -> None:
    """Kill all stale UMM processes then start fresh."""
    cmd_killall(cfg)
    time.sleep(0.5)
    cmd_start(cfg, target, pm, extra_args=extra_args)


    """Show version of umm_ctl and each running agent."""
    head("UMM Version Information")
    print()

    # umm_ctl / core library version
    try:
        from umm.core.messages import UMM_VERSION_STR
        ok(f"Core library:  {UMM_VERSION_STR}")
    except ImportError:
        warn("Core library version not available")

    print()
    info("Running agents:")

    # Query each running agent with --version
    for agent in cfg.agents.values():
        if agent.status() != 'running':
            continue
        cmd = cfg.python + ' -m ' + agent.module + ' --version'
        try:
            result = __import__('subprocess').run(
                cmd.split(), capture_output=True, text=True, timeout=5)
            ver = result.stdout.strip() or result.stderr.strip()
            if ver:
                print(f"  {agent.display_name:<22} {ver}")
            else:
                print(f"  {agent.display_name:<22} (no version info)")
        except Exception as exc:
            print(f"  {agent.display_name:<22} (query failed: {exc})")

    print()

    # Show version in log
    log_link = cfg.log_dir / 'current'
    if log_link.exists():
        info(f"Current log: {log_link.read_text().strip()}")
    print()


def cmd_logs(cfg: Config, target: Optional[str] = None) -> None:
    """Tail the current log, list all logs, or reset to a fresh log file.

    target=None or 'tail'  → tail -f the current log (default)
    target='list'          → list all log files in log_dir
    target='reset'         → start a new log file and print its path
    """
    log_dir  = cfg.log_dir
    link     = log_dir / 'current'

    if target == 'list':
        head("Log files")
        current = link.read_text().strip() if link.exists() else ''
        logs = sorted(log_dir.glob('umm_*.log'))
        if not logs:
            info("No log files found")
            return
        for lf in logs:
            marker = '  ← current' if str(lf.resolve()) == current else ''
            size   = lf.stat().st_size
            lines  = sum(1 for _ in lf.open())
            print(f"  {lf.name}  ({lines} lines, {size} bytes){marker}")
        print()
        return

    if target == 'reset':
        log_dir.mkdir(parents=True, exist_ok=True)
        ts  = time.strftime('%Y%m%d_%H%M%S')
        log = (log_dir / f"umm_{ts}.log").resolve()
        log.touch()
        link.write_text(str(log))
        ok(f"New log file: {log}")
        info("Agents already running will continue writing to their previous log path.")
        info("Restart agents to redirect their output to the new file.")
        return

    # Default: tail current log
    if not link.exists():
        err("No log file found — run 'start' first")
        return
    log = link.read_text().strip()
    if not Path(log).exists():
        err(f"Log file listed in 'current' does not exist: {log}")
        err("Run 'logs reset' to create a fresh log file")
        return
    info(f"Tailing {log}  (Ctrl+C to stop)")
    try:
        os.execvp('tail', ['tail', '-f', log])
    except Exception as exc:
        err(f"Could not tail log: {exc}")


# ── main ──────────────────────────────────────────────────────────────────────

def _cmd_agent_help(args, p) -> None:
    """
    'umm_ctl.py help [agent]' — show an agent's own --help output.

    If no agent is given, shows umm_ctl's own help.
    The agent name must match a key in umm.conf [agent.*].

    Also handles '--help' passed after a start command:
      umm_ctl.py start parser --help   →  parser --help
      umm_ctl.py help parser           →  parser --help
    """
    # Determine which agent name was requested
    # For 'help parser': command='help', target='parser'
    # For 'start parser --help': command='start', target='parser', help=True
    agent_name = args.target

    if not agent_name:
        p.print_help()
        return

    # Load config to find the agent's module
    config_path = Path(args.config)
    if not config_path.is_absolute() and not config_path.parent.parts:
        config_path = Path(__file__).resolve().parent / config_path
    if not config_path.exists():
        err(f"Config file not found: {config_path}")
        info("Cannot look up agent without a config file.")
        sys.exit(1)

    cfg = parse_config(config_path)

    agent_def = cfg.agents.get(agent_name)
    if agent_def is None:
        # Check if it's a known built-in not in config
        BUILTIN_MODULES = {
            'router':     'umm.router',
            'parser':     'umm.modules.parser',
            'timer':      'umm.modules.timer',
            'supervisor': 'umm.modules.supervisor',
            'send':       'umm.tools.send',
        }
        module = BUILTIN_MODULES.get(agent_name)
        if module is None:
            err(f"Unknown agent '{agent_name}'. "
                f"Known agents: {', '.join(list(cfg.agents.keys()) + list(BUILTIN_MODULES.keys()))}")
            sys.exit(1)
    else:
        module = agent_def.module

    # Run the agent with --help
    if module == 'umm_gui.server':
        script = Path(__file__).resolve().parent / 'umm_gui' / 'server.py'
        cmd = [cfg.python, str(script), '--help']
    else:
        cmd = [cfg.python, '-m', module, '--help']

    info(f"Showing help for '{agent_name}' ({module}):")
    print()
    import subprocess as _sp
    _sp.run(cmd)


def main() -> None:
    p = argparse.ArgumentParser(
        description='UMM Service Manager',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        # Suppress built-in -h/--help so we can handle it ourselves and
        # avoid it shadowing agent --help flags passed via extra_args.
        add_help=False,
        epilog="""
Commands:
  start [target]      Start agents (target: group name, agent name, or 'all')
  stop  [target]      Stop agents
  restart [target]    Stop then start
  status [target]     Show agent status (includes router port, GUI port, bridges)
  validate            Check configuration for errors
  show                Display parsed configuration (includes bridge config and env var status)
  logs [list|reset]   Tail current log, list all logs, or reset to fresh file
  version             Show version of running agents
  killall             Kill all UMM-related processes (ignores PID files)
  cleanstart [target] Kill all stale processes then start fresh
  help [agent]        Show this help, or show an agent's own --help output

Setup targets (run once on a new installation before starting the demos):
  runumm start sorting-database-setup  # create sorting demo DB tables then exit
  runumm start tank-database-setup     # create tank demo DB tables then exit

Options:
  --config FILE       Config file (default: umm.conf)
  --debug             Pass --debug to every agent process (verbose logging)
  -h, --help          Show this help message and exit

Passing flags to agents:
  Any extra arguments after the agent name are passed directly to that agent.
  Flags that share a name with umm_ctl options (--debug, --config) must be
  placed AFTER the agent name.  Use -- to force everything after it to be
  treated as agent arguments:

    runumm start parser --mtype 100 --subtype 1
    runumm start parser -- --help      # show parser's own help
    runumm start supervisor -- --config supervisor.conf
    runumm start send --trusted --shutdown --delay 30 "Maintenance"

  Conflicts to be aware of:
    --config   umm_ctl reads this for its own config file; supervisor also has
               --config for supervisor.conf.  Place supervisor's --config
               after the agent name, or use the help command to check.
    --debug    umm_ctl passes this through to all agents automatically.
               Do not repeat it after the agent name.
    --version  Use the 'version' command for running agents, or
               'help <agent>' to see an agent's version flag.
    --help     Use 'help [agent]' or '-- --help' after the agent name.

Examples:
  runumm start              # start router + supervisor (which starts everything)
  runumm cleanstart         # kill stale processes then start fresh
  runumm killall            # kill everything UMM-related
  runumm start sorting-database-setup # create sorting demo DB tables (run once)
  runumm start tank-database-setup    # create tank demo DB tables (run once)
  runumm --debug start sorting # start sorting demo group with debug logging
  runumm start bridge                  # start all configured bridges
  runumm start bridge-link-to-store    # start one bridge by name
  runumm stop  sorting
  runumm status
  runumm show               # show config including bridge env var status
  runumm validate
  runumm logs               # tail current log
  runumm logs list          # list all log files
  runumm logs reset         # start a fresh log file
  runumm version
  runumm help               # this help
  runumm help parser        # show parser's --help output
  runumm help supervisor    # show supervisor's --help output
  runumm start parser -- --help        # same as above
  runumm start send --trusted --shutdown --delay 30 "Scheduled maintenance"

Running a second router on the same machine:
  runumm --config umm-plant-b.conf start
  (use a separate config file with different port, gui_port, router_id)
        """)
    p.add_argument('-h', '--help', action='store_true', default=False,
                   help='Show this help message and exit')
    p.add_argument('--config', default='umm.conf',
                   help='Config file (default: umm.conf)')
    p.add_argument('--debug', action='store_true',
                   help='Pass --debug to every agent process (verbose output in logs)')
    p.add_argument('command', nargs='?', default=None,
                   choices=['start','stop','restart','status','agents',
                            'validate','show','logs','version',
                            'killall','cleanstart','help'],
                   help='Command to run')
    p.add_argument('target', nargs='?', default=None,
                   help='Group name, agent name, "all", or subcommand (e.g. logs reset)')
    args, extra_args = p.parse_known_args()

    # --help with no command: show umm_ctl help
    if args.help and not args.command:
        p.print_help()
        return

    # No command at all
    if args.command is None:
        p.print_help()
        return

    # 'help' command or --help after a command: show the agent's own --help
    if args.command == 'help' or args.help:
        _cmd_agent_help(args, p)
        return

    if extra_args and args.command not in ('start', 'cleanstart'):
        warn(f"Extra arguments {extra_args} are only used with 'start'/'cleanstart' — ignoring")

    config_path = Path(args.config)
    # If a bare filename (no directory component) is given, look for it
    # next to umm_ctl.py rather than the current working directory.
    if not config_path.is_absolute() and not config_path.parent.parts:
        config_path = Path(__file__).resolve().parent / config_path
    if not config_path.exists():
        err(f"Config file not found: {config_path}")
        info("Create a umm.conf file — see 'runumm --help'")
        sys.exit(1)

    cfg = parse_config(config_path)

    if args.command == 'validate':
        cmd_validate(cfg)
        return
    if args.command == 'show':
        cmd_show(cfg)
        return
    if args.command == 'logs':
        cmd_logs(cfg, args.target)
        return
    if args.command == 'status':
        cmd_status(cfg, args.target)
        return
    if args.command == 'agents':
        cmd_agents(cfg)
        return
    if args.command == 'version':
        cmd_version(cfg)
        return

    pm = ProcessManager(cfg, debug=args.debug)

    if args.debug:
        info(f"Debug mode: --debug will be appended to all agent commands")

    if args.command == 'start':
        cmd_start(cfg, args.target, pm, extra_args=extra_args or None)
    elif args.command == 'stop':
        cmd_stop(cfg, args.target, pm)
    elif args.command == 'restart':
        cmd_restart(cfg, args.target, pm)
    elif args.command == 'killall':
        cmd_killall(cfg)
    elif args.command == 'cleanstart':
        cmd_cleanstart(cfg, args.target, pm, extra_args=extra_args or None)


if __name__ == '__main__':
    main()