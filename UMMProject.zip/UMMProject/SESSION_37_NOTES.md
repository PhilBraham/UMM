# SESSION 37 NOTES — capability queries fixed for config-driven agents (FSM, database)

## 0. The reported bug

FSM and database agents did not respond to capability queries from the
GUI. Phil recalled this being fixed — it was, but only for the timer
(Session 33-era) and the bridge. FSM and database never received the
same treatment, and **every** FSM/database instance in umm.conf runs
with a `type` override (sorting-fsm 1055, feeder-fsm 1056, tank-fsm-0
5055, sorting-database 1008, tank-database 5008), so all of them were
deaf to targeted capability queries.

## 1. Root cause

`FSM_CAPABILITY` (fsm.py module level) and `DatabaseModule.CAPABILITY`
(class attribute) are built at **import time** with
`mtype = MT_FSM` / `MT_DATABASE` — snapshots of the defaults (5, 8).
The `type` override reassigns the module global in `__init__`, which
the version/debug/shutdown handlers pick up because they read the
global at `run()` time — but the capability descriptor kept the stale
snapshot. Consequences for an FSM at 1055:

- Mixin subscription 1 (targeted): content-match `Int == 5` — a query
  carrying `Int(1055)` matched nothing.
- Mixin subscription 2 (broadcast): callback filtered
  `target != cap.mtype (5)` → dropped.
- Mixin subscription 3 (reserved GetCapability): registered on
  `(5, 1)`, not `(1055, 1)`.
- Broadcast discovery *worked* but advertised mtype 5 — misleading.

Timer's existing fix (timer.py ~line 172):
`if MT_TIMER != MType.TIMER: cap = replace(cap, mtype=MT_TIMER)`.
Bridge passes `mtype_override=`. FSM and database had neither.

## 2. Fixes

**umm/modules/fsm.py** — `run()`: same patch as timer.
`if int(MT_FSM) != int(MType.FSM): cap = replace(FSM_CAPABILITY,
mtype=int(MT_FSM))` before `register_capability_handler`.

**umm/modules/database.py** — `run()`: same patch
(`MT_DATABASE` / `MType.DATABASE`), and now passes
`instance=self.process_name` so SortingDatabase / TankDatabase are
distinguishable in broadcast discovery (parity with FSM, which already
passed its process name).

## 3. Two further bugs found while reproducing

**umm/capability.py — `query_capability()` / `discover_agents()`
subscribed on the wrong channel.** Both helpers registered their
response subscription on the default APP channel (1), but capability
responses travel on META (4) — so the standalone helpers and the
`python3 -m umm.capability` CLI timed out against **every** agent,
healthy or not. Likely broken since the META-channel move; unnoticed
because the GUI server subscribes channel 4 explicitly (server.py
~line 390) and was the usual query path. Both now subscribe with
`channel=int(Channel.META)`. Watchdog imports `query_capability` but
does not currently call it — no other callers.

**umm/capability.py — duplicate response to targeted queries.** A
targeted query at the correct mtype fired BOTH mixin subscriptions
(the router content-match AND the broadcast callback's manual filter),
producing two identical responses. `on_query_broadcast` now returns
early on any query carrying an Int payload when the targeted
subscription is registered (i.e. always, in practice — the fallthrough
manual filter is kept only for the theoretical int_type-missing case).

## 4. Verification (live, Python router, port 5300)

Probe agent subscribed `(UMM, 52)` channel 0, FSM at `--type 1055`
(plant_cell.fsm) + database at `--type 1008` (database.conf):

- `Int(1055)` → exactly **one** response, mtype 1055. Same for
  `Int(1008)` → 1008.
- `Int(5)` / `Int(8)` → correctly nothing (no stale responders).
- Broadcast → three responses, one each: router (1), DB (1008),
  FSM (1055). No duplicates, correct mtypes.
- `python3 -m umm.capability --mtype 1055` → full descriptor
  (CLI channel fix confirmed).
- Regression: FSM/DB started **without** `type` override still answer
  at 5 / 8, instance names present.

Not exercised: C router (not involved — all fixes are client-side and
apply unchanged when agents run against it).

## 5. Open items / next session candidates

- Teaching ladder → Teacher's Manual proper (carried from S35/S36).
- Optional: C agent send_confirmed() helper (S36 §4 scope note).
- Optional: fix Appendix C paragraph styles in the Word export (S36 §3).
- Chess meta/mtype names in umm_names.conf — still open unless done
  offline.
- Docs: Vol 2/Vol 3 capability sections — worth checking whether any
  text tells the reader to query a config-driven agent's *default*
  mtype, or documents the CLI helper; both behaviours changed subtly
  (CLI now actually works; targeted queries yield one response).

## 6. Files touched this session

Modified: umm/capability.py          (helper channel fix, duplicate-response fix)
          umm/modules/fsm.py          (capability mtype patch)
          umm/modules/database.py     (capability mtype patch, instance name)
